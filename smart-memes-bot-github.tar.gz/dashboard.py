"""
Dashboard for SMART MEMES BOT.

This module provides a web interface for monitoring and controlling the bot.
"""

import os
import time
import json
import logging
import datetime
from typing import Dict, Any, List, Optional, Tuple
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, 
    flash, session, jsonify, abort
)
from flask_login import (
    LoginManager, login_user, logout_user, login_required, 
    current_user, UserMixin
)
from werkzeug.security import generate_password_hash, check_password_hash

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Import database functionality
from app import app, db
from models import User, TokenInfo, SafetyReport, TokenSnipe, ProfitRecord, WalletActivity, APIService, TokenAnalysis

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    """Load user from database."""
    return User.query.get(int(user_id))

def admin_required(f):
    """Decorator for routes that require admin access."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin access required.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Routes
@app.route('/')
def home():
    """Home page."""
    return render_template('index.html', now=datetime.datetime.now())

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = 'remember' in request.form
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user, remember=remember)
            user.last_login = datetime.datetime.utcnow()
            db.session.commit()
            
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password.', 'danger')
    
    return render_template('login.html', now=datetime.datetime.now())

@app.route('/logout')
@login_required
def logout():
    """Logout."""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard."""
    return render_template('dashboard.html', now=datetime.datetime.now())

@app.route('/api-health')
@login_required
def api_health():
    """API health dashboard."""
    return render_template('api_health.html', now=datetime.datetime.now())

@app.route('/token-analyzer')
@login_required
def ai_token_analyzer():
    """AI Token Analyzer dashboard."""
    return render_template('ai_token_analyzer.html', now=datetime.datetime.now())

@app.route('/api/health')
@login_required
def api_health_json():
    """API health data in JSON format."""
    try:
        # Get API services from database if available
        if 'db' in globals():
            api_services = APIService.query.all()
            services_data = []
            
            for service in api_services:
                services_data.append({
                    'name': service.name,
                    'url': service.url,
                    'status': service.status,
                    'response_time': service.response_time,
                    'success_count': service.success_count,
                    'failure_count': service.failure_count,
                    'last_checked': service.last_checked.isoformat() if service.last_checked else None,
                    'success_rate': round((service.success_count / (service.success_count + service.failure_count)) * 100, 1) 
                               if (service.success_count + service.failure_count) > 0 else 0
                })
        else:
            # Sample data if database is not available
            services_data = [
                {'name': 'BirdEye API', 'status': 'operational', 'response_time': 187, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:23'},
                {'name': 'Solana RPC', 'status': 'operational', 'response_time': 245, 'success_rate': 99.8, 'last_checked': '2025-04-19 11:45:22'},
                {'name': 'Ethereum RPC', 'status': 'operational', 'response_time': 312, 'success_rate': 99.7, 'last_checked': '2025-04-19 11:45:21'},
                {'name': 'Token Price API', 'status': 'operational', 'response_time': 175, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:20'},
                {'name': 'Telegram Bot API', 'status': 'operational', 'response_time': 230, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:19'},
                {'name': 'Blockchain Data API', 'status': 'operational', 'response_time': 198, 'success_rate': 99.8, 'last_checked': '2025-04-19 11:45:18'},
                {'name': 'Token Contract API', 'status': 'degraded', 'response_time': 425, 'success_rate': 97.5, 'last_checked': '2025-04-19 11:45:17'},
                {'name': 'Wallet Analysis API', 'status': 'operational', 'response_time': 210, 'success_rate': 99.7, 'last_checked': '2025-04-19 11:45:16'},
                {'name': 'Trading API', 'status': 'operational', 'response_time': 188, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:15'},
                {'name': 'OpenAI API', 'status': 'operational', 'response_time': 352, 'success_rate': 99.8, 'last_checked': '2025-04-19 11:45:14'},
                {'name': 'Mempool Monitor', 'status': 'operational', 'response_time': 165, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:13'},
                {'name': 'Token Safety API', 'status': 'operational', 'response_time': 198, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:12'}
            ]
        
        # Calculate overall statistics
        total_services = len(services_data)
        operational_services = sum(1 for service in services_data if service['status'] == 'operational')
        degraded_services = sum(1 for service in services_data if service['status'] == 'degraded')
        down_services = total_services - operational_services - degraded_services
        
        avg_response_time = sum(service['response_time'] for service in services_data) / total_services if total_services > 0 else 0
        avg_success_rate = sum(service['success_rate'] for service in services_data) / total_services if total_services > 0 else 0
        
        overall_status = 'operational' if down_services == 0 and degraded_services <= 1 else \
                         'degraded' if down_services == 0 else 'outage'
        
        return jsonify({
            'status': 'success',
            'data': {
                'overall': {
                    'status': overall_status,
                    'operational_services': operational_services,
                    'degraded_services': degraded_services,
                    'down_services': down_services,
                    'total_services': total_services,
                    'avg_response_time': round(avg_response_time, 2),
                    'avg_success_rate': round(avg_success_rate, 1)
                },
                'services': services_data
            }
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@app.route('/api/health/<service_name>')
@login_required
def api_health_service_json(service_name):
    """API health data for a specific service in JSON format."""
    try:
        # Get API service from database if available
        if 'db' in globals():
            service = APIService.query.filter_by(name=service_name).first()
            
            if service:
                service_data = {
                    'name': service.name,
                    'url': service.url,
                    'status': service.status,
                    'response_time': service.response_time,
                    'success_count': service.success_count,
                    'failure_count': service.failure_count,
                    'last_checked': service.last_checked.isoformat() if service.last_checked else None,
                    'success_rate': round((service.success_count / (service.success_count + service.failure_count)) * 100, 1) 
                               if (service.success_count + service.failure_count) > 0 else 0,
                    'settings': json.loads(service.settings) if service.settings else {}
                }
            else:
                return jsonify({
                    'status': 'error',
                    'message': f'Service {service_name} not found'
                }), 404
        else:
            # Sample data if database is not available
            sample_services = {
                'BirdEye API': {'name': 'BirdEye API', 'status': 'operational', 'response_time': 187, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:23'},
                'Solana RPC': {'name': 'Solana RPC', 'status': 'operational', 'response_time': 245, 'success_rate': 99.8, 'last_checked': '2025-04-19 11:45:22'},
                'Ethereum RPC': {'name': 'Ethereum RPC', 'status': 'operational', 'response_time': 312, 'success_rate': 99.7, 'last_checked': '2025-04-19 11:45:21'},
                'Token Price API': {'name': 'Token Price API', 'status': 'operational', 'response_time': 175, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:20'},
                'Telegram Bot API': {'name': 'Telegram Bot API', 'status': 'operational', 'response_time': 230, 'success_rate': 99.9, 'last_checked': '2025-04-19 11:45:19'}
            }
            
            if service_name in sample_services:
                service_data = sample_services[service_name]
            else:
                return jsonify({
                    'status': 'error',
                    'message': f'Service {service_name} not found'
                }), 404
        
        # Get recent history data (mock data for now)
        history_data = []
        base_response_time = service_data['response_time']
        
        # Generate 24 hours of mock history data
        for i in range(24):
            hour = (datetime.datetime.now() - datetime.timedelta(hours=23-i)).strftime('%H:00')
            variation = (((i % 5) - 2) / 10) * base_response_time  # Creates a wave pattern
            history_data.append({
                'timestamp': hour,
                'response_time': max(50, base_response_time + variation),
                'status': 'operational'
            })
        
        return jsonify({
            'status': 'success',
            'data': {
                'service': service_data,
                'history': history_data
            }
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    """404 error handler."""
    return render_template('error.html', error=e, code=404, message="Page not found"), 404

@app.errorhandler(500)
def server_error(e):
    """500 error handler."""
    return render_template('error.html', error=e, code=500, message="Server error"), 500

@app.route('/api/analyze-token')
@login_required
def analyze_token_api():
    """API endpoint to analyze a token."""
    try:
        # Get query parameters
        token_address = request.args.get('address')
        chain = request.args.get('chain', 'auto')
        
        if not token_address:
            return jsonify({
                'status': 'error',
                'message': 'Token address is required'
            }), 400
        
        # Import token analyzer
        try:
            from token_analyzer import token_analyzer
        except ImportError:
            logger.error("Could not import token_analyzer")
            return jsonify({
                'status': 'error',
                'message': 'Token analyzer module not available'
            }), 500
        
        # Check if we should be using API keys for external services
        if ('blockchain' in chain or chain == 'solana') and not os.environ.get('BIRDEYE_API_KEY'):
            logger.warning("BirdEye API key not set")
            # Check BirdEye secret
            if not os.environ.get('BIRDEYE_API_KEY'):
                return jsonify({
                    'status': 'error',
                    'message': 'BirdEye API key not set. Please set the BIRDEYE_API_KEY environment variable.'
                }), 400
        
        # Analyze token
        try:
            # Check if token analysis exists in database first
            token_analysis = None
            if 'db' in globals():
                # Import model
                from models import TokenAnalysis
                
                # Check database
                token_analysis = TokenAnalysis.query.filter_by(
                    token_address=token_address,
                    chain=chain if chain != 'auto' else '%'
                ).order_by(TokenAnalysis.updated_at.desc()).first()
                
                # Check if analysis is still fresh (less than 1 hour old)
                if token_analysis and (datetime.datetime.utcnow() - token_analysis.updated_at).total_seconds() < 3600:
                    # Convert database model to dict
                    analysis = {
                        'token_info': json.loads(token_analysis.token_info) if token_analysis.token_info else {},
                        'safety_analysis': {
                            'contract_score': token_analysis.contract_score,
                            'liquidity_score': token_analysis.liquidity_score,
                            'holder_score': token_analysis.holder_score,
                            'social_score': token_analysis.social_score,
                            'overall_score': token_analysis.overall_score,
                            'is_honeypot': token_analysis.is_honeypot,
                            'is_mintable': token_analysis.is_mintable,
                            'risk_factors': json.loads(token_analysis.risk_factors) if token_analysis.risk_factors else [],
                            'ai_analysis': token_analysis.ai_analysis
                        },
                        'risk_level': token_analysis.risk_level,
                        'recommendation': 'Consider for investment' if token_analysis.overall_score >= 60 else 'High risk investment',
                        'trading_parameters': json.loads(token_analysis.trading_parameters) if token_analysis.trading_parameters else {},
                        'timestamp': token_analysis.updated_at.isoformat()
                    }
                    
                    return jsonify({
                        'status': 'success',
                        'data': analysis,
                        'source': 'database'
                    })
            
            # If not in database or not fresh, get from API
            analysis = token_analyzer.analyze_token(token_address, chain)
            
            # Save to database if available
            if 'db' in globals() and analysis:
                try:
                    # Import model if not already imported
                    if 'TokenAnalysis' not in locals():
                        from models import TokenAnalysis
                    
                    # Create or update token analysis
                    if not token_analysis:
                        token_analysis = TokenAnalysis(
                            token_address=token_address,
                            chain=analysis['token_info']['chain'],
                            token_name=analysis['token_info']['name'],
                            token_symbol=analysis['token_info']['symbol']
                        )
                    
                    # Update fields
                    token_analysis.contract_score = analysis['safety_analysis']['contract_score']
                    token_analysis.liquidity_score = analysis['safety_analysis']['liquidity_score']
                    token_analysis.holder_score = analysis['safety_analysis']['holder_score']
                    token_analysis.social_score = analysis['safety_analysis']['social_score']
                    token_analysis.overall_score = analysis['safety_analysis']['overall_score']
                    token_analysis.is_honeypot = analysis['safety_analysis']['is_honeypot']
                    token_analysis.is_mintable = analysis['safety_analysis'].get('is_mintable', False)
                    token_analysis.risk_level = analysis['risk_level']
                    token_analysis.risk_factors = json.dumps(analysis['safety_analysis']['risk_factors'])
                    token_analysis.ai_analysis = analysis['safety_analysis'].get('ai_analysis', '')
                    token_analysis.trading_parameters = json.dumps(analysis['trading_parameters'])
                    token_analysis.token_info = json.dumps(analysis['token_info'])
                    token_analysis.updated_at = datetime.datetime.utcnow()
                    
                    # Save to database
                    db.session.add(token_analysis)
                    db.session.commit()
                    
                except Exception as e:
                    logger.error(f"Error saving token analysis to database: {e}")
                    if 'db' in locals():
                        db.session.rollback()
            
            return jsonify({
                'status': 'success',
                'data': analysis,
                'source': 'api'
            })
        
        except Exception as e:
            logger.error(f"Error analyzing token: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Error analyzing token: {str(e)}'
            }), 500
    
    except Exception as e:
        logger.error(f"Error in analyze_token_api: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)