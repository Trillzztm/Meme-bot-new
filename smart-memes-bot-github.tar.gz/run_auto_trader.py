"""
Run Auto-Trader in background
"""

import logging
import time
from threading import Thread
from auto_trade_engine import auto_trader

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("auto_trader_runner.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("AutoTraderRunner")

def run_background_trades():
    """Run auto-trader in background thread"""
    logger.info("Starting auto-trader in background...")
    trader_thread = auto_trader.run_in_background()
    
    if trader_thread:
        logger.info("Auto-trader started successfully!")
    else:
        logger.error("Failed to start auto-trader!")
    
    return trader_thread

if __name__ == "__main__":
    try:
        thread = run_background_trades()
        
        # Keep main thread alive
        logger.info("Auto-trader running. Press Ctrl+C to stop.")
        while True:
            time.sleep(10)
            
    except KeyboardInterrupt:
        logger.info("Auto-trader runner stopped by user")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")