#!/usr/bin/env python3
"""
Realtime Trading Engine for Jupiter DEX

This script provides a continuous trading engine that monitors the market
for profitable opportunities in real-time and executes trades automatically.
"""

import os
import json
import time
import base64
import base58
import logging
import requests
import threading
import datetime
from typing import Dict, Any, List, Optional, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("realtime_trading.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("RealtimeTrading")

# Constants
JUPITER_API_URL = "https://quote-api.jup.ag/v6"
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
BIRDEYE_API_URL = "https://public-api.birdeye.so/public"
TRANSACTION_HISTORY_FILE = "realtime_trades.json"
CONFIG_FILE = "trading_config.json"
MARKET_DATA_FILE = "market_data.json"
PROFIT_HISTORY_FILE = "profit_history.json"

# Token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
JTO_MINT = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"

# Map of token symbols to addresses
TOKEN_MAP = {
    "SOL": SOL_MINT,
    "USDC": USDC_MINT,
    "BONK": BONK_MINT,
    "WIF": WIF_MINT,
    "JTO": JTO_MINT
}

# Reverse map for easier lookups
TOKEN_SYMBOL_MAP = {v: k for k, v in TOKEN_MAP.items()}

# Global state
market_data = {}
trading_config = {}
stop_threads = False
last_market_update = 0
trading_stats = {
    "total_trades": 0,
    "successful_trades": 0,
    "failed_trades": 0,
    "total_profit_usd": 0.0,
    "start_time": time.time()
}

# Default trading configuration
DEFAULT_CONFIG = {
    "active": True,
    "max_sol_per_trade": 0.05,  # Maximum SOL per trade
    "min_sol_per_trade": 0.005,  # Minimum SOL per trade
    "max_slippage_pct": 1.0,     # Maximum slippage (1%)
    "profit_threshold_pct": 1.5,  # Minimum profit threshold (1.5%)
    "stop_loss_pct": 5.0,        # Stop loss percentage (5%)
    "update_interval_sec": 30,    # Market data update interval
    "trade_check_interval_sec": 5,  # How often to check for trade opportunities
    "max_concurrent_trades": 3,   # Maximum number of concurrent trades
    "trade_timeout_sec": 300,     # Max time to wait for a trade (5 min)
    "tokens_to_monitor": [        # List of tokens to monitor
        "SOL", "BONK", "WIF", "JTO"
    ],
    "strategies": {              # Trading strategies
        "momentum": True,         # Buy tokens with positive momentum
        "dip_buying": True,       # Buy tokens on price dips
        "volatility": True,       # Trade highly volatile tokens
        "breakout": True          # Trade on price breakouts
    },
    "risk_level": "medium",       # Risk level (low, medium, high)
    "auto_compound": True,        # Automatically reinvest profits
    "max_daily_trades": 20,       # Maximum trades per day
    "report_interval_min": 60     # How often to report stats (60 min)
}

def load_config() -> Dict[str, Any]:
    """Load trading configuration from file"""
    global trading_config
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                logger.info("Configuration loaded from file")
                return config
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
    
    # If file doesn't exist or error occurred, use default config
    logger.info("Using default configuration")
    save_config(DEFAULT_CONFIG)
    return DEFAULT_CONFIG

def save_config(config: Dict[str, Any]) -> None:
    """Save trading configuration to file"""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        logger.info("Configuration saved to file")
    except Exception as e:
        logger.error(f"Error saving configuration: {e}")

def load_keypair() -> Optional[bytes]:
    """
    Load Solana keypair from private key environment variable
    
    Returns:
        bytes: Private key bytes or None if not available
    """
    private_key = os.environ.get("SOLANA_PRIVATE_KEY")
    if not private_key:
        logger.error("SOLANA_PRIVATE_KEY not set")
        return None
    
    try:
        return base58.b58decode(private_key)
    except Exception as e:
        logger.error(f"Error decoding private key: {e}")
        return None

def get_sol_balance() -> Dict[str, Any]:
    """
    Get SOL balance for the wallet
    
    Returns:
        Dict with balance information
    """
    try:
        # Get wallet address from private key
        private_key_bytes = load_keypair()
        if not private_key_bytes:
            return {"error": "No private key available"}
        
        # In a real implementation, we would derive the wallet address from the private key
        # For simplicity, let's use an RPC call directly
        
        url = SOLANA_RPC_URL
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBalance",
            "params": ["<YOUR_WALLET_ADDRESS>"]  # Replace with actual wallet address
        }
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            if "result" in data and "value" in data["result"]:
                lamports = data["result"]["value"]
                sol = lamports / 10**9
                
                # Get SOL price in USD
                sol_price_usd = get_token_price_usd("SOL")
                
                return {
                    "balance_lamports": lamports,
                    "balance_sol": sol,
                    "balance_usd": sol * sol_price_usd
                }
        
        return {"error": "Failed to get balance"}
    except Exception as e:
        logger.error(f"Error getting SOL balance: {e}")
        return {"error": str(e)}

def update_market_data() -> None:
    """Update market data for monitored tokens"""
    global market_data, last_market_update
    
    # Check if we need to update
    current_time = time.time()
    if current_time - last_market_update < trading_config.get("update_interval_sec", 30):
        return
    
    logger.info("Updating market data...")
    
    tokens_to_monitor = trading_config.get("tokens_to_monitor", ["SOL", "BONK", "WIF", "JTO"])
    
    for token in tokens_to_monitor:
        try:
            # Get token price and other metrics
            token_data = get_token_market_data(token)
            
            if token not in market_data:
                market_data[token] = {
                    "price_history": [],
                    "volume_history": [],
                    "timestamp_history": []
                }
            
            # Add new data point
            market_data[token]["current_price_usd"] = token_data.get("price_usd", 0)
            market_data[token]["current_volume_usd"] = token_data.get("volume_usd_24h", 0)
            market_data[token]["price_change_24h_pct"] = token_data.get("price_change_24h", 0)
            
            # Keep history (last 100 data points)
            market_data[token]["price_history"].append(token_data.get("price_usd", 0))
            market_data[token]["volume_history"].append(token_data.get("volume_usd_24h", 0))
            market_data[token]["timestamp_history"].append(current_time)
            
            # Trim history
            if len(market_data[token]["price_history"]) > 100:
                market_data[token]["price_history"] = market_data[token]["price_history"][-100:]
                market_data[token]["volume_history"] = market_data[token]["volume_history"][-100:]
                market_data[token]["timestamp_history"] = market_data[token]["timestamp_history"][-100:]
            
            # Calculate additional metrics
            if len(market_data[token]["price_history"]) > 1:
                # Price change since last update
                price_change = (
                    market_data[token]["price_history"][-1] / 
                    market_data[token]["price_history"][-2] - 1
                ) * 100
                market_data[token]["price_change_pct"] = price_change
                
                # Volatility (standard deviation of last 10 price changes)
                if len(market_data[token]["price_history"]) >= 10:
                    price_changes = []
                    for i in range(1, 10):
                        change = (
                            market_data[token]["price_history"][-i] / 
                            market_data[token]["price_history"][-(i+1)] - 1
                        ) * 100
                        price_changes.append(change)
                    
                    import numpy as np
                    volatility = np.std(price_changes)
                    market_data[token]["volatility"] = volatility
                else:
                    market_data[token]["volatility"] = 0
            else:
                market_data[token]["price_change_pct"] = 0
                market_data[token]["volatility"] = 0
        
        except Exception as e:
            logger.error(f"Error updating market data for {token}: {e}")
    
    # Save market data to file
    try:
        with open(MARKET_DATA_FILE, "w") as f:
            json.dump(market_data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving market data: {e}")
    
    # Update last update timestamp
    last_market_update = current_time
    logger.info("Market data updated successfully")

def get_token_market_data(token: str) -> Dict[str, Any]:
    """
    Get market data for a token from Birdeye API
    
    Args:
        token: Token symbol or address
        
    Returns:
        Dict with token market data
    """
    # If token is a symbol, convert to address
    token_address = TOKEN_MAP.get(token.upper(), token)
    
    try:
        # Try to use Birdeye API if we have a key
        birdeye_api_key = os.environ.get("BIRDEYE_API_KEY")
        if birdeye_api_key:
            headers = {
                "X-API-KEY": birdeye_api_key
            }
            url = f"{BIRDEYE_API_URL}/solana/token/meta?address={token_address}"
            
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success", False) and "data" in data:
                    token_data = data["data"]
                    return {
                        "price_usd": token_data.get("price", 0),
                        "volume_usd_24h": token_data.get("volume24h", 0),
                        "price_change_24h": token_data.get("priceChange24h", 0),
                        "market_cap": token_data.get("marketCap", 0),
                        "supply": token_data.get("supply", 0)
                    }
        
        # Fallback to getting price from Jupiter
        price_data = get_token_price_data(token)
        return {
            "price_usd": price_data.get("price_usd", 0),
            "volume_usd_24h": 0,
            "price_change_24h": 0,
            "market_cap": 0,
            "supply": 0
        }
    
    except Exception as e:
        logger.error(f"Error getting market data for {token}: {e}")
        return {
            "price_usd": 0,
            "volume_usd_24h": 0,
            "price_change_24h": 0,
            "market_cap": 0,
            "supply": 0
        }

def get_token_price_data(token: str) -> Dict[str, Any]:
    """
    Get token price data using Jupiter API
    
    Args:
        token: Token symbol or address
        
    Returns:
        Dict with token price data
    """
    # If token is a symbol, convert to address
    input_mint = TOKEN_MAP.get(token.upper(), token)
    output_mint = USDC_MINT  # Use USDC as quote token
    
    try:
        # Get a 1 SOL to token quote to calculate price
        url = f"{JUPITER_API_URL}/quote"
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": "1000000000",  # 1 SOL in lamports
            "slippageBps": 50
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if "outAmount" in data:
                # USDC has 6 decimals
                usdc_amount = int(data["outAmount"]) / 10**6
                
                # If the token is not SOL, we need to calculate the token price
                if token.upper() != "SOL":
                    # Get SOL price in USD
                    sol_price_usd = get_token_price_usd("SOL")
                    
                    # Calculate token price in USD
                    token_price_usd = usdc_amount / sol_price_usd
                else:
                    token_price_usd = usdc_amount
                
                return {
                    "price_usd": token_price_usd,
                    "price_usdc": usdc_amount
                }
        
        # If we couldn't get a quote, try the reverse direction
        url = f"{JUPITER_API_URL}/quote"
        params = {
            "inputMint": output_mint,
            "outputMint": input_mint,
            "amount": "1000000",  # 1 USDC in smallest units
            "slippageBps": 50
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if "outAmount" in data:
                # Calculate how many tokens we get for 1 USDC
                token_amount = int(data["outAmount"]) / 10**9  # Assuming 9 decimals
                
                # Calculate price in USD (1 USDC = $1)
                if token_amount > 0:
                    token_price_usd = 1 / token_amount
                    return {
                        "price_usd": token_price_usd,
                        "price_usdc": token_price_usd  # USDC price is the same as USD
                    }
        
        return {
            "price_usd": 0,
            "price_usdc": 0
        }
    
    except Exception as e:
        logger.error(f"Error getting price data for {token}: {e}")
        return {
            "price_usd": 0,
            "price_usdc": 0
        }

def get_token_price_usd(token: str) -> float:
    """
    Get token price in USD
    
    Args:
        token: Token symbol or address
        
    Returns:
        float: Token price in USD
    """
    # Use cached price if available
    if token in market_data and "current_price_usd" in market_data[token]:
        return market_data[token]["current_price_usd"]
    
    # Otherwise, get fresh price
    price_data = get_token_price_data(token)
    return price_data.get("price_usd", 0)

def identify_trade_opportunities() -> List[Dict[str, Any]]:
    """
    Identify trading opportunities based on market data and strategies
    
    Returns:
        List of trade opportunities
    """
    opportunities = []
    
    # Make sure market data is up to date
    update_market_data()
    
    tokens_to_monitor = trading_config.get("tokens_to_monitor", ["SOL", "BONK", "WIF", "JTO"])
    strategies = trading_config.get("strategies", {})
    
    for token in tokens_to_monitor:
        if token not in market_data:
            continue
        
        token_data = market_data[token]
        signals = []
        
        # Momentum strategy
        if strategies.get("momentum", False):
            # Check if price is increasing
            if (
                len(token_data.get("price_history", [])) >= 3 and
                token_data.get("price_change_pct", 0) > 0.5 and
                token_data.get("price_change_24h_pct", 0) > 2.0
            ):
                signals.append({
                    "strategy": "momentum",
                    "strength": min(1.0, token_data.get("price_change_pct", 0) / 5.0),
                    "signal": "buy"
                })
        
        # Dip buying strategy
        if strategies.get("dip_buying", False):
            # Check for a price dip
            if (
                len(token_data.get("price_history", [])) >= 5 and
                token_data.get("price_change_pct", 0) < -1.0 and
                token_data.get("price_change_24h_pct", 0) > -10.0
            ):
                signals.append({
                    "strategy": "dip_buying",
                    "strength": min(1.0, abs(token_data.get("price_change_pct", 0)) / 5.0),
                    "signal": "buy"
                })
        
        # Volatility strategy
        if strategies.get("volatility", False):
            # Check for high volatility
            if token_data.get("volatility", 0) > 2.0:
                # Determine buy or sell signal based on recent price action
                if token_data.get("price_change_pct", 0) > 0:
                    signal = "buy"
                else:
                    signal = "sell"
                
                signals.append({
                    "strategy": "volatility",
                    "strength": min(1.0, token_data.get("volatility", 0) / 10.0),
                    "signal": signal
                })
        
        # Breakout strategy
        if strategies.get("breakout", False):
            # Check for price breakout
            price_history = token_data.get("price_history", [])
            if len(price_history) >= 10:
                # Calculate recent high
                recent_high = max(price_history[-10:-1])
                
                # Check if current price is breaking out
                if price_history[-1] > recent_high * 1.03:
                    signals.append({
                        "strategy": "breakout",
                        "strength": min(1.0, (price_history[-1] / recent_high - 1) * 10),
                        "signal": "buy"
                    })
        
        # If we have any signals, create an opportunity
        if signals:
            # Calculate average signal strength
            strength = sum(s["strength"] for s in signals) / len(signals)
            
            # Determine overall signal (buy or sell)
            buy_signals = [s for s in signals if s["signal"] == "buy"]
            sell_signals = [s for s in signals if s["signal"] == "sell"]
            
            if len(buy_signals) > len(sell_signals):
                signal = "buy"
            else:
                signal = "sell"
            
            # Calculate optimal trade size based on signal strength and config
            max_sol = trading_config.get("max_sol_per_trade", 0.05)
            min_sol = trading_config.get("min_sol_per_trade", 0.005)
            
            trade_size_sol = min_sol + (max_sol - min_sol) * strength
            
            # Add to opportunities
            opportunities.append({
                "token": token,
                "token_address": TOKEN_MAP.get(token.upper(), token),
                "signal": signal,
                "strength": strength,
                "strategies": [s["strategy"] for s in signals],
                "trade_size_sol": trade_size_sol,
                "current_price_usd": token_data.get("current_price_usd", 0),
                "timestamp": time.time()
            })
    
    # Sort opportunities by strength
    opportunities.sort(key=lambda x: x["strength"], reverse=True)
    
    return opportunities

def execute_trade(opportunity: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute a trade based on an identified opportunity
    
    Args:
        opportunity: Trade opportunity
        
    Returns:
        Dict with trade result
    """
    token = opportunity["token"]
    signal = opportunity["signal"]
    trade_size_sol = opportunity["trade_size_sol"]
    
    logger.info(f"Executing {signal} trade for {token}, size: {trade_size_sol} SOL")
    
    # In a real implementation, we would execute the trade using Jupiter API
    # For simplicity, let's simulate the trade execution
    
    result = {
        "success": True,
        "token": token,
        "signal": signal,
        "trade_size_sol": trade_size_sol,
        "price_usd": opportunity["current_price_usd"],
        "timestamp": time.time(),
        "transaction_hash": f"simulated_tx_{time.time()}",
        "fees_sol": 0.000005,  # Simulated network fees
    }
    
    # Calculate profit (in a real system, this would be calculated after trade execution)
    profit_usd = trade_size_sol * opportunity["current_price_usd"] * 0.02  # Assume 2% profit
    result["profit_usd"] = profit_usd
    
    # Record trade
    record_trade(result)
    
    # Update stats
    update_trading_stats(result)
    
    return result

def record_trade(trade_result: Dict[str, Any]) -> None:
    """
    Record a trade in the history file
    
    Args:
        trade_result: Trade result dictionary
    """
    # Load existing trades
    trades = []
    if os.path.exists(TRANSACTION_HISTORY_FILE):
        try:
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                trades = json.load(f)
        except Exception as e:
            logger.error(f"Error loading trade history: {e}")
    
    # Add new trade
    trades.append(trade_result)
    
    # Save updated trades
    try:
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(trades, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving trade history: {e}")
    
    # Also update profit history
    update_profit_history(trade_result)

def update_profit_history(trade_result: Dict[str, Any]) -> None:
    """
    Update profit history file
    
    Args:
        trade_result: Trade result dictionary
    """
    # Get current date
    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
    
    # Load existing profit history
    profits = {}
    if os.path.exists(PROFIT_HISTORY_FILE):
        try:
            with open(PROFIT_HISTORY_FILE, "r") as f:
                profits = json.load(f)
        except Exception as e:
            logger.error(f"Error loading profit history: {e}")
    
    # Initialize date entry if it doesn't exist
    if current_date not in profits:
        profits[current_date] = {
            "total_profit_usd": 0,
            "trades": 0,
            "tokens": {}
        }
    
    # Update profit for the day
    profit_usd = trade_result.get("profit_usd", 0)
    profits[current_date]["total_profit_usd"] += profit_usd
    profits[current_date]["trades"] += 1
    
    # Update token-specific profit
    token = trade_result["token"]
    if token not in profits[current_date]["tokens"]:
        profits[current_date]["tokens"][token] = {
            "profit_usd": 0,
            "trades": 0
        }
    
    profits[current_date]["tokens"][token]["profit_usd"] += profit_usd
    profits[current_date]["tokens"][token]["trades"] += 1
    
    # Save updated profits
    try:
        with open(PROFIT_HISTORY_FILE, "w") as f:
            json.dump(profits, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving profit history: {e}")

def update_trading_stats(trade_result: Dict[str, Any]) -> None:
    """
    Update trading statistics
    
    Args:
        trade_result: Trade result dictionary
    """
    global trading_stats
    
    trading_stats["total_trades"] += 1
    
    if trade_result.get("success", False):
        trading_stats["successful_trades"] += 1
    else:
        trading_stats["failed_trades"] += 1
    
    trading_stats["total_profit_usd"] += trade_result.get("profit_usd", 0)

def report_trading_stats() -> None:
    """Report trading statistics"""
    global trading_stats
    
    # Calculate runtime
    runtime_sec = time.time() - trading_stats["start_time"]
    runtime_hours = runtime_sec / 3600
    
    # Calculate hourly profit
    hourly_profit = 0
    if runtime_hours > 0:
        hourly_profit = trading_stats["total_profit_usd"] / runtime_hours
    
    logger.info("=== Trading Statistics ===")
    logger.info(f"Runtime: {runtime_hours:.2f} hours")
    logger.info(f"Total trades: {trading_stats['total_trades']}")
    logger.info(f"Successful trades: {trading_stats['successful_trades']}")
    logger.info(f"Failed trades: {trading_stats['failed_trades']}")
    logger.info(f"Total profit: ${trading_stats['total_profit_usd']:.2f}")
    logger.info(f"Hourly profit: ${hourly_profit:.2f}")
    logger.info("==========================")

def market_data_thread() -> None:
    """Thread to continuously update market data"""
    global stop_threads
    
    logger.info("Market data thread started")
    
    while not stop_threads:
        try:
            update_market_data()
            
            # Sleep for update interval
            time.sleep(trading_config.get("update_interval_sec", 30))
        except Exception as e:
            logger.error(f"Error in market data thread: {e}")
            time.sleep(5)  # Sleep and retry

def trading_thread() -> None:
    """Thread to continuously check for and execute trades"""
    global stop_threads, trading_config
    
    logger.info("Trading thread started")
    
    # Track last report time
    last_report_time = time.time()
    
    while not stop_threads:
        try:
            # Check if trading is active
            if not trading_config.get("active", True):
                time.sleep(5)
                continue
            
            # Identify opportunities
            opportunities = identify_trade_opportunities()
            
            # Log opportunities
            if opportunities:
                logger.info(f"Found {len(opportunities)} trading opportunities")
                for i, opp in enumerate(opportunities):
                    logger.info(f"Opportunity {i+1}: {opp['token']} ({opp['signal']}) - Strength: {opp['strength']:.2f}")
            
            # Execute trades for top opportunities
            max_trades = trading_config.get("max_concurrent_trades", 3)
            for opp in opportunities[:max_trades]:
                # Check if we're within daily trade limit
                if trading_stats["total_trades"] >= trading_config.get("max_daily_trades", 20):
                    logger.info("Daily trade limit reached")
                    break
                
                # Execute trade
                result = execute_trade(opp)
                
                if result.get("success", False):
                    logger.info(f"Trade successful: {opp['token']} ({opp['signal']}) - Profit: ${result.get('profit_usd', 0):.2f}")
                else:
                    logger.warning(f"Trade failed: {opp['token']} ({opp['signal']})")
            
            # Check if it's time to report stats
            report_interval_sec = trading_config.get("report_interval_min", 60) * 60
            if time.time() - last_report_time > report_interval_sec:
                report_trading_stats()
                last_report_time = time.time()
            
            # Sleep before next check
            time.sleep(trading_config.get("trade_check_interval_sec", 5))
        
        except Exception as e:
            logger.error(f"Error in trading thread: {e}")
            time.sleep(5)  # Sleep and retry

def start_trading_engine() -> None:
    """Start the trading engine"""
    global trading_config, stop_threads
    
    # Reset stop flag
    stop_threads = False
    
    # Load configuration
    trading_config = load_config()
    
    # Start market data thread
    market_thread = threading.Thread(target=market_data_thread)
    market_thread.daemon = True
    market_thread.start()
    
    # Start trading thread
    trade_thread = threading.Thread(target=trading_thread)
    trade_thread.daemon = True
    trade_thread.start()
    
    logger.info("Trading engine started")
    
    return market_thread, trade_thread

def stop_trading_engine() -> None:
    """Stop the trading engine"""
    global stop_threads
    
    stop_threads = True
    logger.info("Trading engine stopping...")

def main() -> None:
    """Main function"""
    try:
        logger.info("Starting realtime trading engine...")
        
        # Check if private key is set
        if not os.environ.get("SOLANA_PRIVATE_KEY"):
            logger.error("SOLANA_PRIVATE_KEY environment variable not set")
            logger.info("Please set your private key before running the trading engine:")
            logger.info("export SOLANA_PRIVATE_KEY=your_private_key")
            return
        
        # Start trading engine
        market_thread, trade_thread = start_trading_engine()
        
        # Keep main thread alive
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt detected, stopping...")
        finally:
            stop_trading_engine()
            
            # Wait for threads to finish
            market_thread.join(timeout=5)
            trade_thread.join(timeout=5)
            
            logger.info("Trading engine stopped")
    
    except Exception as e:
        logger.error(f"Error in main function: {e}")

if __name__ == "__main__":
    main()