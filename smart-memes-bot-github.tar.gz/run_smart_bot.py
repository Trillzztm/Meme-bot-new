"""
SMART MEMES BOT - Main Runner

This is the main entry point for running the SMART MEMES BOT system.
It starts both the Telegram bot and the Web Dashboard.
"""

import os
import sys
import time
import logging
import subprocess
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - MainRunner - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("smart_bot.log"),
    ]
)
logger = logging.getLogger("MainRunner")

def create_profits_file():
    """Ensure the profits file exists."""
    import json
    try:
        if not os.path.exists("profits.json"):
            with open("profits.json", "w") as f:
                json.dump({"total_profit_usd": 0, "trades": []}, f, indent=2)
            logger.info("Created profits.json file")
    except Exception as e:
        logger.error(f"Error creating profits file: {e}")

def start_bot():
    """Start the Telegram bot in a separate process."""
    try:
        logger.info("Starting Telegram bot...")
        bot_process = subprocess.Popen(
            [sys.executable, "direct_bot.py"],
            stdout=open("direct_bot.log", "a"),
            stderr=subprocess.STDOUT,
        )
        logger.info(f"Telegram bot started with PID {bot_process.pid}")
        return bot_process
    except Exception as e:
        logger.error(f"Error starting Telegram bot: {e}")
        return None

def main():
    """Start everything and keep it running."""
    try:
        logger.info("=== SMART MEMES BOT SYSTEM STARTING ===")
        
        # Ensure profits file exists
        create_profits_file()
        
        # Start the Telegram bot
        bot_process = start_bot()
        
        # Print startup message
        logger.info("""
        ====================================================
        🚀 SMART MEMES BOT SYSTEM STARTED 🚀
        
        Telegram Bot: Running ✅
        
        Send /start to the Telegram bot to begin interacting.
        All profit commands are enabled and working.
        ====================================================
        """)
        
        # Keep checking that the bot is still running
        while True:
            if bot_process and bot_process.poll() is not None:
                logger.warning(f"Bot process exited with code {bot_process.returncode}, restarting...")
                bot_process = start_bot()
            
            time.sleep(30)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
        if 'bot_process' in locals() and bot_process:
            bot_process.terminate()
        logger.info("System shutdown complete")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        if 'bot_process' in locals() and bot_process:
            bot_process.terminate()

if __name__ == "__main__":
    main()