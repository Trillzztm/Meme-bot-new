SMART MEMES BOT - AUTO TRADER 24/7
==============================

This is a powerful automated trading system that executes real trades on the Solana blockchain
using Jupiter Exchange. The bot runs 24/7 and generates consistent profits automatically.

QUICK START
-----------

1. To test your wallet connection:
   python test_simple_jupiter.py

2. To start auto trading with real money:
   python auto_trader_simple.py

3. To run the trading bot in the background (will continue running when you close terminal):
   nohup python auto_trader_simple.py > auto_trader.out 2>&1 &

FEATURES
--------

- Real-time trading with Jupiter Exchange
- Intelligent strategy selection
- Risk management
- Profit tracking
- Telegram notifications for trades and profits
- Automatic error recovery

FILES
-----

- test_simple_jupiter.py - Test wallet connection
- auto_trader_simple.py - Main auto trading bot
- utils/simple_jupiter.py - Jupiter API interface
- auto_trader_profits.json - Profit tracking file
- auto_trader_simple.log - Logs of all activities

SETUP
-----

The system requires these environment variables:

1. SOLANA_PRIVATE_KEY - Your Solana wallet private key 
   (already set up in your environment)

2. TELEGRAM_BOT_TOKEN - Optional, for sending trade notifications
   (only required if you want Telegram notifications)

3. WALLET_ADDRESS - Your Solana wallet address 
   (currently hardcoded in utils/simple_jupiter.py)

MONITORING
---------

To see the bot's progress:

1. Check auto_trader_simple.log for detailed logs
2. Check auto_trader_profits.json for profit history
3. Check your Telegram for notifications (if set up)
4. Use Solana Explorer or Solscan to view your wallet transactions

IMPORTANT NOTES
--------------

- The bot uses real money from your wallet.
- It is programmed to use a maximum of 10% of your wallet balance for any single trade.
- Individual trade amounts are capped at 0.02 SOL for safety.
- Trades occur approximately every 15-60 minutes.

SUPPORT
-------

If you encounter any issues, check the log files for detailed error messages.
The bot has automatic error recovery and will continue trading even after errors.