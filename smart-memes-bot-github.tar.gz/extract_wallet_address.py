#!/usr/bin/env python3
"""
Extract Solana Wallet Address from Private Key

This script derives and displays your wallet address from your SOLANA_PRIVATE_KEY.
"""

import os
import sys
import base58

# Get private key from environment
private_key = os.environ.get("SOLANA_PRIVATE_KEY")
if not private_key:
    print("ERROR: SOLANA_PRIVATE_KEY environment variable not found!")
    sys.exit(1)

try:
    # Decode private key from base58 to bytes
    private_key_bytes = base58.b58decode(private_key)
    print(f"Successfully decoded private key (first 4 bytes: {private_key_bytes[:4].hex()})")
    
    try:
        # Try to use solana library to derive public key
        from solana.keypair import Keypair
        keypair = Keypair.from_secret_key(private_key_bytes)
        public_key = str(keypair.public_key)
        print(f"\nYour Solana Wallet Address: {public_key}")
        print("\nAdd this to your environment variables with:")
        print(f"export WALLET_ADDRESS={public_key}")
    except ImportError:
        print("\nCouldn't import solana.keypair module.")
        print("Make sure you have the solana package installed.")
except Exception as e:
    print(f"Error processing private key: {e}")
    print("Make sure your SOLANA_PRIVATE_KEY is in the correct format.")