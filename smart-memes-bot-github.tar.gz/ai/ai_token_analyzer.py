"""
AI-Powered Token Analyzer for SMART MEMES BOT.

This module provides advanced AI analysis for cryptocurrency tokens,
generating comprehensive ratings, profit potential estimates, and
risk assessments using the OpenAI API.
"""

import os
import time
import asyncio
import logging
import json
from typing import Dict, List, Tuple, Set, Optional, Union, Any
from datetime import datetime, timedelta

# Import OpenAI integration
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    logging.warning("OpenAI library not available for token analysis")

# Try to import enhanced token safety
try:
    from utils.enhanced_token_safety import analyze_token_safety
    ENHANCED_SAFETY_AVAILABLE = True
except ImportError:
    ENHANCED_SAFETY_AVAILABLE = False
    logging.warning("Enhanced token safety not available for AI analysis")

# Try to import token info
try:
    from utils.token_info import get_token_info
    TOKEN_INFO_AVAILABLE = True
except ImportError:
    TOKEN_INFO_AVAILABLE = False
    logging.warning("Token info not available for AI analysis")

# Try to import social proof
try:
    from utils.social_proof import get_social_metrics
    SOCIAL_PROOF_AVAILABLE = True
except ImportError:
    SOCIAL_PROOF_AVAILABLE = False
    logging.warning("Social proof not available for AI analysis")

# Configure logging
logger = logging.getLogger(__name__)

# Default settings
DEFAULT_SETTINGS = {
    "cache_duration": 1800,          # Cache AI analyses for 30 minutes
    "max_cache_size": 100,           # Maximum tokens in cache
    "openai_model": "gpt-4o",        # OpenAI model to use
    "min_confidence": 0.7,           # Minimum confidence score to trust predictions
    "enable_meme_potential": True,   # Analyze meme potential
    "enable_community_analysis": True, # Analyze community sentiment
    "enable_profit_prediction": True, # Predict profit potential
    "enable_risk_assessment": True,  # Assess risk factors
    "enable_social_sentiment": True, # Analyze social media sentiment
    "openai_api_key": os.environ.get("OPENAI_API_KEY", "")
}

# AI analysis cache
_ai_analysis_cache = {}

class AITokenAnalyzer:
    """
    AI-Powered Token Analyzer using OpenAI.
    """
    
    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        """
        Initialize the AI Token Analyzer.
        
        Args:
            settings: Optional custom settings
        """
        self.settings = DEFAULT_SETTINGS.copy()
        if settings:
            self.settings.update(settings)
        
        # Initialize AI client if available
        self.client = None
        if OPENAI_AVAILABLE and self.settings["openai_api_key"]:
            self.client = OpenAI(api_key=self.settings["openai_api_key"])
        
        # Initialize cache management
        self.last_cache_cleanup = time.time()
        
        logger.info("AI Token Analyzer initialized")
    
    def _cleanup_cache(self):
        """Clean up expired cache entries."""
        global _ai_analysis_cache
        
        current_time = time.time()
        # Only cleanup periodically
        if current_time - self.last_cache_cleanup < 300:  # Once per 5 minutes at most
            return
            
        self.last_cache_cleanup = current_time
        
        # Find expired entries
        expired_keys = []
        for token_address, cache_entry in _ai_analysis_cache.items():
            if current_time - cache_entry["timestamp"] > self.settings["cache_duration"]:
                expired_keys.append(token_address)
        
        # Remove expired entries
        for key in expired_keys:
            del _ai_analysis_cache[key]
        
        # If still too large, remove oldest entries
        if len(_ai_analysis_cache) > self.settings["max_cache_size"]:
            # Sort by timestamp (oldest first)
            sorted_cache = sorted(_ai_analysis_cache.items(), key=lambda x: x[1]["timestamp"])
            # Remove oldest entries
            to_remove = len(sorted_cache) - self.settings["max_cache_size"]
            for i in range(to_remove):
                del _ai_analysis_cache[sorted_cache[i][0]]
        
        logger.debug(f"Cleaned {len(expired_keys)} expired entries from AI analysis cache")
    
    async def analyze_token(self, token_address: str, token_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Perform AI-powered token analysis.
        
        Args:
            token_address: Token address to analyze
            token_data: Optional token data to include in analysis
            
        Returns:
            Dictionary with comprehensive AI analysis
        """
        # Check cache first
        global _ai_analysis_cache
        if token_address in _ai_analysis_cache:
            cache_entry = _ai_analysis_cache[token_address]
            # Check if cache is still valid
            if time.time() - cache_entry["timestamp"] < self.settings["cache_duration"]:
                logger.debug(f"Using cached AI analysis for {token_address}")
                return cache_entry["analysis"]
        
        # Clean up cache periodically
        self._cleanup_cache()
        
        # Collect data for AI analysis
        analysis_data = await self._collect_token_data(token_address, token_data)
        
        # Check if we have data for analysis
        if not analysis_data or not analysis_data.get("token_info"):
            logger.warning(f"Insufficient data for AI analysis of {token_address}")
            return {
                "success": False,
                "error": "Insufficient token data for analysis",
                "token_address": token_address,
                "timestamp": time.time()
            }
        
        # Perform AI analysis
        ai_analysis = await self._perform_ai_analysis(token_address, analysis_data)
        
        # Add to cache
        _ai_analysis_cache[token_address] = {
            "analysis": ai_analysis,
            "timestamp": time.time()
        }
        
        return ai_analysis
    
    async def _collect_token_data(self, token_address: str, token_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Collect comprehensive token data for AI analysis.
        
        Args:
            token_address: Token address
            token_data: Optional pre-existing token data
            
        Returns:
            Dictionary with token data for analysis
        """
        analysis_data = {
            "token_address": token_address,
            "collection_timestamp": time.time()
        }
        
        # Include provided token data if available
        if token_data:
            analysis_data.update(token_data)
        
        # Get token info
        if TOKEN_INFO_AVAILABLE and not analysis_data.get("token_info"):
            try:
                token_info = await get_token_info(token_address)
                analysis_data["token_info"] = token_info
            except Exception as e:
                logger.error(f"Error getting token info: {str(e)}")
                # Continue with other data sources
        
        # Get token safety analysis
        if ENHANCED_SAFETY_AVAILABLE and not analysis_data.get("safety_analysis"):
            try:
                safety_score, safety_details = await analyze_token_safety(token_address)
                analysis_data["safety_analysis"] = {
                    "score": safety_score,
                    "details": safety_details
                }
            except Exception as e:
                logger.error(f"Error getting token safety analysis: {str(e)}")
                # Continue with other data sources
        
        # Get social proof
        if SOCIAL_PROOF_AVAILABLE and not analysis_data.get("social_metrics"):
            try:
                social_metrics = await get_social_metrics(token_address)
                analysis_data["social_metrics"] = social_metrics
            except Exception as e:
                logger.error(f"Error getting social metrics: {str(e)}")
                # Continue with other data sources
        
        return analysis_data
    
    async def _perform_ai_analysis(self, token_address: str, analysis_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform AI analysis on token data.
        
        Args:
            token_address: Token address
            analysis_data: Token data for analysis
            
        Returns:
            Dictionary with AI analysis results
        """
        if not self.client:
            logger.error("OpenAI client not available for AI analysis")
            return {
                "success": False,
                "error": "OpenAI client not available",
                "token_address": token_address,
                "timestamp": time.time()
            }
        
        try:
            # Prepare token data summary for the AI
            token_info = analysis_data.get("token_info", {})
            safety_analysis = analysis_data.get("safety_analysis", {})
            social_metrics = analysis_data.get("social_metrics", {})
            
            token_symbol = token_info.get("symbol", "UNKNOWN")
            token_name = token_info.get("name", "Unknown Token")
            
            # Create a summary of the token
            token_summary = f"""
            Token: {token_name} ({token_symbol})
            Address: {token_address}
            
            Token Info:
            - Total Supply: {token_info.get('total_supply', 'Unknown')}
            - Decimals: {token_info.get('decimals', 'Unknown')}
            - Current Price: {token_info.get('current_price', 'Unknown')}
            - Market Cap: {token_info.get('market_cap', 'Unknown')}
            - 24h Volume: {token_info.get('volume_24h', 'Unknown')}
            - Created: {token_info.get('created_at', 'Unknown')}
            
            Safety Analysis:
            - Safety Score: {safety_analysis.get('score', 'Unknown')}
            - Risk Level: {safety_analysis.get('details', {}).get('risk_level', 'Unknown')}
            """
            
            # Add critical issues if available
            critical_issues = safety_analysis.get('details', {}).get('critical_issues', [])
            if critical_issues:
                token_summary += "- Critical Issues:\n"
                for issue in critical_issues:
                    token_summary += f"  * {issue}\n"
            
            # Add social metrics if available
            if social_metrics:
                token_summary += f"""
                Social Metrics:
                - Telegram Members: {social_metrics.get('telegram_members', 'Unknown')}
                - Twitter Followers: {social_metrics.get('twitter_followers', 'Unknown')}
                - Social Score: {social_metrics.get('social_score', 'Unknown')}
                """
            
            # Construct the prompt for the AI
            prompt = f"""
            Your task is to analyze a cryptocurrency token and provide a comprehensive evaluation.
            
            TOKEN INFORMATION:
            {token_summary}
            
            Please provide a detailed analysis in JSON format covering the following aspects:
            
            1. Overall Rating (0-100)
            2. Investment Potential (Low, Medium, High)
            3. Profit Potential (percentage range and timeframe)
            4. Risk Assessment (Low, Medium, High, Extreme)
            5. Strengths (list at least 3 if possible)
            6. Concerns (list at least 3 if possible)
            7. Meme Potential (0-100, only if it appears to be a meme token)
            8. Community Sentiment (Negative, Neutral, Positive, Very Positive)
            9. Recommendation (Strong Sell, Sell, Hold, Buy, Strong Buy)
            10. Trading Strategy (brief description of recommended approach)
            11. Confidence Score (0-1, how confident you are in this analysis)
            
            Analyze all the information provided and deliver insights that would help a trader make informed decisions.
            
            Response must be in the following JSON format:
            {{
                "overall_rating": 70,
                "investment_potential": "Medium",
                "profit_potential": {{
                    "min_percentage": 20,
                    "max_percentage": 150,
                    "timeframe_days": 30
                }},
                "risk_assessment": "Medium",
                "strengths": ["strength1", "strength2", "strength3"],
                "concerns": ["concern1", "concern2", "concern3"],
                "meme_potential": 80,
                "community_sentiment": "Positive",
                "recommendation": "Buy",
                "trading_strategy": "Brief description of strategy",
                "confidence_score": 0.85
            }}
            """
            
            # Call the OpenAI API
            logger.info(f"Calling OpenAI API for token analysis: {token_symbol} ({token_address})")
            
            response = self.client.chat.completions.create(
                model=self.settings["openai_model"],
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            
            # Parse the response
            ai_response = response.choices[0].message.content
            ai_analysis = json.loads(ai_response)
            
            # Add metadata
            result = {
                "success": True,
                "token_address": token_address,
                "token_symbol": token_symbol,
                "token_name": token_name,
                "timestamp": time.time(),
                "ai_model": self.settings["openai_model"],
                "analysis": ai_analysis
            }
            
            logger.info(f"Completed AI analysis for {token_symbol}: Rating {ai_analysis.get('overall_rating', 'Unknown')}, " +
                       f"Recommendation: {ai_analysis.get('recommendation', 'Unknown')}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error performing AI analysis: {str(e)}")
            return {
                "success": False,
                "error": f"Error performing AI analysis: {str(e)}",
                "token_address": token_address,
                "timestamp": time.time()
            }
    
    async def get_profit_potential(self, token_address: str) -> Dict[str, Any]:
        """
        Get AI-estimated profit potential for a token.
        
        Args:
            token_address: Token address
            
        Returns:
            Dictionary with profit potential assessment
        """
        analysis = await self.analyze_token(token_address)
        
        if not analysis.get("success", False):
            return {
                "success": False,
                "error": analysis.get("error", "Analysis failed"),
                "token_address": token_address
            }
        
        ai_analysis = analysis.get("analysis", {})
        confidence = ai_analysis.get("confidence_score", 0)
        
        # Only return results if confidence meets minimum threshold
        if confidence < self.settings["min_confidence"]:
            return {
                "success": False,
                "error": f"Low confidence analysis ({confidence})",
                "token_address": token_address,
                "confidence": confidence
            }
        
        profit_potential = ai_analysis.get("profit_potential", {})
        
        return {
            "success": True,
            "token_address": token_address,
            "token_symbol": analysis.get("token_symbol"),
            "min_profit": profit_potential.get("min_percentage", 0),
            "max_profit": profit_potential.get("max_percentage", 0),
            "timeframe_days": profit_potential.get("timeframe_days", 0),
            "recommendation": ai_analysis.get("recommendation", "Hold"),
            "confidence": confidence
        }
    
    async def get_risk_assessment(self, token_address: str) -> Dict[str, Any]:
        """
        Get AI-generated risk assessment for a token.
        
        Args:
            token_address: Token address
            
        Returns:
            Dictionary with risk assessment
        """
        analysis = await self.analyze_token(token_address)
        
        if not analysis.get("success", False):
            return {
                "success": False,
                "error": analysis.get("error", "Analysis failed"),
                "token_address": token_address
            }
        
        ai_analysis = analysis.get("analysis", {})
        confidence = ai_analysis.get("confidence_score", 0)
        
        # Only return results if confidence meets minimum threshold
        if confidence < self.settings["min_confidence"]:
            return {
                "success": False,
                "error": f"Low confidence analysis ({confidence})",
                "token_address": token_address,
                "confidence": confidence
            }
        
        return {
            "success": True,
            "token_address": token_address,
            "token_symbol": analysis.get("token_symbol"),
            "risk_assessment": ai_analysis.get("risk_assessment", "Unknown"),
            "concerns": ai_analysis.get("concerns", []),
            "overall_rating": ai_analysis.get("overall_rating", 0),
            "confidence": confidence
        }
    
    async def get_trading_strategy(self, token_address: str) -> Dict[str, Any]:
        """
        Get AI-recommended trading strategy for a token.
        
        Args:
            token_address: Token address
            
        Returns:
            Dictionary with recommended trading strategy
        """
        analysis = await self.analyze_token(token_address)
        
        if not analysis.get("success", False):
            return {
                "success": False,
                "error": analysis.get("error", "Analysis failed"),
                "token_address": token_address
            }
        
        ai_analysis = analysis.get("analysis", {})
        confidence = ai_analysis.get("confidence_score", 0)
        
        # Only return results if confidence meets minimum threshold
        if confidence < self.settings["min_confidence"]:
            return {
                "success": False,
                "error": f"Low confidence analysis ({confidence})",
                "token_address": token_address,
                "confidence": confidence
            }
        
        return {
            "success": True,
            "token_address": token_address,
            "token_symbol": analysis.get("token_symbol"),
            "recommendation": ai_analysis.get("recommendation", "Hold"),
            "trading_strategy": ai_analysis.get("trading_strategy", ""),
            "investment_potential": ai_analysis.get("investment_potential", "Medium"),
            "confidence": confidence
        }

# Singleton instance
_ai_analyzer = None

async def get_ai_analyzer(settings: Optional[Dict[str, Any]] = None) -> AITokenAnalyzer:
    """
    Get the AI Token Analyzer instance.
    
    Args:
        settings: Optional custom settings
        
    Returns:
        AITokenAnalyzer instance
    """
    global _ai_analyzer
    
    if _ai_analyzer is None:
        _ai_analyzer = AITokenAnalyzer(settings)
    elif settings:
        _ai_analyzer.settings.update(settings)
    
    return _ai_analyzer

# Primary analysis function for external use
async def analyze_token(token_address: str, token_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Analyze token using AI.
    
    Args:
        token_address: Token address to analyze
        token_data: Optional token data to include in analysis
        
    Returns:
        Dictionary with AI analysis results
    """
    analyzer = await get_ai_analyzer()
    return await analyzer.analyze_token(token_address, token_data)

async def get_profit_potential(token_address: str) -> Dict[str, Any]:
    """
    Get AI-estimated profit potential for a token.
    
    Args:
        token_address: Token address
        
    Returns:
        Dictionary with profit potential assessment
    """
    analyzer = await get_ai_analyzer()
    return await analyzer.get_profit_potential(token_address)

async def get_risk_assessment(token_address: str) -> Dict[str, Any]:
    """
    Get AI-generated risk assessment for a token.
    
    Args:
        token_address: Token address
        
    Returns:
        Dictionary with risk assessment
    """
    analyzer = await get_ai_analyzer()
    return await analyzer.get_risk_assessment(token_address)

async def get_trading_strategy(token_address: str) -> Dict[str, Any]:
    """
    Get AI-recommended trading strategy for a token.
    
    Args:
        token_address: Token address
        
    Returns:
        Dictionary with recommended trading strategy
    """
    analyzer = await get_ai_analyzer()
    return await analyzer.get_trading_strategy(token_address)

# Example usage
async def test_ai_token_analyzer():
    """
    Test the AI token analyzer functionality.
    """
    logger.info("Testing AI Token Analyzer")
    
    # Check if OpenAI API key is available
    if not os.environ.get("OPENAI_API_KEY"):
        logger.error("OpenAI API key not found in environment variables")
        return
    
    # Initialize analyzer
    analyzer = await get_ai_analyzer()
    
    # Test with example token
    token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC on Solana (for testing)
    
    # Create test token data (normally this would come from actual API calls)
    token_data = {
        "token_info": {
            "symbol": "USDC",
            "name": "USD Coin",
            "total_supply": "5000000000",
            "decimals": 6,
            "current_price": 1.0,
            "market_cap": 45000000000,
            "volume_24h": 2500000000,
            "created_at": "2020-02-15"
        },
        "safety_analysis": {
            "score": 0.95,
            "details": {
                "risk_level": "low",
                "critical_issues": []
            }
        },
        "social_metrics": {
            "telegram_members": 15000,
            "twitter_followers": 250000,
            "social_score": 0.85
        }
    }
    
    logger.info(f"Analyzing token: {token_address}")
    
    try:
        # Perform analysis
        analysis = await analyzer.analyze_token(token_address, token_data)
        
        if analysis.get("success", False):
            ai_analysis = analysis.get("analysis", {})
            logger.info(f"Analysis successful!")
            logger.info(f"Overall Rating: {ai_analysis.get('overall_rating')}")
            logger.info(f"Recommendation: {ai_analysis.get('recommendation')}")
            logger.info(f"Risk Assessment: {ai_analysis.get('risk_assessment')}")
            
            # Get profit potential
            profit = await analyzer.get_profit_potential(token_address)
            logger.info(f"Profit Potential: {profit.get('min_profit')}% to {profit.get('max_profit')}% in {profit.get('timeframe_days')} days")
            
            # Get trading strategy
            strategy = await analyzer.get_trading_strategy(token_address)
            logger.info(f"Trading Strategy: {strategy.get('trading_strategy')}")
        else:
            logger.error(f"Analysis failed: {analysis.get('error')}")
    
    except Exception as e:
        logger.error(f"Error testing AI analyzer: {str(e)}")
    
    logger.info("AI Token Analyzer test completed")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_ai_token_analyzer())