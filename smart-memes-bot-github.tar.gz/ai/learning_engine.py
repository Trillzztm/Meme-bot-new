"""
Continuous Learning Infrastructure for SMART MEMES BOT.

This module implements a comprehensive learning system that:
1. Records analysis results with source data
2. Creates datasets for algorithm improvement
3. Builds historical records for pattern detection
4. Supports ongoing optimization of trading signals

The system collects data from all bot components to continuously
improve performance over time through pattern analysis and adaptation.
"""

import os
import json
import logging
import time
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set, Union
from dataclasses import dataclass
import sqlite3
import pickle
import aiohttp
import numpy as np
from datetime import datetime, timedelta

# Configure logger
logger = logging.getLogger(__name__)

# Constants
DATA_DIR = "data"
LEARNING_DIR = os.path.join(DATA_DIR, "learning")
MODELS_DIR = os.path.join(LEARNING_DIR, "models")
DATASETS_DIR = os.path.join(LEARNING_DIR, "datasets")

# Ensure directories exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(DATASETS_DIR, exist_ok=True)


@dataclass
class LearningRecord:
    """Data class to hold a learning record."""
    record_id: str
    record_type: str  # "token_analysis", "trade_result", "group_activity", "wallet_activity", etc.
    timestamp: float
    data: Dict[str, Any]
    features: Dict[str, Any]
    outcome: Optional[Dict[str, Any]] = None
    is_labeled: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert record to dictionary for storage."""
        return {
            "record_id": self.record_id,
            "record_type": self.record_type,
            "timestamp": self.timestamp,
            "data": self.data,
            "features": self.features,
            "outcome": self.outcome,
            "is_labeled": self.is_labeled
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LearningRecord':
        """Create record from dictionary."""
        return cls(
            record_id=data["record_id"],
            record_type=data["record_type"],
            timestamp=data["timestamp"],
            data=data["data"],
            features=data["features"],
            outcome=data["outcome"],
            is_labeled=data["is_labeled"]
        )


class DataCollector:
    """Class to collect and store learning data."""
    
    def __init__(self):
        """Initialize the data collector."""
        self.conn = self._create_connection()
        self._create_tables()
        self.logger = logging.getLogger(__name__ + ".DataCollector")
        self.logger.info("Data collector initialized")
    
    def _create_connection(self) -> sqlite3.Connection:
        """Create a database connection."""
        db_path = os.path.join(LEARNING_DIR, "learning_data.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _create_tables(self) -> None:
        """Create the necessary database tables."""
        cursor = self.conn.cursor()
        
        # Main records table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS learning_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id TEXT UNIQUE,
            record_type TEXT,
            timestamp REAL,
            data TEXT,
            features TEXT,
            outcome TEXT,
            is_labeled INTEGER
        )
        ''')
        
        # Table for token analysis records
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS token_analysis_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_address TEXT,
            record_id TEXT,
            timestamp REAL,
            social_proof_score REAL,
            safety_score REAL,
            liquidity_score REAL,
            combined_score REAL,
            FOREIGN KEY (record_id) REFERENCES learning_records (record_id)
        )
        ''')
        
        # Table for trade result records
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS trade_result_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_address TEXT,
            record_id TEXT,
            timestamp REAL,
            entry_price REAL,
            exit_price REAL,
            profit_percent REAL,
            was_successful INTEGER,
            FOREIGN KEY (record_id) REFERENCES learning_records (record_id)
        )
        ''')
        
        # Table for group activity records
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS group_activity_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id TEXT,
            record_id TEXT,
            timestamp REAL,
            mentions_count INTEGER,
            average_score REAL,
            token_count INTEGER,
            FOREIGN KEY (record_id) REFERENCES learning_records (record_id)
        )
        ''')
        
        self.conn.commit()
    
    def save_record(self, record: LearningRecord) -> bool:
        """
        Save a learning record to the database.
        
        Args:
            record: The learning record to save
            
        Returns:
            True if successful, False otherwise
        """
        try:
            cursor = self.conn.cursor()
            
            # Insert into main records table
            cursor.execute('''
            INSERT OR REPLACE INTO learning_records
            (record_id, record_type, timestamp, data, features, outcome, is_labeled)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                record.record_id,
                record.record_type,
                record.timestamp,
                json.dumps(record.data),
                json.dumps(record.features),
                json.dumps(record.outcome) if record.outcome else None,
                1 if record.is_labeled else 0
            ))
            
            # Insert into specialized tables based on record type
            if record.record_type == "token_analysis":
                cursor.execute('''
                INSERT OR REPLACE INTO token_analysis_records
                (token_address, record_id, timestamp, social_proof_score, safety_score, liquidity_score, combined_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    record.data.get("token_address"),
                    record.record_id,
                    record.timestamp,
                    record.features.get("social_proof_score"),
                    record.features.get("safety_score"),
                    record.features.get("liquidity_score"),
                    record.features.get("combined_score")
                ))
            
            elif record.record_type == "trade_result":
                cursor.execute('''
                INSERT OR REPLACE INTO trade_result_records
                (token_address, record_id, timestamp, entry_price, exit_price, profit_percent, was_successful)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    record.data.get("token_address"),
                    record.record_id,
                    record.timestamp,
                    record.features.get("entry_price"),
                    record.features.get("exit_price"),
                    record.features.get("profit_percent"),
                    1 if record.features.get("was_successful") else 0
                ))
            
            elif record.record_type == "group_activity":
                cursor.execute('''
                INSERT OR REPLACE INTO group_activity_records
                (group_id, record_id, timestamp, mentions_count, average_score, token_count)
                VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    record.data.get("group_id"),
                    record.record_id,
                    record.timestamp,
                    record.features.get("mentions_count"),
                    record.features.get("average_score"),
                    record.features.get("token_count")
                ))
            
            self.conn.commit()
            return True
        
        except Exception as e:
            self.logger.error(f"Error saving record: {e}")
            return False
    
    def get_record(self, record_id: str) -> Optional[LearningRecord]:
        """
        Get a learning record by ID.
        
        Args:
            record_id: The record ID to retrieve
            
        Returns:
            LearningRecord if found, None otherwise
        """
        try:
            cursor = self.conn.cursor()
            
            cursor.execute('''
            SELECT * FROM learning_records WHERE record_id = ?
            ''', (record_id,))
            
            row = cursor.fetchone()
            
            if not row:
                return None
            
            record_dict = {
                "record_id": row["record_id"],
                "record_type": row["record_type"],
                "timestamp": row["timestamp"],
                "data": json.loads(row["data"]) if row["data"] else {},
                "features": json.loads(row["features"]) if row["features"] else {},
                "outcome": json.loads(row["outcome"]) if row["outcome"] else None,
                "is_labeled": bool(row["is_labeled"])
            }
            
            return LearningRecord.from_dict(record_dict)
        
        except Exception as e:
            self.logger.error(f"Error getting record: {e}")
            return None
    
    def get_records_by_type(self, record_type: str, limit: int = 100) -> List[LearningRecord]:
        """
        Get learning records by type.
        
        Args:
            record_type: The record type to retrieve
            limit: Maximum number of records to retrieve
            
        Returns:
            List of LearningRecord objects
        """
        try:
            cursor = self.conn.cursor()
            
            cursor.execute('''
            SELECT * FROM learning_records 
            WHERE record_type = ? 
            ORDER BY timestamp DESC 
            LIMIT ?
            ''', (record_type, limit))
            
            rows = cursor.fetchall()
            
            records = []
            for row in rows:
                record_dict = {
                    "record_id": row["record_id"],
                    "record_type": row["record_type"],
                    "timestamp": row["timestamp"],
                    "data": json.loads(row["data"]) if row["data"] else {},
                    "features": json.loads(row["features"]) if row["features"] else {},
                    "outcome": json.loads(row["outcome"]) if row["outcome"] else None,
                    "is_labeled": bool(row["is_labeled"])
                }
                
                records.append(LearningRecord.from_dict(record_dict))
            
            return records
        
        except Exception as e:
            self.logger.error(f"Error getting records by type: {e}")
            return []
    
    def get_token_analysis_records(self, token_address: str) -> List[LearningRecord]:
        """
        Get token analysis records for a specific token.
        
        Args:
            token_address: The token address to retrieve records for
            
        Returns:
            List of LearningRecord objects
        """
        try:
            cursor = self.conn.cursor()
            
            cursor.execute('''
            SELECT lr.* FROM learning_records lr
            JOIN token_analysis_records tar ON lr.record_id = tar.record_id
            WHERE tar.token_address = ?
            ORDER BY lr.timestamp DESC
            ''', (token_address,))
            
            rows = cursor.fetchall()
            
            records = []
            for row in rows:
                record_dict = {
                    "record_id": row["record_id"],
                    "record_type": row["record_type"],
                    "timestamp": row["timestamp"],
                    "data": json.loads(row["data"]) if row["data"] else {},
                    "features": json.loads(row["features"]) if row["features"] else {},
                    "outcome": json.loads(row["outcome"]) if row["outcome"] else None,
                    "is_labeled": bool(row["is_labeled"])
                }
                
                records.append(LearningRecord.from_dict(record_dict))
            
            return records
        
        except Exception as e:
            self.logger.error(f"Error getting token analysis records: {e}")
            return []
    
    def update_record_outcome(self, record_id: str, outcome: Dict[str, Any]) -> bool:
        """
        Update the outcome of a learning record.
        
        Args:
            record_id: The record ID to update
            outcome: The outcome to set
            
        Returns:
            True if successful, False otherwise
        """
        try:
            cursor = self.conn.cursor()
            
            cursor.execute('''
            UPDATE learning_records 
            SET outcome = ?, is_labeled = 1
            WHERE record_id = ?
            ''', (json.dumps(outcome), record_id))
            
            self.conn.commit()
            return cursor.rowcount > 0
        
        except Exception as e:
            self.logger.error(f"Error updating record outcome: {e}")
            return False
    
    def close(self) -> None:
        """Close the database connection."""
        if self.conn:
            self.conn.close()


class LearningEngine:
    """Class to manage learning and model training."""
    
    def __init__(self):
        """Initialize the learning engine."""
        self.data_collector = DataCollector()
        self.models = {}
        self.logger = logging.getLogger(__name__ + ".LearningEngine")
        self.logger.info("Learning engine initialized")
    
    async def record_token_analysis(
        self,
        token_address: str,
        social_proof_score: float,
        safety_score: float,
        liquidity_score: float,
        combined_score: float,
        risk_level: str,
        additional_data: Dict[str, Any] = None
    ) -> str:
        """
        Record a token analysis for learning.
        
        Args:
            token_address: The token address
            social_proof_score: Social proof score (0-10)
            safety_score: Safety score (0-10)
            liquidity_score: Liquidity score (0-10)
            combined_score: Combined score (0-10)
            risk_level: Risk level category
            additional_data: Any additional data to include
            
        Returns:
            Record ID if successful, empty string otherwise
        """
        try:
            # Create a unique record ID
            record_id = f"token_analysis_{token_address}_{int(time.time())}"
            
            # Prepare data and features
            data = {
                "token_address": token_address,
                "risk_level": risk_level
            }
            
            if additional_data:
                data.update(additional_data)
            
            features = {
                "social_proof_score": social_proof_score,
                "safety_score": safety_score,
                "liquidity_score": liquidity_score,
                "combined_score": combined_score
            }
            
            # Create record
            record = LearningRecord(
                record_id=record_id,
                record_type="token_analysis",
                timestamp=time.time(),
                data=data,
                features=features
            )
            
            # Save record
            success = self.data_collector.save_record(record)
            
            if success:
                self.logger.info(f"Recorded token analysis for {token_address}")
                return record_id
            else:
                self.logger.error(f"Failed to record token analysis for {token_address}")
                return ""
        
        except Exception as e:
            self.logger.error(f"Error recording token analysis: {e}")
            return ""
    
    async def record_trade_result(
        self,
        token_address: str,
        entry_price: float,
        exit_price: float,
        profit_percent: float,
        was_successful: bool,
        source_type: str,
        source_id: str,
        additional_data: Dict[str, Any] = None
    ) -> str:
        """
        Record a trade result for learning.
        
        Args:
            token_address: The token address
            entry_price: Entry price
            exit_price: Exit price
            profit_percent: Profit percentage
            was_successful: Whether the trade was successful
            source_type: Source type (group, wallet, twitter)
            source_id: Source identifier
            additional_data: Any additional data to include
            
        Returns:
            Record ID if successful, empty string otherwise
        """
        try:
            # Create a unique record ID
            record_id = f"trade_result_{token_address}_{int(time.time())}"
            
            # Prepare data and features
            data = {
                "token_address": token_address,
                "source_type": source_type,
                "source_id": source_id
            }
            
            if additional_data:
                data.update(additional_data)
            
            features = {
                "entry_price": entry_price,
                "exit_price": exit_price,
                "profit_percent": profit_percent,
                "was_successful": was_successful
            }
            
            # Create record
            record = LearningRecord(
                record_id=record_id,
                record_type="trade_result",
                timestamp=time.time(),
                data=data,
                features=features
            )
            
            # Save record
            success = self.data_collector.save_record(record)
            
            if success:
                self.logger.info(f"Recorded trade result for {token_address}: {profit_percent:+.2f}%")
                
                # Also update any related token analysis records with this outcome
                await self._update_token_analysis_outcomes(token_address, profit_percent, was_successful)
                
                return record_id
            else:
                self.logger.error(f"Failed to record trade result for {token_address}")
                return ""
        
        except Exception as e:
            self.logger.error(f"Error recording trade result: {e}")
            return ""
    
    async def record_group_activity(
        self,
        group_id: str,
        group_name: str,
        mentions_count: int,
        average_score: float,
        token_count: int,
        additional_data: Dict[str, Any] = None
    ) -> str:
        """
        Record group activity for learning.
        
        Args:
            group_id: The group ID
            group_name: The group name
            mentions_count: Number of token mentions
            average_score: Average token mention score
            token_count: Number of unique tokens mentioned
            additional_data: Any additional data to include
            
        Returns:
            Record ID if successful, empty string otherwise
        """
        try:
            # Create a unique record ID
            record_id = f"group_activity_{group_id}_{int(time.time())}"
            
            # Prepare data and features
            data = {
                "group_id": group_id,
                "group_name": group_name
            }
            
            if additional_data:
                data.update(additional_data)
            
            features = {
                "mentions_count": mentions_count,
                "average_score": average_score,
                "token_count": token_count
            }
            
            # Create record
            record = LearningRecord(
                record_id=record_id,
                record_type="group_activity",
                timestamp=time.time(),
                data=data,
                features=features
            )
            
            # Save record
            success = self.data_collector.save_record(record)
            
            if success:
                self.logger.info(f"Recorded group activity for {group_id}")
                return record_id
            else:
                self.logger.error(f"Failed to record group activity for {group_id}")
                return ""
        
        except Exception as e:
            self.logger.error(f"Error recording group activity: {e}")
            return ""
    
    async def record_wallet_activity(
        self,
        wallet_address: str,
        transaction_count: int,
        token_count: int,
        total_volume: float,
        profit_trades: int,
        loss_trades: int,
        additional_data: Dict[str, Any] = None
    ) -> str:
        """
        Record wallet activity for learning.
        
        Args:
            wallet_address: The wallet address
            transaction_count: Number of transactions
            token_count: Number of unique tokens traded
            total_volume: Total volume traded
            profit_trades: Number of profitable trades
            loss_trades: Number of loss-making trades
            additional_data: Any additional data to include
            
        Returns:
            Record ID if successful, empty string otherwise
        """
        try:
            # Create a unique record ID
            record_id = f"wallet_activity_{wallet_address}_{int(time.time())}"
            
            # Prepare data and features
            data = {
                "wallet_address": wallet_address
            }
            
            if additional_data:
                data.update(additional_data)
            
            features = {
                "transaction_count": transaction_count,
                "token_count": token_count,
                "total_volume": total_volume,
                "profit_trades": profit_trades,
                "loss_trades": loss_trades,
                "win_rate": profit_trades / (profit_trades + loss_trades) if (profit_trades + loss_trades) > 0 else 0
            }
            
            # Create record
            record = LearningRecord(
                record_id=record_id,
                record_type="wallet_activity",
                timestamp=time.time(),
                data=data,
                features=features
            )
            
            # Save record
            success = self.data_collector.save_record(record)
            
            if success:
                self.logger.info(f"Recorded wallet activity for {wallet_address}")
                return record_id
            else:
                self.logger.error(f"Failed to record wallet activity for {wallet_address}")
                return ""
        
        except Exception as e:
            self.logger.error(f"Error recording wallet activity: {e}")
            return ""
    
    async def _update_token_analysis_outcomes(
        self,
        token_address: str,
        profit_percent: float,
        was_successful: bool
    ) -> None:
        """
        Update token analysis records with trade outcomes.
        
        Args:
            token_address: The token address
            profit_percent: Profit percentage
            was_successful: Whether the trade was successful
        """
        try:
            # Get token analysis records for this token
            records = self.data_collector.get_token_analysis_records(token_address)
            
            # Update each record with the outcome
            for record in records:
                if not record.is_labeled:
                    outcome = {
                        "profit_percent": profit_percent,
                        "was_successful": was_successful,
                        "outcome_time": time.time()
                    }
                    
                    self.data_collector.update_record_outcome(record.record_id, outcome)
                    self.logger.debug(f"Updated outcome for record {record.record_id}")
        
        except Exception as e:
            self.logger.error(f"Error updating token analysis outcomes: {e}")
    
    async def create_training_dataset(
        self,
        record_type: str,
        min_samples: int = 50,
        save_to_file: bool = True
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """
        Create a training dataset from learning records.
        
        Args:
            record_type: The record type to use
            min_samples: Minimum number of samples required
            save_to_file: Whether to save the dataset to a file
            
        Returns:
            Tuple of (features, labels) arrays if successful, (None, None) otherwise
        """
        try:
            # Get labeled records of the specified type
            cursor = self.data_collector.conn.cursor()
            
            query = f'''
            SELECT * FROM learning_records 
            WHERE record_type = ? AND is_labeled = 1
            ORDER BY timestamp DESC
            '''
            
            cursor.execute(query, (record_type,))
            rows = cursor.fetchall()
            
            if len(rows) < min_samples:
                self.logger.warning(f"Not enough labeled samples for {record_type} ({len(rows)}/{min_samples})")
                return None, None
            
            # Extract features and labels
            X = []
            y = []
            
            for row in rows:
                features = json.loads(row["features"])
                outcome = json.loads(row["outcome"])
                
                if not features or not outcome:
                    continue
                
                # For token analysis, predict profitability
                if record_type == "token_analysis":
                    # Extract key features
                    feature_vector = [
                        features.get("social_proof_score", 0),
                        features.get("safety_score", 0),
                        features.get("liquidity_score", 0),
                        features.get("combined_score", 0)
                    ]
                    
                    # Extract label (profit)
                    profit_percent = outcome.get("profit_percent", 0)
                    was_successful = outcome.get("was_successful", False)
                    
                    # Skip records with missing data
                    if None in feature_vector:
                        continue
                    
                    X.append(feature_vector)
                    y.append(profit_percent)
                
                # For other record types, define feature extraction and labels accordingly
                # ...
            
            if len(X) < min_samples:
                self.logger.warning(f"Not enough usable samples for {record_type} ({len(X)}/{min_samples})")
                return None, None
            
            # Convert to numpy arrays
            X_array = np.array(X, dtype=np.float32)
            y_array = np.array(y, dtype=np.float32)
            
            # Save dataset if requested
            if save_to_file:
                dataset_path = os.path.join(DATASETS_DIR, f"{record_type}_dataset.npz")
                np.savez(dataset_path, X=X_array, y=y_array)
                self.logger.info(f"Saved dataset to {dataset_path}")
            
            return X_array, y_array
        
        except Exception as e:
            self.logger.error(f"Error creating training dataset: {e}")
            return None, None
    
    async def train_model(
        self,
        model_type: str,
        record_type: str,
        min_samples: int = 50,
        save_model: bool = True
    ) -> bool:
        """
        Train a machine learning model.
        
        Args:
            model_type: Type of model to train
            record_type: Record type to use for training
            min_samples: Minimum number of samples required
            save_model: Whether to save the model to a file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create dataset
            X, y = await self.create_training_dataset(record_type, min_samples, save_to_file=True)
            
            if X is None or y is None:
                self.logger.warning(f"Could not create dataset for {model_type}_{record_type}")
                return False
            
            # For simplicity, just create a dummy model that predicts the mean
            # In a real implementation, this would use scikit-learn or another ML library
            
            # Mean predictor model
            class MeanPredictor:
                def __init__(self):
                    self.mean = 0.0
                
                def fit(self, X, y):
                    self.mean = np.mean(y)
                    return self
                
                def predict(self, X):
                    return np.ones(len(X)) * self.mean
            
            # Train the model
            model = MeanPredictor().fit(X, y)
            
            # Save the model in memory
            model_key = f"{model_type}_{record_type}"
            self.models[model_key] = model
            
            # Save the model to a file if requested
            if save_model:
                model_path = os.path.join(MODELS_DIR, f"{model_key}.pkl")
                with open(model_path, 'wb') as f:
                    pickle.dump(model, f)
                self.logger.info(f"Saved model to {model_path}")
            
            self.logger.info(f"Trained {model_type} model for {record_type} records")
            return True
        
        except Exception as e:
            self.logger.error(f"Error training model: {e}")
            return False
    
    async def predict(
        self,
        model_type: str,
        record_type: str,
        features: Dict[str, Any]
    ) -> Optional[float]:
        """
        Make a prediction using a trained model.
        
        Args:
            model_type: Type of model to use
            record_type: Record type the model was trained on
            features: Features to use for prediction
            
        Returns:
            Prediction if successful, None otherwise
        """
        try:
            model_key = f"{model_type}_{record_type}"
            
            # Check if model is loaded in memory
            if model_key not in self.models:
                # Try to load from file
                model_path = os.path.join(MODELS_DIR, f"{model_key}.pkl")
                if os.path.exists(model_path):
                    with open(model_path, 'rb') as f:
                        self.models[model_key] = pickle.load(f)
                else:
                    self.logger.warning(f"Model {model_key} not found")
                    return None
            
            # Get the model
            model = self.models[model_key]
            
            # Prepare feature vector
            if record_type == "token_analysis":
                feature_vector = np.array([
                    [
                        features.get("social_proof_score", 0),
                        features.get("safety_score", 0),
                        features.get("liquidity_score", 0),
                        features.get("combined_score", 0)
                    ]
                ], dtype=np.float32)
            else:
                self.logger.warning(f"Prediction for {record_type} not implemented")
                return None
            
            # Make prediction
            prediction = model.predict(feature_vector)[0]
            
            return float(prediction)
        
        except Exception as e:
            self.logger.error(f"Error making prediction: {e}")
            return None
    
    async def get_performance_summary(self) -> Dict[str, Any]:
        """
        Get a summary of learning performance.
        
        Returns:
            Dictionary with performance summary
        """
        try:
            cursor = self.data_collector.conn.cursor()
            
            # Get record counts
            cursor.execute("SELECT COUNT(*) as total FROM learning_records")
            total_records = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) as labeled FROM learning_records WHERE is_labeled = 1")
            labeled_records = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) as token_analysis FROM learning_records WHERE record_type = 'token_analysis'")
            token_analysis_records = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) as trade_result FROM learning_records WHERE record_type = 'trade_result'")
            trade_result_records = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) as group_activity FROM learning_records WHERE record_type = 'group_activity'")
            group_activity_records = cursor.fetchone()[0]
            
            # Get trade performance metrics
            cursor.execute('''
            SELECT AVG(CAST(json_extract(features, '$.profit_percent') AS REAL)) as avg_profit,
                   COUNT(*) as count
            FROM learning_records 
            WHERE record_type = 'trade_result'
            ''')
            
            row = cursor.fetchone()
            avg_profit = row[0] if row[0] is not None else 0
            trade_count = row[1]
            
            # Get labeled token analysis metrics
            cursor.execute('''
            SELECT AVG(CAST(json_extract(features, '$.combined_score') AS REAL)) as avg_score,
                   COUNT(*) as count
            FROM learning_records 
            WHERE record_type = 'token_analysis' AND is_labeled = 1
            ''')
            
            row = cursor.fetchone()
            avg_token_score = row[0] if row[0] is not None else 0
            labeled_token_count = row[1]
            
            return {
                "total_records": total_records,
                "labeled_records": labeled_records,
                "token_analysis_records": token_analysis_records,
                "trade_result_records": trade_result_records,
                "group_activity_records": group_activity_records,
                "avg_profit_percent": avg_profit,
                "trade_count": trade_count,
                "avg_token_score": avg_token_score,
                "labeled_token_count": labeled_token_count,
                "last_updated": time.time()
            }
        
        except Exception as e:
            self.logger.error(f"Error getting performance summary: {e}")
            return {
                "error": str(e),
                "last_updated": time.time()
            }
    
    def close(self) -> None:
        """Close the data collector."""
        self.data_collector.close()


# Singleton instance
_learning_engine = None


def get_learning_engine() -> LearningEngine:
    """
    Get the singleton learning engine instance.
    
    Returns:
        LearningEngine instance
    """
    global _learning_engine
    if _learning_engine is None:
        _learning_engine = LearningEngine()
    return _learning_engine


async def record_token_analysis(
    token_address: str,
    social_proof_score: float,
    safety_score: float,
    liquidity_score: float,
    combined_score: float,
    risk_level: str,
    additional_data: Dict[str, Any] = None
) -> str:
    """
    Record a token analysis for learning.
    
    Args:
        token_address: The token address
        social_proof_score: Social proof score (0-10)
        safety_score: Safety score (0-10)
        liquidity_score: Liquidity score (0-10)
        combined_score: Combined score (0-10)
        risk_level: Risk level category
        additional_data: Any additional data to include
        
    Returns:
        Record ID if successful, empty string otherwise
    """
    engine = get_learning_engine()
    return await engine.record_token_analysis(
        token_address, social_proof_score, safety_score, liquidity_score,
        combined_score, risk_level, additional_data
    )


async def record_trade_result(
    token_address: str,
    entry_price: float,
    exit_price: float,
    profit_percent: float,
    was_successful: bool,
    source_type: str,
    source_id: str,
    additional_data: Dict[str, Any] = None
) -> str:
    """
    Record a trade result for learning.
    
    Args:
        token_address: The token address
        entry_price: Entry price
        exit_price: Exit price
        profit_percent: Profit percentage
        was_successful: Whether the trade was successful
        source_type: Source type (group, wallet, twitter)
        source_id: Source identifier
        additional_data: Any additional data to include
        
    Returns:
        Record ID if successful, empty string otherwise
    """
    engine = get_learning_engine()
    return await engine.record_trade_result(
        token_address, entry_price, exit_price, profit_percent,
        was_successful, source_type, source_id, additional_data
    )


async def predict_token_profit(
    social_proof_score: float,
    safety_score: float,
    liquidity_score: float,
    combined_score: float
) -> Optional[float]:
    """
    Predict the profit potential of a token.
    
    Args:
        social_proof_score: Social proof score (0-10)
        safety_score: Safety score (0-10)
        liquidity_score: Liquidity score (0-10)
        combined_score: Combined score (0-10)
        
    Returns:
        Predicted profit percentage if model available, None otherwise
    """
    engine = get_learning_engine()
    
    features = {
        "social_proof_score": social_proof_score,
        "safety_score": safety_score,
        "liquidity_score": liquidity_score,
        "combined_score": combined_score
    }
    
    return await engine.predict("profit_predictor", "token_analysis", features)


async def get_learning_summary() -> Dict[str, Any]:
    """
    Get a summary of learning performance.
    
    Returns:
        Dictionary with performance summary
    """
    engine = get_learning_engine()
    return await engine.get_performance_summary()


async def main():
    """Run a test of the learning engine."""
    # Initialize the learning engine
    engine = get_learning_engine()
    
    # Record some test data
    for i in range(50):
        # Generate random token analysis
        token_address = f"Token{i}"
        social_proof_score = 5.0 + (i % 5)
        safety_score = 6.0 + (i % 4)
        liquidity_score = 7.0 + (i % 3)
        combined_score = (social_proof_score + safety_score + liquidity_score) / 3
        risk_level = ["low", "medium", "high"][i % 3]
        
        record_id = await engine.record_token_analysis(
            token_address, social_proof_score, safety_score, liquidity_score,
            combined_score, risk_level
        )
        
        # Generate matching trade result
        profit_mult = 1.0 if combined_score > 6.5 else -0.5
        profit_percent = (combined_score - 5.0) * 10 * profit_mult + (i % 10) - 5
        
        await engine.record_trade_result(
            token_address, 1.0, 1.0 + (profit_percent / 100),
            profit_percent, profit_percent > 0, "test", "test_source"
        )
    
    # Train a model
    await engine.train_model("profit_predictor", "token_analysis")
    
    # Make a prediction
    prediction = await predict_token_profit(8.0, 7.0, 9.0, 8.0)
    print(f"Predicted profit: {prediction:.2f}%")
    
    # Get performance summary
    summary = await get_learning_summary()
    print("Learning summary:")
    for key, value in summary.items():
        print(f"  {key}: {value}")
    
    # Close the engine
    engine.close()


if __name__ == "__main__":
    asyncio.run(main())