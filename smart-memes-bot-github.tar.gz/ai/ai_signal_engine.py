"""
AI Signal Engine for SMART MEMES BOT.

This module provides AI-powered token analysis and safety reporting.
It leverages OpenAI's GPT models for analysis with robust fallback
mechanisms to ensure reliability.
"""

import logging
import os
import json
import asyncio
import time
from typing import Dict, Any, Optional, List, Tuple
import re

# Configure logging
logger = logging.getLogger(__name__)

# Try to import OpenAI module
try:
    from openai import OpenAI
    HAS_OPENAI = True
    logger.info("OpenAI module available")
except ImportError:
    HAS_OPENAI = False
    logger.warning("OpenAI module not available, using simplified analysis")

# Init OpenAI client with API key
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
if HAS_OPENAI and OPENAI_API_KEY:
    openai_client = OpenAI(api_key=OPENAI_API_KEY)
    logger.info("OpenAI client initialized")
else:
    openai_client = None
    if HAS_OPENAI:
        logger.warning("OpenAI API key not provided")

# Cache for analysis results
_analysis_cache = {}
_safety_cache = {}
CACHE_TTL = 3600  # 1 hour


async def analyze_token(token_address: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Analyze a token using AI to get investment insights.
    
    Args:
        token_address: The token address to analyze
        context: Optional additional context (e.g., recent news, market conditions)
        
    Returns:
        Dictionary with analysis results
    """
    # Check cache first
    cache_key = f"{token_address}_{hash(str(context) if context else '')}"
    if cache_key in _analysis_cache:
        cache_entry = _analysis_cache[cache_key]
        if time.time() - cache_entry['timestamp'] < CACHE_TTL:
            logger.info(f"Using cached analysis for {token_address}")
            return cache_entry['data']
    
    # Create default response
    result = {
        "token_address": token_address,
        "score": 0,
        "verdict": "Could not analyze token",
        "recommendation": "avoid",
        "confidence": 0.0
    }
    
    # Try to analyze using OpenAI
    if openai_client:
        try:
            logger.info(f"Analyzing token {token_address} with OpenAI")
            
            # Create the system and user messages
            system_message = """
            You are a cryptocurrency token analyst expert. Analyze the token address provided 
            and assess its investment potential. Provide a score from 0-100 (higher is better), 
            a brief verdict (max 50 words), and a recommendation (buy, watch, caution, or avoid).
            Also provide a confidence score from 0.0 to 1.0.
            
            Respond ONLY with a valid JSON object in this format:
            {
                "score": 75,
                "verdict": "Strong fundamentals with growing community, appears to be a legitimate project",
                "recommendation": "buy",
                "confidence": 0.85
            }
            """
            
            user_message = f"Analyze this token address: {token_address}"
            
            # Add context if provided
            if context:
                context_str = "\n\nAdditional context:\n"
                for key, value in context.items():
                    context_str += f"- {key}: {value}\n"
                user_message += context_str
            
            # Call OpenAI API
            response = openai_client.chat.completions.create(
                model="gpt-4o",  # Use gpt-4o as it's more powerful than older models
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": user_message}
                ],
                temperature=0.2,  # Low temperature for more consistent results
                response_format={"type": "json_object"}
            )
            
            # Process response
            if response and hasattr(response, 'choices') and len(response.choices) > 0:
                # Extract the JSON content from the response
                json_content = response.choices[0].message.content
                
                try:
                    ai_result = json.loads(json_content)
                    
                    # Update the result with AI analysis
                    result.update(ai_result)
                    logger.info(f"Successfully analyzed {token_address} with AI")
                    
                    # Cache the result
                    _analysis_cache[cache_key] = {
                        'timestamp': time.time(),
                        'data': result
                    }
                    
                    return result
                    
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse JSON from OpenAI response: {json_content}")
            else:
                logger.error("Invalid response from OpenAI")
                
        except Exception as e:
            logger.error(f"Error analyzing token with OpenAI: {e}")
    
    # If we reach here, use a simplified fallback analysis
    try:
        # This is a very simplified algorithm that should be replaced with
        # a more sophisticated fallback in production
        simplified_score = _calculate_simplified_score(token_address)
        result["score"] = simplified_score
        
        if simplified_score >= 70:
            result["verdict"] = "Appears to have positive potential based on address analysis"
            result["recommendation"] = "buy"
        elif simplified_score >= 50:
            result["verdict"] = "Shows moderate indicators, requires careful consideration"
            result["recommendation"] = "watch"
        else:
            result["verdict"] = "Does not show positive indicators in basic analysis"
            result["recommendation"] = "avoid"
            
        result["confidence"] = 0.3  # Low confidence as this is a fallback
        
        # Cache the result
        _analysis_cache[cache_key] = {
            'timestamp': time.time(),
            'data': result
        }
        
        logger.info(f"Used simplified analysis for {token_address} with score {simplified_score}")
        
    except Exception as e:
        logger.error(f"Error in simplified analysis: {e}")
    
    return result


async def get_token_safety_report(token_address: str) -> Dict[str, Any]:
    """
    Get a safety report for a token to identify potential risks.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Dictionary with safety analysis results
    """
    # Check cache first
    if token_address in _safety_cache:
        cache_entry = _safety_cache[token_address]
        if time.time() - cache_entry['timestamp'] < CACHE_TTL:
            logger.info(f"Using cached safety report for {token_address}")
            return cache_entry['data']
    
    # Create default response
    result = {
        "token_address": token_address,
        "safety_score": 0,
        "risk_level": "high",
        "risks": ["Unknown token - could not assess risks"],
        "recommendation": "avoid"
    }
    
    # Try to analyze using OpenAI
    if openai_client:
        try:
            logger.info(f"Generating safety report for {token_address} with OpenAI")
            
            # Create the system and user messages
            system_message = """
            You are a cryptocurrency security expert. Analyze the token address provided and assess
            its safety profile. Provide a safety score from 0-100 (higher is safer), identify a 
            risk level (low, medium, high), and list specific risks.
            
            Respond ONLY with a valid JSON object in this format:
            {
                "safety_score": 65,
                "risk_level": "medium",
                "risks": ["Limited trading history", "Small liquidity pool", "New contract"],
                "recommendation": "caution"
            }
            
            For recommendation, use one of: "safe", "caution", "avoid"
            """
            
            user_message = f"Analyze the safety of this token address: {token_address}"
            
            # Call OpenAI API
            response = openai_client.chat.completions.create(
                model="gpt-4o",  # Use gpt-4o as it's more powerful than older models
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": user_message}
                ],
                temperature=0.2,  # Low temperature for more consistent results
                response_format={"type": "json_object"}
            )
            
            # Process response
            if response and hasattr(response, 'choices') and len(response.choices) > 0:
                # Extract the JSON content from the response
                json_content = response.choices[0].message.content
                
                try:
                    ai_result = json.loads(json_content)
                    
                    # Update the result with AI analysis
                    result.update(ai_result)
                    logger.info(f"Successfully generated safety report for {token_address} with AI")
                    
                    # Cache the result
                    _safety_cache[token_address] = {
                        'timestamp': time.time(),
                        'data': result
                    }
                    
                    return result
                    
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse JSON from OpenAI response: {json_content}")
            else:
                logger.error("Invalid response from OpenAI")
                
        except Exception as e:
            logger.error(f"Error generating safety report with OpenAI: {e}")
    
    # If we reach here, use a simplified fallback safety analysis
    try:
        # This is a very simplified algorithm that should be replaced with
        # a more sophisticated fallback in production
        simplified_score = _calculate_simplified_safety(token_address)
        result["safety_score"] = simplified_score
        
        # Determine risk level and recommendations
        if simplified_score >= 70:
            result["risk_level"] = "low"
            result["risks"] = ["Limited data available for comprehensive assessment"]
            result["recommendation"] = "safe"
        elif simplified_score >= 40:
            result["risk_level"] = "medium"
            result["risks"] = [
                "Limited data available for comprehensive assessment",
                "Potential volatility risk"
            ]
            result["recommendation"] = "caution"
        else:
            result["risk_level"] = "high"
            result["risks"] = [
                "Limited data available for comprehensive assessment",
                "Potential high volatility",
                "Unknown contract behavior"
            ]
            result["recommendation"] = "avoid"
            
        # Cache the result
        _safety_cache[token_address] = {
            'timestamp': time.time(),
            'data': result
        }
        
        logger.info(f"Used simplified safety analysis for {token_address} with score {simplified_score}")
        
    except Exception as e:
        logger.error(f"Error in simplified safety analysis: {e}")
    
    return result


def _calculate_simplified_score(token_address: str) -> int:
    """
    Calculate a simplified score for a token address.
    This is a placeholder algorithm used when AI analysis fails.
    
    Args:
        token_address: The token address to score
        
    Returns:
        Score from 0-100
    """
    # For Solana's native SOL token, give a high score
    if token_address == "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v":
        return 90
        
    # Extract characteristics of the address
    length_score = min(50, len(token_address) * 2)  # More chars = higher score up to 50
    
    # Check format (e.g., does it match expected formats for token addresses)
    format_score = 0
    if re.match(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$', token_address):  # Solana-like
        format_score = 30
    elif re.match(r'^0x[a-fA-F0-9]{40}$', token_address):  # Ethereum-like
        format_score = 30
        
    # Combine scores with weighted components
    final_score = int((length_score * 0.3) + (format_score * 0.7))
    
    # Ensure within 0-100 range
    return max(0, min(100, final_score))


def _calculate_simplified_safety(token_address: str) -> int:
    """
    Calculate a simplified safety score for a token address.
    This is a placeholder algorithm used when AI analysis fails.
    
    Args:
        token_address: The token address to score
        
    Returns:
        Safety score from 0-100
    """
    # For Solana's SOL token, give a high safety score
    if token_address == "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v":
        return 95
        
    # For unknown tokens, conservatively assume lower safety
    # Base safety on address characteristics
    
    # Check format for validity
    format_score = 0
    if re.match(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$', token_address):  # Solana-like
        format_score = 35
    elif re.match(r'^0x[a-fA-F0-9]{40}$', token_address):  # Ethereum-like
        format_score = 35
        
    # Use deterministic randomness based on the address for demo purposes
    # In production, this would be replaced with actual safety checks
    import hashlib
    hash_obj = hashlib.md5(token_address.encode())
    hash_int = int(hash_obj.hexdigest(), 16)
    random_component = (hash_int % 40) + 10  # 10-50 range
    
    # Combine scores
    safety_score = format_score + random_component
    
    # Ensure within 0-100 range
    return max(0, min(100, safety_score))


async def clear_cache():
    """Clear the analysis and safety caches."""
    global _analysis_cache, _safety_cache
    _analysis_cache = {}
    _safety_cache = {}
    logger.info("AI analysis caches cleared")


async def test_signal_engine():
    """Test the AI signal engine with a sample token address."""
    # Test tokens
    test_tokens = [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # Solana SOL
        "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Random Solana token
        "0x6b175474e89094c44da98b954eedeac495271d0f"     # Ethereum DAI token
    ]
    
    results = {}
    
    for token in test_tokens:
        # Analysis test
        logger.info(f"Testing analysis for {token}")
        analysis = await analyze_token(token)
        
        # Safety test
        logger.info(f"Testing safety report for {token}")
        safety = await get_token_safety_report(token)
        
        # Store results
        results[token] = {
            "analysis": analysis,
            "safety": safety
        }
        
        # Print summary
        logger.info(f"Results for {token}:")
        logger.info(f"Analysis Score: {analysis.get('score', 0)}/100")
        logger.info(f"Recommendation: {analysis.get('recommendation', 'unknown')}")
        logger.info(f"Safety Score: {safety.get('safety_score', 0)}/100")
        logger.info(f"Risk Level: {safety.get('risk_level', 'unknown')}")
        logger.info("-" * 40)
    
    return results
    

# Run test if executed directly
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(test_signal_engine())