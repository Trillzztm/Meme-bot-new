# SMART MEMES BOT

An advanced AI-powered cryptocurrency trading platform that combines intelligent algorithms, real-time market analysis, and innovative user engagement tools to revolutionize digital asset trading on the Solana blockchain.

## Features

- **AI-Enhanced Token Analysis**: Get comprehensive analysis of any Solana token with risk assessment and trading recommendations
- **Real Blockchain Trading**: Execute actual transactions on Solana blockchain through Jupiter DEX
- **Telegram Bot Integration**: Interact with the trading system through Telegram commands
- **Advanced Token Sniping**: Automatically detect and buy tokens mentioned in Telegram groups
- **24/7 Continuous Operation**: Trading watchdog ensures the system never stops
- **Web Dashboard**: Monitor your trading performance, wallet balance, and token analysis

## Quick Start

1. Ensure you have Python 3.8+ installed
2. Set required environment variables (see below)
3. Run `./start.sh` to start the system

## Required Environment Variables

- `OPENAI_API_KEY`: API key for OpenAI GPT (for AI token analysis)
- `TELEGRAM_BOT_TOKEN`: Telegram Bot token (for Telegram bot functionality)
- `SOLANA_PRIVATE_KEY`: Solana wallet private key (for executing real trades)

You can set these in a `.env` file in the project root directory or export them in your shell.

## Telegram Bot Commands

- `/tokeninfo <address>` - Get AI analysis on a token
- `/manualsnipe <address> <amount_in_sol>` - Buy a token
- `/aiadvice <token_address> <market_address>` - Get AI trading advice
- `/status` - Check bot status and wallet balance
- `/help` - Show help message

## Architecture

The system consists of several components:

1. **Web Dashboard**: Flask web application for monitoring and control
2. **Telegram Bot**: Telegram bot interface for user interaction
3. **AI Token Analyzer**: OpenAI GPT integration for token analysis
4. **Trading Engine**: Real blockchain trading functionality through Jupiter DEX
5. **Profit Monitor**: Automatic profit tracking and selling

## Manual Installation

If the automatic installation doesn't work, you can install dependencies manually:

```bash
# Web server dependencies
pip install Flask Flask-Login gunicorn

# Telegram bot
pip install "python-telegram-bot>=20.0,<21.0"

# AI and NLP
pip install openai

# Solana Blockchain
pip install "solana>=0.27.0,<0.28.0" "pyserum>=0.2.0,<0.3.0"

# Utilities
pip install aiohttp python-dotenv requests base58
```

## Development

To develop or extend the SMART MEMES BOT, you can modify the following components:

- `main.py`: Web dashboard and API endpoints
- `bot.py`: Telegram bot functionality
- `utils/`: Utility modules for trading, analysis, etc.
- `templates/`: HTML templates for the web dashboard

## Security Warning

This system requires sensitive API keys and wallet private keys. Never share these with anyone.
The Solana private key gives complete control over your wallet, so use with caution.

## License

Proprietary. All rights reserved.

## Support

For support or questions, please contact the developer directly.