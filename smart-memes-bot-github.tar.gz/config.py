"""
Configuration settings for SMART MEMES BOT.

This module contains configuration settings for the bot,
including API tokens, blockchain settings, and other parameters.
"""

import os
from typing import Dict, Any, List

# Bot configuration
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
BOT_USERNAME = "SmartMemesBot"

# Blockchain configuration
DEFAULT_NETWORK = "solana"  # Options: "ethereum", "bsc", "polygon", "solana"
NETWORKS = {
    "solana": {
        "rpc_url": "https://api.mainnet-beta.solana.com",
        "explorer_url": "https://solscan.io",
        "token_explorer_url": "https://solscan.io/token/{}",
        "tx_explorer_url": "https://solscan.io/tx/{}"
    },
    "ethereum": {
        "rpc_url": "https://mainnet.infura.io/v3/YOUR_INFURA_KEY",
        "explorer_url": "https://etherscan.io",
        "token_explorer_url": "https://etherscan.io/token/{}",
        "tx_explorer_url": "https://etherscan.io/tx/{}"
    },
    "bsc": {
        "rpc_url": "https://bsc-dataseed.binance.org/",
        "explorer_url": "https://bscscan.com",
        "token_explorer_url": "https://bscscan.com/token/{}",
        "tx_explorer_url": "https://bscscan.com/tx/{}"
    },
    "polygon": {
        "rpc_url": "https://polygon-rpc.com",
        "explorer_url": "https://polygonscan.com",
        "token_explorer_url": "https://polygonscan.com/token/{}",
        "tx_explorer_url": "https://polygonscan.com/tx/{}"
    }
}

# Enhanced RPC configuration
SOLANA_RPC_ENDPOINTS = [
    "https://api.mainnet-beta.solana.com",
    "https://solana-api.projectserum.com",
    "https://rpc.ankr.com/solana",
    "https://solana.public-rpc.com",
    "https://mainnet.rpcpool.com",
    "https://api.mainnet.rpcpool.com",
    "https://api.metaplex.solana.com"
]

# Wallet configuration
DEFAULT_WALLET = "BGAQ5Wnamx6rDCdyaDhyW5xtorSxHWCPC6SckiTST9A1"  # Default Solana wallet
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY", "")

# Trading configuration
MAX_SPEND = 20  # Maximum amount to spend on a token (in SOL/ETH/etc.)
DEFAULT_SLIPPAGE = 0.5  # Default slippage percentage
GAS_PRESETS = {
    "low": 5,
    "medium": 10,
    "high": 15,
    "rapid": 20
}

# Auto-sniper configuration
AUTO_SNIPE_MIN_MENTIONS = 3  # Minimum number of mentions before auto-sniping
AUTO_SNIPE_AMOUNT = 0.1  # Amount to use for auto-sniping (in SOL/ETH/etc.)
MAX_AUTO_SNIPE_AMOUNT = 0.5  # Maximum amount to allow for auto-sniping
AUTO_SNIPE_THRESHOLD_SCORE = 7.0  # Minimum safety score (out of 10) for auto-sniping

# Whale detector configuration
WHALE_THRESHOLD = 50000  # USD value to consider a whale transaction
WHALE_TRANSACTION_THRESHOLD = 1000000  # Token amount to consider a whale transaction
WHALE_ALERT_INTERVAL = 300  # Minimum seconds between alerts for the same token
WHALE_AUTO_BUY_DEFAULT = False  # Default setting for auto-buy on whale detection
WHALE_DEFAULT_BUY_AMOUNT = 0.1  # Default SOL amount for auto-buy on whale detection

# AI Market Predictor configuration
MAX_AI_PREDICTION_WINDOW = 7  # Maximum days for price prediction
AI_CONFIDENCE_THRESHOLD = 0.65  # Minimum confidence for high-conviction predictions
PREDICTION_UPDATE_INTERVAL = 1800  # Update predictions every 30 minutes
AUTO_TRADE_ON_AI_SIGNAL = False  # Default setting for auto-trading on AI signals
AI_SIGNAL_TRADE_AMOUNT = 0.2  # Default SOL amount for AI signal trades

# Arbitrage detector configuration
ARBITRAGE_MIN_PROFIT_PERCENT = 1.0  # Minimum profit percentage to execute arbitrage
ARBITRAGE_MAX_AMOUNT = 1.0  # Maximum SOL to use per arbitrage opportunity
ARBITRAGE_ENABLED_DEXES = ["raydium", "orca", "serum"]  # Enabled DEXes for arbitrage
ARBITRAGE_DETECTION_INTERVAL = 60  # Seconds between arbitrage detection cycles
AUTO_EXECUTE_ARBITRAGE = True  # Automatically execute detected arbitrage opportunities

# Enhanced token safety checks
ADVANCED_SAFETY_CHECKS = True  # Enable enhanced token safety analysis
TOKEN_BLACKLIST = []  # Known scam token addresses
MIN_TOKEN_AGE_HOURS = 1  # Minimum token age for consideration
MIN_LIQUIDITY_USD = 10000  # Minimum liquidity in USD for safe tokens
HIGH_RISK_HOLDER_CONCENTRATION = 80  # Percentage of supply held by top 5 wallets to flag as high risk

# Profit protection settings
DEFAULT_TAKE_PROFIT = 200  # Default take profit percentage (2x)
DEFAULT_STOP_LOSS = 50  # Default stop loss percentage (50% loss)
TRAILING_STOP_ENABLED = True  # Enable trailing stop loss by default
TRAILING_STOP_PERCENT = 15  # Default trailing stop percentage
PROFIT_CHECK_INTERVAL = 60  # Check profit/loss conditions every 60 seconds

# Meme generation
MEME_TEMPLATES = [
    "moon_lambo",
    "diamond_hands",
    "rug_pull",
    "to_the_moon",
    "wojak_cry",
    "wojak_happy"
]

# Database configuration
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///crypto_bot.db")

# Web dashboard configuration
DASHBOARD_SECRET_KEY = os.environ.get("DASHBOARD_SECRET_KEY", "development_secret_key")
DASHBOARD_PORT = int(os.environ.get("DASHBOARD_PORT", "5000"))

# Performance analysis
PERFORMANCE_TRACKING_ENABLED = True  # Track and analyze trade performance
PERFORMANCE_METRICS_WINDOW = 30  # Days to include in performance metrics
AUTO_ADJUST_STRATEGY = True  # Automatically adjust strategy based on performance

# Flash Loan Arbitrage configuration
FLASH_LOAN_ENABLED = True  # Enable flash loan arbitrage detection and execution
FLASH_LOAN_MIN_PROFIT_PERCENT = 0.8  # Minimum profit percentage to execute flash loan arbitrage
FLASH_LOAN_MAX_AMOUNT = 100000  # Maximum USDC/USDT to use in flash loans
FLASH_LOAN_PLATFORMS = ["solend", "port", "mango"]  # Enabled lending platforms for flash loans

# Machine Learning Reinforcement Trader configuration
ML_TRADER_ENABLED = True  # Enable ML-based automated trading
ML_TRADER_MAX_POSITION = 1.0  # Maximum SOL per position
ML_TRADER_MAX_POSITIONS = 5  # Maximum concurrent positions
ML_TRADER_LEARNING_RATE = 0.05  # Learning rate for the ML model
ML_TRADER_EXPLORATION_RATE = 0.1  # Exploration rate for trying new strategies
ML_TRADER_RISK_TOLERANCE = 0.7  # Risk tolerance factor (0-1)

# API Integration
BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY", "")
SOLSCAN_API_KEY = os.environ.get("SOLSCAN_API_KEY", "")

# Notification settings
NOTIFICATION_LEVELS = {
    "critical": True,  # Critical alerts (stop loss, security issues)
    "important": True,  # Important alerts (take profit, whale movements)
    "informational": True,  # Informational alerts (price updates, new tokens)
    "debug": False  # Debug information
}

# Logging configuration
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
LOG_FILE = os.environ.get("LOG_FILE", "telegram_bot.log")