"""
Token Mint Addresses for Solana Tokens

This module provides a mapping between token symbols and their mint addresses
for use in trading operations.
"""

# Standard tokens on Solana
STANDARD_TOKEN_ADDRESSES = {
    # Major tokens
    "SOL": "So11111111111111111111111111111111111111112",  # Native SOL
    "USDC": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC (native)
    "USDT": "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",  # USDT
    "BTC": "9n4nbM75f5Ui33ZbPYXn59EwSgE8CGsHtAeTH5YFeJ9E",  # Wrapped Bitcoin on Solana
    "ETH": "7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs",  # Wrapped Ethereum on Solana
    
    # Solana ecosystem
    "BONK": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",  # BONK
    "JTO": "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn",  # Jito
    "PYTH": "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",  # Pyth
    "RAY": "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",  # Raydium
    "ORCA": "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",  # Orca
    "WIF": "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",  # Dog token
    "STRK": "STRKpJNA7WNxNDko2gTGJchuexZMRCZnK6fbPmvXdBC",  # Striketo
    "BNB": "9gP2kCy3wA1ctvYWQk75guqXuHfrEomqydHLtcTCqiLa",  # BNB on Solana
    "MSOL": "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",  # Marinade staked SOL
    "BOME": "DUSTawucrTsGU8hcqRdHDCbuYhCPADMLM2VcCb8VnFnQ",  # BOME Meme token
    
    # Other popular tokens
    "SHDW": "SHDWyBxihqiCj6YekG2GUr7wqKLeLAMK1gHZck9pL6y",  # Shadow
    "DUST": "DUSTawucrTsGU8hcqRdHDCbuYhCPADMLM2VcCb8VnFnQ",  # Dust Protocol
    
    # Additional tokens our system tries to trade
    "RNDR": "rndrizKT3MK1iimdxRdWabvzMu5fMzHAMecNNxhQ8Nz",  # Render Network (wrapped on Solana)
    "AVAX": "AXsYaVJhAXtBbhrbysnKEfUYuMFEWfEKQbHmwkAjqtRd",  # Avalanche (wrapped)
    "ARB": "8ZU12KiRSx9TYzVmQi1pcUQPHRfHbiiQz9tU1seMiD8P",  # Arbitrum (wrapped)
    "POPCAT": "A98UDy7z8MfmWnTQt6cKjje7UfqV3pTLf4yEbuwL2HrH",  # POPCAT
    "SLOTH": "4dMcA9jfogetcCFKeMV7CtDYUXK6ZRSCfxfqAkXjyDf6",  # SLOTH
    "SAMO": "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Samoyedcoin
    "BOOK": "DUSTawucrTsGU8hcqRdHDCbuYhCPADMLM2VcCb8VnFnQ",  # BOOK
    "MANGO": "MangoCzJ36AjZyKwVj3VnYU4GTonjfVEnJmvvWaxLac", # Mango Markets
    "SUNNY": "SUNNYWgPQmFxe9wTZzNK7iPnJ3vYDrkgnxJRJm1s3ag",  # Sunny Aggregator
    "RUN": "RunaE1YoJCMYEfWETmVUWdx3y9X2QVbAJPQfeLGxLjc",  # RUN
    "SILLY": "7EYnhQoR9YM3N7UoaKRoA44Jb1LP1N5GFhL2imBAXCUJ"  # SILLY
}

def get_token_mint_address(token_symbol: str) -> str:
    """
    Get the mint address for a token symbol
    
    Args:
        token_symbol: Token symbol (e.g., "SOL", "BONK")
        
    Returns:
        Mint address as string
    
    Raises:
        ValueError: If token symbol is not found
    """
    # Normalize token symbol to uppercase
    token_symbol = token_symbol.upper()
    
    # Check if token is in standard addresses
    if token_symbol in STANDARD_TOKEN_ADDRESSES:
        return STANDARD_TOKEN_ADDRESSES[token_symbol]
    
    # If not found, raise error
    raise ValueError(f"Token symbol '{token_symbol}' not found in address database")

def get_token_symbol_from_mint(mint_address: str) -> str:
    """
    Get token symbol from mint address
    
    Args:
        mint_address: Mint address
        
    Returns:
        Token symbol
        
    Raises:
        ValueError: If mint address is not found
    """
    # Reverse lookup
    for symbol, address in STANDARD_TOKEN_ADDRESSES.items():
        if address.lower() == mint_address.lower():
            return symbol
    
    # If not found, use truncated address
    return f"UNK...{mint_address[-6:]}"
