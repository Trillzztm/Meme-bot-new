#!/bin/bash

echo "==============================================="
echo "SMART MEMES BOT - REAL TRADING STARTER"
echo "==============================================="
echo

# Check if private key is set
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
    echo "❌ ERROR: SOLANA_PRIVATE_KEY environment variable not set!"
    echo "Please set your private key: export SOLANA_PRIVATE_KEY='your_key_here'"
    exit 1
fi

# Clean up any existing processes
pkill -f real_trader.py > /dev/null 2>&1
echo "✅ Cleaned up any previous trader processes"

# Start the trading script
nohup python real_trader.py > trader.out 2> trader.err &
PID=$!
echo $PID > trader.pid
echo "🚀 Started Real Blockchain Trader with PID: $PID"

# Verify it's running
sleep 2
if ps -p $PID > /dev/null; then
    echo "✅ Verified that trader is running properly"
else
    echo "❌ ERROR: Trader failed to start. Check trader.err for details."
    cat trader.err
    exit 1
fi

echo
echo "💰 Your REAL MONEY trades are now being executed on the blockchain!"
echo
echo "💡 Monitor progress with:"
echo "   tail -f real_trades.log          (see detailed logs)"
echo "   tail -f trader.out               (see standard output)"
echo "   cat real_trades_history.json     (see trade history)"
echo
echo "⚠️ To stop trading run: ./stop_trading.sh"
echo
echo "==============================================="