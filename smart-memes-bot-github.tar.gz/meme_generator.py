"""
Meme generator for cryptocurrency-themed memes.

This module handles:
- Loading meme templates
- Customizing memes with token data
- Generating SVG and PNG images
- Saving generated memes

Multiple fallback mechanisms for SVG to PNG conversion:
1. CairoSVG (primary)
2. Inkscape (fallback 1)
3. ImageMagick (fallback 2)
4. PIL-based custom renderer (final fallback)
"""

import json
import logging
import os
import random
import re
import shutil
import time
import traceback
import subprocess
import tempfile
import base64
from datetime import datetime
from io import BytesIO, StringIO
from urllib.parse import quote_plus

# Configure logging first
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import dependencies
import database as db
from PIL import Image, ImageDraw, ImageFont
from token_analyzer import get_token_info

# Define constants
MEME_TEMPLATES_DIR = "assets/meme_templates"
GENERATED_MEMES_DIR = "temp"
DEFAULT_FONT = "Arial"
AVAILABLE_THEMES = ["moon_lambo", "diamond_hands", "chad_trader", "bear_market", "fud_destroyer", "wen_lambo", "to_the_moon"]

# Ensure the generated memes directory exists
os.makedirs(GENERATED_MEMES_DIR, exist_ok=True)

# Import cairosvg with multiple fallback options
HAS_CAIROSVG = False
HAS_INKSCAPE = False
HAS_IMAGEMAGICK = False
HAS_ALTERNATIVE_RENDERER = False

# Try to import cairosvg for SVG to PNG conversion
try:
    import cairosvg
    HAS_CAIROSVG = True
    logger.info("CairoSVG loaded successfully for SVG rendering")
except (ImportError, OSError) as e:
    logger.warning(f"CairoSVG unavailable: {e}")
    # Check if system has inkscape installed
    try:
        result = subprocess.run(['which', 'inkscape'], capture_output=True, text=True)
        if result.returncode == 0:
            HAS_INKSCAPE = True
            logger.info("Inkscape found as fallback for SVG rendering")
        else:
            # Check for imagemagick convert
            result = subprocess.run(['which', 'convert'], capture_output=True, text=True)
            if result.returncode == 0:
                HAS_IMAGEMAGICK = True
                logger.info("ImageMagick found as fallback for SVG rendering")
    except Exception as e:
        logger.warning(f"Failed to check for alternative renderers: {e}")

# If none of the standard renderers are available, we'll use a PIL-based alternative approach
if not any([HAS_CAIROSVG, HAS_INKSCAPE, HAS_IMAGEMAGICK]):
    HAS_ALTERNATIVE_RENDERER = True
    logger.info("Using alternative renderer based on PIL for SVG content")

def convert_svg_to_png(svg_content, png_path, width=800, height=600):
    """
    Convert SVG to PNG using the best available method with multiple fallbacks.
    
    Args:
        svg_content (str): SVG content as string
        png_path (str): Output path for PNG file
        width (int): Image width
        height (int): Image height
        
    Returns:
        bool: True if conversion successful, False otherwise
    """
    conversion_success = False
    
    # Try CairoSVG (preferred method)
    if HAS_CAIROSVG and not conversion_success:
        try:
            cairosvg.svg2png(
                bytestring=svg_content.encode('utf-8'), 
                write_to=png_path, 
                output_width=width, 
                output_height=height
            )
            conversion_success = True
            logger.info("Successfully converted SVG to PNG using CairoSVG")
        except Exception as e:
            logger.warning(f"CairoSVG conversion failed: {e}")
    
    # Try Inkscape
    if HAS_INKSCAPE and not conversion_success:
        try:
            # Create a temporary SVG file for inkscape processing
            with tempfile.NamedTemporaryFile(suffix='.svg', delete=False) as temp_svg:
                temp_svg_path = temp_svg.name
                temp_svg.write(svg_content.encode('utf-8'))
            
            # Use Inkscape CLI to convert SVG to PNG
            inkscape_cmd = [
                'inkscape', 
                '--export-filename', png_path,
                '--export-width', str(width),
                '--export-height', str(height),
                temp_svg_path
            ]
            result = subprocess.run(inkscape_cmd, capture_output=True)
            
            # Clean up temp file
            os.unlink(temp_svg_path)
            
            if result.returncode == 0:
                conversion_success = True
                logger.info("Successfully converted SVG to PNG using Inkscape")
            else:
                logger.warning(f"Inkscape conversion failed: {result.stderr.decode()}")
                
        except Exception as e:
            logger.warning(f"Inkscape conversion failed: {e}")
    
    # Try ImageMagick
    if HAS_IMAGEMAGICK and not conversion_success:
        try:
            # Create a temporary SVG file for ImageMagick processing
            with tempfile.NamedTemporaryFile(suffix='.svg', delete=False) as temp_svg:
                temp_svg_path = temp_svg.name
                temp_svg.write(svg_content.encode('utf-8'))
            
            # Use ImageMagick convert to convert SVG to PNG
            convert_cmd = [
                'convert',
                '-background', 'none',
                '-size', f'{width}x{height}',
                temp_svg_path,
                png_path
            ]
            result = subprocess.run(convert_cmd, capture_output=True)
            
            # Clean up temp file
            os.unlink(temp_svg_path)
            
            if result.returncode == 0:
                conversion_success = True
                logger.info("Successfully converted SVG to PNG using ImageMagick")
            else:
                logger.warning(f"ImageMagick conversion failed: {result.stderr.decode()}")
                
        except Exception as e:
            logger.warning(f"ImageMagick conversion failed: {e}")
    
    # Final fallback: use a simple rendering approach with PIL
    if not conversion_success:
        try:
            # Create a blank image with PIL and write a message
            img = Image.new('RGBA', (width, height), color=(26, 26, 46, 255))
            draw = ImageDraw.Draw(img)
            
            # Try to extract text and important elements from SVG
            token_symbol = re.search(r'id="tokenSymbol"[^>]*>(.*?)<', svg_content)
            token_symbol = token_symbol.group(1) if token_symbol else "TOKEN"
            
            top_text = re.search(r'id="topText"[^>]*>(.*?)<', svg_content)
            top_text = top_text.group(1) if top_text else "TOP TEXT"
            
            bottom_text = re.search(r'id="bottomText"[^>]*>(.*?)<', svg_content)
            bottom_text = bottom_text.group(1) if bottom_text else "BOTTOM TEXT"
            
            # Draw text on image (simplified version)
            draw.text((width/2, 80), top_text, fill=(255, 255, 255, 255), anchor="mm")
            draw.text((width/2, height/2 - 50), token_symbol, fill=(255, 204, 0, 255), anchor="mm")
            draw.text((width/2, height - 50), bottom_text, fill=(255, 255, 255, 255), anchor="mm")
            
            # Save the image
            img.save(png_path)
            conversion_success = True
            logger.info("Created a fallback PNG image using PIL")
            
        except Exception as e:
            logger.error(f"All conversion methods failed: {e}")
            # Just return False to let the caller handle it
            return False
    
    return conversion_success

class MemeGenerator:
    """Class for generating crypto-themed memes."""
    
    def __init__(self):
        """Initialize the meme generator."""
        self.templates = self._load_templates()
        logger.info(f"Loaded {len(self.templates)} meme templates")
    
    def _load_templates(self):
        """Load all available meme templates."""
        templates = {}
        
        try:
            # Get all SVG templates from the directory
            for filename in os.listdir(MEME_TEMPLATES_DIR):
                if filename.endswith(".svg"):
                    template_path = os.path.join(MEME_TEMPLATES_DIR, filename)
                    template_name = os.path.splitext(filename)[0]
                    
                    with open(template_path, "r") as f:
                        template_content = f.read()
                    
                    # Extract template metadata if available
                    metadata = {}
                    metadata_match = re.search(r"<!-- METADATA:(.*?)-->", template_content, re.DOTALL)
                    if metadata_match:
                        try:
                            metadata = json.loads(metadata_match.group(1))
                        except json.JSONDecodeError:
                            logger.warning(f"Invalid metadata in template {template_name}")
                    
                    # Store template
                    templates[template_name] = {
                        "path": template_path,
                        "content": template_content,
                        "metadata": metadata
                    }
            
            # If no templates found, create default templates
            if not templates:
                self._create_default_templates()
                return self._load_templates()
                
            return templates
        
        except Exception as e:
            logger.error(f"Error loading meme templates: {str(e)}")
            # Create default templates in case of error
            self._create_default_templates()
            return self._load_templates()
    
    def _create_default_templates(self):
        """Create default meme templates if none exist."""
        logger.info("Creating default meme templates")
        
        try:
            # Ensure the directory exists
            os.makedirs(MEME_TEMPLATES_DIR, exist_ok=True)
            
            # Create templates
            self._create_moon_lambo_template()
            self._create_diamond_hands_template()
            
            logger.info("Default templates created")
        except Exception as e:
            logger.error(f"Error creating default templates: {str(e)}")
    
    def _create_moon_lambo_template(self):
        """Create a 'moon lambo' meme template."""
        template_path = os.path.join(MEME_TEMPLATES_DIR, "template1.svg")
        
        # Define the SVG content
        svg_content = """<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- METADATA:{"title":"To The Moon Lambo","textFields":["topText","bottomText"],"tokenFields":["tokenSymbol","tokenPrice"],"themes":["moon_lambo","to_the_moon","wen_lambo"]}-->
<svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="600" fill="#1a1a2e"/>
  <circle cx="400" cy="150" r="100" fill="#f9f9f9"/> <!-- Moon -->
  <rect x="200" y="400" width="400" height="100" rx="20" fill="#ff9900"/> <!-- Lambo body -->
  <rect x="150" y="450" width="500" height="50" rx="10" fill="#ff9900"/> <!-- Lambo extended body -->
  <circle cx="250" cy="500" r="30" fill="#333333"/> <!-- Wheel -->
  <circle cx="550" cy="500" r="30" fill="#333333"/> <!-- Wheel -->
  <rect x="530" y="430" width="70" height="20" fill="#ff9900"/> <!-- Spoiler -->
  <text id="topText" x="400" y="80" font-family="Arial" font-size="40" text-anchor="middle" fill="#ffffff">TOP_TEXT</text>
  <text id="bottomText" x="400" y="550" font-family="Arial" font-size="40" text-anchor="middle" fill="#ffffff">BOTTOM_TEXT</text>
  <text id="tokenSymbol" x="400" y="250" font-family="Arial" font-size="60" text-anchor="middle" fill="#ffcc00">TOKEN</text>
  <text id="tokenPrice" x="400" y="320" font-family="Arial" font-size="30" text-anchor="middle" fill="#ffffff">$0.00000001</text>
</svg>
"""
        
        # Write the template file
        with open(template_path, "w") as f:
            f.write(svg_content)
    
    def _create_diamond_hands_template(self):
        """Create a 'diamond hands' meme template."""
        template_path = os.path.join(MEME_TEMPLATES_DIR, "template2.svg")
        
        # Define the SVG content
        svg_content = """<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- METADATA:{"title":"Diamond Hands","textFields":["topText","bottomText"],"tokenFields":["tokenSymbol","profitPercentage"],"themes":["diamond_hands","chad_trader"]}-->
<svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="600" fill="#0a0a1a"/>
  <polygon points="350,150 400,100 450,150 400,200" fill="#61dafb" opacity="0.8"/> <!-- Diamond top -->
  <polygon points="350,150 300,200 350,250 400,200" fill="#61dafb" opacity="0.6"/> <!-- Diamond left -->
  <polygon points="450,150 500,200 450,250 400,200" fill="#61dafb" opacity="0.7"/> <!-- Diamond right -->
  <polygon points="350,250 400,300 450,250 400,200" fill="#61dafb" opacity="0.5"/> <!-- Diamond bottom -->
  <rect x="250" y="350" width="100" height="150" rx="20" fill="#ffddaa"/> <!-- Left hand -->
  <rect x="450" y="350" width="100" height="150" rx="20" fill="#ffddaa"/> <!-- Right hand -->
  <text id="topText" x="400" y="80" font-family="Arial" font-size="40" text-anchor="middle" fill="#ffffff">TOP_TEXT</text>
  <text id="bottomText" x="400" y="550" font-family="Arial" font-size="40" text-anchor="middle" fill="#ffffff">BOTTOM_TEXT</text>
  <text id="tokenSymbol" x="400" y="250" font-family="Arial" font-size="60" text-anchor="middle" fill="#ffffff">TOKEN</text>
  <text id="profitPercentage" x="400" y="320" font-family="Arial" font-size="30" text-anchor="middle" fill="#00ff00">+100%</text>
</svg>
"""
        
        # Write the template file
        with open(template_path, "w") as f:
            f.write(svg_content)
    
    def get_available_themes(self):
        """Get list of available meme themes."""
        themes = set()
        for template in self.templates.values():
            metadata = template.get("metadata", {})
            template_themes = metadata.get("themes", [])
            themes.update(template_themes)
        
        # If no themes found, return default list
        if not themes:
            return AVAILABLE_THEMES
        
        return sorted(list(themes))
    
    def get_templates_for_theme(self, theme):
        """Get templates that support a specific theme."""
        matching_templates = {}
        
        for name, template in self.templates.items():
            metadata = template.get("metadata", {})
            template_themes = metadata.get("themes", [])
            
            if theme in template_themes:
                matching_templates[name] = template
        
        # If no matching templates, return all templates
        if not matching_templates:
            return self.templates
        
        return matching_templates
    
    def _generate_top_text(self, token_symbol, token_name, theme, price_change_24h):
        """Generate top text for meme based on theme and token data."""
        # Create a pool of possible texts
        if theme in ["moon_lambo", "to_the_moon"]:
            texts = [
                f"{token_symbol} TO THE MOON!",
                f"HODL {token_symbol} FOREVER",
                f"{token_symbol} GOING PARABOLIC",
                f"WHEN LAMBO? NOW WITH {token_symbol}!"
            ]
        elif theme in ["diamond_hands", "chad_trader"]:
            texts = [
                f"DIAMOND HANDS ON {token_symbol}",
                f"NEVER SELLING MY {token_symbol}",
                f"HODL {token_symbol} LIKE A CHAD",
                f"{token_symbol} WHALES UNITE"
            ]
        elif theme == "bear_market":
            texts = [
                f"BUYING THE {token_symbol} DIP",
                f"BEAR MARKET? BUY {token_symbol}",
                f"TIME TO ACCUMULATE {token_symbol}",
                f"{token_symbol} HODLERS SURVIVE"
            ]
        elif theme == "fud_destroyer":
            texts = [
                f"FUD CAN'T STOP {token_symbol}",
                f"{token_symbol} > FUD",
                f"IGNORE FUD, BUY {token_symbol}",
                f"{token_symbol} COMMUNITY STRONG"
            ]
        else:
            texts = [
                f"{token_symbol} TO THE MOON!",
                f"HODL {token_symbol}",
                f"{token_symbol} IS THE WAY",
                f"{token_symbol} ARMY STRONG"
            ]
        
        # Select a random text
        return random.choice(texts)
    
    def _generate_bottom_text(self, token_symbol, token_name, theme, price_change_24h):
        """Generate bottom text for meme based on theme and token data."""
        # Format percentage
        if price_change_24h > 0:
            price_text = f"UP {price_change_24h:.2f}%"
        else:
            price_text = f"DOWN {abs(price_change_24h):.2f}%"
        
        # Create a pool of possible texts
        if theme in ["moon_lambo", "to_the_moon"]:
            texts = [
                f"NEXT STOP: {price_change_24h*10:.2f}%",
                f"PAPER HANDS REKT",
                f"WAGMI WITH {token_symbol}",
                f"{price_text} TODAY, 1000% SOON"
            ]
        elif theme in ["diamond_hands", "chad_trader"]:
            texts = [
                f"DIAMOND HANDS {price_text}",
                f"HODLERS REWARDED",
                f"PAPER HANDS MISSED OUT",
                f"CHADS ONLY"
            ]
        elif theme == "bear_market":
            texts = [
                f"STILL {price_text} IN A BEAR MARKET",
                f"BEARS GETTING REKT",
                f"ACCUMULATE AND WAIT",
                f"LONG TERM VISION"
            ]
        elif theme == "fud_destroyer":
            texts = [
                f"FUD DESTROYED, {price_text}",
                f"COMMUNITY > FUDDERS",
                f"FUD EXIT LIQUIDITY",
                f"TRUST THE PROJECT"
            ]
        else:
            texts = [
                f"{price_text} AND CLIMBING",
                f"JUST THE BEGINNING",
                f"EARLY ADOPTERS WIN",
                f"HODL FOR GLORY"
            ]
        
        # Select a random text
        return random.choice(texts)
    
    async def generate_token_meme(self, token_address, theme, top_text=None, bottom_text=None, network="ethereum", user_id=None):
        """
        Generate a meme for a specific token.
        
        Args:
            token_address (str): The token contract address
            theme (str): Meme theme
            top_text (str, optional): Top text for the meme
            bottom_text (str, optional): Bottom text for the meme
            network (str): Blockchain network
            user_id (str, optional): Telegram user ID for recording
            
        Returns:
            dict: Generation results with paths to the generated files
        """
        logger.info(f"Generating {theme} meme for token {token_address}")
        
        try:
            # Get token info
            token_info = await get_token_info(token_address, network)
            if not token_info or not token_info.get("fetch_success", False):
                return {
                    "success": False,
                    "error": f"Failed to get token information: {token_info.get('error', 'Unknown error')}"
                }
            
            # Get token data
            token_symbol = token_info.get("symbol", "???")
            token_name = token_info.get("name", "Unknown")
            token_price = token_info.get("price_usd", 0)
            price_change_24h = token_info.get("price_change_24h", 0)
            
            # Format price based on value
            if token_price < 0.000001:
                formatted_price = f"${token_price:.10f}"
            elif token_price < 0.01:
                formatted_price = f"${token_price:.8f}"
            elif token_price < 1:
                formatted_price = f"${token_price:.6f}"
            else:
                formatted_price = f"${token_price:.2f}"
            
            # Format price change
            price_change_color = "#00ff00" if price_change_24h >= 0 else "#ff0000"
            formatted_change = f"{'+' if price_change_24h >= 0 else ''}{price_change_24h:.2f}%"
            
            # Generate default texts if not provided
            if not top_text:
                top_text = self._generate_top_text(token_symbol, token_name, theme, price_change_24h)
            
            if not bottom_text:
                bottom_text = self._generate_bottom_text(token_symbol, token_name, theme, price_change_24h)
            
            # Get templates for the theme
            theme_templates = self.get_templates_for_theme(theme)
            if not theme_templates:
                return {
                    "success": False,
                    "error": f"No templates available for theme '{theme}'"
                }
            
            # Select a random template
            template_name = random.choice(list(theme_templates.keys()))
            template = theme_templates[template_name]
            
            # Clone the template content
            svg_content = template["content"]
            
            # Replace text placeholders
            svg_content = svg_content.replace(">TOP_TEXT<", f">{top_text}<")
            svg_content = svg_content.replace(">BOTTOM_TEXT<", f">{bottom_text}<")
            
            # Replace token placeholders
            svg_content = svg_content.replace(">TOKEN<", f">{token_symbol}<")
            svg_content = svg_content.replace("$0.00000001", formatted_price)
            svg_content = svg_content.replace("+100%", formatted_change)
            
            # Change color of price change text
            svg_content = svg_content.replace('fill="#00ff00">+100%<', f'fill="{price_change_color}">{formatted_change}<')
            
            # Generate filenames
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            random_suffix = ''.join(random.choices('0123456789abcdef', k=6))
            base_filename = f"{token_symbol.lower()}_{theme}_{timestamp}_{random_suffix}"
            svg_filename = f"{base_filename}.svg"
            png_filename = f"{base_filename}.png"
            
            # Save SVG file
            svg_path = os.path.join(GENERATED_MEMES_DIR, svg_filename)
            with open(svg_path, "w") as f:
                f.write(svg_content)
            
            # Convert to PNG with robust fallback mechanisms
            png_path = os.path.join(GENERATED_MEMES_DIR, png_filename)
            conversion_success = convert_svg_to_png(svg_content, png_path)
            
            if not conversion_success:
                # If all conversion methods failed, just copy the SVG
                logger.warning("All PNG conversion methods failed. Using SVG directly.")
                shutil.copy(svg_path, png_path)
            
            # Record in database if user_id provided
            if user_id:
                db.record_generated_meme(
                    user_id,
                    theme,
                    top_text=top_text,
                    bottom_text=bottom_text,
                    token_referenced=token_address,
                    image_path=png_path
                )
            
            # Create image URLs
            image_url = f"/memes/{png_filename}"
            
            return {
                "success": True,
                "token_info": {
                    "symbol": token_symbol,
                    "name": token_name,
                    "price": formatted_price,
                    "price_change_24h": formatted_change
                },
                "meme": {
                    "theme": theme,
                    "top_text": top_text,
                    "bottom_text": bottom_text,
                    "svg_path": svg_path,
                    "png_path": png_path,
                    "image_url": image_url
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating meme: {str(e)}")
            return {
                "success": False,
                "error": f"Meme generation error: {str(e)}"
            }
    
    def generate_custom_meme(self, theme, top_text, bottom_text, user_id=None):
        """
        Generate a custom meme without token data.
        
        Args:
            theme (str): Meme theme
            top_text (str): Top text for the meme
            bottom_text (str): Bottom text for the meme
            user_id (str, optional): Telegram user ID for recording
            
        Returns:
            dict: Generation results with paths to the generated files
        """
        logger.info(f"Generating custom {theme} meme")
        
        try:
            # Get templates for the theme
            theme_templates = self.get_templates_for_theme(theme)
            if not theme_templates:
                return {
                    "success": False,
                    "error": f"No templates available for theme '{theme}'"
                }
            
            # Select a random template
            template_name = random.choice(list(theme_templates.keys()))
            template = theme_templates[template_name]
            
            # Clone the template content
            svg_content = template["content"]
            
            # Replace text placeholders
            svg_content = svg_content.replace(">TOP_TEXT<", f">{top_text}<")
            svg_content = svg_content.replace(">BOTTOM_TEXT<", f">{bottom_text}<")
            
            # Generate filenames
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            random_suffix = ''.join(random.choices('0123456789abcdef', k=6))
            base_filename = f"custom_{theme}_{timestamp}_{random_suffix}"
            svg_filename = f"{base_filename}.svg"
            png_filename = f"{base_filename}.png"
            
            # Save SVG file
            svg_path = os.path.join(GENERATED_MEMES_DIR, svg_filename)
            with open(svg_path, "w") as f:
                f.write(svg_content)
            
            # Convert to PNG with robust fallback mechanisms
            png_path = os.path.join(GENERATED_MEMES_DIR, png_filename)
            conversion_success = convert_svg_to_png(svg_content, png_path)
            
            if not conversion_success:
                # If all conversion methods failed, just copy the SVG
                logger.warning("All PNG conversion methods failed. Using SVG directly.")
                shutil.copy(svg_path, png_path)
            
            # Record in database if user_id provided
            if user_id:
                db.record_generated_meme(
                    user_id,
                    theme,
                    top_text=top_text,
                    bottom_text=bottom_text,
                    image_path=png_path
                )
            
            # Create image URLs
            image_url = f"/memes/{png_filename}"
            
            return {
                "success": True,
                "meme": {
                    "theme": theme,
                    "top_text": top_text,
                    "bottom_text": bottom_text,
                    "svg_path": svg_path,
                    "png_path": png_path,
                    "image_url": image_url
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating custom meme: {str(e)}")
            return {
                "success": False,
                "error": f"Meme generation error: {str(e)}"
            }

# Initialize the meme generator
meme_generator = MemeGenerator()