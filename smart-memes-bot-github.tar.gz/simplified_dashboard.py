"""
Simplified dashboard for Smart Memes Bot.
This is a stripped-down version to avoid JSON serialization issues.
"""
import os
import logging
import time
from datetime import datetime
from flask import Flask, render_template, redirect, url_for

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key") 

# Create custom filter for time ago formatting
@app.template_filter('timeago')
def timeago_filter(timestamp):
    """Convert a timestamp to a 'time ago' string."""
    if not timestamp:
        return "Never"
    
    now = time.time()
    diff = now - timestamp
    
    if diff < 60:
        return "Just now"
    elif diff < 3600:
        minutes = int(diff / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif diff < 86400:
        hours = int(diff / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif diff < 2592000:
        days = int(diff / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    else:
        months = int(diff / 2592000)
        return f"{months} month{'s' if months != 1 else ''} ago"

@app.template_filter('first')
def first_filter(value):
    """Return the first item in a list or string."""
    if not value:
        return ""
    if hasattr(value, "__getitem__") and len(value) > 0:
        return value[0]
    return ""

@app.template_filter('last')
def last_filter(value):
    """Return the last item in a list or string."""
    if not value:
        return ""
    if hasattr(value, "__getitem__") and len(value) > 0:
        return value[len(value) - 1]
    return ""

# Create custom filter for timestamp formatting
@app.template_filter('timestampformat')
def timestampformat_filter(timestamp):
    """Format a timestamp as a readable date/time."""
    if not timestamp:
        return "N/A"
    
    try:
        return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")
    except:
        return "Invalid date"

@app.route('/')
def index():
    """Render the main landing page."""
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """Render the fully static dashboard HTML."""
    try:
        # Using a completely static dashboard template to avoid any JSON serialization issues
        return render_template('static_dashboard.html')
    except Exception as e:
        logger.error(f"Error loading dashboard: {str(e)}")
        return render_template(
            'error.html', 
            error=f"Error loading static dashboard: {str(e)}",
            details="Please try again later or contact support if the issue persists."
        )

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)