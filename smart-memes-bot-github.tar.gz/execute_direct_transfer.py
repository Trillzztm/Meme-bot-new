#!/usr/bin/env python3
"""
Execute Direct Transfer - SMART MEMES BOT

This script provides a direct interface to execute transfers and trades on Solana.
It leverages real transaction signing for Phantom wallet operations.
"""

import os
import json
import time
import argparse
import base58
import logging
from typing import Dict, Any, Optional

# Import Solana libraries
from solana.rpc.api import Client
from solana.transaction import Transaction
from solana.system_program import transfer, TransferParams
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.rpc.types import TxOpts

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ExecuteDirectTransfer")

# Constants
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")
TRANSACTION_HISTORY_FILE = "real_transactions.json"

# Initialize Solana client
client = Client(SOLANA_RPC_URL)

def load_keypair() -> Optional[Keypair]:
    """
    Load Solana keypair from private key environment variable
    
    Returns:
        Keypair or None if not available
    """
    if not SOLANA_PRIVATE_KEY:
        logger.error("SOLANA_PRIVATE_KEY environment variable not set")
        return None
    
    try:
        # Convert from base58
        private_key_bytes = base58.b58decode(SOLANA_PRIVATE_KEY)
        return Keypair.from_secret_key(private_key_bytes)
    except Exception as e:
        logger.error(f"Error loading keypair: {e}")
        return None

def get_wallet_address() -> Optional[str]:
    """
    Get wallet address from private key
    
    Returns:
        Wallet address or None if private key not available
    """
    keypair = load_keypair()
    if not keypair:
        return None
    
    return str(keypair.public_key)

def get_sol_balance() -> Dict[str, Any]:
    """
    Get SOL balance for the wallet
    
    Returns:
        Dict with balance information
    """
    wallet_address = get_wallet_address()
    if not wallet_address:
        return {"error": "No wallet address available"}
    
    try:
        response = client.get_balance(PublicKey(wallet_address))
        if "result" in response and "value" in response["result"]:
            balance_lamports = response["result"]["value"]
            balance_sol = balance_lamports / 10**9
            
            # For simplicity, assume $100 per SOL
            sol_price_usd = 100.0
            
            return {
                "address": wallet_address,
                "balance_lamports": balance_lamports,
                "balance_sol": balance_sol,
                "balance_usd": balance_sol * sol_price_usd
            }
        else:
            return {"error": f"Failed to get balance: {response}"}
    except Exception as e:
        logger.error(f"Error getting SOL balance: {e}")
        return {"error": str(e)}

def execute_sol_transfer(to_address: str, sol_amount: float) -> Dict[str, Any]:
    """
    Execute a direct SOL transfer
    
    Args:
        to_address: Destination wallet address
        sol_amount: Amount of SOL to transfer
        
    Returns:
        Dict with transfer result
    """
    keypair = load_keypair()
    if not keypair:
        return {"error": "No private key available for signing"}
    
    try:
        # Convert SOL to lamports
        lamports = int(sol_amount * 10**9)
        
        # Create a transfer instruction
        transfer_instruction = transfer(
            TransferParams(
                from_pubkey=keypair.public_key,
                to_pubkey=PublicKey(to_address),
                lamports=lamports
            )
        )
        
        # Create a transaction
        transaction = Transaction().add(transfer_instruction)
        
        # Sign and send the transaction
        logger.info(f"Sending {sol_amount} SOL to {to_address}")
        
        opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
        result = client.send_transaction(transaction, keypair, opts=opts)
        
        if "result" in result:
            tx_hash = result["result"]
            logger.info(f"Transfer sent: {tx_hash}")
            
            # Record the transaction
            record_transaction(tx_hash, sol_amount, to_address)
            
            # Wait for confirmation
            logger.info("Waiting for confirmation...")
            time.sleep(5)
            
            # Check transaction status
            status = client.confirm_transaction(tx_hash)
            
            if status and status.get("result", {}).get("value", {}).get("err") is None:
                logger.info(f"Transfer confirmed: {tx_hash}")
                return {
                    "success": True,
                    "tx_hash": tx_hash,
                    "amount_sol": sol_amount,
                    "to_address": to_address,
                    "confirmed": True
                }
            else:
                logger.warning(f"Transfer may have failed: {tx_hash}")
                return {
                    "success": True,  # We got a transaction hash
                    "tx_hash": tx_hash,
                    "amount_sol": sol_amount,
                    "to_address": to_address,
                    "confirmed": False,
                    "error": "Transfer may have failed"
                }
        else:
            error_msg = f"Error sending transfer: {result}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error executing transfer: {e}")
        return {"error": str(e)}

def record_transaction(tx_hash: str, sol_amount: float, to_address: str) -> None:
    """
    Record a transaction in the history file
    
    Args:
        tx_hash: Transaction hash
        sol_amount: SOL amount transferred
        to_address: Recipient address
    """
    # Load existing transactions
    transactions = []
    if os.path.exists(TRANSACTION_HISTORY_FILE):
        try:
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                transactions = json.load(f)
        except Exception as e:
            logger.error(f"Error loading transaction history: {e}")
    
    # Create transaction record
    transaction = {
        "timestamp": time.time(),
        "tx_hash": tx_hash,
        "amount_sol": sol_amount,
        "to_address": to_address,
        "from_address": get_wallet_address(),
        "type": "transfer",
        "real_transaction": True
    }
    
    # Add to list
    transactions.append(transaction)
    
    # Save updated list
    try:
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(transactions, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving transaction history: {e}")

def run_direct_transfer(args):
    """
    Run a direct SOL transfer based on command-line arguments
    
    Args:
        args: Command-line arguments
    """
    # Get balance
    balance = get_sol_balance()
    
    if "error" in balance:
        print(f"Error getting balance: {balance['error']}")
        return
    
    sol_balance = balance["balance_sol"]
    
    # Check if we have enough SOL
    if sol_balance < args.amount:
        print(f"Error: Insufficient SOL balance ({sol_balance} SOL) for transfer of {args.amount} SOL")
        return
    
    # Show information
    print(f"From: {balance['address']}")
    print(f"To: {args.to_address}")
    print(f"Amount: {args.amount} SOL")
    print(f"Current balance: {sol_balance} SOL")
    print(f"Balance after transfer: {sol_balance - args.amount} SOL")
    
    # Confirm with user
    if not args.yes:
        confirm = input("Execute this transfer? (y/n): ")
        if confirm.lower() != "y":
            print("Transfer cancelled")
            return
    
    # Execute the transfer
    print("Executing transfer...")
    result = execute_sol_transfer(args.to_address, args.amount)
    
    if "error" in result:
        print(f"Error executing transfer: {result['error']}")
    elif result.get("success"):
        print(f"Transfer submitted successfully!")
        print(f"Transaction hash: {result['tx_hash']}")
        print(f"Status: {'Confirmed' if result.get('confirmed') else 'Pending confirmation'}")
        
        if result.get("confirmed"):
            print(f"Amount: {args.amount} SOL")
            print(f"To: {args.to_address}")
    else:
        print(f"Transfer failed: {result}")

def check_environment():
    """Check for required environment variables"""
    if not SOLANA_PRIVATE_KEY:
        print("ERROR: SOLANA_PRIVATE_KEY environment variable not set.")
        print("Please set your private key before running this script:")
        print("export SOLANA_PRIVATE_KEY=your_private_key")
        return False
    
    return True

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Execute direct SOL transfer")
    parser.add_argument("to_address", help="Destination wallet address")
    parser.add_argument("amount", type=float, help="Amount of SOL to transfer")
    parser.add_argument("--yes", "-y", action="store_true", help="Execute without confirmation")
    
    args = parser.parse_args()
    
    # Check environment
    if not check_environment():
        return
    
    # Run the direct transfer
    run_direct_transfer(args)

if __name__ == "__main__":
    main()