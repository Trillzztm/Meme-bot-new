"""
Main entry point for SMART MEMES BOT.

This is the main entry point for the bot. It sets up and runs the bot with
all the necessary handlers and utilities.
"""

import logging
import os
import sys
from typing import Any

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Import configuration
from config import BOT_TOKEN


def main():
    """Main function to run the bot."""
    logger.info("Starting SMART MEMES BOT")
    
    # Get token from environment or config
    token = os.environ.get("TELEGRAM_BOT_TOKEN", BOT_TOKEN)
    if not token:
        logger.error("No bot token found. Please set TELEGRAM_BOT_TOKEN environment variable.")
        sys.exit(1)
    
    try:
        # Try to run the standard bot first
        bot = setup_standard_bot(token)
        logger.info("Running standard bot")
        bot.run_polling()
    except Exception as e:
        logger.error(f"Error running standard bot: {e}")
        logger.info("Falling back to simplified bot")
        
        try:
            # Fall back to the simplified bot
            bot = setup_simplified_bot(token)
            logger.info("Running simplified bot")
            bot.start()
        except Exception as e2:
            logger.error(f"Error running simplified bot: {e2}")
            sys.exit(1)


def setup_standard_bot(token):
    """Set up the standard Telegram bot with all handlers."""
    try:
        from telegram.ext import ApplicationBuilder, CommandHandler
        
        # Import all handlers
        from handlers import (
            start, help, manualsnipe, tokeninfo, watchgroup,
            tokensafety, trackwallet, autosnipe, generateprememe,
            marketpredict
        )
        
        # Create the Application
        app = ApplicationBuilder().token(token).build()
        
        # Add command handlers - Basic commands
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("help", help))
        
        # Token information and analysis
        app.add_handler(CommandHandler("tokeninfo", tokeninfo))
        app.add_handler(CommandHandler("tokensafety", tokensafety))
        app.add_handler(CommandHandler("marketpredict", marketpredict))
        
        # Trading commands
        app.add_handler(CommandHandler("manualsnipe", manualsnipe))
        app.add_handler(CommandHandler("autosnipe", autosnipe))
        
        # Monitoring commands
        app.add_handler(CommandHandler("watchgroup", watchgroup))
        app.add_handler(CommandHandler("trackwallet", trackwallet))
        
        # Content generation
        app.add_handler(CommandHandler("generateprememe", generateprememe))
        
        # Add error handler
        app.add_error_handler(error_handler)
        
        logger.info("Standard bot setup completed")
        return app
    except Exception as e:
        logger.error(f"Failed to set up standard bot: {e}")
        raise


def setup_simplified_bot(token):
    """Set up the simplified bot implementation."""
    try:
        from simple_bot import SimpleTelegramBot
        
        # Create the bot
        bot = SimpleTelegramBot(token)
        
        logger.info("Simplified bot setup completed")
        return bot
    except Exception as e:
        logger.error(f"Failed to set up simplified bot: {e}")
        raise


async def error_handler(update: Any, context: Any):
    """Handle errors in the Telegram bot."""
    from telegram import Update
    
    logger.error("Exception while handling an update:", exc_info=context.error)
    
    # Send error message to user if possible
    if update and isinstance(update, Update) and update.effective_chat:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="An error occurred while processing your request. Please try again later."
        )


if __name__ == "__main__":
    main()