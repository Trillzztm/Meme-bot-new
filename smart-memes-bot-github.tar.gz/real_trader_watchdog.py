#!/usr/bin/env python3
"""
SMART MEMES BOT - Real Trader Watchdog

This script monitors and restarts the real trader if it crashes,
ensuring 24/7 operation without interruption.
"""

import os
import sys
import time
import logging
import subprocess
import signal
import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("watchdog.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("RealTraderWatchdog")

# Constants
CHECK_INTERVAL = 60  # Check every 60 seconds
MAX_RESTARTS = 9999  # Basically unlimited restarts
TRADER_SCRIPT = "real_trader_24_7.py"
PID_FILE = "trader_24_7.pid"

# Exit flag for graceful shutdown
exit_flag = False

def signal_handler(sig, frame):
    """Handle SIGINT/SIGTERM signals for graceful shutdown"""
    global exit_flag
    logger.info("Watchdog shutdown signal received.")
    exit_flag = True

def is_process_running(pid):
    """Check if a process with the given PID is running"""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def read_pid_file():
    """Read the PID from the PID file"""
    if not os.path.exists(PID_FILE):
        return None
    
    try:
        with open(PID_FILE, 'r') as f:
            pid = int(f.read().strip())
        return pid
    except Exception as e:
        logger.error(f"Error reading PID file: {e}")
        return None

def start_trader():
    """Start the real trader process"""
    logger.info("Starting Real Money Trader")
    
    try:
        # Start the trader process
        process = subprocess.Popen(
            ["python", TRADER_SCRIPT],
            stdout=open("trader_24_7.out", "a"),
            stderr=open("trader_24_7.err", "a"),
            start_new_session=True
        )
        
        # Write PID to file
        pid = process.pid
        with open(PID_FILE, 'w') as f:
            f.write(str(pid))
        
        logger.info(f"Wrote PID {pid} to {PID_FILE}")
        logger.info(f"Started Real Money Trader with PID {pid}")
        
        # Send a Telegram notification if possible
        try:
            send_telegram_notification(f"Real Money Trader restarted with PID {pid}")
        except:
            pass
        
        return pid
    
    except Exception as e:
        logger.error(f"Error starting Real Money Trader: {e}")
        return None

def send_telegram_notification(message):
    """Send a notification via Telegram"""
    try:
        import requests
        
        # Get Telegram bot token and chat ID from environment variables
        token = os.environ.get("TELEGRAM_BOT_TOKEN")
        chat_id = os.environ.get("TELEGRAM_CHAT_ID", "6915721378")  # Default fallback
        
        if not token:
            return False
        
        # Send the message
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": f"SMART MEMES BOT: {message}",
            "parse_mode": "Markdown"
        }
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            logger.info("Telegram notification sent successfully")
            return True
        else:
            logger.warning(f"Failed to send Telegram notification: {response.text}")
            return False
    
    except Exception as e:
        logger.warning(f"Error sending Telegram notification: {e}")
        return False

def main():
    """Main entry point for the watchdog"""
    logger.info("Starting Watchdog for Real Money Trader")
    
    # Set up signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Send startup notification
    try:
        send_telegram_notification("Real Money Trader Watchdog started")
    except:
        pass
    
    restart_count = 0
    
    # Monitor and restart the trader as needed
    while not exit_flag and restart_count < MAX_RESTARTS:
        # Check if the trader is running
        pid = read_pid_file()
        
        if pid and is_process_running(pid):
            logger.info(f"Real Money Trader process with PID {pid} is running")
        else:
            if pid:
                logger.warning(f"Real Money Trader process with PID {pid} is not running")
            else:
                logger.warning("No PID file found for Real Money Trader")
            
            # Start the trader
            new_pid = start_trader()
            if new_pid:
                restart_count += 1
                logger.info(f"Restart count: {restart_count}/{MAX_RESTARTS}")
            else:
                logger.error("Failed to start Real Money Trader")
        
        # Wait before checking again
        for _ in range(CHECK_INTERVAL):
            if exit_flag:
                break
            time.sleep(1)
    
    logger.info("Watchdog shutting down")

if __name__ == "__main__":
    main()