#!/usr/bin/env python3
"""
Simple Trading Script for Jupiter DEX

This script provides a simplified way to trade on Jupiter DEX using 
your Solana wallet. It focuses on core functionality without complex dependencies.
"""

import os
import json
import time
import base64
import base58
import logging
import requests
import argparse
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SimpleTrade")

# Constants
JUPITER_API_URL = "https://quote-api.jup.ag/v6"
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
TRANSACTION_HISTORY_FILE = "jupiter_simple_trades.json"

# Token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
JTO_MINT = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"

# Map of token symbols to addresses
TOKEN_MAP = {
    "SOL": SOL_MINT,
    "USDC": USDC_MINT,
    "BONK": BONK_MINT,
    "WIF": WIF_MINT,
    "JTO": JTO_MINT
}

def get_quote(input_mint: str, output_mint: str, amount: int, slippage_bps: int = 50) -> Dict[str, Any]:
    """
    Get a quote from Jupiter API
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        Dict with quote information
    """
    try:
        url = f"{JUPITER_API_URL}/quote"
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": str(amount),
            "slippageBps": slippage_bps
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"Error {response.status_code}: {response.text}"}
    except Exception as e:
        return {"error": f"Exception: {str(e)}"}

def get_wallet_address() -> Optional[str]:
    """Get wallet address from private key"""
    private_key = os.environ.get("SOLANA_PRIVATE_KEY")
    if not private_key:
        return None
    
    # In a real implementation, we would derive the public key from the private key
    # For simplicity, let's use a placeholder method
    return "GWrigDjL6HsYvK32y5b7ZzwTH8Vw1ZR2miN5jMLrM8f1"

def get_wallet_balance() -> Dict[str, Any]:
    """Get wallet SOL balance"""
    wallet_address = get_wallet_address()
    if not wallet_address:
        return {"error": "No wallet address available"}
    
    try:
        url = SOLANA_RPC_URL
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBalance",
            "params": [wallet_address]
        }
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            if "result" in data and "value" in data["result"]:
                lamports = data["result"]["value"]
                sol = lamports / 10**9
                return {
                    "address": wallet_address,
                    "balance_lamports": lamports,
                    "balance_sol": sol,
                    "balance_usd": sol * 100  # Assuming $100 per SOL
                }
        
        return {"error": "Failed to get balance"}
    except Exception as e:
        return {"error": f"Exception: {str(e)}"}

def get_token_price(input_token: str, output_token: str = "USDC", amount: float = 1.0) -> Dict[str, Any]:
    """
    Get token price in terms of another token
    
    Args:
        input_token: Input token symbol or address
        output_token: Output token symbol or address
        amount: Amount of input token
        
    Returns:
        Dict with price information
    """
    # Resolve token addresses
    input_mint = TOKEN_MAP.get(input_token.upper(), input_token)
    output_mint = TOKEN_MAP.get(output_token.upper(), output_token)
    
    # Determine amount in smallest units
    input_decimals = 9  # Default for most tokens
    if input_token.upper() == "USDC":
        input_decimals = 6
    
    amount_smallest = int(amount * 10**input_decimals)
    
    # Get quote
    quote = get_quote(input_mint, output_mint, amount_smallest)
    
    if "error" in quote:
        return quote
    
    # Calculate price
    output_decimals = 9  # Default for most tokens
    if output_token.upper() == "USDC":
        output_decimals = 6
    
    output_amount = int(quote.get("outputAmount", 0))
    output_value = output_amount / 10**output_decimals
    
    return {
        "input_token": input_token,
        "output_token": output_token,
        "input_amount": amount,
        "output_amount": output_value,
        "price": output_value / amount if amount > 0 else 0,
        "price_impact_pct": quote.get("priceImpactPct", 0) * 100
    }

def generate_jupiter_swap_link(
    input_token: str,
    output_token: str,
    amount: float
) -> str:
    """
    Generate a Jupiter swap link
    
    Args:
        input_token: Input token symbol or address
        output_token: Output token symbol or address
        amount: Amount of input token
        
    Returns:
        str: Jupiter swap link
    """
    # Resolve token addresses
    input_mint = TOKEN_MAP.get(input_token.upper(), input_token)
    output_mint = TOKEN_MAP.get(output_token.upper(), output_token)
    
    # Construct URL with parameters
    url = f"https://jup.ag/swap/{input_token}-{output_token}?inputMint={input_mint}&outputMint={output_mint}&amount={amount}"
    
    return url

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Simple Trading Script for Jupiter DEX")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Balance command
    balance_parser = subparsers.add_parser("balance", help="Check wallet balance")
    
    # Price command
    price_parser = subparsers.add_parser("price", help="Get token price")
    price_parser.add_argument("token", help="Token symbol or address")
    price_parser.add_argument("--quote-token", default="USDC", help="Quote token (default: USDC)")
    price_parser.add_argument("--amount", type=float, default=1.0, help="Token amount (default: 1.0)")
    
    # Link command
    link_parser = subparsers.add_parser("link", help="Generate Jupiter swap link")
    link_parser.add_argument("from_token", help="From token symbol or address")
    link_parser.add_argument("to_token", help="To token symbol or address")
    link_parser.add_argument("--amount", type=float, default=1.0, help="Token amount (default: 1.0)")
    
    args = parser.parse_args()
    
    # Execute command
    if args.command == "balance":
        balance = get_wallet_balance()
        
        if "error" in balance:
            print(f"Error: {balance['error']}")
        else:
            print(f"Wallet: {balance['address']}")
            print(f"Balance: {balance['balance_sol']} SOL (${balance['balance_usd']:.2f})")
    
    elif args.command == "price":
        price = get_token_price(args.token, args.quote_token, args.amount)
        
        if "error" in price:
            print(f"Error: {price['error']}")
        else:
            print(f"Price: {price['price']:.6f} {args.quote_token} per {args.token}")
            print(f"{args.amount} {args.token} = {price['output_amount']:.6f} {args.quote_token}")
            print(f"Price impact: {price['price_impact_pct']:.2f}%")
    
    elif args.command == "link":
        link = generate_jupiter_swap_link(args.from_token, args.to_token, args.amount)
        print(f"Jupiter swap link:")
        print(link)
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()