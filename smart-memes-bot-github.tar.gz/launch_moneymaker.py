"""
Launch Money Maker Script for SMART MEMES BOT

This script serves as the main entry point for the SMART MEMES BOT money making system.
It starts all necessary components including the web dashboard, trading engine,
and Jupiter connectivity.
"""

import os
import sys
import time
import logging
import threading
import subprocess
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("LaunchMoneyMaker")

# Import our trading components
from phantom_direct_connector import connect_phantom_wallet, get_wallet_balance
import start_trading

def ensure_environment():
    """Make sure the environment is properly set up"""
    # Check for essential environment variables
    solana_key = os.environ.get("SOLANA_PRIVATE_KEY")
    
    if not solana_key:
        logger.warning("SOLANA_PRIVATE_KEY environment variable not found.")
        logger.warning("The bot will run in simulation mode only.")
        return False
    
    return True

def start_dashboard():
    """Start the money dashboard web interface"""
    logger.info("Starting Money Dashboard...")
    
    try:
        # Start the dashboard in a separate process
        process = subprocess.Popen(
            [sys.executable, "money_dashboard.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Check if it started successfully
        time.sleep(2)
        if process.poll() is None:
            logger.info("Money Dashboard started successfully")
            return process
        else:
            stdout, stderr = process.communicate()
            logger.error(f"Failed to start Money Dashboard: {stderr.decode()}")
            return None
    except Exception as e:
        logger.error(f"Error starting Money Dashboard: {e}")
        return None

def main():
    """Main entry point"""
    print("================================")
    print("SMART MEMES BOT - Money Maker")
    print("================================")
    print("\nInitializing system...")
    
    # Ensure the environment is set up
    if not ensure_environment():
        print("\nWARNING: Running in simulation mode only")
        print("For full functionality, please set the SOLANA_PRIVATE_KEY environment variable")
    
    # Connect to wallet
    print("\nConnecting to Phantom wallet...")
    wallet_connected = connect_phantom_wallet()
    
    if wallet_connected:
        print("Wallet connected successfully!")
        
        # Display wallet balance
        balance = get_wallet_balance()
        print(f"Current wallet balance: {balance.get('balance_sol', 0)} SOL (${balance.get('balance_usd', 0):.2f})")
    else:
        print("Failed to connect to wallet. Please check your configuration.")
        return
    
    # Start the money dashboard
    print("\nStarting Money Dashboard...")
    dashboard_process = start_dashboard()
    
    if dashboard_process:
        print("Money Dashboard started successfully!")
        print("Access it at: http://localhost:8080")
    else:
        print("Failed to start Money Dashboard")
        return
    
    # Start trading
    print("\nStarting automated trading...")
    trading_started = start_trading.start_trading()
    
    if trading_started:
        print("Automated trading started successfully!")
    else:
        print("Failed to start automated trading")
        dashboard_process.terminate()
        return
    
    # Keep running until interrupted
    print("\nSMART MEMES BOT is now running")
    print("Press Ctrl+C to stop")
    
    try:
        while True:
            # Keep the main thread alive
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down SMART MEMES BOT...")
        
        # Stop trading
        start_trading.stop_trading()
        
        # Stop dashboard
        dashboard_process.terminate()
        
        print("SMART MEMES BOT stopped")

if __name__ == "__main__":
    main()