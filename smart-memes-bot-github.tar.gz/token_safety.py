"""
Functions for checking token safety and identifying potential risks.
"""
import logging
import aiohttp
from config import ETHERSCAN_API_KEY, ETHERSCAN_API_URL, MINIMUM_TOKEN_AGE_DAYS
import utils

logger = logging.getLogger(__name__)

async def check_token_safety(token_address):
    """
    Perform a comprehensive safety check for a token.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        tuple: A tuple containing (safety_score, list_of_issues)
    """
    logger.info(f"Checking token safety for {token_address}")
    
    # Initialize variables
    safety_score = 100
    safety_issues = []
    
    try:
        # Get token contract code to analyze
        contract_code = await get_contract_code(token_address)
        
        # Check if contract is verified
        if not contract_code:
            safety_score -= 30
            safety_issues.append("Contract is not verified - cannot analyze code")
        else:
            # Check for potential red flags in the contract code
            contract_flags = check_contract_for_red_flags(contract_code)
            
            for flag, penalty in contract_flags:
                safety_score -= penalty
                safety_issues.append(flag)
        
        # Check token age
        token_age_days = await get_token_age(token_address)
        if token_age_days < MINIMUM_TOKEN_AGE_DAYS:
            penalty = min(20, max(5, 20 - token_age_days * 5))
            safety_score -= penalty
            safety_issues.append(f"Token is very new ({token_age_days} days old)")
        
        # Check liquidity
        liquidity_locked, lock_details = await check_liquidity_lock(token_address)
        if not liquidity_locked:
            safety_score -= 15
            safety_issues.append("Liquidity does not appear to be locked - high risk of rug pull")
        
        # Check ownership
        ownership_renounced = await check_ownership_renounced(token_address)
        if not ownership_renounced:
            safety_score -= 10
            safety_issues.append("Contract ownership is not renounced - owner can modify contract")
        
        # Check holder distribution
        large_holder_risk, holder_details = await check_holder_distribution(token_address)
        if large_holder_risk > 0:
            safety_score -= large_holder_risk
            safety_issues.append(holder_details)
        
        # Check for honeypot potential
        is_potential_honeypot, honeypot_details = check_for_honeypot(contract_code)
        if is_potential_honeypot:
            safety_score -= 25
            safety_issues.append(f"Potential honeypot detected: {honeypot_details}")
        
        # Ensure score stays in range 0-100
        safety_score = max(0, min(100, safety_score))
        
        return safety_score, safety_issues
    
    except Exception as e:
        logger.error(f"Error checking token safety: {str(e)}")
        safety_score = 30  # Low default score due to failure
        safety_issues.append("Error during safety check - proceed with extreme caution")
        return safety_score, safety_issues

async def get_contract_code(token_address):
    """
    Get the source code of a token contract.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        str: The source code or empty string if not verified
    """
    try:
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "contract",
                "action": "getsourcecode",
                "address": token_address,
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1" and data["result"]:
                        if data["result"][0].get("SourceCode", ""):
                            return data["result"][0]["SourceCode"]
        
        return ""
    
    except Exception as e:
        logger.error(f"Error getting contract code: {str(e)}")
        return ""

def check_contract_for_red_flags(contract_code):
    """
    Check a contract's source code for potential red flags.
    
    Args:
        contract_code (str): The contract source code
        
    Returns:
        list: A list of tuples (flag_description, penalty_score)
    """
    red_flags = []
    contract_code_lower = contract_code.lower()
    
    # Check for common red flags in smart contracts
    
    # Backdoor functions
    if "_approve" in contract_code_lower and "owner" in contract_code_lower:
        red_flags.append(("Potential backdoor in approval function", 15))
    
    # High transfer fees
    if "fee" in contract_code_lower and any(x in contract_code_lower for x in ["20%", "30%", "40%", "50%"]):
        red_flags.append(("Extremely high transfer fees detected", 10))
    
    # Blacklist functionality
    if "blacklist" in contract_code_lower:
        red_flags.append(("Blacklist function detected - could prevent selling", 10))
    
    # Max transaction limits
    if "maxTransactionAmount" in contract_code or "maxTxAmount" in contract_code:
        red_flags.append(("Max transaction amount limits detected - could restrict selling", 5))
    
    # Mint functions
    if "mint" in contract_code_lower and "onlyOwner" in contract_code_lower:
        red_flags.append(("Owner can mint new tokens - potential for infinite inflation", 15))
    
    # Trading limitations
    trading_limits = ["canTrade", "tradingEnabled", "enableTrading"]
    if any(limit in contract_code for limit in trading_limits):
        red_flags.append(("Trading can be enabled/disabled by owner", 10))
    
    # Proxy patterns that allow contract upgrades
    if "upgradeable" in contract_code_lower or "proxy" in contract_code_lower:
        red_flags.append(("Contract is upgradeable - functionality can change", 10))
    
    return red_flags

async def get_token_age(token_address):
    """
    Determine the age of a token in days.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        int: The token age in days
    """
    try:
        # Get the first transaction to the contract to estimate creation date
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "account",
                "action": "txlist",
                "address": token_address,
                "sort": "asc",
                "page": 1,
                "offset": 1,
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1" and data["result"]:
                        # Get timestamp of first transaction
                        creation_timestamp = int(data["result"][0]["timeStamp"])
                        return utils.calculate_days_since(creation_timestamp)
        
        return 0  # Default to 0 if we can't determine the age
    
    except Exception as e:
        logger.error(f"Error getting token age: {str(e)}")
        return 0

async def check_liquidity_lock(token_address):
    """
    Check if a token's liquidity is locked.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        tuple: (is_locked, details)
    """
    # In a real implementation, you would check known liquidity lockers
    # or analyze transactions to LP token contracts
    # This is a simplified simulation
    import random
    
    is_locked = random.choice([True, False])
    
    if is_locked:
        lock_duration = random.randint(30, 365)
        return True, f"Liquidity locked for {lock_duration} days"
    else:
        return False, "No liquidity lock detected"

async def check_ownership_renounced(token_address):
    """
    Check if ownership of the token contract has been renounced.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        bool: True if ownership is renounced, False otherwise
    """
    # In a real implementation, you would check if the owner address is the zero address
    # This is a simplified simulation
    import random
    return random.choice([True, False])

async def check_holder_distribution(token_address):
    """
    Check the distribution of token holders for centralization risks.
    
    Args:
        token_address (str): The token contract address
        
    Returns:
        tuple: (risk_score, details)
    """
    # In a real implementation, you would query token holders and their balances
    # This is a simplified simulation
    import random
    
    risk_levels = [
        (0, "Healthy holder distribution with no large concentrated wallets"),
        (5, "A few large holders control 20-30% of supply"),
        (10, "Concerning concentration with 3-5 wallets holding 50%+ of supply"),
        (15, "High risk - single wallet holds over 30% of supply")
    ]
    
    return random.choice(risk_levels)

def check_for_honeypot(contract_code):
    """
    Check if a contract might be a honeypot (allows buys but not sells).
    
    Args:
        contract_code (str): The contract source code
        
    Returns:
        tuple: (is_potential_honeypot, details)
    """
    if not contract_code:
        return False, ""
    
    contract_code_lower = contract_code.lower()
    
    # Look for common honeypot patterns
    honeypot_indicators = [
        ("buy" in contract_code_lower and "sell" not in contract_code_lower, 
         "Contract has buy function but no sell function"),
        ("sellEnabled" in contract_code_lower, 
         "Selling can be disabled by contract owner"),
        ("_transfer" in contract_code_lower and "require(" in contract_code_lower and "sell" in contract_code_lower,
         "Contract may have special restrictions on sell transfers")
    ]
    
    for indicator, details in honeypot_indicators:
        if indicator:
            return True, details
    
    return False, ""
