#!/bin/bash

echo "==============================================="
echo "SMART MEMES BOT - STOP REAL TRADING"
echo "==============================================="
echo

if [ -f trader.pid ]; then
    PID=$(cat trader.pid)
    if ps -p $PID > /dev/null; then
        echo "Stopping Real Blockchain Trader (PID: $PID)"
        kill $PID
        echo "✅ Real Blockchain Trader stopped successfully"
    else
        echo "Trader process not found. It may have already stopped."
    fi
    rm trader.pid
else
    echo "No trader.pid file found. Stopping any running instances..."
    pkill -f real_trader.py
fi

echo "✅ Cleaned up all trading processes"
echo
echo "==============================================="