#!/bin/bash

echo "==============================================="
echo "SMART MEMES BOT - START REAL TRADER WATCHDOG"
echo "==============================================="
echo

# Clean up any existing watchdog processes
pkill -f real_trader_watchdog.py > /dev/null 2>&1
echo "✅ Cleaned up any previous watchdog processes"

# Start the watchdog script
nohup python real_trader_watchdog.py > watchdog.out 2> watchdog.err &
PID=$!
echo $PID > watchdog.pid
echo "✅ Started Real Money Trader Watchdog with PID: $PID"

echo
echo "💰 Your REAL MONEY trading is now protected 24/7!"
echo
echo "📱 The watchdog will:"
echo "   - Monitor your Real Money Trader continuously"
echo "   - Automatically restart it if it crashes"
echo "   - Send Telegram notifications about restarts"
echo
echo "⚠️ To stop the watchdog run: ./stop_real_trader_watchdog.sh"
echo
echo "==============================================="