from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Database setup
db = SQLAlchemy()

class ProfitLog(db.Model):
    """
    Model to track trade profits.
    """
    id = db.Column(db.Integer, primary_key=True)
    token_address = db.Column(db.String(48), nullable=False)
    market_address = db.Column(db.String(48), nullable=False)
    buy_price = db.Column(db.Float, nullable=False)
    buy_amount_sol = db.Column(db.Float, nullable=False)
    buy_timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    buy_tx = db.Column(db.String(96), nullable=True)
    size = db.Column(db.Float, nullable=False)
    sold = db.Column(db.Boolean, default=False)
    sell_price = db.Column(db.Float, nullable=True)
    sell_timestamp = db.Column(db.DateTime, nullable=True)
    sell_tx = db.Column(db.String(96), nullable=True)
    profit_sol = db.Column(db.Float, nullable=True)
    profit_percent = db.Column(db.Float, nullable=True)
    source = db.Column(db.String(32), nullable=True)  # e.g., "manual", "auto", "telegram"
    
    def save(self):
        """Convenience method to save the model to the database."""
        db.session.add(self)
        db.session.commit()
    
    def calculate_profit(self):
        """Calculate profit in SOL and percent."""
        if self.sold and self.sell_price:
            self.profit_sol = (self.sell_price * self.size) - self.buy_amount_sol
            self.profit_percent = (self.profit_sol / self.buy_amount_sol) * 100
            return self.profit_sol, self.profit_percent
        return None, None

class Token(db.Model):
    """
    Model to store token information.
    """
    id = db.Column(db.Integer, primary_key=True)
    address = db.Column(db.String(48), unique=True, nullable=False)
    name = db.Column(db.String(128), nullable=True)
    symbol = db.Column(db.String(32), nullable=True)
    decimals = db.Column(db.Integer, nullable=True)
    total_supply = db.Column(db.BigInteger, nullable=True)
    last_price_sol = db.Column(db.Float, nullable=True)
    last_price_usd = db.Column(db.Float, nullable=True)
    price_change_24h = db.Column(db.Float, nullable=True)
    volume_24h = db.Column(db.Float, nullable=True)
    liquidity = db.Column(db.Float, nullable=True)
    market_cap = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    ai_risk_score = db.Column(db.Integer, nullable=True)  # 1-10, 10 being highest risk
    ai_analysis = db.Column(db.Text, nullable=True)
    social_sentiment = db.Column(db.Text, nullable=True)
    
    def save(self):
        """Convenience method to save the model to the database."""
        db.session.add(self)
        db.session.commit()

class TelegramGroup(db.Model):
    """
    Model to track Telegram groups being monitored.
    """
    id = db.Column(db.Integer, primary_key=True)
    group_id = db.Column(db.BigInteger, unique=True, nullable=False)
    group_name = db.Column(db.String(128), nullable=True)
    group_username = db.Column(db.String(64), nullable=True)
    auto_snipe = db.Column(db.Boolean, default=False)
    snipe_amount_sol = db.Column(db.Float, default=0.1)
    max_tokens_per_hour = db.Column(db.Integer, default=1)
    whitelist_only = db.Column(db.Boolean, default=True)
    last_token_sniped_at = db.Column(db.DateTime, nullable=True)
    token_count_last_hour = db.Column(db.Integer, default=0)
    success_count = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    profit_total_sol = db.Column(db.Float, default=0.0)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def save(self):
        """Convenience method to save the model to the database."""
        db.session.add(self)
        db.session.commit()
    
    def success_rate(self):
        """Calculate success rate for tokens sniped from this group."""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0
        return (self.success_count / total) * 100