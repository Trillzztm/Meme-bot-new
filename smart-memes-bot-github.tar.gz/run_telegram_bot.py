#!/usr/bin/env python3
"""
SMART MEMES BOT - Bot Runner

This script starts the Telegram bot and ensures it stays running.
"""

import os
import sys
import time
import signal
import subprocess
import logging
from datetime import datetime, timedelta

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("telegram_bot_runner.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("BotRunner")

# Global variables
BOT_PROCESS = None
RUNNING = True
HEALTH_FILE = "bot_health.txt"
RESTART_INTERVAL = 12 * 60 * 60  # Restart every 12 hours for freshness

def save_health_status(status):
    """Save the current health status to a file"""
    with open(HEALTH_FILE, "w") as f:
        f.write(f"Status: {status}\n")
        f.write(f"Last checked: {datetime.now().isoformat()}\n")
    logger.info(f"Bot status updated: {status}")

def start_bot():
    """Start the bot process"""
    global BOT_PROCESS
    logger.info("Starting bot process...")
    
    try:
        # Start the process
        BOT_PROCESS = subprocess.Popen(
            [sys.executable, "crypto_bot.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        save_health_status("RUNNING")
        logger.info(f"Bot started with PID {BOT_PROCESS.pid}")
        return True
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        save_health_status(f"ERROR: {str(e)}")
        return False

def stop_bot():
    """Stop the bot process"""
    global BOT_PROCESS
    
    if BOT_PROCESS:
        logger.info("Stopping bot...")
        try:
            BOT_PROCESS.terminate()
            BOT_PROCESS.wait(timeout=10)
            logger.info("Bot stopped successfully")
        except subprocess.TimeoutExpired:
            logger.warning("Bot did not terminate gracefully, killing...")
            BOT_PROCESS.kill()
        except Exception as e:
            logger.error(f"Error stopping bot: {e}")
        
        BOT_PROCESS = None
        save_health_status("STOPPED")

def check_bot_health():
    """Check if the bot is still running and healthy"""
    global BOT_PROCESS
    
    if not BOT_PROCESS:
        logger.warning("Bot not running")
        save_health_status("STOPPED")
        return False
    
    # Check if process is still running
    if BOT_PROCESS.poll() is not None:
        exit_code = BOT_PROCESS.poll()
        logger.warning(f"Bot process terminated with code {exit_code}")
        save_health_status(f"CRASHED: Exit code {exit_code}")
        return False
    
    # Read any available output
    for line in BOT_PROCESS.stdout:
        logger.info(f"Bot output: {line.decode().strip()}")
    
    # Everything seems good
    save_health_status("HEALTHY")
    return True

def run_forever():
    """Run the bot forever, handling all errors and crashes"""
    global RUNNING
    
    last_restart = datetime.now()
    
    # Start the bot
    if not start_bot():
        logger.error("Failed to start bot initially")
        time.sleep(60)  # Wait before retrying
    
    # Main loop
    while RUNNING:
        try:
            # Check bot health
            if not check_bot_health():
                logger.warning("Bot unhealthy, restarting...")
                stop_bot()
                if not start_bot():
                    logger.error("Failed to restart bot after crash")
                    time.sleep(60)  # Wait before retrying
            
            # Check if we need to do a scheduled restart
            now = datetime.now()
            if now - last_restart > timedelta(seconds=RESTART_INTERVAL):
                logger.info("Performing scheduled bot restart")
                stop_bot()
                if start_bot():
                    last_restart = now
                else:
                    logger.error("Failed to restart bot during scheduled restart")
            
            # Sleep before next check
            time.sleep(30)
            
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received, shutting down...")
            RUNNING = False
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
            time.sleep(60)  # Wait a bit longer if there's an error

def signal_handler(sig, frame):
    """Handle termination signals"""
    global RUNNING
    logger.info(f"Received signal {sig}, shutting down")
    RUNNING = False
    stop_bot()
    sys.exit(0)

if __name__ == "__main__":
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("="*50)
    logger.info("SMART MEMES BOT RUNNER STARTING")
    logger.info("="*50)
    
    try:
        # Run the bot forever
        run_forever()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        # Clean up
        RUNNING = False
        stop_bot()
        logger.info("SMART MEMES BOT RUNNER EXITING")