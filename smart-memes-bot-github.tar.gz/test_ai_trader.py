"""
Test script for the AI trading module.

This script provides a simple way to test the AI trading functionality
with sample token addresses.
"""

import asyncio
import logging
import sys
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Import AI integration
try:
    from ai_integration import get_ai_token_analysis, get_ai_safety_report
    HAS_AI = True
except ImportError:
    HAS_AI = False
    logger.warning("AI integration not available, using fallbacks")

# Import trading utilities
try:
    from utils.trading import calculate_position_size, calculate_exit_strategy, execute_trade
    from utils.token_scanner import extract_token_address, is_valid_token_address
    from utils.solana_trade import get_wallet_info
    HAS_TRADING = True
except ImportError:
    HAS_TRADING = False
    logger.warning("Trading modules not available, limited functionality")


async def test_ai_analysis(token_address: str) -> Dict[str, Any]:
    """
    Test AI analysis on a token.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Combined analysis results
    """
    if not HAS_AI:
        logger.error("AI integration not available, cannot perform analysis")
        return {"error": "AI integration not available"}
        
    try:
        # Perform analysis
        logger.info(f"Analyzing token: {token_address}")
        analysis_result = await get_ai_token_analysis(token_address)
        safety_result = await get_ai_safety_report(token_address)
        
        # Create a combined analysis
        combined_analysis = {
            **analysis_result,
            "safety_score": safety_result.get("safety_score", 0),
            "risks": safety_result.get("risks", []),
            "risk_level": safety_result.get("risk_level", "high")
        }
        
        # Print results
        logger.info(f"Analysis complete for {token_address}")
        logger.info(f"Potential Score: {combined_analysis.get('score', 0)}/100")
        logger.info(f"Safety Score: {combined_analysis.get('safety_score', 0)}/100")
        logger.info(f"Risk Level: {combined_analysis.get('risk_level', 'unknown')}")
        logger.info(f"Recommendation: {combined_analysis.get('recommendation', 'unknown')}")
        
        if combined_analysis.get('risks'):
            logger.info("Risks:")
            for risk in combined_analysis.get('risks', [])[:5]:
                logger.info(f"  - {risk}")
                
        return combined_analysis
        
    except Exception as e:
        logger.error(f"Error during AI analysis: {e}")
        return {"error": str(e)}


async def test_position_sizing(analysis: Dict[str, Any]) -> float:
    """
    Test position sizing based on analysis.
    
    Args:
        analysis: The token analysis data
        
    Returns:
        Calculated position size
    """
    if not HAS_TRADING:
        logger.error("Trading modules not available, cannot calculate position size")
        return 0.0
        
    try:
        # Calculate position size
        position_size = calculate_position_size(analysis)
        
        logger.info(f"Calculated position size: {position_size:.3f} SOL")
        return position_size
        
    except Exception as e:
        logger.error(f"Error calculating position size: {e}")
        return 0.0


async def test_exit_strategy(analysis: Dict[str, Any]) -> Dict[str, float]:
    """
    Test exit strategy calculation.
    
    Args:
        analysis: The token analysis data
        
    Returns:
        Exit strategy details
    """
    if not HAS_TRADING:
        logger.error("Trading modules not available, cannot calculate exit strategy")
        return {}
        
    try:
        # Use a sample entry price
        entry_price = 0.00001
        
        # Calculate exit strategy
        exit_strategy = calculate_exit_strategy(entry_price, analysis)
        
        logger.info(f"Entry price: {entry_price:.10f}")
        logger.info(f"Stop loss: {exit_strategy.get('stop_loss', 0):.10f} " +
                   f"(-{exit_strategy.get('stop_loss_percent', 0)*100:.1f}%)")
        logger.info(f"Take profit 1: {exit_strategy.get('take_profit_1', 0):.10f} " +
                   f"(+{exit_strategy.get('tp1_percent', 0)*100:.1f}%)")
        logger.info(f"Take profit 2: {exit_strategy.get('take_profit_2', 0):.10f} " +
                   f"(+{exit_strategy.get('tp2_percent', 0)*100:.1f}%)")
        logger.info(f"Take profit 3: {exit_strategy.get('take_profit_3', 0):.10f} " +
                   f"(+{exit_strategy.get('tp3_percent', 0)*100:.1f}%)")
                   
        return exit_strategy
        
    except Exception as e:
        logger.error(f"Error calculating exit strategy: {e}")
        return {}


async def test_token_scanner(text: str) -> None:
    """
    Test token address extraction from text.
    
    Args:
        text: The text to scan for token addresses
    """
    try:
        # Extract token addresses
        addresses = extract_token_address(text)
        
        logger.info(f"Extracted {len(addresses)} token addresses from text:")
        for i, addr in enumerate(addresses):
            logger.info(f"  {i+1}. {addr} - Valid: {is_valid_token_address(addr)}")
            
    except Exception as e:
        logger.error(f"Error extracting token addresses: {e}")


async def test_wallet_info() -> Dict[str, Any]:
    """
    Test wallet info retrieval.
    
    Returns:
        Wallet information
    """
    if not HAS_TRADING:
        logger.error("Trading modules not available, cannot get wallet info")
        return {}
        
    try:
        # Get wallet info
        wallet_info = await get_wallet_info()
        
        logger.info(f"Wallet address: {wallet_info.get('wallet_address', 'Unknown')}")
        logger.info(f"SOL balance: {wallet_info.get('sol_balance', 0):.3f} SOL")
        
        if wallet_info.get('simulated'):
            logger.warning("Using simulated wallet (SOLANA_PRIVATE_KEY not configured)")
            
        return wallet_info
        
    except Exception as e:
        logger.error(f"Error getting wallet info: {e}")
        return {}


async def test_trade_execution(token_address: str, amount: float = 0.1) -> Dict[str, Any]:
    """
    Test trade execution.
    
    Args:
        token_address: The token address to trade
        amount: The amount in SOL to trade
        
    Returns:
        Trade result
    """
    if not HAS_TRADING:
        logger.error("Trading modules not available, cannot execute trade")
        return {"error": "Trading modules not available"}
        
    try:
        # Execute buy trade
        logger.info(f"Executing test BUY trade for {token_address}: {amount} SOL")
        result = await execute_trade(
            token_address=token_address,
            amount=amount,
            is_buy=True,
            slippage=0.02
        )
        
        # Log result
        if result.get('success'):
            logger.info(f"Trade successful!")
            logger.info(f"Transaction hash: {result.get('transaction_hash', 'Unknown')}")
            logger.info(f"Entry price: {result.get('entry_price', 0):.10f}")
            logger.info(f"Tokens received: {result.get('tokens_received', 0):.2f}")
            
            if result.get('simulated'):
                logger.warning("This was a simulated trade (Solana libraries or wallet not configured)")
        else:
            logger.error(f"Trade failed: {result.get('error', 'Unknown error')}")
            
        return result
        
    except Exception as e:
        logger.error(f"Error executing trade: {e}")
        return {"error": str(e)}


async def run_tests():
    """Run all tests with sample data."""
    try:
        print("\n============== TESTING AI TRADER COMPONENTS ==============\n")
        
        # Test wallet info
        print("\n----- Testing Wallet Info -----\n")
        await test_wallet_info()
        
        # Sample token addresses (use real ones for better testing)
        sample_tokens = [
            "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # SOL
            "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Sample token
            "0x6b175474e89094c44da98b954eedeac495271d0f"  # Ethereum example (DAI)
        ]
        
        # Test token scanner
        print("\n----- Testing Token Scanner -----\n")
        sample_text = """
        Check out these tokens:
        EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v is SOL
        7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU is another token
        This is an Ethereum token: 0x6b175474e89094c44da98b954eedeac495271d0f
        """
        await test_token_scanner(sample_text)
        
        # Select a token for further testing
        selected_token = sample_tokens[0]  # Use SOL for testing
        
        # Test AI analysis
        print(f"\n----- Testing AI Analysis for {selected_token} -----\n")
        analysis = await test_ai_analysis(selected_token)
        
        if "error" not in analysis:
            # Test position sizing
            print("\n----- Testing Position Sizing -----\n")
            position_size = await test_position_sizing(analysis)
            
            # Test exit strategy
            print("\n----- Testing Exit Strategy -----\n")
            await test_exit_strategy(analysis)
            
            # Test trade execution with a small amount
            print("\n----- Testing Trade Execution (Simulated) -----\n")
            await test_trade_execution(selected_token, amount=0.01)
        
        print("\n============== TESTS COMPLETED ==============\n")
        
    except Exception as e:
        logger.error(f"Error running tests: {e}")


if __name__ == "__main__":
    # Run the tests
    asyncio.run(run_tests())