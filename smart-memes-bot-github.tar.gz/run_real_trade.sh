#!/bin/bash
# Real Trading Script for SMART MEMES BOT
# This script facilitates real trading with Jupiter on Solana

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if a command is available
check_command() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}Error: $1 is required but not installed.${NC}"
        exit 1
    fi
}

# Install required packages if needed
setup_packages() {
    echo -e "\n${BLUE}Checking required packages...${NC}"
    check_command "python3"
    
    # Check for Solana packages
    echo "import solana" | python3 2>/dev/null || {
        echo -e "${YELLOW}Installing required Python packages...${NC}"
        pip install solana base58 
    }
}

# Setup private key
setup_private_key() {
    # Check if private key is already set
    if [ -z "$SOLANA_PRIVATE_KEY" ]; then
        echo -e "\n${YELLOW}SOLANA_PRIVATE_KEY not set. Running setup...${NC}"
        python3 solana_private_key_setup.py
        
        # Check if setup was successful
        if [ -f "solana_key.txt" ]; then
            export SOLANA_PRIVATE_KEY=$(cat solana_key.txt)
            echo -e "${GREEN}Private key loaded from file.${NC}"
        else
            echo -e "${RED}Failed to setup private key.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}SOLANA_PRIVATE_KEY is already set.${NC}"
    fi
}

# Check wallet balance
check_balance() {
    echo -e "\n${BLUE}Checking wallet balance...${NC}"
    python3 -c "
import os
import sys
sys.path.append('.')
try:
    from direct_jupiter_trade import get_sol_balance, get_wallet_address
    
    wallet = get_wallet_address()
    if not wallet:
        print('No wallet available. Check your private key.')
        sys.exit(1)
    
    print(f'Wallet address: {wallet}')
    
    balance = get_sol_balance()
    if 'error' in balance:
        print(f'Error getting balance: {balance[\"error\"]}')
        sys.exit(1)
    
    sol = balance['balance_sol']
    usd = balance['balance_usd']
    print(f'Balance: {sol} SOL (${usd:.2f})')
except Exception as e:
    print(f'Error: {e}')
    sys.exit(1)
"
}

# Execute buy trade
buy_token() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo -e "${RED}Usage: ./run_real_trade.sh buy <token_symbol> <sol_amount>${NC}"
        return 1
    fi
    
    token=$1
    amount=$2
    
    echo -e "\n${BLUE}Buying $token with $amount SOL...${NC}"
    python3 direct_jupiter_trade.py SOL $token $amount
}

# Execute sell trade
sell_token() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo -e "${RED}Usage: ./run_real_trade.sh sell <token_symbol> <token_amount>${NC}"
        return 1
    fi
    
    token=$1
    amount=$2
    
    echo -e "\n${BLUE}Selling $amount $token for SOL...${NC}"
    python3 direct_jupiter_trade.py $token SOL $amount
}

# Transfer SOL
transfer_sol() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo -e "${RED}Usage: ./run_real_trade.sh transfer <to_address> <sol_amount>${NC}"
        return 1
    fi
    
    to_address=$1
    amount=$2
    
    echo -e "\n${BLUE}Transferring $amount SOL to $to_address...${NC}"
    python3 execute_direct_transfer.py $to_address $amount
}

# Show help
show_help() {
    echo -e "\n${GREEN}SMART MEMES BOT - Real Trading Script${NC}"
    echo -e "Usage:"
    echo -e "  ${YELLOW}./run_real_trade.sh balance${NC} - Check wallet balance"
    echo -e "  ${YELLOW}./run_real_trade.sh buy <token_symbol> <sol_amount>${NC} - Buy a token with SOL"
    echo -e "  ${YELLOW}./run_real_trade.sh sell <token_symbol> <token_amount>${NC} - Sell a token for SOL"
    echo -e "  ${YELLOW}./run_real_trade.sh transfer <to_address> <sol_amount>${NC} - Transfer SOL to an address"
    echo -e "  ${YELLOW}./run_real_trade.sh setup${NC} - Setup private key"
    echo -e "  ${YELLOW}./run_real_trade.sh help${NC} - Show this help message"
    echo -e "\nAvailable tokens: SOL, USDC, BONK, WIF, JTO"
}

# Main script
main() {
    # Make script executable
    chmod +x run_real_trade.sh
    
    # Setup packages
    setup_packages
    
    # Parse command
    case "$1" in
        balance)
            setup_private_key
            check_balance
            ;;
        buy)
            setup_private_key
            buy_token "$2" "$3"
            ;;
        sell)
            setup_private_key
            sell_token "$2" "$3"
            ;;
        transfer)
            setup_private_key
            transfer_sol "$2" "$3"
            ;;
        setup)
            setup_private_key
            ;;
        help|"")
            show_help
            ;;
        *)
            echo -e "${RED}Unknown command: $1${NC}"
            show_help
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"