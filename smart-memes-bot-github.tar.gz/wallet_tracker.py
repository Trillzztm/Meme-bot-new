"""
Functions for tracking and monitoring crypto wallets.
"""
import logging
import aiohttp
import json
from config import ETHERSCAN_API_KEY, ETHERSCAN_API_URL, WALLET_CACHE
import utils

logger = logging.getLogger(__name__)

async def get_wallet_info(wallet_address):
    """
    Get information about a wallet address, including balance and tokens.
    
    Args:
        wallet_address (str): The wallet address to get information for
        
    Returns:
        dict: A dictionary containing wallet information
    """
    # Check cache first
    if wallet_address in WALLET_CACHE and not utils.is_cache_expired(WALLET_CACHE[wallet_address]["last_updated"]):
        logger.info(f"Using cached wallet info for {wallet_address}")
        return WALLET_CACHE[wallet_address]
    
    logger.info(f"Fetching wallet info for {wallet_address}")
    
    # Prepare the result dictionary
    wallet_info = {
        "address": wallet_address,
        "balance": 0,
        "balance_formatted": "0",
        "tokens": [],
        "last_updated": utils.get_current_timestamp()
    }
    
    try:
        # Get ETH balance
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "account",
                "action": "balance",
                "address": wallet_address,
                "tag": "latest",
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1":
                        # Convert Wei to ETH (1 ETH = 10^18 Wei)
                        balance_wei = int(data["result"])
                        balance_eth = balance_wei / 10**18
                        wallet_info["balance"] = balance_eth
                        wallet_info["balance_formatted"] = f"{balance_eth:.4f}"
                    else:
                        logger.error(f"Etherscan API error: {data['message']}")
        
        # Get tokens (ERC-20)
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "account",
                "action": "tokentx",
                "address": wallet_address,
                "sort": "desc",
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1":
                        # Process token transactions
                        token_dict = {}  # To avoid duplicates
                        
                        for tx in data["result"]:
                            token_address = tx["contractAddress"]
                            
                            if token_address not in token_dict:
                                token_dict[token_address] = {
                                    "address": token_address,
                                    "name": tx["tokenName"],
                                    "symbol": tx["tokenSymbol"],
                                    "decimals": int(tx["tokenDecimal"]),
                                    "last_transaction": tx["timeStamp"]
                                }
                        
                        # Get current token balances
                        for token_address, token_data in token_dict.items():
                            token_balance = await get_token_balance(wallet_address, token_address, token_data["decimals"])
                            token_data["balance"] = token_balance
                            
                            # Only include tokens with non-zero balance
                            if token_balance > 0:
                                wallet_info["tokens"].append(token_data)
                    else:
                        logger.error(f"Etherscan API error: {data['message']}")
        
        # Update cache
        WALLET_CACHE[wallet_address] = wallet_info
        
        return wallet_info
    
    except Exception as e:
        logger.error(f"Error fetching wallet info for {wallet_address}: {str(e)}")
        raise

async def get_token_balance(wallet_address, token_address, decimals):
    """
    Get the balance of a specific token for a wallet address.
    
    Args:
        wallet_address (str): The wallet address
        token_address (str): The token contract address
        decimals (int): The token decimals
        
    Returns:
        float: The token balance
    """
    try:
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "account",
                "action": "tokenbalance",
                "contractaddress": token_address,
                "address": wallet_address,
                "tag": "latest",
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1":
                        # Convert balance based on token decimals
                        balance_raw = int(data["result"])
                        balance = balance_raw / (10 ** decimals)
                        return balance
                    else:
                        logger.error(f"Etherscan API error: {data['message']}")
                        return 0
    
    except Exception as e:
        logger.error(f"Error fetching token balance: {str(e)}")
        return 0

async def get_recent_transactions(wallet_address, limit=10):
    """
    Get recent transactions for a wallet address.
    
    Args:
        wallet_address (str): The wallet address
        limit (int): Maximum number of transactions to fetch
        
    Returns:
        list: A list of recent transactions
    """
    try:
        async with aiohttp.ClientSession() as session:
            params = {
                "module": "account",
                "action": "txlist",
                "address": wallet_address,
                "sort": "desc",
                "page": 1,
                "offset": limit,
                "apikey": ETHERSCAN_API_KEY
            }
            
            async with session.get(ETHERSCAN_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data["status"] == "1":
                        transactions = []
                        
                        for tx in data["result"]:
                            transaction = {
                                "hash": tx["hash"],
                                "from": tx["from"],
                                "to": tx["to"],
                                "value": float(tx["value"]) / 10**18,  # Convert Wei to ETH
                                "timestamp": tx["timeStamp"],
                                "gas_used": tx["gasUsed"],
                                "is_error": tx["isError"] == "1"
                            }
                            transactions.append(transaction)
                        
                        return transactions
                    else:
                        logger.error(f"Etherscan API error: {data['message']}")
                        return []
    
    except Exception as e:
        logger.error(f"Error fetching recent transactions: {str(e)}")
        return []

async def detect_significant_changes(wallet_address, previous_data, current_data):
    """
    Detect significant changes in wallet data to notify the user.
    
    Args:
        wallet_address (str): The wallet address
        previous_data (dict): Previous wallet data
        current_data (dict): Current wallet data
        
    Returns:
        list: A list of significant changes to report
    """
    changes = []
    
    # Check for significant balance change (5% or more)
    prev_balance = previous_data.get("balance", 0)
    current_balance = current_data.get("balance", 0)
    
    if prev_balance > 0:
        balance_change_pct = abs(current_balance - prev_balance) / prev_balance * 100
        
        if balance_change_pct >= 5:
            if current_balance > prev_balance:
                changes.append(f"📈 ETH balance increased by {balance_change_pct:.2f}% " 
                              f"({(current_balance - prev_balance):.4f} ETH)")
            else:
                changes.append(f"📉 ETH balance decreased by {balance_change_pct:.2f}% " 
                              f"({(prev_balance - current_balance):.4f} ETH)")
    
    # Check for new tokens
    prev_tokens = {t["address"]: t for t in previous_data.get("tokens", [])}
    current_tokens = {t["address"]: t for t in current_data.get("tokens", [])}
    
    # New tokens
    new_tokens = [t for addr, t in current_tokens.items() if addr not in prev_tokens]
    for token in new_tokens:
        changes.append(f"🆕 New token: {token['name']} ({token['symbol']}) - " 
                      f"Balance: {token['balance']}")
    
    # Disappeared tokens
    removed_tokens = [t for addr, t in prev_tokens.items() if addr not in current_tokens]
    for token in removed_tokens:
        changes.append(f"🗑️ Removed token: {token['name']} ({token['symbol']}) - " 
                      f"Previous balance: {token['balance']}")
    
    # Significant token balance changes (20% or more)
    for addr, token in current_tokens.items():
        if addr in prev_tokens:
            prev_balance = prev_tokens[addr].get("balance", 0)
            current_balance = token.get("balance", 0)
            
            if prev_balance > 0:
                balance_change_pct = abs(current_balance - prev_balance) / prev_balance * 100
                
                if balance_change_pct >= 20:
                    if current_balance > prev_balance:
                        changes.append(f"📈 {token['name']} ({token['symbol']}) balance increased by " 
                                      f"{balance_change_pct:.2f}% ({(current_balance - prev_balance):.4f})")
                    else:
                        changes.append(f"📉 {token['name']} ({token['symbol']}) balance decreased by " 
                                      f"{balance_change_pct:.2f}% ({(prev_balance - current_balance):.4f})")
    
    return changes
