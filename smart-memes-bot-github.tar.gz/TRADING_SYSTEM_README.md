# SMART MEMES BOT - Real-Time Trading System

## Overview

SMART MEMES BOT is an advanced AI-powered cryptocurrency trading platform that executes real trades on the Solana blockchain using Jupiter DEX. The system continuously monitors the market for profitable trading opportunities, automatically executes trades, and provides a comprehensive dashboard for monitoring performance.

## Features

- **Real-time Market Monitoring**: Continuously scans the market for trading opportunities
- **Automated Trading**: Automatically executes trades based on market signals
- **Profit Tracking**: Records and visualizes all trading profits
- **Trading Dashboard**: Web interface for monitoring system performance and controlling trading parameters
- **Multiple Trading Strategies**: Implements various strategies including momentum, breakout, dip buying, and volatility trading
- **Risk Management**: Configurable risk levels and position sizing
- **Solana Blockchain Integration**: Direct integration with Phantom wallet and Jupiter DEX

## Quick Start

1. **Set up your Solana private key**:
   ```
   python solana_private_key_setup.py
   ```

2. **Start the complete trading system**:
   ```
   ./start_trading_system.sh start
   ```

3. **Access the trading dashboard**:
   Open your browser and go to: http://localhost:5001

## Components

The SMART MEMES BOT trading system consists of several key components:

1. **Market Monitor** (`market_monitor.py`): Monitors the market in real-time, analyzing price movements, volatility, and other indicators to identify potential trading opportunities.

2. **Trading Engine** (`realtime_trading_engine.py`): Handles the execution of trades based on signals from the market monitor, manages risk, and records trade results.

3. **Trading Dashboard** (`trading_dashboard.py`): Provides a web interface for monitoring system performance, configuring trading parameters, and tracking profits.

4. **Jupiter Integration** (`jupiter_real_trader.py`): Interfaces directly with the Jupiter DEX API to execute trades on the Solana blockchain.

5. **Transaction Management** (`execute_direct_transfer.py`): Provides functionality for direct SOL transfers and transaction signing.

## Commands

The `start_trading_system.sh` script provides several commands:

- `start`: Start all components of the trading system
- `stop`: Stop all components
- `status`: Show the status of all components
- `logs [component] [lines]`: Show logs for a specific component (market, trading, dashboard, or all)
- `help`: Show help message

## Manual Trading

In addition to automated trading, you can manually execute trades:

1. Using the trading dashboard:
   - Go to http://localhost:5001
   - Use the "Market Prices" section to buy or sell tokens

2. Using the command-line interface:
   ```
   python jupiter_real_trader.py buy BONK 0.05
   python jupiter_real_trader.py sell BONK 1000000
   ```

## Trading Strategies

The system implements several trading strategies:

1. **Momentum Trading**: Identifies tokens with strong price momentum and trades in the direction of the trend
2. **Breakout Trading**: Detects price breakouts above key resistance levels
3. **Dip Buying**: Buys tokens during temporary price dips in an overall uptrend
4. **Volatility Trading**: Capitalizes on highly volatile tokens with rapid price movements

You can enable or disable these strategies through the trading dashboard's configuration section.

## Market Signals

Market signals are calculated based on several factors:

- **Price Momentum**: Recent price change direction and strength
- **Volume Analysis**: Trading volume trends and abnormalities
- **Volatility Measurement**: Price volatility relative to historical norms
- **Technical Indicators**: Various technical analysis indicators
- **Market Sentiment**: Market-wide sentiment and token-specific factors

Signals with a strength above the configured threshold will trigger automatic trades if auto-trading is enabled.

## Configuration

You can configure the trading system through the dashboard:

1. **Risk Level**: Set the overall risk profile (low, medium, high)
2. **Maximum SOL Per Trade**: Limit the amount of SOL used per trade
3. **Auto-Trading**: Enable or disable automated trading
4. **Market Monitor**: Enable or disable market monitoring

## Requirements

- Python 3.6+
- Solana wallet private key
- Birdeye API key (optional but recommended for enhanced market data)
- Internet connection for accessing blockchain and API services

## Important Notes

1. **Security**: Your private key is stored securely and is required for transaction signing. Never share it with anyone.
2. **Risk**: Cryptocurrency trading involves significant risk. Only trade with funds you can afford to lose.
3. **Configuration**: Start with small trade amounts and conservative risk settings until you're comfortable with the system's performance.

## Troubleshooting

If you encounter issues with the trading system:

1. Check the logs with `./start_trading_system.sh logs all`
2. Verify your Solana private key is correctly set up
3. Ensure you have sufficient SOL balance for trades and transaction fees
4. Restart the system with `./start_trading_system.sh stop` followed by `./start_trading_system.sh start`