"""
Setup script for SMART MEMES BOT

This script sets up the environment and installs required packages.
"""

import os
import sys
import subprocess
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("Setup")

def check_python_version():
    """Check Python version"""
    logger.info(f"Python version: {sys.version}")
    if sys.version_info < (3, 8):
        logger.error("Python 3.8 or higher is required")
        return False
    return True

def install_packages():
    """Install required packages"""
    required_packages = [
        "flask",
        "requests",
        "python-dotenv"
    ]
    
    logger.info("Installing required packages...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + required_packages)
        logger.info("Package installation completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Error installing packages: {e}")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    if not os.path.exists(".env"):
        logger.info("Creating .env file...")
        with open(".env", "w") as f:
            f.write("""# Environment variables for SMART MEMES BOT
# Replace these with your actual values

# Solana wallet private key (required for real trading)
#SOLANA_PRIVATE_KEY=your_solana_private_key

# Telegram bot token (optional, for Telegram bot functionality)
#TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# BirdEye API key (optional, for enhanced token analysis)
#BIRDEYE_API_KEY=your_birdeye_api_key
""")
        logger.info(".env file created successfully")
    else:
        logger.info(".env file already exists")
    return True

def setup_templates():
    """Create template directory and files"""
    os.makedirs("templates", exist_ok=True)
    logger.info("Templates directory created/verified")
    return True

def main():
    """Main setup function"""
    logger.info("Setting up SMART MEMES BOT...")
    
    if not check_python_version():
        return 1
    
    if not install_packages():
        return 1
    
    if not create_env_file():
        return 1
    
    if not setup_templates():
        return 1
    
    logger.info("=" * 50)
    logger.info("Setup completed successfully!")
    logger.info("=" * 50)
    logger.info("You can now run the system using:")
    logger.info("1. For the web interface:   python quick_connect.py")
    logger.info("2. For the money maker:     ./start_moneymaker.sh")
    logger.info("")
    logger.info("Make sure to edit the .env file with your Solana private key and other credentials.")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())