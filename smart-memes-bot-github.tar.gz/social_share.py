"""
Social media sharing functionality for crypto memes.
"""
import os
import logging
import urllib.parse
import requests
import base64
import json
import time
import random
from datetime import datetime

logger = logging.getLogger(__name__)

# Constants for social sharing
SHARE_PLATFORMS = {
    "twitter": {
        "name": "Twitter",
        "icon": "📱",
        "url_template": "https://twitter.com/intent/tweet?text={message}&url={url}"
    },
    "telegram": {
        "name": "Telegram",
        "icon": "📞",
        "url_template": "https://t.me/share/url?url={url}&text={message}"
    },
    "reddit": {
        "name": "Reddit",
        "icon": "📣",
        "url_template": "https://www.reddit.com/submit?title={message}&url={url}"
    },
    "whatsapp": {
        "name": "WhatsApp",
        "icon": "💬",
        "url_template": "https://api.whatsapp.com/send?text={message}%20{url}"
    },
    "facebook": {
        "name": "Facebook",
        "icon": "👥",
        "url_template": "https://www.facebook.com/sharer/sharer.php?u={url}&quote={message}"
    },
    "discord": {
        "name": "Discord",
        "icon": "🎮",
        "direct_share": True  # Special case - no direct URL, just copy to clipboard
    },
    "linkedin": {
        "name": "LinkedIn",
        "icon": "💼",
        "url_template": "https://www.linkedin.com/sharing/share-offsite/?url={url}"
    }
}

def get_available_platforms():
    """Get list of available sharing platforms."""
    return list(SHARE_PLATFORMS.keys())

def get_platform_info(platform):
    """Get information about a specific platform."""
    return SHARE_PLATFORMS.get(platform, None)

def create_share_url(platform, message, url=""):
    """
    Create a sharing URL for the specified platform.
    
    Args:
        platform (str): Platform to share to
        message (str): Message to include
        url (str): URL to share (if applicable)
        
    Returns:
        str: Sharing URL
    """
    if platform not in SHARE_PLATFORMS:
        return None
    
    platform_info = SHARE_PLATFORMS[platform]
    
    # Handle direct share platforms
    if platform_info.get("direct_share", False):
        return "#copy"  # Special signal for clipboard copy
    
    # Encode parameters
    encoded_message = urllib.parse.quote(message)
    encoded_url = urllib.parse.quote(url)
    
    # Create sharing URL
    try:
        share_url = platform_info["url_template"].format(
            message=encoded_message,
            url=encoded_url
        )
        return share_url
    except Exception as e:
        logger.error(f"Error creating share URL for {platform}: {str(e)}")
        return None

def generate_share_buttons_html(image_path, message="Check out this crypto meme!", image_base64=None):
    """
    Generate HTML for social sharing buttons.
    
    Args:
        image_path (str): Path to the image
        message (str): Message to include in shares
        image_base64 (str, optional): Base64 encoded image data (if available)
        
    Returns:
        str: HTML for sharing buttons
    """
    # Create unique identifier for this image
    timestamp = int(time.time())
    random_id = random.randint(1000, 9999)
    meme_id = f"meme_{timestamp}_{random_id}"
    
    # Base64 encode the image if not provided
    if not image_base64 and os.path.exists(image_path):
        try:
            with open(image_path, "rb") as img_file:
                image_binary = img_file.read()
                image_base64 = base64.b64encode(image_binary).decode('utf-8')
        except Exception as e:
            logger.error(f"Error reading image file: {str(e)}")
            return "<p>Error preparing image for sharing</p>"
    
    # Build HTML for sharing buttons
    html = f"""
    <div class="share-container" id="{meme_id}_container">
        <h4>Share this meme:</h4>
        <div class="share-buttons">
    """
    
    # Add buttons for each platform
    for platform_id, platform_info in SHARE_PLATFORMS.items():
        platform_name = platform_info["name"]
        platform_icon = platform_info["icon"]
        
        # Create button
        html += f"""
        <button class="share-button" data-platform="{platform_id}" 
                onclick="shareMeme('{platform_id}', '{meme_id}')">
            {platform_icon} {platform_name}
        </button>
        """
    
    # Add hidden data and JavaScript
    html += f"""
        </div>
        <div id="{meme_id}_result" class="share-result"></div>
        <input type="hidden" id="{meme_id}_image_data" value="{image_base64}">
        <input type="hidden" id="{meme_id}_message" value="{message}">
    </div>
    
    <script>
    function shareMeme(platform, memeId) {{
        // Get data
        const message = document.getElementById(memeId + '_message').value;
        const imageData = document.getElementById(memeId + '_image_data').value;
        const resultDiv = document.getElementById(memeId + '_result');
        
        // Handle sharing based on platform
        let shareUrl = '';
        
        switch(platform) {{
            case 'twitter':
                shareUrl = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(message);
                break;
            case 'telegram':
                shareUrl = 'https://t.me/share/url?url=&text=' + encodeURIComponent(message);
                break;
            case 'reddit':
                shareUrl = 'https://www.reddit.com/submit?title=' + encodeURIComponent(message);
                break;
            case 'whatsapp':
                shareUrl = 'https://api.whatsapp.com/send?text=' + encodeURIComponent(message);
                break;
            case 'facebook':
                shareUrl = 'https://www.facebook.com/sharer/sharer.php?quote=' + encodeURIComponent(message);
                break;
            case 'linkedin':
                shareUrl = 'https://www.linkedin.com/sharing/share-offsite/?url=' + encodeURIComponent(window.location.href);
                break;
            case 'discord':
                // Copy to clipboard for Discord
                copyImageToClipboard(imageData, memeId);
                return;
        }}
        
        // Open share window
        if (shareUrl) {{
            window.open(shareUrl, '_blank', 'width=600,height=400');
            resultDiv.innerHTML = '<div class="alert alert-success mt-2">Opened sharing window!</div>';
            setTimeout(() => {{ resultDiv.innerHTML = ''; }}, 3000);
        }}
    }}
    
    function copyImageToClipboard(imageData, memeId) {{
        const resultDiv = document.getElementById(memeId + '_result');
        
        // Create a temporary textarea for copying
        const textarea = document.createElement('textarea');
        textarea.value = 'Check out this awesome crypto meme!';
        document.body.appendChild(textarea);
        textarea.select();
        
        try {{
            // Execute copy command
            document.execCommand('copy');
            resultDiv.innerHTML = '<div class="alert alert-success mt-2">Caption copied to clipboard! For Discord, right-click the image and select "Copy Image".</div>';
        }} catch (err) {{
            resultDiv.innerHTML = '<div class="alert alert-danger mt-2">Error copying to clipboard: ' + err + '</div>';
        }} finally {{
            document.body.removeChild(textarea);
            setTimeout(() => {{ resultDiv.innerHTML = ''; }}, 5000);
        }}
    }}
    </script>
    
    <style>
    .share-container {{
        margin: 15px 0;
        padding: 10px;
        border: 1px solid #dee2e6;
        border-radius: 5px;
        background-color: #f8f9fa;
    }}
    
    .share-buttons {{
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 10px;
    }}
    
    .share-button {{
        padding: 8px 12px;
        border: none;
        border-radius: 4px;
        background-color: #6c757d;
        color: white;
        cursor: pointer;
        transition: background-color 0.2s;
    }}
    
    .share-button:hover {{
        background-color: #5a6268;
    }}
    </style>
    """
    
    return html

def generate_sharable_link(image_path, message="Check out this crypto meme!"):
    """
    Generate a sharable link for the meme.
    
    Args:
        image_path (str): Path to the image
        message (str): Message to include
        
    Returns:
        str: Sharable link (or empty string if error)
    """
    # In a real implementation, this would upload the image to a service
    # and return a public link. For this demo, we'll return a placeholder.
    return f"https://example.com/meme/{os.path.basename(image_path)}"

def telegram_share_button(bot_username, message=""):
    """
    Create a simple Telegram share button using the bot's username.
    
    Args:
        bot_username (str): Telegram bot username
        message (str): Optional message to include
        
    Returns:
        str: HTML for Telegram share button
    """
    encoded_message = urllib.parse.quote(message) if message else ""
    share_url = f"https://t.me/{bot_username}?start=share_{encoded_message}"
    
    html = f"""
    <a href="{share_url}" target="_blank" class="btn btn-primary">
        Share on Telegram <i class="fa fa-telegram"></i>
    </a>
    """
    
    return html