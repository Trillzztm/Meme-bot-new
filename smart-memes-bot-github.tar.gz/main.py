import os
import logging
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_file
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from models import db, ProfitLog, Token, TelegramGroup

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "smart_memes_bot_secret_key")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# Create database tables if they don't exist
with app.app_context():
    db.create_all()

# Import utility modules
from utils.ai_token_analyzer import analyze_token
from utils.solana_client import run_async, get_token_price, buy_token, sell_token

# Helper functions
def get_profits_summary():
    """Get summary of profits from the database."""
    with app.app_context():
        # Get all profit logs
        profit_logs = ProfitLog.query.all()
        
        # Calculate total profit
        total_profit_sol = sum([log.profit_sol or 0 for log in profit_logs if log.sold])
        
        # Calculate average profit percentage
        profit_percentages = [log.profit_percent for log in profit_logs if log.sold and log.profit_percent]
        avg_profit_percent = sum(profit_percentages) / len(profit_percentages) if profit_percentages else 0
        
        # Get recent trades
        recent_trades = ProfitLog.query.order_by(ProfitLog.buy_timestamp.desc()).limit(5).all()
        
        return {
            "total_profit_sol": total_profit_sol,
            "avg_profit_percent": avg_profit_percent,
            "trade_count": len(profit_logs),
            "recent_trades": recent_trades,
        }

# Flask-Login user loader
@login_manager.user_loader
def load_user(user_id):
    # Since we're not implementing user authentication in this simple version,
    # we'll just return None
    return None

# Routes
@app.route("/")
def home():
    """Home page."""
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    """Dashboard page."""
    profits = get_profits_summary()
    return render_template("dashboard.html", profits=profits)

@app.route("/token-analyzer")
def token_analyzer():
    """Token analyzer page."""
    return render_template("token_analyzer.html")

@app.route("/api/analyze-token", methods=["POST"])
def api_analyze_token():
    """API endpoint to analyze a token."""
    data = request.json
    token_address = data.get("token_address")
    
    if not token_address:
        return jsonify({"error": "Token address is required"}), 400
    
    try:
        # Get token analysis
        analysis = analyze_token(token_address)
        
        # Store in database
        token = Token.query.filter_by(address=token_address).first()
        if not token:
            token = Token(address=token_address)
        
        # Update token data
        token.name = analysis["metadata"].get("name")
        token.symbol = analysis["metadata"].get("symbol")
        token.decimals = analysis["metadata"].get("decimals")
        token.total_supply = analysis["metadata"].get("supply")
        token.last_price_sol = analysis["market_data"].get("price")
        token.price_change_24h = analysis["market_data"].get("price_change_24h")
        token.volume_24h = analysis["market_data"].get("volume_24h")
        token.liquidity = analysis["market_data"].get("liquidity")
        token.ai_analysis = analysis["ai_analysis"].get("technical_analysis")
        token.social_sentiment = analysis["ai_analysis"].get("social_sentiment")
        token.updated_at = datetime.utcnow()
        
        token.save()
        
        return jsonify(analysis)
    except Exception as e:
        logger.error(f"Error analyzing token {token_address}: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/buy-token", methods=["POST"])
def api_buy_token():
    """API endpoint to buy a token."""
    data = request.json
    token_address = data.get("token_address")
    amount_sol = data.get("amount_sol")
    
    if not token_address or not amount_sol:
        return jsonify({"error": "Token address and SOL amount are required"}), 400
    
    try:
        amount_sol = float(amount_sol)
    except ValueError:
        return jsonify({"error": "Invalid SOL amount"}), 400
    
    if amount_sol <= 0 or amount_sol > 10:
        return jsonify({"error": "SOL amount must be between 0 and 10"}), 400
    
    try:
        # Get token price
        price = run_async(get_token_price(token_address))
        
        if price <= 0:
            return jsonify({"error": "Could not get token price. Invalid token or liquidity too low."}), 400
        
        # Execute the trade
        tx_url = run_async(buy_token(token_address, price, amount_sol))
        
        # Log the trade to database
        profit_log = ProfitLog(
            token_address=token_address,
            market_address=token_address,
            buy_price=price,
            buy_amount_sol=amount_sol,
            size=amount_sol / price if price > 0 else 0,
            buy_tx=tx_url if "solscan.io" in str(tx_url) else None,
            source="web",
        )
        profit_log.save()
        
        return jsonify({
            "success": True,
            "token_address": token_address,
            "price": price,
            "amount_sol": amount_sol,
            "tx_url": tx_url,
        })
    except Exception as e:
        logger.error(f"Error buying token {token_address}: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/sell-token", methods=["POST"])
def api_sell_token():
    """API endpoint to sell a token."""
    data = request.json
    profit_log_id = data.get("profit_log_id")
    
    if not profit_log_id:
        return jsonify({"error": "Profit log ID is required"}), 400
    
    try:
        # Get the profit log
        profit_log = ProfitLog.query.get(profit_log_id)
        
        if not profit_log:
            return jsonify({"error": "Trade not found"}), 404
        
        if profit_log.sold:
            return jsonify({"error": "Token already sold"}), 400
        
        # Get current price
        price = run_async(get_token_price(profit_log.token_address))
        
        if price <= 0:
            return jsonify({"error": "Could not get token price. Invalid token or liquidity too low."}), 400
        
        # Execute the trade
        tx_url = run_async(sell_token(profit_log.token_address, price, int(profit_log.size)))
        
        # Update profit log
        profit_log.sold = True
        profit_log.sell_price = price
        profit_log.sell_timestamp = datetime.utcnow()
        profit_log.sell_tx = tx_url if "solscan.io" in str(tx_url) else None
        profit_log.calculate_profit()
        profit_log.save()
        
        return jsonify({
            "success": True,
            "token_address": profit_log.token_address,
            "price": price,
            "tx_url": tx_url,
            "profit_sol": profit_log.profit_sol,
            "profit_percent": profit_log.profit_percent,
        })
    except Exception as e:
        logger.error(f"Error selling token from profit log {profit_log_id}: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/profits")
def api_profits():
    """API endpoint to get profits data."""
    profits = get_profits_summary()
    return jsonify(profits)

@app.route("/api/recent-trades")
def api_recent_trades():
    """API endpoint to get recent trades."""
    try:
        trades = ProfitLog.query.order_by(ProfitLog.buy_timestamp.desc()).limit(10).all()
        
        trades_data = []
        for trade in trades:
            trades_data.append({
                "id": trade.id,
                "token_address": trade.token_address,
                "buy_price": trade.buy_price,
                "buy_amount_sol": trade.buy_amount_sol,
                "buy_timestamp": trade.buy_timestamp.isoformat(),
                "sold": trade.sold,
                "sell_price": trade.sell_price,
                "profit_sol": trade.profit_sol,
                "profit_percent": trade.profit_percent,
            })
        
        return jsonify(trades_data)
    except Exception as e:
        logger.error(f"Error getting recent trades: {e}")
        return jsonify({"error": str(e)}), 500

# Download routes
@app.route("/download")
def download_page():
    """Download page for project archive."""
    return render_template("download.html")

@app.route("/download-archive")
def download_archive():
    """Download the project archive file."""
    # Create a copy in the static folder if it doesn't exist
    source_file = "/tmp/smart-memes-bot-github.tar.gz"
    destination_file = os.path.join(app.root_path, "static", "smart-memes-bot-github.tar.gz")
    
    # Check if source file exists
    if not os.path.exists(source_file):
        return "Archive file not found. Please contact support.", 404
    
    # Copy file if needed
    if not os.path.exists(destination_file):
        os.system(f"cp {source_file} {destination_file}")
    
    # Use send_file to initiate the download
    return send_file(
        destination_file,
        as_attachment=True,
        download_name="smart-memes-bot-github.tar.gz",
        mimetype="application/gzip"
    )

# Run the app if executed directly
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)