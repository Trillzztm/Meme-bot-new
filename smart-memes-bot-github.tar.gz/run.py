import os
import logging
import threading
import time
import subprocess
import sys

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("run")

def run_flask_app():
    """Run the Flask web application."""
    logger.info("Starting Flask web application...")
    # Start in repl.it workflow using gunicorn
    subprocess.run(["gunicorn", "--bind", "0.0.0.0:5000", "--reuse-port", "--reload", "main:app"])

def run_telegram_bot():
    """Run the Telegram bot."""
    logger.info("Starting Telegram bot...")
    # Delay the bot startup to ensure the Flask app is up first
    time.sleep(5)
    # Make sure the bot.py script can import modules
    sys.path.append(os.getcwd())
    # Import and run the bot
    import bot
    bot.main()

def main():
    """Run both the Flask web application and Telegram bot."""
    logger.info("Starting SMART MEMES BOT system...")
    
    # Check required environment variables
    if not os.getenv("TELEGRAM_BOT_TOKEN"):
        logger.error("TELEGRAM_BOT_TOKEN environment variable is not set!")
    
    if not os.getenv("OPENAI_API_KEY"):
        logger.error("OPENAI_API_KEY environment variable is not set!")
        
    if not os.getenv("SOLANA_PRIVATE_KEY"):
        logger.error("SOLANA_PRIVATE_KEY environment variable is not set!")
    
    # Start Flask app in a separate thread
    flask_thread = threading.Thread(target=run_flask_app)
    flask_thread.daemon = True
    flask_thread.start()
    
    # Start Telegram bot in the main thread
    # This will keep the script running
    run_telegram_bot()

if __name__ == "__main__":
    main()