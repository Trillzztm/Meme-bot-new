"""
API Resilience Test Script for SMART MEMES BOT.

This script tests the enhanced API resilience features to ensure the system 
continues functioning even when external APIs experience outages.
"""

import asyncio
import logging
import json
import time
from handlers.advanced_safety import analyze_token
from utils.pricing import get_token_price, get_token_metrics
from utils.token_safety import check_birdeye_liquidity, check_token_safety

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Test tokens
TEST_TOKENS = [
    # USDC - very established token
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    
    # SOL - native token
    "So11111111111111111111111111111111111111112",
    
    # BONK - popular meme token
    "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
]

async def test_token_price_api():
    """Test token price API with resilience features"""
    logger.info("Testing token price API with enhanced resilience...")
    
    for token in TEST_TOKENS:
        logger.info(f"Getting price for {token}")
        price = await get_token_price(token)
        if price is not None:
            logger.info(f"✅ Price for {token}: ${price}")
        else:
            logger.error(f"❌ Failed to get price for {token}")

async def test_token_metrics_api():
    """Test token metrics API with resilience features"""
    logger.info("Testing token metrics API with enhanced resilience...")
    
    for token in TEST_TOKENS:
        logger.info(f"Getting metrics for {token}")
        metrics = await get_token_metrics(token)
        
        if metrics.get("success", False):
            logger.info(f"✅ Metrics for {token}: {metrics['token_symbol']} - ${metrics['price']}")
            logger.info(f"   API Status: {metrics.get('api_status', 'unknown')}")
        else:
            logger.warning(f"⚠️ Limited metrics for {token}: {metrics.get('error', 'Unknown error')}")
            logger.info(f"   API Status: {metrics.get('api_status', 'unknown')}")

async def test_token_safety_api():
    """Test token safety API with resilience features"""
    logger.info("Testing token safety API with enhanced resilience...")
    
    for token in TEST_TOKENS:
        logger.info(f"Checking safety for {token}")
        safety_data = await check_birdeye_liquidity(token)
        
        if safety_data.get("success", False):
            logger.info(f"✅ Safety data for {token}: Score {safety_data.get('score', 0)}")
            logger.info(f"   API Status: {safety_data.get('api_status', 'unknown')}")
        else:
            logger.warning(f"⚠️ Limited safety data for {token}")
            logger.info(f"   API Status: {safety_data.get('api_status', 'unknown')}")
            logger.info(f"   Warnings: {safety_data.get('warnings', [])}")

async def test_comprehensive_analysis():
    """Test full token analysis with resilience features"""
    logger.info("Testing comprehensive token analysis with enhanced resilience...")
    
    for token in TEST_TOKENS:
        logger.info(f"Analyzing token {token}")
        safety_score, summary, token_data = await analyze_token(token)
        
        logger.info(f"✅ Analysis for {token}: Score {safety_score}/100")
        logger.info(f"   Summary: {summary}")
        
        # Show API status
        if "api_status" in token_data:
            successful_apis = sum(1 for status in token_data["api_status"].values() if status == "success")
            total_apis = len(token_data["api_status"])
            logger.info(f"   API Status: {successful_apis}/{total_apis} services available")
            logger.info(f"   Status details: {token_data['api_status']}")

async def main():
    """Run all tests"""
    logger.info("Starting API resilience tests...")
    
    # Run tests
    await test_token_price_api()
    print("\n" + "-"*50 + "\n")
    
    await test_token_metrics_api()
    print("\n" + "-"*50 + "\n")
    
    await test_token_safety_api()
    print("\n" + "-"*50 + "\n")
    
    await test_comprehensive_analysis()
    
    logger.info("All tests completed!")

if __name__ == "__main__":
    asyncio.run(main())