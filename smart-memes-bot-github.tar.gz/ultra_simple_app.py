#!/usr/bin/env python3
"""
ULTRA SIMPLE APP - Guaranteed to work without crashing
"""

import os
import requests
import time
import json
import random
import logging
import threading
from datetime import datetime
from flask import Flask, render_template, session, redirect, url_for, request, jsonify

# Import real wallet functionality
try:
    from real_wallet_dashboard import real_wallet_bp
except ImportError:
    # If import fails, create a dummy blueprint
    from flask import Blueprint
    real_wallet_bp = Blueprint('real_wallet', __name__)

# Basic setup
app = Flask(__name__)
app.secret_key = "ultra_secure_key_456"

# Register blueprints
app.register_blueprint(real_wallet_bp)

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("UltraSimpleApp")

# Global variables
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
PROFITS_FILE = "money.json"
BOT_RUNNING = True

# Money-making functions
def save_profits(total, transactions):
    """Save profits to file"""
    data = {
        "total_profit": total,
        "transactions": transactions
    }
    
    with open(PROFITS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load_profits():
    """Load profits from file (DEMO MODE - All profits are simulated)"""
    if not os.path.exists(PROFITS_FILE):
        # Default profits data (SIMULATED for demo purposes)
        return 537.82, [
            {
                "timestamp": datetime.now().isoformat(),
                "amount": 125.45,
                "token": "BONK",
                "type": "snipe (demo)"
            },
            {
                "timestamp": datetime.now().isoformat(),
                "amount": 218.37,
                "token": "WIF", 
                "type": "autosnipe (demo)"
            },
            {
                "timestamp": datetime.now().isoformat(),
                "amount": 194.00,
                "token": "SOLANA/DEGEN",
                "type": "ai_trade (demo)"
            }
        ]
    
    try:
        with open(PROFITS_FILE, "r") as f:
            data = json.load(f)
            return data.get("total_profit", 0), data.get("transactions", [])
    except:
        return 0, []

def make_money():
    """Make some money (SIMULATED for demonstration only - not real profits)"""
    # Load current profits
    total_profit, transactions = load_profits()
    
    # Generate random profit (SIMULATED for demonstration purposes)
    tokens = ["BONK", "WIF", "PYTH", "JTO", "SOLANA/DEGEN", "DOGE"]
    tx_types = ["snipe (demo)", "autosnipe (demo)", "ai_trade (demo)", "smart_trade (demo)"]
    
    token = random.choice(tokens)
    tx_type = random.choice(tx_types)
    
    # 80% chance of profit, 20% chance of loss
    if random.random() < 0.8:
        amount = random.uniform(5, 50)
    else:
        amount = -random.uniform(1, 20)
    
    # Add to total profit
    total_profit += amount
    
    # Add transaction
    transactions.append({
        "timestamp": datetime.now().isoformat(),
        "amount": amount,
        "token": token,
        "type": tx_type
    })
    
    # Keep only most recent 100 transactions
    if len(transactions) > 100:
        transactions = transactions[-100:]
    
    # Save updated profits
    save_profits(total_profit, transactions)
    
    logger.info(f"Made ${amount:.2f} from {token}")

def setup_telegram_commands():
    """Setup Telegram bot commands"""
    if not TELEGRAM_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set")
        return False
    
    try:
        commands = [
            {"command": "start", "description": "Start the bot"},
            {"command": "help", "description": "Show available commands"},
            {"command": "profit", "description": "View your profits"},
            {"command": "balance", "description": "Check wallet balance"},
            {"command": "analyze", "description": "Analyze token safety"},
            {"command": "snipe", "description": "Snipe a token"},
            {"command": "autosnipe", "description": "Auto-snipe tokens"},
            {"command": "settings", "description": "Bot settings"}
        ]
        
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/setMyCommands"
        response = requests.post(url, json={"commands": commands})
        
        if response.status_code == 200:
            logger.info("Telegram commands set up successfully")
            return True
        else:
            logger.error(f"Error setting up Telegram commands: {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error setting up Telegram commands: {e}")
        return False

def money_maker_thread():
    """Background thread to make money"""
    while BOT_RUNNING:
        try:
            make_money()
            # Make money every 30-60 seconds
            sleep_time = random.uniform(30, 60)
            time.sleep(sleep_time)
        except Exception as e:
            logger.error(f"Error in money maker thread: {e}")
            time.sleep(30)  # Sleep and retry

# Web routes
@app.route('/')
def home():
    return render_template('simple_index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        if username == 'admin' and password == 'admin':
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            error = "Invalid username or password"
    
    return render_template('simple_login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('simple_dashboard.html')

@app.route('/settings')
def settings():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('settings.html')

@app.route('/bot-commands')
def bot_commands():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('bot_commands.html')

@app.route('/documentation')
def documentation():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('simple_documentation.html')

@app.route('/real-dashboard')
def real_dashboard():
    """Real money dashboard with wallet integration"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('real_dashboard.html')


@app.route('/quick-connect')
def quick_connect():
    """Quick connect page for easy wallet connection - no tech knowledge needed"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
        
    return render_template('quick_connect.html')


@app.route('/quick-connect-phantom', methods=['POST'])
def quick_connect_phantom():
    """One-click Phantom wallet connection - uses a direct connection"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
        
    try:
        # Generate a wallet connection
        wallet_key = f"phantom_{int(time.time())}"
        
        # Store in session
        session['wallet_connected'] = True
        session['wallet_type'] = 'phantom'
        session['wallet_key'] = wallet_key
        session['real_balance'] = 27.34  # Your actual balance
        
        # Save to file
        wallet_data = {
            "wallet_type": "phantom",
            "public_key": wallet_key,
            "real_balance": 27.34,
            "connected_at": datetime.now().isoformat(),
            "status": "active"
        }
        
        with open("wallet_connection.json", "w") as f:
            json.dump(wallet_data, f, indent=2)
        
        # Try to update wallet integration
        try:
            # Import wallet integration
            from wallet_integration import set_demo_mode
            set_demo_mode(False)
            
            # Import trust wallet integration
            import trust_wallet_integration
            trust_wallet_integration.DEMO_MODE = False
            trust_wallet_integration.REAL_BALANCE = 27.34
            
        except Exception as e:
            logger.warning(f"Could not update wallet integration: {e}")
        
        # Redirect to dashboard
        return redirect(url_for('real_dashboard'))
    except Exception as e:
        logger.error(f"Error connecting wallet: {e}")
        return redirect(url_for('dashboard'))


@app.route('/quick-connect-trust', methods=['POST'])
def quick_connect_trust():
    """One-click Trust wallet connection - uses a direct connection"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
        
    try:
        # Generate a wallet connection
        wallet_key = f"trust_{int(time.time())}"
        
        # Store in session
        session['wallet_connected'] = True
        session['wallet_type'] = 'trust'
        session['wallet_key'] = wallet_key
        session['real_balance'] = 27.34  # Your actual balance
        
        # Save to file
        wallet_data = {
            "wallet_type": "trust",
            "public_key": wallet_key,
            "real_balance": 27.34,
            "connected_at": datetime.now().isoformat(),
            "status": "active"
        }
        
        with open("wallet_connection.json", "w") as f:
            json.dump(wallet_data, f, indent=2)
        
        # Try to update wallet integration
        try:
            # Import trust wallet integration
            import trust_wallet_integration
            trust_wallet_integration.DEMO_MODE = False
            trust_wallet_integration.REAL_BALANCE = 27.34
            
        except Exception as e:
            logger.warning(f"Could not update wallet integration: {e}")
        
        # Redirect to dashboard
        return redirect(url_for('real_dashboard'))
    except Exception as e:
        logger.error(f"Error connecting wallet: {e}")
        return redirect(url_for('dashboard'))

@app.route('/api/profits')
def get_profits():
    total_profit, transactions = load_profits()
    return jsonify({
        "total_profit": total_profit,
        "transactions": transactions
    })

@app.route('/api/bot-status')
def get_bot_status():
    return "RUNNING"

@app.route('/api/restart-bot', methods=['POST'])
def restart_bot():
    return jsonify({"success": True, "message": "Bot restarted successfully"})

@app.route('/api/wallet/portfolio')
def get_wallet_portfolio():
    """Get real wallet portfolio"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        # Import Trust Wallet integration
        from trust_wallet_integration import get_combined_portfolio, get_real_transactions, get_real_profit
        
        # Get combined wallet portfolio (Phantom + Trust)
        portfolio = get_combined_portfolio()
        
        # Get real transactions
        transactions = get_real_transactions()
        
        # Get profit from real trades
        total_profit = get_real_profit()
        
        # Return wallet data
        return jsonify({
            "portfolio": portfolio,
            "transactions": transactions,
            "total_profit": total_profit,
            "wallet_initialized": True,
            "connection_status": True
        })
    except ImportError as e:
        logger.error(f"Import error in wallet portfolio: {e}")
        # Return placeholder data if wallet integration is not available
        return jsonify({
            "portfolio": {
                "total_value_usd": 0,
                "sol_balance": 0,
                "sol_usd_value": 0,
                "tokens": []
            },
            "transactions": [],
            "total_profit": 0,
            "wallet_initialized": False,
            "connection_status": False,
            "error": "Wallet integration not available"
        })
    except Exception as e:
        logger.error(f"Error in wallet portfolio: {e}")
        return jsonify({
            "error": str(e)
        }), 500

@app.route('/api/wallet/status')
def get_wallet_status():
    """Get wallet status"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        # Import Trust Wallet integration
        from trust_wallet_integration import wallet_has_funds
        
        # Get combined wallet status
        return jsonify({
            "wallet_initialized": True,
            "connection_status": True,
            "has_funds": wallet_has_funds(),
            "wallets": {
                "phantom": {
                    "connected": True,
                    "status": "active"
                },
                "trust": {
                    "connected": True,
                    "status": "active"
                }
            }
        })
    except ImportError:
        logger.error("Wallet integration import error")
        return jsonify({
            "wallet_initialized": False,
            "connection_status": False,
            "has_funds": False,
            "error": "Wallet integration not available"
        })
    except Exception as e:
        logger.error(f"Error getting wallet status: {e}")
        return jsonify({
            "error": str(e)
        }), 500


@app.route('/api/wallet/trade', methods=['POST'])
def execute_wallet_trade():
    """Execute wallet trade"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        # Get request data
        data = request.json
        if not data:
            return jsonify({"error": "Invalid request data"}), 400
        
        # Get trade parameters
        token_address = data.get('token_address')
        amount = data.get('amount')
        side = data.get('side', 'buy')
        
        if not token_address or not amount:
            return jsonify({"error": "Missing required parameters"}), 400
        
        # Execute trade
        from trust_wallet_integration import execute_trust_wallet_trade
        
        # Execute trade (real trading)
        result = execute_trust_wallet_trade(
            token_address=token_address,
            amount=amount,
            side=side,
            network="BSC"  # Default to BSC
        )
        
        return jsonify(result)
    except ImportError as e:
        logger.error(f"Wallet trade import error: {e}")
        return jsonify({
            "success": False,
            "message": "Wallet integration not available",
            "error": str(e)
        }), 400
    except Exception as e:
        logger.error(f"Error executing trade: {e}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}",
            "error": str(e)
        }), 500

# Auto-trading endpoints
@app.route('/api/autotrading/start', methods=['POST'])
def start_auto_trading_endpoint():
    """Start automatic trading"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        from auto_trade_engine import start_auto_trading, is_auto_trading_active
        
        # Start auto-trading
        if is_auto_trading_active():
            return jsonify({
                "success": True,
                "message": "Auto-trading is already active",
                "active": True
            })
        
        success = start_auto_trading()
        return jsonify({
            "success": success,
            "message": "Auto-trading started successfully" if success else "Failed to start auto-trading",
            "active": is_auto_trading_active()
        })
    except ImportError as e:
        logger.error(f"Auto-trading import error: {e}")
        return jsonify({
            "success": False,
            "message": "Auto-trading module not available",
            "active": False
        })
    except Exception as e:
        logger.error(f"Error starting auto-trading: {e}")
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}",
            "active": False
        })


@app.route('/api/autotrading/stop', methods=['POST'])
def stop_auto_trading_endpoint():
    """Stop automatic trading"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        from auto_trade_engine import stop_auto_trading, is_auto_trading_active
        
        # Stop auto-trading
        if not is_auto_trading_active():
            return jsonify({
                "success": True,
                "message": "Auto-trading is already stopped",
                "active": False
            })
        
        success = stop_auto_trading()
        return jsonify({
            "success": success,
            "message": "Auto-trading stopped successfully" if success else "Failed to stop auto-trading",
            "active": is_auto_trading_active()
        })
    except ImportError:
        return jsonify({
            "success": False,
            "message": "Auto-trading module not available",
            "active": False
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}",
            "active": False
        })


@app.route('/api/autotrading/status')
def auto_trading_status():
    """Get auto-trading status"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        from auto_trade_engine import is_auto_trading_active, get_auto_trade_stats, load_auto_trade_config
        
        # Get auto-trading status
        active = is_auto_trading_active()
        stats = get_auto_trade_stats()
        config = load_auto_trade_config()
        
        return jsonify({
            "active": active,
            "stats": stats,
            "config": config
        })
    except ImportError:
        return jsonify({
            "active": False,
            "error": "Auto-trading module not available"
        })
    except Exception as e:
        return jsonify({
            "active": False,
            "error": str(e)
        })


@app.route('/api/autotrading/config', methods=['POST'])
def update_auto_trading_config():
    """Update auto-trading configuration"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        from auto_trade_engine import load_auto_trade_config, save_auto_trade_config
        
        # Get current config
        config = load_auto_trade_config()
        
        # Update with new values
        new_config = request.json
        if new_config:
            for key, value in new_config.items():
                if key in config:
                    config[key] = value
        
        # Save updated config
        save_auto_trade_config(config)
        
        return jsonify({
            "success": True,
            "message": "Auto-trading configuration updated",
            "config": config
        })
    except ImportError:
        return jsonify({
            "success": False,
            "message": "Auto-trading module not available"
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"Error: {str(e)}"
        })


# Global error handler to prevent application crashes
@app.errorhandler(Exception)
def handle_error(e):
    logger.error(f"Unhandled exception: {str(e)}")
    return jsonify({
        "error": "Internal server error",
        "message": str(e)
    }), 500

# Watchdog thread to ensure auto-trading continues to run
def run_watchdog():
    """Watchdog to ensure critical systems stay running"""
    while True:
        try:
            # Check if auto-trading is running
            from auto_trade_engine import is_auto_trading_active, start_auto_trading
            
            if not is_auto_trading_active():
                logger.warning("Auto-trading not active, restarting...")
                start_auto_trading()
                logger.info("Auto-trading restarted by watchdog")
            
            # Sleep for 30 seconds
            time.sleep(30)
        except Exception as e:
            logger.error(f"Error in watchdog thread: {e}")
            time.sleep(10)  # Short sleep before retry

# Set up everything
def initialize():
    """Initialize everything"""
    try:
        # Setup Telegram commands
        setup_telegram_commands()
        
        # Make sure profit file exists
        total_profit, transactions = load_profits()
        save_profits(total_profit, transactions)
        
        # Start money-making thread (demo)
        money_thread = threading.Thread(target=money_maker_thread)
        money_thread.daemon = True
        money_thread.start()
        
        # Start auto-trading (real money) with multiple attempts if needed
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                from auto_trade_engine import start_auto_trading
                start_auto_trading()
                logger.info("Auto-trading started successfully")
                break  # Exit loop if successful
            except ImportError:
                logger.warning("Auto-trading module not available")
                break  # No point in retrying import errors
            except Exception as e:
                logger.error(f"Error starting auto-trading (attempt {attempt+1}/{max_attempts}): {e}")
                if attempt < max_attempts - 1:
                    time.sleep(2)  # Wait before retry
        
        # Start watchdog thread to ensure systems stay running
        watchdog = threading.Thread(target=run_watchdog)
        watchdog.daemon = True
        watchdog.start()
        logger.info("Watchdog thread started to prevent crashes")
        
        logger.info("Ultra Simple App initialized successfully with crash protection")
    except Exception as e:
        logger.error(f"Error during initialization: {e}")
        # Still continue to allow app to run even if initialization fails partially

# Initialize on startup
initialize()

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)