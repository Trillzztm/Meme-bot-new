#!/usr/bin/env python3
"""
Execute Jupiter Trade - SMART MEMES BOT

This script allows you to manually execute trades using Jupiter DEX on Solana.
It provides a command-line interface for buying and selling tokens with real money.

USAGE:
  python execute_jupiter_trade.py buy --token BONK --amount 0.01
  python execute_jupiter_trade.py sell --token BONK --amount 1000
  python execute_jupiter_trade.py quote --input SOL --output BONK --amount 0.01
  python execute_jupiter_trade.py balance
"""

import os
import sys
import json
import time
import logging
import argparse
from typing import Dict, Any, Optional

# Import our Jupiter trading module
import jupiter_direct_trades as jupiter

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("ExecuteJupiterTrade")

# Token symbols to addresses mapping
TOKEN_SYMBOLS = {
    "SOL": jupiter.SOL_MINT,
    "USDC": jupiter.USDC_MINT,
    "BONK": jupiter.BONK_MINT,
    "WIF": jupiter.WIF_MINT,
    "JTO": jupiter.JTO_MINT,
}

def print_trade_result(result: Dict[str, Any]) -> None:
    """Print trade result in a user-friendly format"""
    print("\n=== TRADE RESULT ===")
    
    if "error" in result:
        print(f"ERROR: {result['error']}")
        return
    
    if result.get("success", False):
        print(f"SUCCESS! Transaction hash: {result.get('tx_hash')}")
        
        # Get input and output details if available
        input_mint = result.get("inputMint")
        output_mint = result.get("outputMint")
        input_amount = result.get("inputAmount")
        output_amount = result.get("outputAmount")
        
        # Get token symbols if available
        input_symbol = "Unknown"
        output_symbol = "Unknown"
        
        for symbol, address in TOKEN_SYMBOLS.items():
            if address == input_mint:
                input_symbol = symbol
            if address == output_mint:
                output_symbol = symbol
        
        # Convert amounts to human-readable values
        input_decimals = 9  # Default for most tokens
        output_decimals = 9  # Default for most tokens
        
        if input_symbol == "USDC":
            input_decimals = 6
        if output_symbol == "USDC":
            output_decimals = 6
        
        input_human = float(input_amount) / (10 ** input_decimals) if input_amount else None
        output_human = float(output_amount) / (10 ** output_decimals) if output_amount else None
        
        # Print details
        if input_human is not None:
            print(f"Input: {input_human} {input_symbol}")
        if output_human is not None:
            print(f"Output: {output_human} {output_symbol}")
            
        print("\nTransaction submitted successfully!")
        print("Check the transaction status on Solana Explorer:")
        print(f"https://explorer.solana.com/tx/{result.get('tx_hash')}")
    else:
        print(f"FAILED: {result}")

def cmd_balance(args):
    """Handle balance command"""
    import transaction_signer as tx_signer
    
    # Get wallet address
    wallet_address = tx_signer.get_public_key()
    if not wallet_address:
        print("ERROR: No wallet available. Check your SOLANA_PRIVATE_KEY environment variable.")
        return
    
    print(f"\nWallet address: {wallet_address}")
    
    # Get SOL balance
    try:
        from solana.rpc.api import Client
        client = Client(tx_signer.SOLANA_RPC_URL)
        response = client.get_balance(wallet_address)
        
        if "result" in response and "value" in response["result"]:
            lamports = response["result"]["value"]
            sol = lamports / 10**9
            usd = sol * 100  # Approximate SOL price at $100
            
            print(f"SOL balance: {sol:.9f} SOL (${usd:.2f})")
        else:
            print(f"Error getting balance: {response}")
    except Exception as e:
        print(f"Error getting balance: {e}")

def cmd_quote(args):
    """Handle quote command"""
    # Convert arguments to required formats
    input_token = args.input.upper()
    output_token = args.output.upper()
    amount = args.amount
    
    # Validate tokens
    if input_token not in TOKEN_SYMBOLS:
        print(f"ERROR: Unknown input token: {input_token}")
        print(f"Available tokens: {', '.join(TOKEN_SYMBOLS.keys())}")
        return
    
    if output_token not in TOKEN_SYMBOLS:
        print(f"ERROR: Unknown output token: {output_token}")
        print(f"Available tokens: {', '.join(TOKEN_SYMBOLS.keys())}")
        return
    
    # Get token addresses
    input_mint = TOKEN_SYMBOLS[input_token]
    output_mint = TOKEN_SYMBOLS[output_token]
    
    # Convert amount to smallest units
    input_decimals = 9  # Default for most tokens
    if input_token == "USDC":
        input_decimals = 6
    
    amount_smallest = int(amount * (10 ** input_decimals))
    
    # Get quote
    print(f"Getting quote for {amount} {input_token} to {output_token}...")
    quote = jupiter.get_quote(input_mint, output_mint, amount_smallest)
    
    if "error" in quote:
        print(f"ERROR: {quote['error']}")
        return
    
    # Print quote details
    input_amount = int(quote.get("inputAmount", "0"))
    output_amount = int(quote.get("outputAmount", "0"))
    
    output_decimals = 9  # Default for most tokens
    if output_token == "USDC":
        output_decimals = 6
    
    input_human = input_amount / (10 ** input_decimals)
    output_human = output_amount / (10 ** output_decimals)
    
    # Calculate rate
    rate = output_human / input_human if input_human > 0 else 0
    impact = quote.get("priceImpactPct", 0)
    
    print("\n=== QUOTE RESULT ===")
    print(f"Input: {input_human} {input_token}")
    print(f"Output: {output_human} {output_token}")
    print(f"Rate: 1 {input_token} = {rate} {output_token}")
    print(f"Price impact: {impact:.2f}%")
    
    # Print routes if available
    routes = quote.get("routePlan", [])
    if routes:
        print("\nRoute Plan:")
        for i, route in enumerate(routes):
            percent = route.get("swapInfo", {}).get("percentageShare", 0) * 100
            print(f"  Route {i+1}: {percent:.1f}%")

def cmd_buy(args):
    """Handle buy command"""
    # Get token address
    token_symbol = args.token.upper()
    if token_symbol not in TOKEN_SYMBOLS:
        print(f"ERROR: Unknown token: {token_symbol}")
        print(f"Available tokens: {', '.join(TOKEN_SYMBOLS.keys())}")
        return
    
    token_mint = TOKEN_SYMBOLS[token_symbol]
    sol_amount = args.amount
    
    # Confirm with user
    print(f"\nYou are about to buy {token_symbol} with {sol_amount} SOL")
    confirm = input("Are you sure you want to proceed? (y/n): ")
    
    if confirm.lower() != "y":
        print("Operation cancelled.")
        return
    
    # Execute trade
    print(f"Buying {token_symbol} with {sol_amount} SOL...")
    result = jupiter.buy_token_with_sol(token_mint, sol_amount)
    
    # Print result
    print_trade_result(result)

def cmd_sell(args):
    """Handle sell command"""
    # Get token address
    token_symbol = args.token.upper()
    if token_symbol not in TOKEN_SYMBOLS:
        print(f"ERROR: Unknown token: {token_symbol}")
        print(f"Available tokens: {', '.join(TOKEN_SYMBOLS.keys())}")
        return
    
    token_mint = TOKEN_SYMBOLS[token_symbol]
    token_amount = args.amount
    
    # Get token decimals
    token_decimals = 9  # Default for most tokens
    if token_symbol == "USDC":
        token_decimals = 6
    
    # Convert to smallest units
    amount_smallest = int(token_amount * (10 ** token_decimals))
    
    # Confirm with user
    print(f"\nYou are about to sell {token_amount} {token_symbol} for SOL")
    confirm = input("Are you sure you want to proceed? (y/n): ")
    
    if confirm.lower() != "y":
        print("Operation cancelled.")
        return
    
    # Execute trade
    print(f"Selling {token_amount} {token_symbol} for SOL...")
    result = jupiter.sell_token_for_sol(token_mint, amount_smallest)
    
    # Print result
    print_trade_result(result)

def cmd_stats(args):
    """Handle stats command"""
    stats = jupiter.get_trade_stats()
    
    if "error" in stats:
        print(f"ERROR: {stats['error']}")
        return
    
    print("\n=== TRADING STATISTICS ===")
    print(f"Total trades: {stats['total_trades']}")
    print(f"Confirmed trades: {stats['confirmed_trades']}")
    print(f"Pending trades: {stats['pending_trades']}")
    print(f"Failed trades: {stats['failed_trades']}")
    print()
    print(f"Total SOL spent: {stats['total_sol_spent']:.4f} SOL")
    print(f"Total SOL received: {stats['total_sol_received']:.4f} SOL")
    print(f"Net SOL profit/loss: {stats['net_sol']:.4f} SOL")
    
    # Print tokens bought
    if stats['tokens_bought']:
        print("\nTokens bought:")
        for token, count in stats['tokens_bought'].items():
            # Try to get the symbol
            symbol = "Unknown"
            for sym, addr in TOKEN_SYMBOLS.items():
                if addr == token:
                    symbol = sym
                    break
            print(f"  {symbol} ({token}): {count} trades")
    
    # Print tokens sold
    if stats['tokens_sold']:
        print("\nTokens sold:")
        for token, count in stats['tokens_sold'].items():
            # Try to get the symbol
            symbol = "Unknown"
            for sym, addr in TOKEN_SYMBOLS.items():
                if addr == token:
                    symbol = sym
                    break
            print(f"  {symbol} ({token}): {count} trades")

def cmd_test(args):
    """Handle test command"""
    print("\n=== TESTING JUPITER INTEGRATION ===")
    
    # Test the integration
    results = jupiter.test_full_integration()
    
    print(f"\nTest results: {'Success' if results.get('success') else 'Failed'}")
    print(f"Message: {results.get('message')}")
    
    if results.get("wallet_available"):
        print(f"\nWallet: {results.get('wallet_address')}")
    
    if "jupiter_api" in results:
        api_test = results["jupiter_api"]
        print(f"\nJupiter API test: {'Success' if api_test.get('success') else 'Failed'}")
        print(f"  {api_test.get('message')}")
    
    if "swap_transaction" in results:
        swap_test = results["swap_transaction"]
        print(f"\nSwap transaction test: {'Success' if swap_test.get('success') else 'Failed'}")
        print(f"  {swap_test.get('message')}")

def setup_parser():
    """Set up command line argument parser"""
    parser = argparse.ArgumentParser(
        description="Execute trades using Jupiter DEX on Solana"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Balance command
    balance_parser = subparsers.add_parser("balance", help="Check wallet balance")
    balance_parser.set_defaults(func=cmd_balance)
    
    # Quote command
    quote_parser = subparsers.add_parser("quote", help="Get a quote for a token swap")
    quote_parser.add_argument("--input", required=True, help="Input token symbol")
    quote_parser.add_argument("--output", required=True, help="Output token symbol")
    quote_parser.add_argument("--amount", required=True, type=float, help="Amount of input token")
    quote_parser.set_defaults(func=cmd_quote)
    
    # Buy command
    buy_parser = subparsers.add_parser("buy", help="Buy a token using SOL")
    buy_parser.add_argument("--token", required=True, help="Token symbol to buy")
    buy_parser.add_argument("--amount", required=True, type=float, help="Amount of SOL to spend")
    buy_parser.set_defaults(func=cmd_buy)
    
    # Sell command
    sell_parser = subparsers.add_parser("sell", help="Sell a token for SOL")
    sell_parser.add_argument("--token", required=True, help="Token symbol to sell")
    sell_parser.add_argument("--amount", required=True, type=float, help="Amount of token to sell")
    sell_parser.set_defaults(func=cmd_sell)
    
    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Get trading statistics")
    stats_parser.set_defaults(func=cmd_stats)
    
    # Test command
    test_parser = subparsers.add_parser("test", help="Test Jupiter integration")
    test_parser.set_defaults(func=cmd_test)
    
    return parser

def main():
    """Main function"""
    parser = setup_parser()
    args = parser.parse_args()
    
    # Check if a command was provided
    if not hasattr(args, "func"):
        parser.print_help()
        return
    
    # Check if SOLANA_PRIVATE_KEY is set
    if not os.environ.get("SOLANA_PRIVATE_KEY"):
        print("ERROR: SOLANA_PRIVATE_KEY environment variable is not set.")
        print("Please set your private key before running this script:")
        print("export SOLANA_PRIVATE_KEY=your_private_key")
        return
    
    # Execute the command
    try:
        args.func(args)
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()