"""
SMART MEMES BOT - Serum DEX Trading Utility

This module provides utility functions for trading directly on Serum DEX
markets without going through Jupiter DEX aggregator.
"""

import os
import asyncio
from solana.rpc.async_api import AsyncClient
from solana.transaction import Transaction
from solana.publickey import PublicKey
from solana.keypair import Keypair
from solana.system_program import TransferParams, transfer
from solana.rpc.commitment import Confirmed
from solana.rpc.types import TxOpts
from pyserum.market import Market

# Initialize Solana client and wallet
RPC = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
_CLIENT = AsyncClient(RPC)
_WALLET = None

def init_wallet():
    """Initialize wallet from private key"""
    global _WALLET
    private_key = os.getenv("SOLANA_PRIVATE_KEY")
    if private_key:
        _WALLET = Keypair.from_secret_key(bytes.fromhex(private_key))
        return True
    return False

async def get_token_price(market_address: str) -> float:
    """
    Get current token price from Serum DEX market
    
    Args:
        market_address: Serum market address
        
    Returns:
        Current mid price (average of best bid and ask)
    """
    mkt = await Market.load(_CLIENT, PublicKey(market_address))
    bid, ask = await mkt.load_bids(), await mkt.load_asks()
    return (bid.get_l2(1)[0][0] + ask.get_l2(1)[0][0]) / 2

async def buy_token(market_address: str, price: float, size: float):
    """
    Buy token on Serum DEX
    
    Args:
        market_address: Serum market address
        price: Limit order price
        size: Order size
        
    Returns:
        Transaction response
    """
    if not _WALLET:
        if not init_wallet():
            raise ValueError("Wallet not initialized. Set SOLANA_PRIVATE_KEY environment variable.")
            
    mkt = await Market.load(_CLIENT, PublicKey(market_address))
    tx = Transaction()
    ix = mkt.make_place_order_instruction(
        owner=_WALLET.public_key,
        payer=_WALLET.public_key,
        side="buy",
        price=price,
        size=size,
        order_type="limit",
        client_id=1
    )
    tx.add(ix)
    resp = await _CLIENT.send_transaction(tx, _WALLET, opts=TxOpts(skip_preflight=True))
    await _CLIENT.confirm_transaction(resp["result"], commitment=Confirmed)
    return resp

async def sell_token(market_address: str, price: float, size: float):
    """
    Sell token on Serum DEX
    
    Args:
        market_address: Serum market address
        price: Limit order price
        size: Order size
        
    Returns:
        Transaction response
    """
    if not _WALLET:
        if not init_wallet():
            raise ValueError("Wallet not initialized. Set SOLANA_PRIVATE_KEY environment variable.")
            
    mkt = await Market.load(_CLIENT, PublicKey(market_address))
    tx = Transaction()
    ix = mkt.make_place_order_instruction(
        owner=_WALLET.public_key,
        payer=_WALLET.public_key,
        side="sell",
        price=price,
        size=size,
        order_type="limit",
        client_id=2
    )
    tx.add(ix)
    resp = await _CLIENT.send_transaction(tx, _WALLET, opts=TxOpts(skip_preflight=True))
    await _CLIENT.confirm_transaction(resp["result"], commitment=Confirmed)
    return resp

def run_async(coro):
    """Run an async coroutine and return its result"""
    return asyncio.get_event_loop().run_until_complete(coro)