"""
Evolving Sniper Algorithm for SMART MEMES BOT.

This module implements an adaptive sniping system that:
1. Self-adjusts trading activity based on recent performance
2. Pauses trading during unprofitable periods (requires >30% average profit)
3. Continues trading during profitable market conditions
4. Dynamically modifies risk parameters based on results
5. Creates an adaptive feedback loop for continuous improvement

The algorithm analyzes past performance to make intelligent decisions about
when to trade, what parameters to use, and how to allocate capital.
"""

import os
import json
import logging
import time
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set, Union
from dataclasses import dataclass
import aiohttp
from datetime import datetime, timedelta

# Configure logger
logger = logging.getLogger(__name__)

# Try to import core components
try:
    from utils.risk_manager import should_continue_trading
except ImportError:
    logger.warning("Could not import risk_manager, some functions may not work")


@dataclass
class TradeRecord:
    """Data class to hold a trade record for performance tracking."""
    token_address: str
    entry_time: float
    exit_time: Optional[float]
    entry_price: float
    exit_price: Optional[float]
    amount_spent: float
    profit_percent: Optional[float]
    source_type: str  # "group", "wallet", "twitter", etc.
    source_id: str
    was_successful: bool
    transaction_hash: str
    risk_level: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert record to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "entry_price": self.entry_price,
            "exit_price": self.exit_price,
            "amount_spent": self.amount_spent,
            "profit_percent": self.profit_percent,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "was_successful": self.was_successful,
            "transaction_hash": self.transaction_hash,
            "risk_level": self.risk_level
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TradeRecord':
        """Create record object from dictionary."""
        return cls(
            token_address=data["token_address"],
            entry_time=data["entry_time"],
            exit_time=data["exit_time"],
            entry_price=data["entry_price"],
            exit_price=data["exit_price"],
            amount_spent=data["amount_spent"],
            profit_percent=data["profit_percent"],
            source_type=data["source_type"],
            source_id=data["source_id"],
            was_successful=data["was_successful"],
            transaction_hash=data["transaction_hash"],
            risk_level=data["risk_level"]
        )


@dataclass
class PerformanceMetrics:
    """Data class to hold performance metrics."""
    time_period: str  # "day", "week", "month", "all"
    start_time: float
    end_time: float
    total_trades: int
    successful_trades: int
    profitable_trades: int
    total_invested: float
    total_returned: float
    net_profit: float
    roi_percent: float
    average_profit_percent: float
    max_profit_percent: float
    max_loss_percent: float
    win_rate: float
    source_performance: Dict[str, Dict[str, float]]
    risk_level_performance: Dict[str, Dict[str, float]]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary for storage."""
        return {
            "time_period": self.time_period,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "total_trades": self.total_trades,
            "successful_trades": self.successful_trades,
            "profitable_trades": self.profitable_trades,
            "total_invested": self.total_invested,
            "total_returned": self.total_returned,
            "net_profit": self.net_profit,
            "roi_percent": self.roi_percent,
            "average_profit_percent": self.average_profit_percent,
            "max_profit_percent": self.max_profit_percent,
            "max_loss_percent": self.max_loss_percent,
            "win_rate": self.win_rate,
            "source_performance": self.source_performance,
            "risk_level_performance": self.risk_level_performance
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PerformanceMetrics':
        """Create metrics object from dictionary."""
        return cls(
            time_period=data["time_period"],
            start_time=data["start_time"],
            end_time=data["end_time"],
            total_trades=data["total_trades"],
            successful_trades=data["successful_trades"],
            profitable_trades=data["profitable_trades"],
            total_invested=data["total_invested"],
            total_returned=data["total_returned"],
            net_profit=data["net_profit"],
            roi_percent=data["roi_percent"],
            average_profit_percent=data["average_profit_percent"],
            max_profit_percent=data["max_profit_percent"],
            max_loss_percent=data["max_loss_percent"],
            win_rate=data["win_rate"],
            source_performance=data["source_performance"],
            risk_level_performance=data["risk_level_performance"]
        )


@dataclass
class TradingParameters:
    """Data class to hold adaptive trading parameters."""
    is_trading_enabled: bool
    min_social_proof_score: float
    min_safety_score: float
    min_liquidity_score: float
    min_combined_score: float
    confirmation_sources_required: int
    max_position_size: float
    max_positions: int
    preferred_risk_level: str
    excluded_sources: List[str]
    preferred_sources: List[str]
    create_time: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert parameters to dictionary for storage."""
        return {
            "is_trading_enabled": self.is_trading_enabled,
            "min_social_proof_score": self.min_social_proof_score,
            "min_safety_score": self.min_safety_score,
            "min_liquidity_score": self.min_liquidity_score,
            "min_combined_score": self.min_combined_score,
            "confirmation_sources_required": self.confirmation_sources_required,
            "max_position_size": self.max_position_size,
            "max_positions": self.max_positions,
            "preferred_risk_level": self.preferred_risk_level,
            "excluded_sources": self.excluded_sources,
            "preferred_sources": self.preferred_sources,
            "create_time": self.create_time
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TradingParameters':
        """Create parameters object from dictionary."""
        return cls(
            is_trading_enabled=data["is_trading_enabled"],
            min_social_proof_score=data["min_social_proof_score"],
            min_safety_score=data["min_safety_score"],
            min_liquidity_score=data["min_liquidity_score"],
            min_combined_score=data["min_combined_score"],
            confirmation_sources_required=data["confirmation_sources_required"],
            max_position_size=data["max_position_size"],
            max_positions=data["max_positions"],
            preferred_risk_level=data["preferred_risk_level"],
            excluded_sources=data["excluded_sources"],
            preferred_sources=data["preferred_sources"],
            create_time=data["create_time"]
        )


# Trade history in memory (would be database in production)
_trade_history = []

# Current trading parameters
_current_parameters = TradingParameters(
    is_trading_enabled=True,
    min_social_proof_score=6.0,
    min_safety_score=6.0,
    min_liquidity_score=5.0,
    min_combined_score=6.5,
    confirmation_sources_required=1,
    max_position_size=0.1,
    max_positions=10,
    preferred_risk_level="medium",
    excluded_sources=[],
    preferred_sources=[],
    create_time=time.time()
)

# Performance cache
_performance_cache = {}


async def record_trade(record: TradeRecord) -> None:
    """
    Record a trade for performance tracking.
    
    Args:
        record: TradeRecord object with trade details
    """
    # In a real implementation, this would save to a database
    # For now, we'll just add to our in-memory list
    _trade_history.append(record)
    
    # Log the trade
    if record.profit_percent is not None:
        profit_str = f"{record.profit_percent:+.2f}%"
    else:
        profit_str = "unknown"
        
    logger.info(f"Recorded trade: {record.token_address}, {profit_str} profit")
    
    # Clear performance cache as it's now outdated
    _performance_cache.clear()


async def update_trade_result(
    transaction_hash: str,
    exit_price: float,
    exit_time: float,
    profit_percent: float
) -> bool:
    """
    Update a trade with its result.
    
    Args:
        transaction_hash: Transaction hash of the trade to update
        exit_price: Exit price
        exit_time: Exit timestamp
        profit_percent: Profit percentage
        
    Returns:
        True if update was successful, False otherwise
    """
    # Find the trade in our history
    for trade in _trade_history:
        if trade.transaction_hash == transaction_hash:
            # Update trade
            trade.exit_price = exit_price
            trade.exit_time = exit_time
            trade.profit_percent = profit_percent
            trade.was_successful = True
            
            # Clear performance cache as it's now outdated
            _performance_cache.clear()
            
            logger.info(f"Updated trade {transaction_hash} with {profit_percent:+.2f}% profit")
            return True
    
    logger.warning(f"Could not find trade with hash {transaction_hash}")
    return False


async def calculate_performance_metrics(
    time_period: str = "all"
) -> PerformanceMetrics:
    """
    Calculate performance metrics for a specific time period.
    
    Args:
        time_period: Time period to calculate for ("day", "week", "month", "all")
        
    Returns:
        PerformanceMetrics object with calculated metrics
    """
    # Check cache first
    cache_key = f"metrics:{time_period}"
    if cache_key in _performance_cache:
        return _performance_cache[cache_key]
    
    # Determine time range
    end_time = time.time()
    if time_period == "day":
        start_time = end_time - 86400
    elif time_period == "week":
        start_time = end_time - 604800
    elif time_period == "month":
        start_time = end_time - 2592000
    else:  # "all"
        start_time = 0
    
    # Filter trades for this time period
    period_trades = [
        trade for trade in _trade_history
        if trade.entry_time >= start_time and trade.entry_time <= end_time
    ]
    
    # If no trades in this period, return default metrics
    if not period_trades:
        metrics = PerformanceMetrics(
            time_period=time_period,
            start_time=start_time,
            end_time=end_time,
            total_trades=0,
            successful_trades=0,
            profitable_trades=0,
            total_invested=0.0,
            total_returned=0.0,
            net_profit=0.0,
            roi_percent=0.0,
            average_profit_percent=0.0,
            max_profit_percent=0.0,
            max_loss_percent=0.0,
            win_rate=0.0,
            source_performance={},
            risk_level_performance={}
        )
        
        # Cache and return
        _performance_cache[cache_key] = metrics
        return metrics
    
    # Calculate metrics
    total_trades = len(period_trades)
    successful_trades = sum(1 for trade in period_trades if trade.was_successful)
    profitable_trades = sum(1 for trade in period_trades 
                           if trade.profit_percent is not None and trade.profit_percent > 0)
    
    total_invested = sum(trade.amount_spent for trade in period_trades)
    
    # Calculate returns and profits
    total_returned = 0.0
    for trade in period_trades:
        if trade.profit_percent is not None and trade.amount_spent > 0:
            # Calculate return based on profit percentage
            trade_return = trade.amount_spent * (1 + trade.profit_percent / 100)
            total_returned += trade_return
    
    net_profit = total_returned - total_invested
    roi_percent = (net_profit / total_invested * 100) if total_invested > 0 else 0.0
    
    # Calculate profit percentages
    profit_percentages = [trade.profit_percent for trade in period_trades 
                         if trade.profit_percent is not None]
    
    average_profit_percent = sum(profit_percentages) / len(profit_percentages) if profit_percentages else 0.0
    max_profit_percent = max(profit_percentages) if profit_percentages else 0.0
    max_loss_percent = min(profit_percentages) if profit_percentages else 0.0
    
    win_rate = profitable_trades / total_trades if total_trades > 0 else 0.0
    
    # Calculate source performance
    source_performance = {}
    for trade in period_trades:
        source_key = f"{trade.source_type}:{trade.source_id}"
        
        if source_key not in source_performance:
            source_performance[source_key] = {
                "total_trades": 0,
                "successful_trades": 0,
                "profitable_trades": 0,
                "total_invested": 0.0,
                "average_profit": 0.0,
                "win_rate": 0.0
            }
        
        # Update source stats
        source_performance[source_key]["total_trades"] += 1
        source_performance[source_key]["total_invested"] += trade.amount_spent
        
        if trade.was_successful:
            source_performance[source_key]["successful_trades"] += 1
            
        if trade.profit_percent is not None and trade.profit_percent > 0:
            source_performance[source_key]["profitable_trades"] += 1
            
        # Recalculate average profit
        source_profits = [t.profit_percent for t in period_trades 
                         if t.source_type == trade.source_type 
                         and t.source_id == trade.source_id
                         and t.profit_percent is not None]
        
        if source_profits:
            source_performance[source_key]["average_profit"] = sum(source_profits) / len(source_profits)
            source_performance[source_key]["win_rate"] = (
                source_performance[source_key]["profitable_trades"] / 
                source_performance[source_key]["total_trades"]
            )
    
    # Calculate risk level performance
    risk_level_performance = {}
    for trade in period_trades:
        risk_level = trade.risk_level
        
        if risk_level not in risk_level_performance:
            risk_level_performance[risk_level] = {
                "total_trades": 0,
                "successful_trades": 0,
                "profitable_trades": 0,
                "total_invested": 0.0,
                "average_profit": 0.0,
                "win_rate": 0.0
            }
        
        # Update risk level stats
        risk_level_performance[risk_level]["total_trades"] += 1
        risk_level_performance[risk_level]["total_invested"] += trade.amount_spent
        
        if trade.was_successful:
            risk_level_performance[risk_level]["successful_trades"] += 1
            
        if trade.profit_percent is not None and trade.profit_percent > 0:
            risk_level_performance[risk_level]["profitable_trades"] += 1
            
        # Recalculate average profit
        risk_profits = [t.profit_percent for t in period_trades 
                       if t.risk_level == risk_level
                       and t.profit_percent is not None]
        
        if risk_profits:
            risk_level_performance[risk_level]["average_profit"] = sum(risk_profits) / len(risk_profits)
            risk_level_performance[risk_level]["win_rate"] = (
                risk_level_performance[risk_level]["profitable_trades"] / 
                risk_level_performance[risk_level]["total_trades"]
            )
    
    # Create metrics object
    metrics = PerformanceMetrics(
        time_period=time_period,
        start_time=start_time,
        end_time=end_time,
        total_trades=total_trades,
        successful_trades=successful_trades,
        profitable_trades=profitable_trades,
        total_invested=total_invested,
        total_returned=total_returned,
        net_profit=net_profit,
        roi_percent=roi_percent,
        average_profit_percent=average_profit_percent,
        max_profit_percent=max_profit_percent,
        max_loss_percent=max_loss_percent,
        win_rate=win_rate,
        source_performance=source_performance,
        risk_level_performance=risk_level_performance
    )
    
    # Cache metrics
    _performance_cache[cache_key] = metrics
    
    return metrics


async def should_adjust_parameters(metrics: PerformanceMetrics) -> bool:
    """
    Determine if trading parameters should be adjusted based on performance.
    
    Args:
        metrics: Performance metrics
        
    Returns:
        True if parameters should be adjusted, False otherwise
    """
    # Adjust every 50 trades minimum
    min_trades_for_adjustment = 50
    
    if metrics.total_trades < min_trades_for_adjustment:
        logger.info(f"Not enough trades ({metrics.total_trades}) for parameter adjustment")
        return False
    
    # Check if it's been at least 24 hours since last adjustment
    last_adjustment_time = _current_parameters.create_time
    if time.time() - last_adjustment_time < 86400:
        logger.info("Less than 24 hours since last parameter adjustment")
        return False
    
    # Adjust if performance is significantly good or bad
    if metrics.average_profit_percent < -10:
        logger.info(f"Poor performance ({metrics.average_profit_percent:.2f}%) suggests parameter adjustment")
        return True
    
    if metrics.average_profit_percent > 50:
        logger.info(f"Excellent performance ({metrics.average_profit_percent:.2f}%) suggests parameter adjustment")
        return True
    
    if metrics.win_rate < 0.3:
        logger.info(f"Low win rate ({metrics.win_rate:.2f}) suggests parameter adjustment")
        return True
    
    # Default to no adjustment
    return False


async def adjust_trading_parameters(metrics: PerformanceMetrics) -> TradingParameters:
    """
    Adjust trading parameters based on performance metrics.
    
    Args:
        metrics: Performance metrics
        
    Returns:
        New TradingParameters
    """
    logger.info("Adjusting trading parameters based on performance")
    
    # Start with current parameters
    new_parameters = TradingParameters(
        is_trading_enabled=_current_parameters.is_trading_enabled,
        min_social_proof_score=_current_parameters.min_social_proof_score,
        min_safety_score=_current_parameters.min_safety_score,
        min_liquidity_score=_current_parameters.min_liquidity_score,
        min_combined_score=_current_parameters.min_combined_score,
        confirmation_sources_required=_current_parameters.confirmation_sources_required,
        max_position_size=_current_parameters.max_position_size,
        max_positions=_current_parameters.max_positions,
        preferred_risk_level=_current_parameters.preferred_risk_level,
        excluded_sources=list(_current_parameters.excluded_sources),  # Create a copy
        preferred_sources=list(_current_parameters.preferred_sources),  # Create a copy
        create_time=time.time()
    )
    
    # Adjust based on overall performance
    if metrics.average_profit_percent < 0:
        # Poor performance: be more conservative
        logger.info("Adjusting parameters to be more conservative due to poor performance")
        
        # Increase minimum scores
        new_parameters.min_social_proof_score = min(9.0, _current_parameters.min_social_proof_score + 0.5)
        new_parameters.min_safety_score = min(9.0, _current_parameters.min_safety_score + 0.5)
        new_parameters.min_liquidity_score = min(8.0, _current_parameters.min_liquidity_score + 0.5)
        new_parameters.min_combined_score = min(8.5, _current_parameters.min_combined_score + 0.5)
        
        # Require more confirmation sources
        new_parameters.confirmation_sources_required = min(3, _current_parameters.confirmation_sources_required + 1)
        
        # Reduce position size
        new_parameters.max_position_size = max(0.05, _current_parameters.max_position_size * 0.8)
        
        # Shift to lower risk
        if _current_parameters.preferred_risk_level == "high":
            new_parameters.preferred_risk_level = "medium"
        elif _current_parameters.preferred_risk_level == "medium":
            new_parameters.preferred_risk_level = "low"
    
    elif metrics.average_profit_percent > 30:
        # Good performance: be more aggressive
        logger.info("Adjusting parameters to be more aggressive due to good performance")
        
        # Decrease minimum scores slightly
        new_parameters.min_social_proof_score = max(5.0, _current_parameters.min_social_proof_score - 0.3)
        new_parameters.min_safety_score = max(5.5, _current_parameters.min_safety_score - 0.3)
        new_parameters.min_liquidity_score = max(4.5, _current_parameters.min_liquidity_score - 0.3)
        new_parameters.min_combined_score = max(6.0, _current_parameters.min_combined_score - 0.3)
        
        # Relax confirmation requirements if currently strict
        if _current_parameters.confirmation_sources_required > 1:
            new_parameters.confirmation_sources_required = _current_parameters.confirmation_sources_required - 1
        
        # Increase position size
        new_parameters.max_position_size = min(0.2, _current_parameters.max_position_size * 1.2)
        
        # Shift to higher risk if doing very well
        if metrics.average_profit_percent > 50 and _current_parameters.preferred_risk_level == "low":
            new_parameters.preferred_risk_level = "medium"
        elif metrics.average_profit_percent > 80 and _current_parameters.preferred_risk_level == "medium":
            new_parameters.preferred_risk_level = "high"
    
    # Adjust for source performance
    if metrics.source_performance:
        # Find best and worst performing sources
        best_sources = []
        worst_sources = []
        
        for source, perf in metrics.source_performance.items():
            if perf["total_trades"] >= 5:  # Minimum trades for consideration
                if perf["average_profit"] > 40 and perf["win_rate"] > 0.5:
                    best_sources.append(source)
                elif perf["average_profit"] < -20 or perf["win_rate"] < 0.2:
                    worst_sources.append(source)
        
        # Update preferred and excluded sources
        for source in best_sources:
            if source not in new_parameters.preferred_sources:
                new_parameters.preferred_sources.append(source)
                logger.info(f"Adding {source} to preferred sources due to good performance")
        
        for source in worst_sources:
            if source not in new_parameters.excluded_sources:
                new_parameters.excluded_sources.append(source)
                logger.info(f"Adding {source} to excluded sources due to poor performance")
    
    # Adjust for risk level performance
    if metrics.risk_level_performance:
        best_risk_level = None
        best_profit = -float('inf')
        
        for risk_level, perf in metrics.risk_level_performance.items():
            if perf["total_trades"] >= 5:  # Minimum trades for consideration
                if perf["average_profit"] > best_profit:
                    best_profit = perf["average_profit"]
                    best_risk_level = risk_level
        
        if best_risk_level and best_risk_level != new_parameters.preferred_risk_level:
            logger.info(f"Changing preferred risk level from {new_parameters.preferred_risk_level} to {best_risk_level}")
            new_parameters.preferred_risk_level = best_risk_level
    
    # Check if we should disable trading entirely
    should_continue, reason, profit_rate = await should_continue_trading(lookback_hours=24)
    new_parameters.is_trading_enabled = should_continue
    
    if not should_continue:
        logger.warning(f"Disabling trading: {reason}")
    
    # Return the new parameters
    return new_parameters


async def evolve_trading_strategy() -> Tuple[bool, TradingParameters]:
    """
    Evolve the trading strategy based on recent performance.
    
    Returns:
        Tuple of (changed, new_parameters)
    """
    # Get recent performance
    metrics = await calculate_performance_metrics(time_period="week")
    
    # Check if we should adjust parameters
    should_adjust = await should_adjust_parameters(metrics)
    
    if should_adjust:
        # Adjust parameters
        new_parameters = await adjust_trading_parameters(metrics)
        
        # Update current parameters
        global _current_parameters
        _current_parameters = new_parameters
        
        logger.info("Trading parameters evolved based on performance")
        return True, new_parameters
    
    return False, _current_parameters


async def run_evolution_cycle() -> bool:
    """
    Run a complete evolution cycle.
    
    Returns:
        True if the strategy evolved, False otherwise
    """
    try:
        logger.info("Running evolution cycle")
        
        # Get performance metrics for different time periods
        day_metrics = await calculate_performance_metrics(time_period="day")
        week_metrics = await calculate_performance_metrics(time_period="week")
        month_metrics = await calculate_performance_metrics(time_period="month")
        all_metrics = await calculate_performance_metrics(time_period="all")
        
        # Log current performance
        logger.info(f"Day: {day_metrics.total_trades} trades, {day_metrics.average_profit_percent:.2f}% avg profit")
        logger.info(f"Week: {week_metrics.total_trades} trades, {week_metrics.average_profit_percent:.2f}% avg profit")
        logger.info(f"Month: {month_metrics.total_trades} trades, {month_metrics.average_profit_percent:.2f}% avg profit")
        logger.info(f"All-time: {all_metrics.total_trades} trades, {all_metrics.average_profit_percent:.2f}% avg profit")
        
        # Evolve the strategy
        changed, new_parameters = await evolve_trading_strategy()
        
        if changed:
            logger.info("Trading strategy evolved")
            logger.info(f"New min combined score: {new_parameters.min_combined_score}")
            logger.info(f"New max position size: {new_parameters.max_position_size}")
            logger.info(f"New preferred risk level: {new_parameters.preferred_risk_level}")
            logger.info(f"Trading enabled: {new_parameters.is_trading_enabled}")
        else:
            logger.info("Trading strategy remains unchanged")
        
        return changed
    
    except Exception as e:
        logger.error(f"Error in evolution cycle: {e}")
        return False


async def get_current_parameters() -> TradingParameters:
    """
    Get the current trading parameters.
    
    Returns:
        Current TradingParameters
    """
    return _current_parameters


async def check_if_should_trade(token_address: str, source_type: str, source_id: str) -> Tuple[bool, str]:
    """
    Check if a specific token from a specific source should be traded.
    
    Args:
        token_address: Token address
        source_type: Source type (group, wallet, twitter)
        source_id: Source identifier
        
    Returns:
        Tuple of (should_trade, reason)
    """
    # Get current parameters
    params = await get_current_parameters()
    
    # Check if trading is enabled
    if not params.is_trading_enabled:
        return False, "Trading is currently disabled"
    
    # Check if source is excluded
    source_key = f"{source_type}:{source_id}"
    if source_key in params.excluded_sources:
        return False, f"Source {source_key} is excluded due to poor performance"
    
    # Additional checks could go here, like token-specific blacklists
    
    return True, "Trading is permitted"


# Test functions
async def test_evolving_sniper():
    # Add some simulated trade records
    for i in range(20):
        # Alternate between profitable and unprofitable trades
        is_profitable = i % 2 == 0
        
        # Create a trade record
        record = TradeRecord(
            token_address=f"Token{i}",
            entry_time=time.time() - (i * 3600),  # Staggered over the past day
            exit_time=time.time() - (i * 3600) + 1800,  # 30 minutes later
            entry_price=1.0,
            exit_price=1.5 if is_profitable else 0.7,
            amount_spent=0.1,
            profit_percent=50.0 if is_profitable else -30.0,
            source_type="group",
            source_id=f"group{i % 3}",  # Three different groups
            was_successful=True,
            transaction_hash=f"tx{i}",
            risk_level=["low", "medium", "high"][i % 3]  # Three risk levels
        )
        
        # Record the trade
        await record_trade(record)
    
    # Calculate performance metrics
    metrics = await calculate_performance_metrics(time_period="all")
    
    print("Performance Metrics:")
    print(f"Total Trades: {metrics.total_trades}")
    print(f"Successful Trades: {metrics.successful_trades}")
    print(f"Profitable Trades: {metrics.profitable_trades}")
    print(f"Average Profit: {metrics.average_profit_percent:.2f}%")
    print(f"Win Rate: {metrics.win_rate:.2f}")
    print(f"ROI: {metrics.roi_percent:.2f}%")
    
    # Print source performance
    print("\nSource Performance:")
    for source, perf in metrics.source_performance.items():
        print(f"{source}: {perf['average_profit']:.2f}% avg profit, {perf['win_rate']:.2f} win rate")
    
    # Print risk level performance
    print("\nRisk Level Performance:")
    for risk, perf in metrics.risk_level_performance.items():
        print(f"{risk}: {perf['average_profit']:.2f}% avg profit, {perf['win_rate']:.2f} win rate")
    
    # Run evolution cycle
    changed = await run_evolution_cycle()
    
    print(f"\nStrategy evolved: {changed}")
    print(f"Current parameters: min_score={_current_parameters.min_combined_score}, "
          f"max_position={_current_parameters.max_position_size}, "
          f"risk_level={_current_parameters.preferred_risk_level}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_evolving_sniper())