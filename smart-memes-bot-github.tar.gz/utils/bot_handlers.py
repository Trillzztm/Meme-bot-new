"""
Unified bot handlers for SMART MEMES BOT.

This module provides a dispatch mechanism for routing commands to their appropriate
handlers regardless of the bot implementation used (standard or simplified).
"""

import logging
import re
from typing import Any, Dict, List, Optional, Union, Tuple, Callable

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def dispatch_command(cmd: str, chat_id: Union[int, str], 
                          message: str, bot: Any) -> bool:
    """
    Dispatch a command to the appropriate handler.
    
    Args:
        cmd: The command without the leading slash
        chat_id: The chat ID where the command was sent
        message: The full message text
        bot: The bot instance
        
    Returns:
        True if the command was handled, False otherwise
    """
    logger.info(f"Dispatching command: {cmd}")
    
    # Extract command args
    parts = message.split()
    args = parts[1:] if len(parts) > 1 else []
    
    try:
        # Map commands to their handlers
        handlers = {
            # Basic commands
            "start": handle_start,
            "help": handle_help,
            
            # Token information and analysis
            "tokeninfo": handle_tokeninfo,
            "tokensafety": handle_tokensafety,
            "marketpredict": handle_marketpredict,
            "aiadvice": handle_aiadvice,  # AI-powered token analysis
            
            # Trading commands
            "manualsnipe": handle_manualsnipe,
            "autosnipe": handle_autosnipe,
            "sniper": handle_sniper,  # Enhanced sniper command
            "smarttrade": handle_smarttrade,  # AI-powered smart trading
            "ultimate": handle_ultimate,  # Ultimate trading engine
            
            # Monitoring commands
            "watchgroup": handle_watchgroup,
            "trackwallet": handle_trackwallet,
            
            # Content generation
            "generateprememe": handle_generateprememe,
            
            # Configuration
            "settings": handle_settings,
        }
        
        # If we have a handler, call it
        if cmd in handlers:
            await handlers[cmd](chat_id, args, bot)
            return True
            
        return False
        
    except Exception as e:
        logger.error(f"Error dispatching command {cmd}: {e}")
        await bot.send_message(
            chat_id,
            f"An error occurred while processing your command: {str(e)}"
        )
        return True  # We handled it, even though there was an error


# Basic commands
async def handle_start(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /start command."""
    try:
        # Import handler
        from handlers.start import handle_start_simple
        
        # Call handler
        await handle_start_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in start handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error processing start command: {str(e)}"
        )

async def handle_help(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /help command."""
    try:
        # Import handler
        from handlers.help import handle_help_simple
        
        # Call handler
        await handle_help_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in help handler: {e}")
        # Format with proper entities to make commands clickable
        message = (
            "Available commands:\n"
            "/tokeninfo <address> - Get token info\n"
            "/tokensafety <address> - Analyze token safety\n"
            "/marketpredict <address> - AI price predictions\n"
            "/manualsnipe <address> <amount> - Execute a token purchase\n"
            "/sniper <address> <amount> - Super-reliable token sniping\n"
            "/smarttrade <address> <amount> - AI-powered smart trading with auto profit-taking\n"
            "/ultimate start - Start the Ultimate Trading Engine (combine all systems)\n"
            "/autosnipe <action> - Configure auto-sniping\n"
            "/watchgroup <group_link> - Monitor a Telegram group\n"
            "/trackwallet <address> - Track wallet activities\n"
            "/generateprememe <address> - Create viral crypto memes\n"
            "/settings - Configure bot preferences"
        )
        
        # This ensures the commands will be properly formatted as clickable blue text
        await bot.send_message(chat_id, message)


# Token information and analysis
async def handle_tokeninfo(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /tokeninfo command."""
    try:
        # Import handler
        from handlers.tokeninfo import handle_tokeninfo_simple
        
        # Call handler
        await handle_tokeninfo_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in tokeninfo handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error getting token info: {str(e)}"
        )

async def handle_tokensafety(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /tokensafety command."""
    try:
        # Import handler
        from handlers.tokensafety import handle_tokensafety_simple
        
        # Call handler
        await handle_tokensafety_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in tokensafety handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error analyzing token safety: {str(e)}"
        )

async def handle_marketpredict(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /marketpredict command."""
    try:
        # Import handler
        from handlers.marketpredict import handle_marketpredict_simple
        
        # Call handler
        await handle_marketpredict_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in marketpredict handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error generating market prediction: {str(e)}"
        )

async def handle_aiadvice(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /aiadvice command - AI-powered token analysis."""
    try:
        # Import handler
        from handlers.aiadvice import handle_aiadvice_simple
        
        # Call handler
        await handle_aiadvice_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in aiadvice handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error getting AI token advice: {str(e)}"
        )


# Trading commands
async def handle_manualsnipe(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /manualsnipe command."""
    try:
        # Import handler
        from handlers.manualsnipe import handle_manualsnipe_simple
        
        # Call handler
        await handle_manualsnipe_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in manualsnipe handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error executing snipe: {str(e)}"
        )

async def handle_autosnipe(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /autosnipe command."""
    try:
        # Import handler
        from handlers.autosnipe import handle_autosnipe_simple
        
        # Call handler
        await handle_autosnipe_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in autosnipe handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error configuring auto-snipe: {str(e)}"
        )

async def handle_sniper(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /sniper command - simplified token sniping."""
    try:
        # Import handler
        from handlers.sniper import handle_sniper_simple
        
        # Call handler
        await handle_sniper_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in sniper handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error executing snipe operation: {str(e)}"
        )

async def handle_smarttrade(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /smarttrade command - AI-powered smart trading."""
    try:
        # Import handler
        from handlers.smarttrade import handle_smarttrade_simple
        
        # Call handler
        await handle_smarttrade_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in smarttrade handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error executing smart trade: {str(e)}"
        )

async def handle_ultimate(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /ultimate command - Ultimate Trading Engine controls."""
    try:
        # Import handler
        from handlers.ultimate import handle_ultimate_simple
        
        # Call handler
        await handle_ultimate_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in ultimate handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error executing ultimate command: {str(e)}"
        )


# Monitoring commands
async def handle_watchgroup(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /watchgroup command."""
    try:
        # Import handler
        from handlers.watchgroup import handle_watchgroup_simple
        
        # Call handler
        await handle_watchgroup_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in watchgroup handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error setting up group monitoring: {str(e)}"
        )

async def handle_trackwallet(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /trackwallet command."""
    try:
        # Import handler
        from handlers.trackwallet import handle_trackwallet_simple
        
        # Call handler
        await handle_trackwallet_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in trackwallet handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error tracking wallet: {str(e)}"
        )


# Content generation
async def handle_generateprememe(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /generateprememe command."""
    try:
        # Import handler
        from handlers.generateprememe import handle_generateprememe_simple
        
        # Call handler
        await handle_generateprememe_simple(bot, chat_id, args)
    except Exception as e:
        logger.error(f"Error in generateprememe handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error generating meme: {str(e)}"
        )


# Configuration commands
async def handle_settings(chat_id: Union[int, str], args: List[str], bot: Any) -> None:
    """Handle the /settings command."""
    try:
        # Check if we have a settings handler
        try:
            from handlers.settings import handle_settings_simple
            await handle_settings_simple(bot, chat_id, args)
        except ImportError:
            # Fallback for missing handler
            await bot.send_message(
                chat_id,
                "⚙️ *Bot Settings*\n\n"
                "Configure your trading preferences and notification settings.\n\n"
                "*Available Settings Categories:*\n"
                "• `trading` - Trading parameters and defaults\n"
                "• `notifications` - Alert preferences and channels\n"
                "• `security` - Security settings and verification levels\n"
                "• `display` - UI preferences and display options\n\n"
                "Use `/settings <category>` to view and configure specific settings.\n\n"
                "Example: `/settings trading`",
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.error(f"Error in settings handler: {e}")
        await bot.send_message(
            chat_id,
            f"Error accessing settings: {str(e)}"
        )