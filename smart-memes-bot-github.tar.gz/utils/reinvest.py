"""
Profit tracking and reinvestment system for SMART MEMES BOT.

This module manages the profits made through trading and implements
an auto-reinvestment strategy to grow the trading capital over time.
"""

import json
import os
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

# Setup logging
logger = logging.getLogger(__name__)

# Constants
REINVEST_FILE = "data/profit_tracker.json"
TRADE_HISTORY_FILE = "data/trade_history.json"
DEFAULT_BAG_SIZE = 5.0  # Default starting capital in SOL

def ensure_data_dir():
    """Ensure the data directory exists."""
    os.makedirs("data", exist_ok=True)

def load_tracker() -> Dict[str, Any]:
    """
    Load the profit tracker data from file.
    
    Returns:
        Dictionary containing profit tracking data
    """
    ensure_data_dir()
    if not os.path.exists(REINVEST_FILE):
        return {"total_profit": 0.0, "current_bag": DEFAULT_BAG_SIZE, "last_updated": datetime.now().isoformat()}
    
    try:
        with open(REINVEST_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Error loading profit tracker: {str(e)}")
        # Return default data if file is corrupted
        return {"total_profit": 0.0, "current_bag": DEFAULT_BAG_SIZE, "last_updated": datetime.now().isoformat()}

def save_tracker(data: Dict[str, Any]) -> None:
    """
    Save the profit tracker data to file.
    
    Args:
        data: Dictionary containing profit tracking data
    """
    ensure_data_dir()
    try:
        # Update the last updated timestamp
        data["last_updated"] = datetime.now().isoformat()
        
        with open(REINVEST_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except IOError as e:
        logger.error(f"Error saving profit tracker: {str(e)}")

def update_profit(profit_amount: float) -> Dict[str, Any]:
    """
    Update the profit tracker with a new profit amount.
    
    This function implements the auto-reinvestment strategy:
    When total_profit reaches 100 SOL, increase bag size by 50%
    and reset total_profit to track the next reinvestment cycle.
    
    Args:
        profit_amount: Amount of profit to add (negative for losses)
        
    Returns:
        Updated profit tracker data
    """
    data = load_tracker()
    
    # Update the running profit total
    data["total_profit"] += profit_amount
    
    # Record this profit in the trade history
    add_trade_history_entry(profit_amount)
    
    # Auto-reinvest: increase bag size every 100 SOL profit
    if data["total_profit"] >= 100.0:
        # Calculate how many 100 SOL thresholds were crossed
        reinvest_cycles = int(data["total_profit"] / 100)
        
        # For each cycle, increase the bag size by 50%
        for _ in range(reinvest_cycles):
            old_bag = data["current_bag"]
            data["current_bag"] = round(data["current_bag"] * 1.5, 2)
            logger.info(f"Auto-reinvest triggered: Bag size increased from {old_bag} SOL to {data['current_bag']} SOL")
        
        # Subtract the reinvested profit
        data["total_profit"] -= (reinvest_cycles * 100)
    
    save_tracker(data)
    return data

def get_bag_size() -> float:
    """
    Get the current bag size (trading capital).
    
    Returns:
        Current bag size in SOL
    """
    return load_tracker().get("current_bag", DEFAULT_BAG_SIZE)

def get_profit_summary() -> Dict[str, Any]:
    """
    Get a summary of profit and reinvestment statistics.
    
    Returns:
        Dictionary with profit summary statistics
    """
    data = load_tracker()
    history = load_trade_history()
    
    # Calculate additional statistics
    total_trades = len(history)
    winning_trades = sum(1 for trade in history if trade.get("profit", 0) > 0)
    losing_trades = sum(1 for trade in history if trade.get("profit", 0) < 0)
    
    # Calculate win rate
    win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
    
    # Calculate total lifetime profit including reinvested amount
    lifetime_profit = data.get("total_profit", 0)
    current_bag = data.get("current_bag", DEFAULT_BAG_SIZE)
    
    # Calculate how much additional capital came from reinvestment
    reinvested_capital = current_bag - DEFAULT_BAG_SIZE
    
    return {
        "current_bag": current_bag,
        "unreinvested_profit": data.get("total_profit", 0),
        "total_trades": total_trades,
        "winning_trades": winning_trades,
        "losing_trades": losing_trades,
        "win_rate": win_rate,
        "reinvested_capital": reinvested_capital,
        "last_updated": data.get("last_updated", datetime.now().isoformat())
    }

def load_trade_history() -> List[Dict[str, Any]]:
    """
    Load the trade history from file.
    
    Returns:
        List of trade history entries
    """
    ensure_data_dir()
    if not os.path.exists(TRADE_HISTORY_FILE):
        return []
    
    try:
        with open(TRADE_HISTORY_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Error loading trade history: {str(e)}")
        return []

def save_trade_history(history: List[Dict[str, Any]]) -> None:
    """
    Save the trade history to file.
    
    Args:
        history: List of trade history entries
    """
    ensure_data_dir()
    try:
        with open(TRADE_HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
    except IOError as e:
        logger.error(f"Error saving trade history: {str(e)}")

def add_trade_history_entry(profit_amount: float, token_address: Optional[str] = None, trade_type: str = "auto") -> None:
    """
    Add a new entry to the trade history.
    
    Args:
        profit_amount: Amount of profit (negative for losses)
        token_address: The token address involved in the trade
        trade_type: Type of trade (e.g., "auto", "manual", "group")
    """
    history = load_trade_history()
    
    entry = {
        "timestamp": datetime.now().isoformat(),
        "profit": profit_amount,
        "token_address": token_address,
        "trade_type": trade_type
    }
    
    history.append(entry)
    save_trade_history(history)

def set_manual_bag_size(new_size: float) -> Dict[str, Any]:
    """
    Manually set the bag size to a new value.
    Only to be used for administrative adjustments.
    
    Args:
        new_size: The new bag size to set
        
    Returns:
        Updated profit tracker data
    """
    if new_size <= 0:
        logger.error(f"Invalid bag size: {new_size}")
        return load_tracker()
    
    data = load_tracker()
    
    # Log the change
    old_bag = data.get("current_bag", DEFAULT_BAG_SIZE)
    logger.info(f"Manual bag size change: {old_bag} SOL to {new_size} SOL")
    
    # Update the bag size
    data["current_bag"] = new_size
    
    save_tracker(data)
    return data


# For testing
if __name__ == "__main__":
    # Setup logging for standalone execution
    logging.basicConfig(level=logging.INFO)
    
    # Test the functions
    print("Current bag size:", get_bag_size())
    print("Adding 25 SOL profit...")
    update_profit(25.0)
    print("New bag size:", get_bag_size())
    print("Profit summary:", get_profit_summary())