"""
Liquidity and Safety Scanner for SMART MEMES BOT.

This module implements a comprehensive token liquidity and safety analysis system that:
1. Evaluates tokens based on liquidity level and distribution
2. Checks for security features like locked liquidity and renounced ownership
3. Detects potential scam indicators and warning signs
4. Provides a numerical scoring system for risk assessment

The scoring system rewards high liquidity (≥$10K = +4 points), liquidity locks (+3),
and renounced ownership (+2), plus other safety factors.
"""

import os
import json
import logging
import time
import re
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set, Union
from dataclasses import dataclass
import aiohttp

# Configure logger
logger = logging.getLogger(__name__)

# Import API keys from config
try:
    from config import BIRDEYE_API_KEY
except ImportError:
    BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY", "")
    logger.warning("Config not found, using environment variables for API keys")


@dataclass
class LiquidityAnalysis:
    """Data class to hold liquidity analysis results."""
    token_address: str
    liquidity_score: float  # 0-10 scale
    liquidity_usd: float
    has_locked_liquidity: bool
    lock_duration_days: Optional[int]
    liquidity_pair_count: int
    primary_pair: str
    primary_pair_liquidity: float
    primary_pair_percent: float
    price: Optional[float]
    price_change_24h: Optional[float]
    volume_24h: Optional[float]
    holders_count: Optional[int]
    timestamp: float
    warnings: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert analysis to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "liquidity_score": self.liquidity_score,
            "liquidity_usd": self.liquidity_usd,
            "has_locked_liquidity": self.has_locked_liquidity,
            "lock_duration_days": self.lock_duration_days,
            "liquidity_pair_count": self.liquidity_pair_count,
            "primary_pair": self.primary_pair,
            "primary_pair_liquidity": self.primary_pair_liquidity,
            "primary_pair_percent": self.primary_pair_percent,
            "price": self.price,
            "price_change_24h": self.price_change_24h,
            "volume_24h": self.volume_24h,
            "holders_count": self.holders_count,
            "timestamp": self.timestamp,
            "warnings": self.warnings
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LiquidityAnalysis':
        """Create analysis object from dictionary."""
        return cls(
            token_address=data["token_address"],
            liquidity_score=data["liquidity_score"],
            liquidity_usd=data["liquidity_usd"],
            has_locked_liquidity=data["has_locked_liquidity"],
            lock_duration_days=data["lock_duration_days"],
            liquidity_pair_count=data["liquidity_pair_count"],
            primary_pair=data["primary_pair"],
            primary_pair_liquidity=data["primary_pair_liquidity"],
            primary_pair_percent=data["primary_pair_percent"],
            price=data["price"],
            price_change_24h=data["price_change_24h"],
            volume_24h=data["volume_24h"],
            holders_count=data["holders_count"],
            timestamp=data["timestamp"],
            warnings=data["warnings"]
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the analysis."""
        warnings_text = f"\n⚠️ Warnings: {', '.join(self.warnings)}" if self.warnings else ""
        lock_text = f"(Locked {self.lock_duration_days} days)" if self.has_locked_liquidity and self.lock_duration_days else ""
        
        return (
            f"Liquidity Score: {self.liquidity_score:.1f}/10\n"
            f"Total Liquidity: ${self.liquidity_usd:,.2f}\n"
            f"Primary Pair: {self.primary_pair} (${self.primary_pair_liquidity:,.2f})\n"
            f"Locked: {'✅' if self.has_locked_liquidity else '❌'} {lock_text}\n"
            f"Price: ${self.price:.6f}\n"
            f"24h Change: {self.price_change_24h:+.2f}%\n"
            f"24h Volume: ${self.volume_24h:,.2f}"
            f"{warnings_text}"
        )


@dataclass
class TokenSafetyAnalysis:
    """Data class to hold token safety analysis results."""
    token_address: str
    safety_score: float  # 0-10 scale
    is_honeypot: bool
    has_anti_whale: bool
    has_mint_function: bool
    has_blacklist_function: bool
    has_fee_modification: bool
    transfer_tax_buy: Optional[float]
    transfer_tax_sell: Optional[float]
    is_verified: bool
    is_proxy: bool
    is_renounced: bool
    is_copied_code: bool
    creation_time: Optional[float]
    ownership_distribution: Optional[Dict[str, float]]
    biggest_holder_percent: Optional[float]
    timestamp: float
    warnings: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert analysis to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "safety_score": self.safety_score,
            "is_honeypot": self.is_honeypot,
            "has_anti_whale": self.has_anti_whale,
            "has_mint_function": self.has_mint_function,
            "has_blacklist_function": self.has_blacklist_function,
            "has_fee_modification": self.has_fee_modification,
            "transfer_tax_buy": self.transfer_tax_buy,
            "transfer_tax_sell": self.transfer_tax_sell,
            "is_verified": self.is_verified,
            "is_proxy": self.is_proxy,
            "is_renounced": self.is_renounced,
            "is_copied_code": self.is_copied_code,
            "creation_time": self.creation_time,
            "ownership_distribution": self.ownership_distribution,
            "biggest_holder_percent": self.biggest_holder_percent,
            "timestamp": self.timestamp,
            "warnings": self.warnings
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TokenSafetyAnalysis':
        """Create analysis object from dictionary."""
        return cls(
            token_address=data["token_address"],
            safety_score=data["safety_score"],
            is_honeypot=data["is_honeypot"],
            has_anti_whale=data["has_anti_whale"],
            has_mint_function=data["has_mint_function"],
            has_blacklist_function=data["has_blacklist_function"],
            has_fee_modification=data["has_fee_modification"],
            transfer_tax_buy=data["transfer_tax_buy"],
            transfer_tax_sell=data["transfer_tax_sell"],
            is_verified=data["is_verified"],
            is_proxy=data["is_proxy"],
            is_renounced=data["is_renounced"],
            is_copied_code=data["is_copied_code"],
            creation_time=data["creation_time"],
            ownership_distribution=data["ownership_distribution"],
            biggest_holder_percent=data["biggest_holder_percent"],
            timestamp=data["timestamp"],
            warnings=data["warnings"]
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the analysis."""
        warnings_text = f"\n⚠️ Warnings: {', '.join(self.warnings)}" if self.warnings else ""
        
        tax_text = ""
        if self.transfer_tax_buy is not None and self.transfer_tax_sell is not None:
            tax_text = f"Transfer Tax: {self.transfer_tax_buy:.1f}% buy, {self.transfer_tax_sell:.1f}% sell\n"
        
        age_text = ""
        if self.creation_time:
            age_days = (time.time() - self.creation_time) / 86400
            age_text = f"Age: {age_days:.1f} days\n"
        
        return (
            f"Safety Score: {self.safety_score:.1f}/10\n"
            f"Honeypot: {'❌ Yes' if self.is_honeypot else '✅ No'}\n"
            f"Verified: {'✅ Yes' if self.is_verified else '❌ No'}\n"
            f"Renounced: {'✅ Yes' if self.is_renounced else '❌ No'}\n"
            f"{tax_text}"
            f"{age_text}"
            f"Biggest Holder: {self.biggest_holder_percent:.1f}%"
            f"{warnings_text}"
        )


@dataclass
class ComprehensiveAnalysis:
    """Data class to combine liquidity and safety analysis."""
    token_address: str
    token_name: Optional[str]
    token_symbol: Optional[str]
    liquidity_analysis: LiquidityAnalysis
    safety_analysis: TokenSafetyAnalysis
    combined_score: float  # 0-10 scale
    risk_level: str  # "low", "medium", "high", "extreme", "forbidden"
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert analysis to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "token_name": self.token_name,
            "token_symbol": self.token_symbol,
            "liquidity_analysis": self.liquidity_analysis.to_dict(),
            "safety_analysis": self.safety_analysis.to_dict(),
            "combined_score": self.combined_score,
            "risk_level": self.risk_level,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ComprehensiveAnalysis':
        """Create analysis object from dictionary."""
        return cls(
            token_address=data["token_address"],
            token_name=data["token_name"],
            token_symbol=data["token_symbol"],
            liquidity_analysis=LiquidityAnalysis.from_dict(data["liquidity_analysis"]),
            safety_analysis=TokenSafetyAnalysis.from_dict(data["safety_analysis"]),
            combined_score=data["combined_score"],
            risk_level=data["risk_level"],
            timestamp=data["timestamp"]
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the analysis."""
        token_info = f"{self.token_symbol} ({self.token_name})" if self.token_symbol and self.token_name else self.token_address
        
        return (
            f"Token: {token_info}\n"
            f"Combined Score: {self.combined_score:.1f}/10\n"
            f"Risk Level: {self.risk_level.upper()}\n\n"
            f"--- LIQUIDITY ---\n"
            f"{self.liquidity_analysis.summary}\n\n"
            f"--- SAFETY ---\n"
            f"{self.safety_analysis.summary}"
        )


# Analysis cache to avoid duplicate API calls
_token_analysis_cache = {}


async def analyze_token_liquidity(token_address: str, network: str = "solana") -> LiquidityAnalysis:
    """
    Analyze the liquidity of a token.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network (solana, ethereum, etc.)
        
    Returns:
        LiquidityAnalysis object with detailed assessment
    """
    # In a real implementation, this would use blockchain and DEX APIs
    # For now, we'll simulate the analysis
    
    logger.info(f"Analyzing liquidity for token {token_address} on {network}")
    
    # Check cache first
    cache_key = f"liquidity:{network}:{token_address}"
    if cache_key in _token_analysis_cache:
        cached = _token_analysis_cache[cache_key]
        # Only use cache if recent (last 15 minutes)
        if time.time() - cached.timestamp < 900:
            logger.info(f"Using cached liquidity analysis for {token_address}")
            return cached
    
    # In a real implementation, we would call DEX APIs here
    # For example, using Birdeye API for Solana:
    
    # Initialize with default values
    liquidity_usd = 0.0
    has_locked_liquidity = False
    lock_duration_days = None
    liquidity_pair_count = 0
    primary_pair = ""
    primary_pair_liquidity = 0.0
    primary_pair_percent = 0.0
    price = None
    price_change_24h = None
    volume_24h = None
    holders_count = None
    warnings = []
    
    if network == "solana":
        try:
            # Use Birdeye API for Solana tokens if we have an API key
            if BIRDEYE_API_KEY:
                # This would be a real API call in production
                # Simulating response for example
                
                # Example Birdeye API call for token data
                # response = await call_birdeye_api(f"/defi/token_data/{token_address}")
                
                # Simulate response
                # For testing, alternate between good and bad metrics
                token_hash = sum(ord(c) for c in token_address)
                is_good_token = token_hash % 2 == 0
                
                if is_good_token:
                    # Good token simulation
                    liquidity_usd = 125000.0
                    has_locked_liquidity = True
                    lock_duration_days = 180
                    liquidity_pair_count = 3
                    primary_pair = "SOL-Token"
                    primary_pair_liquidity = 100000.0
                    primary_pair_percent = 80.0
                    price = 0.000023
                    price_change_24h = 5.2
                    volume_24h = 45000.0
                    holders_count = 850
                    
                    # No major warnings for good token
                    if token_hash % 5 == 0:
                        warnings.append("New token (less than 3 days old)")
                else:
                    # Questionable token simulation
                    liquidity_usd = 8500.0
                    has_locked_liquidity = token_hash % 3 == 0
                    lock_duration_days = 30 if has_locked_liquidity else None
                    liquidity_pair_count = 1
                    primary_pair = "USDC-Token"
                    primary_pair_liquidity = 8500.0
                    primary_pair_percent = 100.0
                    price = 0.0000012
                    price_change_24h = -12.5 if token_hash % 3 == 0 else 35.0
                    volume_24h = 3500.0
                    holders_count = 120
                    
                    # Add warnings for questionable token
                    warnings.append("Low liquidity (less than $10K)")
                    if not has_locked_liquidity:
                        warnings.append("Unlocked liquidity")
                    if token_hash % 3 == 0:
                        warnings.append("High price volatility")
            else:
                logger.warning("BIRDEYE_API_KEY not set, using fallback token analysis")
                liquidity_usd = 50000.0
                has_locked_liquidity = True
                lock_duration_days = 90
                liquidity_pair_count = 2
        except Exception as e:
            logger.error(f"Error analyzing token liquidity: {e}")
            warnings.append("Error fetching token data")
    
    # Calculate liquidity score (0-10 scale)
    liquidity_score = calculate_liquidity_score(
        liquidity_usd,
        has_locked_liquidity,
        lock_duration_days,
        liquidity_pair_count,
        primary_pair_percent,
        volume_24h
    )
    
    # Create analysis object
    analysis = LiquidityAnalysis(
        token_address=token_address,
        liquidity_score=liquidity_score,
        liquidity_usd=liquidity_usd,
        has_locked_liquidity=has_locked_liquidity,
        lock_duration_days=lock_duration_days,
        liquidity_pair_count=liquidity_pair_count,
        primary_pair=primary_pair,
        primary_pair_liquidity=primary_pair_liquidity,
        primary_pair_percent=primary_pair_percent,
        price=price,
        price_change_24h=price_change_24h,
        volume_24h=volume_24h,
        holders_count=holders_count,
        timestamp=time.time(),
        warnings=warnings
    )
    
    # Cache the analysis
    _token_analysis_cache[cache_key] = analysis
    
    return analysis


def calculate_liquidity_score(
    liquidity_usd: float,
    has_locked_liquidity: bool,
    lock_duration_days: Optional[int],
    liquidity_pair_count: int,
    primary_pair_percent: float,
    volume_24h: Optional[float]
) -> float:
    """
    Calculate a liquidity score for a token.
    
    Args:
        liquidity_usd: Total liquidity in USD
        has_locked_liquidity: Whether liquidity is locked
        lock_duration_days: Number of days liquidity is locked for
        liquidity_pair_count: Number of liquidity pairs
        primary_pair_percent: Percentage of liquidity in primary pair
        volume_24h: 24-hour trading volume
        
    Returns:
        Liquidity score (0-10 scale)
    """
    # Base score from liquidity level (0-4 points)
    if liquidity_usd >= 100000:
        liquidity_points = 4.0  # $100K+ liquidity
    elif liquidity_usd >= 50000:
        liquidity_points = 3.0  # $50K+ liquidity
    elif liquidity_usd >= 10000:
        liquidity_points = 2.0  # $10K+ liquidity
    elif liquidity_usd >= 5000:
        liquidity_points = 1.0  # $5K+ liquidity
    else:
        liquidity_points = 0.0  # <$5K liquidity
    
    # Points for locked liquidity (0-3 points)
    lock_points = 0.0
    if has_locked_liquidity:
        if lock_duration_days and lock_duration_days >= 180:
            lock_points = 3.0  # 6+ months lock
        elif lock_duration_days and lock_duration_days >= 90:
            lock_points = 2.0  # 3+ months lock
        elif lock_duration_days and lock_duration_days >= 30:
            lock_points = 1.0  # 1+ month lock
        else:
            lock_points = 0.5  # Some lock, duration unknown
    
    # Points for multiple liquidity pairs (0-1 points)
    pair_points = min(liquidity_pair_count - 1, 1.0)
    
    # Penalty for concentrated liquidity
    concentration_penalty = 0.0
    if primary_pair_percent > 95:
        concentration_penalty = 0.5  # Over 95% in one pair
    
    # Points for volume (0-2 points)
    volume_points = 0.0
    if volume_24h:
        if volume_24h >= liquidity_usd:
            volume_points = 2.0  # Volume >= liquidity
        elif volume_24h >= liquidity_usd * 0.5:
            volume_points = 1.5  # Volume >= 50% of liquidity
        elif volume_24h >= liquidity_usd * 0.2:
            volume_points = 1.0  # Volume >= 20% of liquidity
        elif volume_24h >= liquidity_usd * 0.1:
            volume_points = 0.5  # Volume >= 10% of liquidity
    
    # Calculate total score
    score = (
        liquidity_points + 
        lock_points + 
        pair_points + 
        volume_points - 
        concentration_penalty
    )
    
    # Ensure score is between 0 and 10
    return max(0.0, min(10.0, score))


async def analyze_token_safety(token_address: str, network: str = "solana") -> TokenSafetyAnalysis:
    """
    Analyze the safety of a token.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network (solana, ethereum, etc.)
        
    Returns:
        TokenSafetyAnalysis object with detailed assessment
    """
    # In a real implementation, this would analyze contract code and token data
    # For now, we'll simulate the analysis
    
    logger.info(f"Analyzing safety for token {token_address} on {network}")
    
    # Check cache first
    cache_key = f"safety:{network}:{token_address}"
    if cache_key in _token_analysis_cache:
        cached = _token_analysis_cache[cache_key]
        # Only use cache if recent (last 15 minutes)
        if time.time() - cached.timestamp < 900:
            logger.info(f"Using cached safety analysis for {token_address}")
            return cached
    
    # In a real implementation, we would analyze contract code here
    # For example, using Solscan API for Solana
    
    # Initialize with default values
    is_honeypot = False
    has_anti_whale = False
    has_mint_function = False
    has_blacklist_function = False
    has_fee_modification = False
    transfer_tax_buy = None
    transfer_tax_sell = None
    is_verified = True
    is_proxy = False
    is_renounced = False
    is_copied_code = False
    creation_time = time.time() - (7 * 86400)  # Default to 7 days old
    ownership_distribution = None
    biggest_holder_percent = 15.0
    warnings = []
    
    # Simulate analysis
    # For testing, alternate between good and bad metrics
    token_hash = sum(ord(c) for c in token_address)
    is_good_token = token_hash % 2 == 0
    
    if is_good_token:
        # Good token simulation
        is_honeypot = False
        has_anti_whale = True
        has_mint_function = False
        has_blacklist_function = False
        has_fee_modification = False
        transfer_tax_buy = 5.0
        transfer_tax_sell = 5.0
        is_verified = True
        is_proxy = False
        is_renounced = True
        is_copied_code = False
        creation_time = time.time() - (30 * 86400)  # 30 days old
        ownership_distribution = {
            "team": 15.0,
            "liquidity": 80.0,
            "other": 5.0
        }
        biggest_holder_percent = 15.0
        
        # No major warnings for good token
    else:
        # Questionable token simulation
        is_honeypot = token_hash % 5 == 0
        has_anti_whale = token_hash % 3 == 0
        has_mint_function = token_hash % 3 != 0
        has_blacklist_function = token_hash % 4 == 0
        has_fee_modification = token_hash % 3 == 0
        transfer_tax_buy = 10.0 if token_hash % 3 == 0 else 5.0
        transfer_tax_sell = 25.0 if token_hash % 3 == 0 else 5.0
        is_verified = token_hash % 5 != 0
        is_proxy = token_hash % 7 == 0
        is_renounced = token_hash % 2 == 0
        is_copied_code = token_hash % 3 == 0
        creation_time = time.time() - (2 * 86400)  # 2 days old
        ownership_distribution = {
            "team": 25.0 if token_hash % 3 == 0 else 10.0,
            "liquidity": 70.0 if token_hash % 3 == 0 else 80.0,
            "other": 5.0 if token_hash % 3 == 0 else 10.0
        }
        biggest_holder_percent = 25.0 if token_hash % 3 == 0 else 10.0
        
        # Add warnings for questionable token
        if is_honeypot:
            warnings.append("Potential honeypot (unable to sell)")
        if has_mint_function:
            warnings.append("Token contract can mint new tokens")
        if has_fee_modification:
            warnings.append("Fees can be modified by owner")
        if transfer_tax_sell and transfer_tax_sell > 15:
            warnings.append(f"High sell tax: {transfer_tax_sell}%")
        if not is_verified:
            warnings.append("Contract not verified")
        if is_proxy:
            warnings.append("Proxy contract (implementation can change)")
        if not is_renounced:
            warnings.append("Ownership not renounced")
        if is_copied_code:
            warnings.append("Similar to known scam contracts")
        if creation_time and time.time() - creation_time < 86400:
            warnings.append("Token less than 24 hours old")
        if biggest_holder_percent and biggest_holder_percent > 20:
            warnings.append(f"Concentrated ownership: {biggest_holder_percent}% held by largest wallet")
    
    # Calculate safety score (0-10 scale)
    safety_score = calculate_safety_score(
        is_honeypot,
        has_mint_function,
        has_blacklist_function,
        has_fee_modification,
        transfer_tax_buy,
        transfer_tax_sell,
        is_verified,
        is_proxy,
        is_renounced,
        is_copied_code,
        creation_time,
        biggest_holder_percent
    )
    
    # Create analysis object
    analysis = TokenSafetyAnalysis(
        token_address=token_address,
        safety_score=safety_score,
        is_honeypot=is_honeypot,
        has_anti_whale=has_anti_whale,
        has_mint_function=has_mint_function,
        has_blacklist_function=has_blacklist_function,
        has_fee_modification=has_fee_modification,
        transfer_tax_buy=transfer_tax_buy,
        transfer_tax_sell=transfer_tax_sell,
        is_verified=is_verified,
        is_proxy=is_proxy,
        is_renounced=is_renounced,
        is_copied_code=is_copied_code,
        creation_time=creation_time,
        ownership_distribution=ownership_distribution,
        biggest_holder_percent=biggest_holder_percent,
        timestamp=time.time(),
        warnings=warnings
    )
    
    # Cache the analysis
    _token_analysis_cache[cache_key] = analysis
    
    return analysis


def calculate_safety_score(
    is_honeypot: bool,
    has_mint_function: bool,
    has_blacklist_function: bool,
    has_fee_modification: bool,
    transfer_tax_buy: Optional[float],
    transfer_tax_sell: Optional[float],
    is_verified: bool,
    is_proxy: bool,
    is_renounced: bool,
    is_copied_code: bool,
    creation_time: Optional[float],
    biggest_holder_percent: Optional[float]
) -> float:
    """
    Calculate a safety score for a token.
    
    Args:
        is_honeypot: Whether the token appears to be a honeypot
        has_mint_function: Whether the contract can mint new tokens
        has_blacklist_function: Whether the contract can blacklist addresses
        has_fee_modification: Whether fees can be modified
        transfer_tax_buy: Buy tax percentage
        transfer_tax_sell: Sell tax percentage
        is_verified: Whether the contract is verified
        is_proxy: Whether the contract is a proxy
        is_renounced: Whether ownership is renounced
        is_copied_code: Whether the code appears to be copied
        creation_time: Timestamp of token creation
        biggest_holder_percent: Percentage held by largest holder
        
    Returns:
        Safety score (0-10 scale)
    """
    # Automatic disqualifications for high-risk features
    if is_honeypot:
        return 0.0  # Zero score for honeypots
    
    # Starting score: 10 points, deduct for issues
    score = 10.0
    
    # Deduct for high-risk features
    if has_mint_function:
        score -= 2.0  # Can mint new tokens
    
    if has_blacklist_function:
        score -= 1.0  # Can blacklist addresses
    
    if has_fee_modification:
        score -= 2.0  # Can change fees
    
    # Deduct for high taxes
    if transfer_tax_buy and transfer_tax_sell:
        if transfer_tax_buy + transfer_tax_sell > 40:
            score -= 3.0  # Very high combined tax
        elif transfer_tax_buy + transfer_tax_sell > 30:
            score -= 2.0  # High combined tax
        elif transfer_tax_buy + transfer_tax_sell > 20:
            score -= 1.0  # Moderate combined tax
        elif transfer_tax_buy + transfer_tax_sell > 10:
            score -= 0.5  # Low combined tax
    
    # Deduct for verification and ownership issues
    if not is_verified:
        score -= 3.0  # Unverified contract
    
    if is_proxy:
        score -= 1.0  # Proxy contract
    
    # Add for renounced ownership
    if is_renounced:
        score += 2.0  # Ownership renounced
    
    if is_copied_code:
        score -= 1.0  # Code appears to be copied
    
    # Deduct for new tokens (risky)
    if creation_time:
        token_age_days = (time.time() - creation_time) / 86400
        if token_age_days < 1:
            score -= 2.0  # Less than 1 day old
        elif token_age_days < 3:
            score -= 1.0  # Less than 3 days old
        elif token_age_days < 7:
            score -= 0.5  # Less than 7 days old
    
    # Deduct for concentrated ownership
    if biggest_holder_percent:
        if biggest_holder_percent > 50:
            score -= 3.0  # Very concentrated ownership
        elif biggest_holder_percent > 30:
            score -= 2.0  # Highly concentrated ownership
        elif biggest_holder_percent > 20:
            score -= 1.0  # Moderately concentrated ownership
    
    # Ensure score is between 0 and 10
    return max(0.0, min(10.0, score))


async def comprehensive_token_analysis(token_address: str, network: str = "solana") -> ComprehensiveAnalysis:
    """
    Perform a comprehensive analysis of a token, combining liquidity and safety.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network (solana, ethereum, etc.)
        
    Returns:
        ComprehensiveAnalysis object with detailed assessment
    """
    # Check cache first
    cache_key = f"comprehensive:{network}:{token_address}"
    if cache_key in _token_analysis_cache:
        cached = _token_analysis_cache[cache_key]
        # Only use cache if recent (last 15 minutes)
        if time.time() - cached.timestamp < 900:
            logger.info(f"Using cached comprehensive analysis for {token_address}")
            return cached
    
    # Get token metadata (name, symbol)
    token_name = None
    token_symbol = None
    
    try:
        # In a real implementation, we would fetch token metadata here
        # For now, we'll simulate
        
        # Simulate token data
        if network == "solana":
            # Simplified simulation
            token_name = f"Token {token_address[-4:]}"
            token_symbol = f"{token_address[-4:].upper()}"
    except Exception as e:
        logger.error(f"Error fetching token metadata: {e}")
    
    # Perform liquidity and safety analysis
    liquidity_analysis = await analyze_token_liquidity(token_address, network)
    safety_analysis = await analyze_token_safety(token_address, network)
    
    # Calculate combined score (weighted average)
    combined_score = (
        liquidity_analysis.liquidity_score * 0.4 +  # 40% weight for liquidity
        safety_analysis.safety_score * 0.6          # 60% weight for safety
    )
    
    # Determine risk level
    risk_level = determine_risk_level(combined_score, liquidity_analysis, safety_analysis)
    
    # Create comprehensive analysis
    analysis = ComprehensiveAnalysis(
        token_address=token_address,
        token_name=token_name,
        token_symbol=token_symbol,
        liquidity_analysis=liquidity_analysis,
        safety_analysis=safety_analysis,
        combined_score=combined_score,
        risk_level=risk_level,
        timestamp=time.time()
    )
    
    # Cache the analysis
    _token_analysis_cache[cache_key] = analysis
    
    return analysis


def determine_risk_level(
    combined_score: float,
    liquidity_analysis: LiquidityAnalysis,
    safety_analysis: TokenSafetyAnalysis
) -> str:
    """
    Determine the risk level for a token.
    
    Args:
        combined_score: Combined score (0-10)
        liquidity_analysis: Liquidity analysis
        safety_analysis: Safety analysis
        
    Returns:
        Risk level category: "low", "medium", "high", "extreme", "forbidden"
    """
    # Automatic disqualifications
    if safety_analysis.is_honeypot:
        return "forbidden"
    
    if safety_analysis.safety_score < 2.0:
        return "forbidden"
    
    if liquidity_analysis.liquidity_usd < 1000:
        return "forbidden"
    
    # Risk level based on combined score
    if combined_score >= 8.0:
        return "low"
    elif combined_score >= 6.5:
        return "medium"
    elif combined_score >= 5.0:
        return "high"
    elif combined_score >= 3.0:
        return "extreme"
    else:
        return "forbidden"


# Test functions
async def test_liquidity_scanner():
    # Test with a good token
    good_token = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    
    print("Analyzing good token...")
    analysis = await comprehensive_token_analysis(good_token)
    
    print(f"Token: {analysis.token_symbol} ({analysis.token_name})")
    print(f"Combined Score: {analysis.combined_score:.1f}/10")
    print(f"Risk Level: {analysis.risk_level}")
    print(f"Liquidity Score: {analysis.liquidity_analysis.liquidity_score:.1f}/10")
    print(f"Safety Score: {analysis.safety_analysis.safety_score:.1f}/10")
    
    # Test with a questionable token
    bad_token = "BadToken000000000000000000000000000000000001"
    
    print("\nAnalyzing questionable token...")
    analysis = await comprehensive_token_analysis(bad_token)
    
    print(f"Token: {analysis.token_symbol} ({analysis.token_name})")
    print(f"Combined Score: {analysis.combined_score:.1f}/10")
    print(f"Risk Level: {analysis.risk_level}")
    print(f"Liquidity Score: {analysis.liquidity_analysis.liquidity_score:.1f}/10")
    print(f"Safety Score: {analysis.safety_analysis.safety_score:.1f}/10")
    print(f"Warnings: {analysis.liquidity_analysis.warnings + analysis.safety_analysis.warnings}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_liquidity_scanner())