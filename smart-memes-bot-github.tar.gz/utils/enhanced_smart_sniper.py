"""
Enhanced Smart Sniper Module for SMART MEMES BOT.

This module provides advanced token sniping capabilities with integrated
risk management, AI-powered decision making, and multi-layer safety checks.
It coordinates all our profit-making systems to make optimal sniping decisions.
"""

import os
import time
import json
import asyncio
import logging
from typing import Dict, List, Tuple, Optional, Union, Any
from decimal import Decimal

# Import our profit-making systems
try:
    from utils.enhanced_token_safety import analyze_token_safety
    SAFETY_AVAILABLE = True
except ImportError:
    SAFETY_AVAILABLE = False
    logging.warning("Enhanced token safety not available, using basic checks")

try:
    from utils.twitter_signal_enhancement import get_signal_for_token
    TWITTER_ENHANCEMENT_AVAILABLE = True
except ImportError:
    TWITTER_ENHANCEMENT_AVAILABLE = False
    
try:
    from utils.advanced_slippage_management import calculate_optimal_slippage
    SLIPPAGE_MANAGEMENT_AVAILABLE = True
except ImportError:
    SLIPPAGE_MANAGEMENT_AVAILABLE = False

try:
    from utils.transaction_speed_enhancement import enhance_transaction_speed
    SPEED_ENHANCEMENT_AVAILABLE = True
except ImportError:
    SPEED_ENHANCEMENT_AVAILABLE = False

try:
    from utils.ai_trade_fallback import execute_trade_with_fallback
    FALLBACK_AVAILABLE = True
except ImportError:
    FALLBACK_AVAILABLE = False

try:
    from utils.mev_optimizer import protect_transaction
    MEV_AVAILABLE = True
except ImportError:
    MEV_AVAILABLE = False

try:
    from ai.trade_parameter_optimizer import optimize_trade_parameters
    AI_OPTIMIZATION_AVAILABLE = True
except ImportError:
    AI_OPTIMIZATION_AVAILABLE = False

# Configure logging
logger = logging.getLogger(__name__)

# Sniping thresholds for each risk profile
THRESHOLDS = {
    "conservative": {
        "safety_threshold": 0.9,    # 90% safety score minimum
        "group_trust_threshold": 0.95,  # 95% group trust minimum
        "wallet_trust_threshold": 0.9,  # 90% wallet trust minimum
        "min_liquidity": 100000,    # $100K min liquidity
        "max_market_cap": 10000000, # $10M max market cap
        "max_position_size": 0.5,   # 0.5 SOL max position
        "slippage_limit": 0.02,     # 2% max slippage
        "exit_strategy": {
            "take_profit": 0.3,     # 30% take profit
            "stop_loss": 0.1,       # 10% stop loss
            "trailing_stop": 0.05   # 5% trailing stop
        }
    },
    "balanced": {
        "safety_threshold": 0.8,    # 80% safety score minimum
        "group_trust_threshold": 0.85,  # 85% group trust minimum
        "wallet_trust_threshold": 0.8,  # 80% wallet trust minimum
        "min_liquidity": 50000,     # $50K min liquidity
        "max_market_cap": 20000000, # $20M max market cap
        "max_position_size": 1.0,   # 1 SOL max position
        "slippage_limit": 0.03,     # 3% max slippage
        "exit_strategy": {
            "take_profit": 0.5,     # 50% take profit
            "stop_loss": 0.15,      # 15% stop loss
            "trailing_stop": 0.08   # 8% trailing stop
        }
    },
    "aggressive": {
        "safety_threshold": 0.7,    # 70% safety score minimum
        "group_trust_threshold": 0.75,  # 75% group trust minimum
        "wallet_trust_threshold": 0.7,  # 70% wallet trust minimum
        "min_liquidity": 10000,     # $10K min liquidity
        "max_market_cap": 50000000, # $50M max market cap
        "max_position_size": 2.0,   # 2 SOL max position
        "slippage_limit": 0.05,     # 5% max slippage
        "exit_strategy": {
            "take_profit": 1.0,     # 100% take profit
            "stop_loss": 0.2,       # 20% stop loss
            "trailing_stop": 0.1    # 10% trailing stop
        }
    }
}

# Twitter signal keywords with weights
SIGNAL_KEYWORDS = {
    "launch": 1.0,
    "launching": 1.0,
    "launched": 0.8,
    "fair launch": 1.0,
    "stealth launch": 1.0,
    "just launched": 1.0,
    "chart live": 0.9,
    "contract live": 0.9,
    "live now": 0.9,
    "fair stealth": 0.9,
    "new gem": 0.8,
    "100x": 0.6,
    "1000x": 0.4,
    "moon": 0.5,
    "going to moon": 0.7,
    "liquidity locked": 0.8,
    "ownership renounced": 0.7,
    "funds safu": 0.7,
    "massive marketing": 0.6,
    "partnership": 0.7,
    "exchange listing": 0.9,
    "airdrop": 0.5
}

# Red flag keywords with weights
RED_FLAG_KEYWORDS = {
    "scam": 1.0,
    "honeypot": 1.0,
    "rugpull": 1.0,
    "rug pull": 1.0,
    "fake": 0.9,
    "pump and dump": 0.9,
    "avoid": 0.8,
    "warning": 0.7,
    "tax": 0.5,
    "high tax": 0.7,
    "100% tax": 1.0,
    "claim fast": 0.8,
    "claim now": 0.8,
    "limited time": 0.6,
    "mint fast": 0.8
}

class EnhancedSmartSniper:
    """
    Enhanced Smart Sniper with integrated profit-making systems.
    """
    
    def __init__(self, risk_profile: str = "balanced"):
        """
        Initialize the Enhanced Smart Sniper.
        
        Args:
            risk_profile: Risk profile (conservative, balanced, aggressive)
        """
        self.risk_profile = risk_profile
        self.thresholds = THRESHOLDS.get(risk_profile, THRESHOLDS["balanced"])
        self.pending_snipes = []
        self.successful_snipes = []
        self.failed_snipes = []
        self.running = False
        self.monitoring_task = None
    
    async def start(self):
        """Start the sniper system."""
        if self.running:
            logger.warning("Smart sniper already running")
            return
        
        self.running = True
        logger.info(f"Starting Enhanced Smart Sniper with {self.risk_profile} risk profile")
        
        # Start background task to process pending snipes
        self.monitoring_task = asyncio.create_task(self._process_pending_snipes())
    
    async def stop(self):
        """Stop the sniper system."""
        if not self.running:
            logger.warning("Smart sniper not running")
            return
        
        self.running = False
        logger.info("Stopping Enhanced Smart Sniper")
        
        # Cancel the monitoring task
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
    
    async def set_risk_profile(self, profile: str):
        """
        Set the risk profile for sniping.
        
        Args:
            profile: Risk profile (conservative, balanced, aggressive)
        """
        if profile not in THRESHOLDS:
            logger.error(f"Invalid risk profile: {profile}")
            return False
        
        self.risk_profile = profile
        self.thresholds = THRESHOLDS[profile]
        logger.info(f"Set risk profile to {profile}")
        return True
    
    async def evaluate_snipe_opportunity(self, 
                                        token_address: str,
                                        token_symbol: Optional[str] = None,
                                        group_score: float = 0.0,
                                        wallet_score: float = 0.0,
                                        message_text: str = "",
                                        liquidity: Optional[float] = None,
                                        market_cap: Optional[float] = None) -> Dict[str, Any]:
        """
        Evaluate a potential sniping opportunity.
        
        Args:
            token_address: Token address
            token_symbol: Optional token symbol
            group_score: Score for the group where token was mentioned
            wallet_score: Score for the wallet that created the token
            message_text: Text of the message that mentioned the token
            liquidity: Optional token liquidity amount in USD
            market_cap: Optional token market cap in USD
            
        Returns:
            Evaluation results with decision
        """
        evaluation = {
            "token_address": token_address,
            "token_symbol": token_symbol,
            "group_score": group_score,
            "wallet_score": wallet_score,
            "timestamp": time.time(),
            "snipe_opportunity": False,
            "position_size": 0.0,
            "confidence": 0.0,
            "reasons": []
        }
        
        # Convert scores to percentage scale
        group_score_pct = group_score
        wallet_score_pct = wallet_score
        
        # 1. Check token safety if available
        safety_score = 0.0
        if SAFETY_AVAILABLE:
            try:
                safety_score, safety_details = await analyze_token_safety(token_address)
                evaluation["safety_score"] = safety_score
                evaluation["safety_details"] = safety_details
                
                # Check safety threshold
                if safety_score < self.thresholds["safety_threshold"]:
                    evaluation["reasons"].append(f"Token safety below threshold: {safety_score:.2f} < {self.thresholds['safety_threshold']:.2f}")
                    return evaluation
                
            except Exception as e:
                logger.error(f"Error analyzing token safety: {str(e)}")
                evaluation["reasons"].append("Error analyzing token safety")
                return evaluation
        
        # 2. Check group and wallet trust scores
        if group_score_pct < self.thresholds["group_trust_threshold"]:
            evaluation["reasons"].append(f"Group trust score below threshold: {group_score_pct:.2f} < {self.thresholds['group_trust_threshold']:.2f}")
            return evaluation
        
        if wallet_score_pct < self.thresholds["wallet_trust_threshold"]:
            evaluation["reasons"].append(f"Wallet trust score below threshold: {wallet_score_pct:.2f} < {self.thresholds['wallet_trust_threshold']:.2f}")
            return evaluation
        
        # 3. Check Twitter signals if available
        signal_boost = 0.0
        if TWITTER_ENHANCEMENT_AVAILABLE:
            try:
                signal = await get_signal_for_token(token_address)
                if signal:
                    evaluation["twitter_signal"] = signal
                    
                    # Boost confidence based on signal confidence
                    signal_boost = signal.get("confidence", 0) * 0.2  # Up to 20% boost
            except Exception as e:
                logger.error(f"Error getting Twitter signal: {str(e)}")
        
        # 4. Check message text for relevant keywords
        keyword_score = 0.0
        keyword_matches = []
        
        if message_text:
            # Check for positive keywords
            for keyword, weight in SIGNAL_KEYWORDS.items():
                if keyword.lower() in message_text.lower():
                    keyword_score += weight
                    keyword_matches.append(keyword)
            
            # Check for negative keywords
            red_flag_score = 0.0
            red_flags = []
            for keyword, weight in RED_FLAG_KEYWORDS.items():
                if keyword.lower() in message_text.lower():
                    red_flag_score += weight
                    red_flags.append(keyword)
            
            evaluation["keyword_matches"] = keyword_matches
            evaluation["red_flags"] = red_flags
            
            # Adjust score based on keywords
            keyword_boost = max(0, min(0.3, keyword_score / 5))  # Up to 30% boost
            red_flag_penalty = min(1.0, red_flag_score)  # Up to 100% penalty
            
            # If major red flags, reject immediately
            if red_flag_score > 0.8:
                evaluation["reasons"].append(f"Major red flags detected: {', '.join(red_flags)}")
                return evaluation
        
        # 5. Check liquidity and market cap if available
        if liquidity is not None and liquidity < self.thresholds["min_liquidity"]:
            evaluation["reasons"].append(f"Liquidity below minimum: ${liquidity:.2f} < ${self.thresholds['min_liquidity']:.2f}")
            return evaluation
        
        if market_cap is not None and market_cap > self.thresholds["max_market_cap"]:
            evaluation["reasons"].append(f"Market cap above maximum: ${market_cap:.2f} > ${self.thresholds['max_market_cap']:.2f}")
            return evaluation
        
        # 6. Calculate confidence score and make decision
        # Base confidence from trust scores and safety
        base_confidence = (group_score_pct + wallet_score_pct + safety_score) / 3
        
        # Adjust with signal boost, keyword boost, and red flag penalty
        confidence = base_confidence + signal_boost + keyword_boost - red_flag_penalty
        confidence = max(0.0, min(1.0, confidence))  # Clamp to 0-1 range
        
        evaluation["confidence"] = confidence
        
        # Decision threshold depends on risk profile
        decision_threshold = {
            "conservative": 0.8,
            "balanced": 0.7,
            "aggressive": 0.6
        }.get(self.risk_profile, 0.7)
        
        if confidence >= decision_threshold:
            # Calculate position size based on confidence and risk profile
            max_position = self.thresholds["max_position_size"]
            position_size = max_position * confidence
            
            evaluation["snipe_opportunity"] = True
            evaluation["position_size"] = position_size
            evaluation["reasons"].append(f"Confidence above threshold: {confidence:.2f} >= {decision_threshold:.2f}")
            
            # Add exit strategy
            evaluation["exit_strategy"] = self.thresholds["exit_strategy"]
        else:
            evaluation["reasons"].append(f"Confidence below threshold: {confidence:.2f} < {decision_threshold:.2f}")
        
        return evaluation
    
    async def schedule_snipe(self, token_address: str, evaluation: Dict[str, Any]) -> str:
        """
        Schedule a token for sniping.
        
        Args:
            token_address: Token address
            evaluation: Evaluation results with decision details
            
        Returns:
            Snipe ID
        """
        if not evaluation.get("snipe_opportunity", False):
            return "rejected"
        
        # Create a snipe record
        snipe_id = f"snipe_{int(time.time())}_{token_address[-6:]}"
        
        snipe_record = {
            "id": snipe_id,
            "token_address": token_address,
            "token_symbol": evaluation.get("token_symbol"),
            "evaluation": evaluation,
            "status": "pending",
            "position_size": evaluation["position_size"],
            "scheduled_at": time.time()
        }
        
        # Add to pending snipes
        self.pending_snipes.append(snipe_record)
        logger.info(f"Scheduled snipe {snipe_id} for {token_address} with position size {evaluation['position_size']:.4f} SOL")
        
        return snipe_id
    
    async def _process_pending_snipes(self):
        """Background task to process pending snipes."""
        try:
            while self.running:
                if not self.pending_snipes:
                    await asyncio.sleep(1)
                    continue
                
                # Process the oldest pending snipe
                snipe = self.pending_snipes[0]
                
                try:
                    logger.info(f"Processing snipe {snipe['id']} for {snipe['token_address']}")
                    
                    # Execute the snipe
                    result = await self._execute_snipe(snipe)
                    
                    # Update the snipe record
                    snipe["result"] = result
                    snipe["executed_at"] = time.time()
                    
                    if result.get("success", False):
                        snipe["status"] = "executed"
                        self.successful_snipes.append(snipe)
                        logger.info(f"Successfully executed snipe {snipe['id']}")
                    else:
                        snipe["status"] = "failed"
                        self.failed_snipes.append(snipe)
                        logger.warning(f"Failed to execute snipe {snipe['id']}: {result.get('error')}")
                    
                except Exception as e:
                    logger.error(f"Error executing snipe {snipe['id']}: {str(e)}")
                    snipe["status"] = "error"
                    snipe["error"] = str(e)
                    self.failed_snipes.append(snipe)
                
                # Remove from pending
                self.pending_snipes.pop(0)
                
                # Wait briefly before next snipe
                await asyncio.sleep(1)
                
        except asyncio.CancelledError:
            logger.info("Snipe processing task cancelled")
            raise
        
        except Exception as e:
            logger.error(f"Unexpected error in snipe processing: {str(e)}")
            raise
    
    async def _execute_snipe(self, snipe: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a scheduled snipe.
        
        Args:
            snipe: Snipe record
            
        Returns:
            Result of snipe execution
        """
        token_address = snipe["token_address"]
        position_size = snipe["position_size"]
        token_symbol = snipe.get("token_symbol", "UNKNOWN")
        
        # Create base trade data
        trade_data = {
            "token_address": token_address,
            "token_symbol": token_symbol,
            "amount": position_size,
            "side": "buy",
            "chain": "solana"
        }
        
        # 1. Calculate optimal slippage if available
        if SLIPPAGE_MANAGEMENT_AVAILABLE:
            try:
                slippage = await calculate_optimal_slippage(token_address, token_symbol, position_size, "buy")
                trade_data["slippage_percentage"] = slippage
            except Exception as e:
                logger.error(f"Error calculating optimal slippage: {str(e)}")
                trade_data["slippage_percentage"] = self.thresholds["slippage_limit"]
        else:
            trade_data["slippage_percentage"] = self.thresholds["slippage_limit"]
        
        # 2. Apply AI trade parameter optimization if available
        if AI_OPTIMIZATION_AVAILABLE:
            try:
                optimized_trade = await optimize_trade_parameters(trade_data)
                trade_data.update(optimized_trade)
            except Exception as e:
                logger.error(f"Error optimizing trade parameters: {str(e)}")
        
        # 3. Apply MEV protection if available
        if MEV_AVAILABLE:
            try:
                protected_trade = await protect_transaction(trade_data)
                trade_data.update(protected_trade)
            except Exception as e:
                logger.error(f"Error applying MEV protection: {str(e)}")
        
        # 4. Enhance transaction speed if available
        if SPEED_ENHANCEMENT_AVAILABLE:
            try:
                enhanced_trade = await enhance_transaction_speed(trade_data)
                trade_data.update(enhanced_trade)
            except Exception as e:
                logger.error(f"Error enhancing transaction speed: {str(e)}")
        
        # 5. Execute the trade with fallback if available
        if FALLBACK_AVAILABLE:
            try:
                result = await execute_trade_with_fallback(trade_data)
                return result
            except Exception as e:
                logger.error(f"Error executing trade with fallback: {str(e)}")
                return {
                    "success": False,
                    "error": str(e),
                    "trade_data": trade_data
                }
        else:
            # Simulate trade execution for testing
            # In a real implementation, this would call the trading module
            logger.info(f"Simulating trade execution: BUY {token_symbol} {position_size} SOL")
            
            # Create simulated result (80% success rate)
            import random
            success = random.random() < 0.8
            
            if success:
                return {
                    "success": True,
                    "token_address": token_address,
                    "token_symbol": token_symbol,
                    "amount": position_size,
                    "executed_price": 1.0,  # Simulated price
                    "executed_amount": position_size * 0.98,  # Account for fees
                    "transaction_hash": f"simulated_tx_{int(time.time())}"
                }
            else:
                return {
                    "success": False,
                    "error": "Simulated trade execution failed",
                    "trade_data": trade_data
                }

    def get_pending_snipes(self) -> List[Dict[str, Any]]:
        """
        Get list of pending snipes.
        
        Returns:
            List of pending snipe records
        """
        return self.pending_snipes
    
    def get_successful_snipes(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent successful snipes.
        
        Args:
            count: Number of snipes to return
            
        Returns:
            List of successful snipe records
        """
        return self.successful_snipes[-count:]
    
    def get_failed_snipes(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent failed snipes.
        
        Args:
            count: Number of snipes to return
            
        Returns:
            List of failed snipe records
        """
        return self.failed_snipes[-count:]

# Singleton instance
_sniper = None

async def get_smart_sniper(risk_profile: str = "balanced") -> EnhancedSmartSniper:
    """
    Get the Enhanced Smart Sniper instance.
    
    Args:
        risk_profile: Risk profile to use
        
    Returns:
        EnhancedSmartSniper instance
    """
    global _sniper
    
    if _sniper is None:
        _sniper = EnhancedSmartSniper(risk_profile)
        await _sniper.start()
    elif _sniper.risk_profile != risk_profile:
        await _sniper.set_risk_profile(risk_profile)
    
    return _sniper

async def smart_snipe(token_address: str, 
                    token_symbol: Optional[str] = None,
                    group_score: float = 0.0,
                    wallet_score: float = 0.0,
                    message_text: str = "",
                    liquidity: Optional[float] = None,
                    market_cap: Optional[float] = None,
                    risk_profile: str = "balanced") -> Dict[str, Any]:
    """
    Enhanced smart sniper function integrating all profit-making systems.
    
    Args:
        token_address: Token address
        token_symbol: Optional token symbol
        group_score: Score for the group where token was mentioned
        wallet_score: Score for the wallet that created the token
        message_text: Text of the message that mentioned the token
        liquidity: Optional token liquidity amount in USD
        market_cap: Optional token market cap in USD
        risk_profile: Risk profile to use
        
    Returns:
        Result of smart snipe operation
    """
    try:
        # Get sniper instance
        sniper = await get_smart_sniper(risk_profile)
        
        # Evaluate the opportunity
        evaluation = await sniper.evaluate_snipe_opportunity(
            token_address=token_address,
            token_symbol=token_symbol,
            group_score=group_score,
            wallet_score=wallet_score,
            message_text=message_text,
            liquidity=liquidity,
            market_cap=market_cap
        )
        
        # If it's a good opportunity, schedule the snipe
        if evaluation["snipe_opportunity"]:
            snipe_id = await sniper.schedule_snipe(token_address, evaluation)
            
            return {
                "success": True,
                "snipe_scheduled": True,
                "snipe_id": snipe_id,
                "token_address": token_address,
                "token_symbol": token_symbol,
                "position_size": evaluation["position_size"],
                "confidence": evaluation["confidence"],
                "evaluation": evaluation
            }
        else:
            return {
                "success": True,
                "snipe_scheduled": False,
                "token_address": token_address,
                "token_symbol": token_symbol,
                "reasons": evaluation["reasons"],
                "evaluation": evaluation
            }
    
    except Exception as e:
        logger.error(f"Error in smart snipe: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "token_address": token_address
        }

# Legacy function for backwards compatibility
def legacy_smart_sniper(token_info, group_score, wallet_score, risk_class, token_keywords):
    """
    Legacy smart sniper function for backwards compatibility.
    
    Args:
        token_info: Token information
        group_score: Group trust score
        wallet_score: Wallet trust score
        risk_class: Risk class
        token_keywords: Keywords in the message
        
    Returns:
        True if sniping should proceed, False otherwise
    """
    # Convert legacy parameters to new format
    token_address = token_info.get('address', 'unknown')
    token_symbol = token_info.get('symbol', 'UNKNOWN')
    message_text = " ".join(token_keywords) if isinstance(token_keywords, list) else token_keywords
    
    # Map legacy risk class to new risk profiles
    risk_profile_map = {
        "low": "conservative",
        "medium": "balanced",
        "high": "aggressive"
    }
    risk_profile = risk_profile_map.get(risk_class, "balanced")
    
    # Call async function in a blocking way
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        # Create a new event loop if one doesn't exist
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    result = loop.run_until_complete(smart_snipe(
        token_address=token_address,
        token_symbol=token_symbol,
        group_score=group_score,
        wallet_score=wallet_score,
        message_text=message_text,
        risk_profile=risk_profile
    ))
    
    # Return True if snipe was scheduled, False otherwise
    return result.get("snipe_scheduled", False)

# Example usage
async def test_smart_sniper():
    """
    Test the enhanced smart sniper functionality.
    """
    logger.info("Testing enhanced smart sniper")
    
    # Sample token data
    token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC on Solana
    token_symbol = "USDC"
    group_score = 0.92
    wallet_score = 0.88
    message_text = "New token launch now! Chart live, liquidity locked. This is going to moon soon!"
    
    # Test with different risk profiles
    for risk_profile in ["conservative", "balanced", "aggressive"]:
        logger.info(f"Testing with {risk_profile} risk profile")
        
        result = await smart_snipe(
            token_address=token_address,
            token_symbol=token_symbol,
            group_score=group_score,
            wallet_score=wallet_score,
            message_text=message_text,
            risk_profile=risk_profile
        )
        
        if result["snipe_scheduled"]:
            logger.info(f"Snipe scheduled with ID: {result['snipe_id']}")
            logger.info(f"Position size: {result['position_size']:.4f} SOL")
            logger.info(f"Confidence: {result['confidence']:.4f}")
        else:
            logger.info(f"Snipe not scheduled. Reasons: {', '.join(result['evaluation']['reasons'])}")
        
        logger.info("---")
    
    # Test with some red flags
    message_with_red_flags = "New token launch now! Avoid high taxes, not a scam! Claim fast before price pumps!"
    
    result = await smart_snipe(
        token_address=token_address,
        token_symbol=token_symbol,
        group_score=group_score,
        wallet_score=wallet_score,
        message_text=message_with_red_flags,
        risk_profile="balanced"
    )
    
    if result["snipe_scheduled"]:
        logger.info(f"Snipe scheduled despite red flags with ID: {result['snipe_id']}")
    else:
        logger.info(f"Snipe correctly rejected due to red flags. Reasons: {', '.join(result['evaluation']['reasons'])}")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_smart_sniper())