"""
Enhanced Solana trade execution with reliability, safety checks, and error handling.

Features:
1. Multiple RPC endpoints with automatic fallback
2. Retry mechanisms with exponential backoff
3. Transaction confirmation verification and timeouts
4. Error handling at every step
5. Safety checks before executing trades
"""

import logging
import asyncio
import time
import json
import base58
import random
from typing import Dict, Any, List, Tuple, Optional
import aiohttp

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our token analysis utilities
from utils.token_analyzer import analyze_token, is_valid_token_address

# Constants
DEFAULT_SLIPPAGE = 0.5  # 0.5% slippage
MAX_RETRIES = 5
BASE_DELAY = 0.5  # seconds
CONFIRMATION_TIMEOUT = 60  # seconds
ERROR_CODES = {
    6000: "Insufficient funds",
    6001: "Invalid token account",
    6002: "Slippage tolerance exceeded",
    6003: "Liquidity constraint violation",
    6004: "Token address not found"
}

# Multiple RPC endpoints for Solana
RPC_ENDPOINTS = [
    "https://api.mainnet-beta.solana.com",
    "https://solana-api.projectserum.com",
    "https://rpc.ankr.com/solana"
]

# Birdeye API endpoint for token data
BIRDEYE_API = "https://public-api.birdeye.so/public/tokenlist?sort_by=v24hUSD&sort_type=desc&offset=0&limit=100"

async def check_token_liquidity(token_address: str) -> Tuple[bool, float, str]:
    """
    Check if a token has enough liquidity before executing a trade.
    
    Args:
        token_address: The token's public key
        
    Returns:
        Tuple containing (has_liquidity, liquidity_amount, message)
    """
    try:
        # Use our token analyzer to get token market data
        _, _, token_data = await analyze_token(token_address)
        
        # Extract liquidity from market data
        market_data = token_data.get("market_data", {})
        liquidity = market_data.get("liquidity")
        
        if liquidity is None:
            return False, 0, "Could not determine token liquidity"
            
        try:
            liquidity_amount = float(liquidity)
            
            # Check if liquidity is sufficient
            # Minimal threshold for safe trading
            if liquidity_amount < 5000:  # $5k
                return False, liquidity_amount, f"Insufficient liquidity (${liquidity_amount:.2f})"
                
            if liquidity_amount < 20000:  # $20k
                return True, liquidity_amount, f"Low liquidity (${liquidity_amount:.2f}) - proceed with caution"
                
            return True, liquidity_amount, f"Sufficient liquidity (${liquidity_amount:.2f})"
                
        except (ValueError, TypeError):
            return False, 0, "Invalid liquidity data format"
            
    except Exception as e:
        logger.error(f"Error checking token liquidity: {e}")
        return False, 0, f"Error checking liquidity: {str(e)}"

async def check_token_safety(token_address: str) -> Tuple[int, List[str]]:
    """
    Analyze a token for safety concerns before purchase.
    
    Args:
        token_address: The token's public key
        
    Returns:
        Tuple containing (safety_score, warnings)
    """
    try:
        # Use our token analyzer
        safety_score, _, token_data = await analyze_token(token_address)
        
        # Extract warnings
        warnings = token_data.get("warnings", [])
        
        return safety_score, warnings
        
    except Exception as e:
        logger.error(f"Error checking token safety: {e}")
        return 0, [f"Error analyzing token: {str(e)}"]

async def fetch_with_retry(
    endpoint: str, 
    method: str = "get", 
    data: Optional[Dict] = None,
    max_retries: int = MAX_RETRIES
) -> Dict[str, Any]:
    """
    Make an HTTP request with retry logic and exponential backoff.
    
    Args:
        endpoint: The API endpoint
        method: HTTP method (get/post)
        data: Request data for POST requests
        max_retries: Maximum number of retry attempts
        
    Returns:
        Response data or error
    """
    for attempt in range(max_retries):
        try:
            async with aiohttp.ClientSession() as session:
                if method.lower() == "get":
                    async with session.get(endpoint, timeout=10) as response:
                        if response.status == 200:
                            return await response.json()
                else:  # POST
                    headers = {"Content-Type": "application/json"}
                    async with session.post(endpoint, json=data, headers=headers, timeout=10) as response:
                        if response.status == 200:
                            return await response.json()
                        
                        # Handle error response
                        error_text = await response.text()
                        logger.error(f"Request failed (attempt {attempt+1}/{max_retries}): {error_text}")
                        
            # If we get here, there was an error
            delay = BASE_DELAY * (2 ** attempt) + (random.randint(0, 1000) / 1000)
            await asyncio.sleep(delay)
            
        except asyncio.TimeoutError:
            logger.warning(f"Request timeout (attempt {attempt+1}/{max_retries})")
            # Backoff before retry
            delay = BASE_DELAY * (2 ** attempt) + (random.randint(0, 1000) / 1000)
            await asyncio.sleep(delay)
            
        except Exception as e:
            logger.error(f"Error in request (attempt {attempt+1}/{max_retries}): {e}")
            # Backoff before retry
            delay = BASE_DELAY * (2 ** attempt) + (random.randint(0, 1000) / 1000)
            await asyncio.sleep(delay)
    
    # All retries failed
    return {"error": "All retry attempts failed"}

async def verify_transaction(tx_hash: str, max_attempts: int = 30, delay: float = 2.0) -> Tuple[bool, Dict[str, Any]]:
    """
    Verify a transaction has been confirmed on the blockchain.
    
    Args:
        tx_hash: The transaction hash to verify
        max_attempts: Maximum verification attempts
        delay: Seconds between verification attempts
        
    Returns:
        (success, tx_data) tuple
    """
    for attempt in range(max_attempts):
        # Try different RPC endpoints for reliability
        endpoint_index = attempt % len(RPC_ENDPOINTS)
        endpoint = RPC_ENDPOINTS[endpoint_index]
        
        try:
            # Prepare JSON-RPC request
            request_data = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getTransaction",
                "params": [
                    tx_hash,
                    {
                        "encoding": "json",
                        "commitment": "confirmed"
                    }
                ]
            }
            
            # Make the request
            result = await fetch_with_retry(endpoint, "post", request_data)
            
            # Check if transaction is confirmed
            if result.get("result"):
                confirmation_status = result["result"].get("meta", {}).get("status", {})
                if confirmation_status:
                    # Transaction confirmed, check if successful
                    if "Err" not in confirmation_status:
                        return True, result["result"]
                    else:
                        error = confirmation_status["Err"]
                        # Translate error code if possible
                        if isinstance(error, dict) and "InstructionError" in error:
                            err_code = error["InstructionError"][1].get("Custom")
                            error_msg = ERROR_CODES.get(err_code, f"Unknown error code: {err_code}")
                            return False, {"error": error_msg}
                        
                        return False, {"error": f"Transaction failed: {error}"}
                else:
                    # Transaction exists but not confirmed yet
                    await asyncio.sleep(delay)
                    continue
            
            # Transaction not found yet, or not confirmed
            await asyncio.sleep(delay)
            
        except Exception as e:
            logger.error(f"Error verifying transaction: {e}")
            # Try a different endpoint next time
            await asyncio.sleep(delay)
    
    # All attempts failed
    return False, {"error": "Transaction verification timeout"}

async def execute_trade(token_address: str, amount: float, slippage: float = DEFAULT_SLIPPAGE) -> Dict[str, Any]:
    """
    Execute a trade with enhanced reliability, fallbacks, and safety checks.
    
    Args:
        token_address: The token's public key
        amount: Amount in SOL to spend
        slippage: Slippage tolerance in percentage
        
    Returns:
        Dict containing transaction results and status
    """
    try:
        # Step 1: Validate token address
        if not is_valid_token_address(token_address):
            return {
                "success": False,
                "error": "Invalid token address format"
            }
        
        # Step 2: Check token safety
        safety_score, warnings = await check_token_safety(token_address)
        
        if safety_score < 3:  # Very unsafe token
            return {
                "success": False,
                "error": f"Token safety check failed (score: {safety_score}/10): {'; '.join(warnings[:3])}"
            }
        
        # Step 3: Check liquidity
        has_liquidity, liquidity_amount, liquidity_message = await check_token_liquidity(token_address)
        
        if not has_liquidity:
            return {
                "success": False,
                "error": f"Insufficient liquidity: {liquidity_message}"
            }
        
        # Step 4: Execute the trade using multiple RPC endpoints
        # This is a simplified implementation - in a real system, this would interact with a DEX
        
        # Simulate a successful transaction for demonstration
        # In a real implementation, this would execute an actual trade
        
        # Generate placeholder transaction data
        transaction_data = {
            "success": True,
            "transaction_hash": f"simulatedTx{random.randint(100000, 999999)}",
            "tokens_received": amount * 10000,  # Simulated token amount
            "price_per_token": 0.0001,  # Simulated token price
            "executed_at": time.time(),
            "network": "solana",
            "token_address": token_address,
            "amount_spent": amount,
            "fee": 0.000005,  # Simulated transaction fee
            "slippage_used": slippage
        }
        
        # Simulate transaction verification
        # In a real implementation, this would call verify_transaction
        
        # Add warning for low safety score if applicable
        if safety_score < 7:
            transaction_data["warnings"] = [
                f"Token has a low safety score ({safety_score}/10)",
                "Exercise caution and monitor closely"
            ]
        
        return transaction_data
        
    except Exception as e:
        logger.error(f"Error executing trade: {e}")
        return {
            "success": False,
            "error": f"Trade execution failed: {str(e)}"
        }

# Example usage
async def example_usage():
    # Example token
    token_address = "Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu"
    
    # Check token safety
    safety_score, warnings = await check_token_safety(token_address)
    print(f"Safety Score: {safety_score}/10")
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")
    
    # Check liquidity
    has_liq, amount, message = await check_token_liquidity(token_address)
    print(f"Liquidity: {message}")
    
    # Execute a trade
    result = await execute_trade(token_address, 0.1)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    asyncio.run(example_usage())