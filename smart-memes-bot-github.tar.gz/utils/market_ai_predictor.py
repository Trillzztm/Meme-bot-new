"""
Advanced AI-powered market prediction utility for SMART MEMES BOT.

This module uses advanced AI models to predict market trends based on:
1. On-chain metrics and transaction patterns
2. Social media sentiment and token mentions
3. Technical analysis and chart patterns
4. Historical price data and correlation analysis
"""

import logging
import asyncio
import time
import json
import random
from typing import Dict, Any, List, Tuple, Optional
import aiohttp
import numpy as np
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our utilities
from utils.token_analyzer import analyze_token
from database import session_scope, get_user_tracked_tokens
from config import (
    MAX_AI_PREDICTION_WINDOW, 
    AI_CONFIDENCE_THRESHOLD,
    PREDICTION_UPDATE_INTERVAL
)

# Constants
HOURS_TO_ANALYZE = 24
MINIMUM_DATA_POINTS = 8
PREDICTION_CACHE_EXPIRY = 3600  # 1 hour
ADVANCED_METRICS = {
    "RSI": "Relative Strength Index",
    "MACD": "Moving Average Convergence Divergence",
    "OBV": "On-Balance Volume",
    "BB": "Bollinger Bands",
    "VWAP": "Volume-Weighted Average Price"
}

# Cache for prediction results
_prediction_cache: Dict[str, Dict[str, Any]] = {}

class MarketPredictor:
    """Advanced AI-powered market prediction engine"""
    
    def __init__(self):
        """Initialize the market predictor"""
        self.running = False
        self.task = None
        self._reset_cache_timer = time.time()
    
    async def predict_price_movement(
        self, 
        token_address: str, 
        time_horizon: str = "24h",
        use_cached: bool = True
    ) -> Dict[str, Any]:
        """
        Predict price movement for a token
        
        Args:
            token_address: Token address to analyze
            time_horizon: Time window for prediction (1h, 24h, 7d)
            use_cached: Whether to use cached results if available
            
        Returns:
            Dictionary with prediction details
        """
        # Check cache first if allowed
        cache_key = f"{token_address}_{time_horizon}"
        if use_cached and cache_key in _prediction_cache:
            cached_result = _prediction_cache[cache_key]
            cache_age = time.time() - cached_result.get("timestamp", 0)
            
            if cache_age < PREDICTION_CACHE_EXPIRY:
                logger.info(f"Using cached prediction for {token_address}")
                return cached_result
        
        try:
            # Get token data first
            safety_score, _, token_data = await analyze_token(token_address)
            
            # Get historical price data
            price_data = await self._get_price_history(token_address, time_horizon)
            
            if not price_data or len(price_data) < MINIMUM_DATA_POINTS:
                logger.warning(f"Insufficient price data for {token_address}")
                return {
                    "success": False,
                    "error": "Insufficient historical data for prediction",
                    "timestamp": time.time()
                }
            
            # Get social media sentiment
            sentiment_data = await self._analyze_social_sentiment(token_address)
            
            # Get on-chain metrics
            onchain_data = await self._get_onchain_metrics(token_address)
            
            # Get technical indicators
            technical_data = self._calculate_technical_indicators(price_data)
            
            # Combine all data sources for prediction
            prediction = await self._generate_prediction(
                token_data,
                price_data,
                sentiment_data,
                onchain_data,
                technical_data,
                time_horizon
            )
            
            # Cache the result
            _prediction_cache[cache_key] = prediction
            
            return prediction
            
        except Exception as e:
            logger.error(f"Error predicting price for {token_address}: {e}")
            return {
                "success": False,
                "error": f"Prediction error: {str(e)}",
                "timestamp": time.time()
            }
    
    async def start(self):
        """Start the background prediction task"""
        if self.running:
            logger.warning("Market predictor already running")
            return
            
        self.running = True
        self.task = asyncio.create_task(self._update_predictions_loop())
        logger.info("Market predictor started")
    
    async def stop(self):
        """Stop the background prediction task"""
        if not self.running:
            return
            
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
                
        logger.info("Market predictor stopped")
    
    async def _update_predictions_loop(self):
        """Background task to update predictions for tracked tokens"""
        try:
            while self.running:
                try:
                    # Get tracked tokens from database
                    tracked_tokens = await self._get_tracked_tokens()
                    
                    # Update predictions for each token
                    for token in tracked_tokens:
                        token_address = token.get("address")
                        if not token_address:
                            continue
                            
                        # Update predictions for different time horizons
                        for horizon in ["1h", "24h", "7d"]:
                            await self.predict_price_movement(token_address, horizon, use_cached=False)
                            
                        # Sleep briefly between tokens to avoid rate limits
                        await asyncio.sleep(2)
                    
                    # Clear old cache entries
                    self._clean_prediction_cache()
                    
                except Exception as e:
                    logger.error(f"Error in prediction update loop: {e}")
                    
                # Wait before next update
                await asyncio.sleep(PREDICTION_UPDATE_INTERVAL)
                
        except asyncio.CancelledError:
            logger.info("Prediction update task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in prediction updates: {e}")
            self.running = False
    
    def _clean_prediction_cache(self):
        """Remove old entries from the prediction cache"""
        current_time = time.time()
        expired_keys = []
        
        for key, prediction in _prediction_cache.items():
            age = current_time - prediction.get("timestamp", 0)
            if age > PREDICTION_CACHE_EXPIRY:
                expired_keys.append(key)
                
        for key in expired_keys:
            del _prediction_cache[key]
            
        if expired_keys:
            logger.info(f"Cleaned {len(expired_keys)} expired predictions from cache")
    
    async def _get_tracked_tokens(self) -> List[Dict[str, Any]]:
        """Get tracked tokens from the database"""
        try:
            # This would typically query the database
            # For now, we'll return a simplified representation
            tokens = []
            
            with session_scope() as session:
                # Fetch all tracked tokens
                db_tokens = session.query("SELECT * FROM tracked_tokens WHERE active = true").all()
                
                # Convert to our format
                for token in db_tokens:
                    tokens.append({
                        "address": token.address,
                        "symbol": token.symbol,
                        "name": token.name,
                        "network": token.network
                    })
                    
            return tokens
            
        except Exception as e:
            logger.error(f"Error fetching tracked tokens: {e}")
            return []
    
    async def _get_price_history(
        self, 
        token_address: str, 
        time_horizon: str
    ) -> List[Dict[str, Any]]:
        """
        Get historical price data for a token
        
        Args:
            token_address: Token address to analyze
            time_horizon: Time window (1h, 24h, 7d)
            
        Returns:
            List of price data points with timestamps
        """
        # This would typically query a price API
        # For now, we'll simulate some realistic price data
        try:
            # Convert time horizon to hours
            hours = 1
            if time_horizon == "24h":
                hours = 24
            elif time_horizon == "7d":
                hours = 168  # 7 days
                
            # Create a realistic price series with timestamps
            # In a real implementation, this would come from an API
            data_points = []
            
            # Dummy code to generate realistic looking price data
            # In a real implementation, this would be replaced with API calls
            base_price = 0.0001  # Example base price
            volatility = 0.05     # Example volatility
            
            # Create data points going back in time
            current_time = time.time()
            interval = hours * 3600 / MINIMUM_DATA_POINTS  # Seconds between data points
            
            price = base_price
            for i in range(MINIMUM_DATA_POINTS):
                timestamp = current_time - (i * interval)
                
                # Simulate price movement (more realistic than random)
                change = base_price * volatility * (np.random.randn() * 0.5 + np.random.randn() * 0.3 + np.random.randn() * 0.2)
                price += change
                
                # Ensure price doesn't go negative
                price = max(0.000001, price)
                
                # Add data point
                data_points.append({
                    "timestamp": timestamp,
                    "price": price,
                    "volume": base_price * 1000000 * (0.5 + 0.5 * np.random.random())
                })
            
            # Reverse to get chronological order
            return list(reversed(data_points))
            
        except Exception as e:
            logger.error(f"Error getting price history for {token_address}: {e}")
            return []
    
    async def _analyze_social_sentiment(self, token_address: str) -> Dict[str, Any]:
        """
        Analyze social media sentiment for a token
        
        Args:
            token_address: Token address to analyze
            
        Returns:
            Dictionary with sentiment metrics
        """
        # This would typically analyze social media for sentiment
        # For now, we'll return placeholder data
        try:
            # In a real implementation, this would query social media platforms and forums
            
            return {
                "sentiment_score": 0.65,  # Positive
                "mention_count": 127,
                "trending_score": 0.82,
                "platforms": {
                    "telegram": 0.78,
                    "twitter": 0.62,
                    "reddit": 0.55
                }
            }
            
        except Exception as e:
            logger.error(f"Error analyzing social sentiment for {token_address}: {e}")
            return {}
    
    async def _get_onchain_metrics(self, token_address: str) -> Dict[str, Any]:
        """
        Get on-chain metrics for a token
        
        Args:
            token_address: Token address to analyze
            
        Returns:
            Dictionary with on-chain metrics
        """
        # This would typically query blockchain analytics APIs
        # For now, we'll return placeholder data
        try:
            # In a real implementation, this would query blockchain data
            
            return {
                "unique_holders": 1240,
                "wallet_concentration": 0.65,
                "txn_volume_24h": 580000,
                "active_wallets_24h": 215,
                "new_wallets_24h": 37,
                "whale_transactions_24h": 4
            }
            
        except Exception as e:
            logger.error(f"Error getting on-chain metrics for {token_address}: {e}")
            return {}
    
    def _calculate_technical_indicators(self, price_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Calculate technical indicators from price data
        
        Args:
            price_data: List of price data points
            
        Returns:
            Dictionary with technical indicators
        """
        try:
            # Extract price series
            prices = [point["price"] for point in price_data]
            volumes = [point.get("volume", 0) for point in price_data]
            
            # Calculate indicators
            # In a real implementation, this would use proper TA libraries
            
            # Simplified RSI calculation (real implementation would be more sophisticated)
            def simplified_rsi(prices, period=14):
                if len(prices) < period:
                    return 50  # Default neutral
                
                deltas = np.diff(prices)
                gains = np.where(deltas > 0, deltas, 0)
                losses = np.where(deltas < 0, -deltas, 0)
                
                avg_gain = np.mean(gains[-period:])
                avg_loss = np.mean(losses[-period:])
                
                if avg_loss == 0:
                    return 100
                
                rs = avg_gain / (avg_loss + 0.0001)  # Avoid division by zero
                rsi = 100 - (100 / (1 + rs))
                return rsi
            
            # Calculate indicators
            rsi = simplified_rsi(prices)
            
            # Additional indicators (simplified implementations)
            price_sma_short = np.mean(prices[-5:]) if len(prices) >= 5 else prices[-1]
            price_sma_long = np.mean(prices[-20:]) if len(prices) >= 20 else prices[-1]
            
            return {
                "rsi": rsi,
                "macd": {
                    "value": price_sma_short - price_sma_long,
                    "signal": 0,
                    "histogram": 0
                },
                "sma": {
                    "short": price_sma_short,
                    "long": price_sma_long
                },
                "bbands": {
                    "upper": prices[-1] * 1.05,
                    "middle": prices[-1],
                    "lower": prices[-1] * 0.95
                }
            }
            
        except Exception as e:
            logger.error(f"Error calculating technical indicators: {e}")
            return {}
    
    async def _generate_prediction(
        self,
        token_data: Dict[str, Any],
        price_data: List[Dict[str, Any]],
        sentiment_data: Dict[str, Any],
        onchain_data: Dict[str, Any],
        technical_data: Dict[str, Any],
        time_horizon: str
    ) -> Dict[str, Any]:
        """
        Generate price prediction based on all available data
        
        Args:
            token_data: Token information
            price_data: Historical price data
            sentiment_data: Social sentiment data
            onchain_data: On-chain metrics
            technical_data: Technical indicators
            time_horizon: Time window for prediction
            
        Returns:
            Dictionary with prediction details
        """
        try:
            # Extract current price (most recent data point)
            current_price = price_data[-1]["price"] if price_data else 0
            
            # In a real implementation, this would use an ML model
            # Here we'll use a simpler approach that considers multiple factors
            
            # Technical signals (simplified)
            rsi = technical_data.get("rsi", 50)
            rsi_signal = 1 if rsi > 70 else (-1 if rsi < 30 else 0)  # Overbought/oversold
            
            macd_value = technical_data.get("macd", {}).get("value", 0)
            macd_signal = 1 if macd_value > 0 else -1
            
            sma_short = technical_data.get("sma", {}).get("short", current_price)
            sma_long = technical_data.get("sma", {}).get("long", current_price)
            trend_signal = 1 if sma_short > sma_long else -1
            
            # Social sentiment
            sentiment_score = sentiment_data.get("sentiment_score", 0.5)
            sentiment_signal = 2 * (sentiment_score - 0.5)  # Range: -1 to 1
            
            # On-chain metrics
            wallet_growth = onchain_data.get("new_wallets_24h", 0) / max(1, onchain_data.get("unique_holders", 1000)) * 100
            whale_signal = 1 if onchain_data.get("whale_transactions_24h", 0) > 2 else 0
            
            # Combine signals
            technical_weight = 0.4
            sentiment_weight = 0.3
            onchain_weight = 0.3
            
            technical_score = (rsi_signal * 0.3 + macd_signal * 0.3 + trend_signal * 0.4)
            sentiment_score_adj = sentiment_signal * (1 + 0.5 * (sentiment_data.get("mention_count", 0) / 100))
            onchain_score = (wallet_growth / 10) * 0.7 + whale_signal * 0.3
            
            combined_signal = (
                technical_score * technical_weight +
                sentiment_score_adj * sentiment_weight +
                onchain_score * onchain_weight
            )
            
            # Convert signal to percentage and prediction
            signal_range = 2.0  # Maximum possible range of combined_signal
            
            # Adjust predicted change based on time horizon
            horizon_multiplier = 1.0
            if time_horizon == "24h":
                horizon_multiplier = 2.5
            elif time_horizon == "7d":
                horizon_multiplier = 5.0
                
            predicted_change_percent = combined_signal / signal_range * 100 * horizon_multiplier
            
            # Calculate confidence based on strength and consistency of signals
            signal_strength = abs(combined_signal) / (signal_range / 2)
            signal_consistency = 1.0 - 0.5 * abs(
                abs(technical_score) - abs(sentiment_score_adj)
            ) - 0.5 * abs(
                abs(technical_score) - abs(onchain_score)
            )
            
            confidence = min(0.95, 0.4 + signal_strength * 0.3 + signal_consistency * 0.3)
            
            # Generate prediction result
            result = {
                "success": True,
                "token_address": token_data.get("address"),
                "token_name": token_data.get("name") or token_data.get("symbol") or "Unknown",
                "current_price": current_price,
                "time_horizon": time_horizon,
                "predicted_change_percent": predicted_change_percent,
                "predicted_price": current_price * (1 + predicted_change_percent / 100),
                "direction": "bullish" if predicted_change_percent > 3 else ("bearish" if predicted_change_percent < -3 else "neutral"),
                "confidence": confidence,
                "timestamp": time.time(),
                "signals": {
                    "technical": {
                        "score": technical_score,
                        "rsi": rsi,
                        "trend": "uptrend" if trend_signal > 0 else "downtrend"
                    },
                    "sentiment": {
                        "score": sentiment_score,
                        "mentions": sentiment_data.get("mention_count", 0),
                        "trending": sentiment_data.get("trending_score", 0)
                    },
                    "onchain": {
                        "wallet_growth": wallet_growth,
                        "whale_activity": onchain_data.get("whale_transactions_24h", 0)
                    }
                }
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error generating prediction: {e}")
            return {
                "success": False,
                "error": f"Prediction generation error: {str(e)}",
                "timestamp": time.time()
            }

# Create global instance
market_predictor = MarketPredictor()

# API functions
async def start_market_predictor():
    """Start the market predictor service"""
    await market_predictor.start()

async def stop_market_predictor():
    """Stop the market predictor service"""
    await market_predictor.stop()

async def predict_token_movement(
    token_address: str, 
    time_horizon: str = "24h"
) -> Dict[str, Any]:
    """
    Get price prediction for a token
    
    Args:
        token_address: Token address to analyze
        time_horizon: Time window for prediction (1h, 24h, 7d)
        
    Returns:
        Price prediction results
    """
    return await market_predictor.predict_price_movement(token_address, time_horizon)