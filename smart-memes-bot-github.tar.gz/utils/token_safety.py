"""
Token safety analyzer for SMART MEMES BOT.

This module provides functions to analyze token safety and risk factors
to protect users from scams, honeypots, and other malicious tokens.
"""

import logging
import asyncio
import random
import hashlib
import time
import re
from typing import Dict, Any, List, Optional, Tuple, Set

# Configure logger
logger = logging.getLogger(__name__)

# Try to import solana analysis tools
try:
    import solana.rpc.api
    HAS_SOLANA = True
except ImportError:
    logger.warning("Solana libraries not available, using simplified implementation")
    HAS_SOLANA = False

# Try to import token info module
try:
    from utils.token_info import get_token_info, is_known_token
    HAS_TOKEN_INFO = True
except ImportError:
    logger.warning("Token info module not available")
    HAS_TOKEN_INFO = False

# Try to import pricing module
try:
    from utils.pricing import get_token_liquidity, get_token_price
    HAS_PRICING = True
except ImportError:
    logger.warning("Pricing module not available")
    HAS_PRICING = False

# Known safe token lists
KNOWN_SAFE_TOKENS = {
    "solana": [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
        "So11111111111111111111111111111111111111112",   # SOL (Wrapped)
        "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",  # USDT
        "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"   # BONK
    ],
    "ethereum": [
        "0x6b175474e89094c44da98b954eedeac495271d0f",  # DAI
        "0xdac17f958d2ee523a2206206994597c13d831ec7",  # USDT
        "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",  # USDC
    ]
}

# Safety threshold levels
SAFETY_THRESHOLDS = {
    "high": 80,   # Score of 80+ is high safety
    "medium": 60,  # Score of 60-79 is medium safety
    "low": 0       # Score below 60 is low safety
}

# Risk level categories
RISK_LEVELS = {
    "low": "Stable token with minimal risk",
    "medium": "Token with some potential risks, exercise caution",
    "high": "Token with significant risks, exercise extreme caution",
    "critical": "Token shows signs of being potentially malicious or a scam"
}


async def check_token_safety(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Comprehensive token safety analysis.
    This is the main entry point for token safety checks.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network (solana, ethereum, bsc, polygon)
        
    Returns:
        Dictionary with safety analysis results
    """
    # Start with neutral safety score
    safety_score = 50
    risks = []
    risk_level = "medium"  # Default risk level
    
    # Check if this is a known safe token
    if network in KNOWN_SAFE_TOKENS and token_address in KNOWN_SAFE_TOKENS[network]:
        return {
            "safety_score": 95,
            "risk_level": "low",
            "risks": ["Limited data available for comprehensive assessment"],
            "recommendation": "safe",
            "analysis": "Known safe token"
        }
    
    # Get token info if available
    token_info = None
    if HAS_TOKEN_INFO:
        try:
            token_info = await get_token_info(token_address, network)
        except Exception as e:
            logger.error(f"Error getting token info: {str(e)}")
    
    # Get token liquidity if available
    liquidity = 0
    if HAS_PRICING:
        try:
            liquidity = await get_token_liquidity(token_address, network)
        except Exception as e:
            logger.error(f"Error getting token liquidity: {str(e)}")
    
    # Check for network-specific safety
    if network == 'solana':
        # Solana-specific checks
        if HAS_SOLANA:
            # Real Solana checks would go here
            solana_safety = await check_solana_token_safety(token_address)
            safety_score = solana_safety["safety_score"]
            risks.extend(solana_safety["risks"])
        else:
            # Fallback to simplified check for demo
            simplified_safety = await check_simplified_token_safety(token_address, network)
            safety_score = simplified_safety["safety_score"]
            risks.extend(simplified_safety["risks"])
    else:
        # Use simplified check for other networks
        simplified_safety = await check_simplified_token_safety(token_address, network)
        safety_score = simplified_safety["safety_score"]
        risks.extend(simplified_safety["risks"])
    
    # Adjust score based on liquidity
    if liquidity > 0:
        if liquidity < 10000:  # Less than $10K
            safety_score -= 20
            risks.append("Very low liquidity")
        elif liquidity < 100000:  # Less than $100K
            safety_score -= 10
            risks.append("Low liquidity")
        elif liquidity < 1000000:  # Less than $1M
            safety_score -= 5
            risks.append("Moderate liquidity")
        elif liquidity > 10000000:  # More than $10M
            safety_score += 15
            
    # Cap the safety score
    safety_score = min(100, max(0, safety_score))
    
    # Determine risk level based on safety score
    if safety_score >= SAFETY_THRESHOLDS["high"]:
        risk_level = "low"
    elif safety_score >= SAFETY_THRESHOLDS["medium"]:
        risk_level = "medium"
    else:
        risk_level = "high"
    
    # If there are critical risks, override risk level
    if any(r.startswith("Critical:") for r in risks):
        risk_level = "critical"
        
    # Determine recommendation
    if risk_level in ["low", "medium"]:
        recommendation = "safe"
    else:
        recommendation = "avoid"
    
    # Create analysis
    analysis = f"Token has a safety score of {safety_score}/100, indicating {risk_level} risk."
    if risks:
        analysis += f" Risk factors include: {', '.join(risks)}."
    
    return {
        "safety_score": safety_score,
        "risk_level": risk_level,
        "risks": risks,
        "recommendation": recommendation,
        "analysis": analysis
    }


async def check_solana_token_safety(token_address: str) -> Dict[str, Any]:
    """
    Solana-specific token safety checks.
    
    Args:
        token_address: The Solana token address to check
        
    Returns:
        Dictionary with safety analysis results
    """
    # In a real implementation, this would make RPC calls to Solana
    # For this example, we'll simulate the checks
    
    # Hash the address to generate consistent safety attributes
    token_hash = int(hashlib.md5(token_address.encode()).hexdigest(), 16) % 100
    
    # Initial safety score from 0-100
    # For demonstration, we'll use the hash to generate a base score
    # In production, this would be based on actual contract analysis
    base_safety_score = 50 + (token_hash % 50)  # 50-99
    
    # Risks identified (will be empty for high safety tokens)
    risks = []
    
    # Simulated checks
    # 1. Check if mint authority is disabled (frozen)
    mint_frozen = token_hash % 5 != 0  # 80% chance it's frozen
    if not mint_frozen:
        base_safety_score -= 20
        risks.append("Mint authority not frozen")
    
    # 2. Check for verified creator
    creator_verified = token_hash % 4 != 0  # 75% chance it's verified
    if not creator_verified:
        base_safety_score -= 15
        risks.append("Creator not verified")
    
    # 3. Check for large holder concentration
    holder_concentration = token_hash % 100  # 0-99%
    if holder_concentration > 80:
        base_safety_score -= 25
        risks.append("High holder concentration")
    elif holder_concentration > 60:
        base_safety_score -= 10
        risks.append("Moderate holder concentration")
    
    # 4. Check for suspicious transfer behavior
    suspicious_transfers = token_hash % 10 == 0  # 10% chance suspicious
    if suspicious_transfers:
        base_safety_score -= 30
        risks.append("Critical: Suspicious transfer patterns detected")
    
    # 5. Check for metadata presence and validity
    has_metadata = token_hash % 3 != 0  # 66% chance has metadata
    if not has_metadata:
        base_safety_score -= 10
        risks.append("Missing or invalid metadata")
    
    # Cap safety score between 0-100
    safety_score = min(100, max(0, base_safety_score))
    
    return {
        "safety_score": safety_score,
        "risks": risks
    }


async def check_simplified_token_safety(token_address: str, network: str) -> Dict[str, Any]:
    """
    Simplified token safety check for demo or when blockchain libraries unavailable.
    
    Args:
        token_address: The token address to check
        network: Blockchain network
        
    Returns:
        Dictionary with safety analysis results
    """
    # Hash the address to generate consistent safety attributes
    token_hash = int(hashlib.md5(token_address.encode()).hexdigest(), 16) % 100
    
    # For known tokens, provide high safety scores
    if HAS_TOKEN_INFO:
        try:
            is_known = await is_known_token(token_address, network)
            if is_known:
                return {
                    "safety_score": 95,
                    "risks": ["Limited data available for comprehensive assessment"]
                }
        except Exception:
            pass
    
    # Different safety tiers based on address hash
    # This is a simplified demo approach - real implementation would
    # analyze actual contract code and behavior
    if token_hash < 15:
        # 15% chance it's a high-risk token
        return {
            "safety_score": 20 + (token_hash * 2),
            "risks": [
                "Potential volatility risk",
                "Limited transaction history",
                f"Critical: Possible {'honeypot' if token_hash < 5 else 'rug pull'} risk detected"
            ]
        }
    elif token_hash < 40:
        # 25% chance it's a medium-risk token
        return {
            "safety_score": 40 + (token_hash % 20),
            "risks": [
                "Limited data available for comprehensive assessment",
                "Potential volatility risk"
            ]
        }
    else:
        # 60% chance it's a fairly safe token
        # Add one mild risk for tokens that aren't perfect
        selected_risk = "Limited data available for comprehensive assessment"
        if token_hash % 2 == 0:
            selected_risk = "Relatively new token with limited history"
            
        return {
            "safety_score": 70 + (token_hash % 25),
            "risks": [selected_risk]
        }


async def check_honeypot_risk(token_address: str, network: str) -> Dict[str, Any]:
    """
    Check if a token has honeypot risk (cannot be sold).
    
    Args:
        token_address: The token address to check
        network: Blockchain network
        
    Returns:
        Dictionary with honeypot analysis
    """
    # In a real implementation, this would attempt a simulated sell
    # and check for indicators of a honeypot
    
    # For the demo, we'll use the hash of the address to simulate
    token_hash = int(hashlib.md5(token_address.encode()).hexdigest(), 16) % 100
    
    if token_hash < 5:  # 5% chance it's a definite honeypot
        return {
            "is_honeypot": True,
            "confidence": 0.95,
            "details": "Critical: Simulated sell test failed, likely a honeypot"
        }
    elif token_hash < 10:  # Another 5% chance it's suspicious
        return {
            "is_honeypot": True,
            "confidence": 0.7,
            "details": "Warning: Suspicious sell conditions detected, possible honeypot"
        }
    else:  # 90% chance it's not a honeypot
        return {
            "is_honeypot": False,
            "confidence": 0.9,
            "details": "No honeypot indicators detected"
        }


async def check_token_analytics(token_address: str, network: str) -> Dict[str, Any]:
    """
    Get additional analytics about token safety.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        Dictionary with analytics
    """
    token_hash = int(hashlib.md5(token_address.encode()).hexdigest(), 16) % 100
    
    # Simulate different ranges for key metrics
    holder_count = 100 + (token_hash * 10)  # 100-1090 holders
    top10_percent = 30 + (token_hash % 60)  # Top 10 wallets hold 30-89%
    
    liquidity = 0
    if HAS_PRICING:
        try:
            liquidity = await get_token_liquidity(token_address, network)
        except Exception:
            pass
    
    # Calculate metrics
    diversity_score = max(0, min(100, 100 - top10_percent)) 
    
    if liquidity < 1000:
        liquidity_rating = "Very Low"
    elif liquidity < 10000:
        liquidity_rating = "Low"
    elif liquidity < 100000:
        liquidity_rating = "Medium"
    elif liquidity < 1000000:
        liquidity_rating = "High"
    else:
        liquidity_rating = "Very High"
    
    # Assign audit status based on hash
    if token_hash < 10:
        audit_status = "Audited by major firm"
    elif token_hash < 30:
        audit_status = "Audited by minor firm"
    else:
        audit_status = "No known audit"
    
    return {
        "holder_count": holder_count,
        "top10_percent": top10_percent,
        "diversity_score": diversity_score,
        "liquidity": liquidity,
        "liquidity_rating": liquidity_rating,
        "audit_status": audit_status
    }


async def analyze_contract_safety(token_address: str, network: str) -> Dict[str, Any]:
    """
    Analyze the contract code safety (mock implementation).
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        Dictionary with contract safety analysis
    """
    # For the demo, we'll simulate contract analysis
    token_hash = int(hashlib.md5(token_address.encode()).hexdigest(), 16) % 100
    
    # Base safety
    contract_safety = 50 + (token_hash % 50)  # 50-99
    
    # Initialize risk indicators
    risks = []
    
    # Simulate different risk patterns
    if token_hash % 10 == 0:
        contract_safety -= 40
        risks.append("Critical backdoor functions detected")
    
    if token_hash % 7 == 0:
        contract_safety -= 30
        risks.append("Hidden fee or tax functions detected")
    
    if token_hash % 5 == 0:
        contract_safety -= 15
        risks.append("Ownership controls not properly renounced")
    
    if token_hash % 3 == 0:
        contract_safety -= 10
        risks.append("Non-standard token implementation")
    
    # Ensure score is within bounds
    contract_safety = max(0, min(100, contract_safety))
    
    return {
        "contract_safety_score": contract_safety,
        "risks": risks,
        "is_verified": token_hash % 3 != 0,  # 66% chance it's verified
        "has_proxy": token_hash % 5 == 0,    # 20% chance it has a proxy
        "compiler_version": f"0.{8 + (token_hash % 3)}.{token_hash % 10}"  # Random compiler version
    }