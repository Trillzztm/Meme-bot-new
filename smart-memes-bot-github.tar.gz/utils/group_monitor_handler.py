"""
Group message monitoring for SMART MEMES BOT.

This module handles monitoring group messages to detect and analyze token mentions,
informing users of potential opportunities and enabling auto-sniping when configured.
It also tracks group performance to identify the most profitable groups to follow.
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional, Set, Tuple
import time

# Telegram imports
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Import utilities
from utils.message_monitor import extract_token_data_from_text, GroupMonitor
from utils.token_info import get_token_info
from utils.token_safety import check_token_safety
from utils.solana_trade import check_token_liquidity, execute_trade
from utils.group_tracker import (
    process_group_message as track_group, 
    get_top_groups, 
    get_group_win_rate,
    get_group_stats_summary, 
    save_group_scores
)

# Import database functions
from database import (
    get_user_watched_groups, add_token_mention, get_user,
    update_user_settings, record_snipe_transaction, update_snipe_status
)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global dictionary to track monitored groups and their mentions
# In a production environment, this would be stored in a database
GROUP_MONITORS = {}  # Dict[chat_id, GroupMonitor]

async def setup_group_monitors():
    """Set up group monitors based on database records."""
    # In a real implementation, this would load all watched groups from the database
    # and create a monitor for each one
    pass

async def process_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process a message from a group chat to detect token mentions.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Only process group messages with text
    if not update.effective_chat or update.effective_chat.type not in ['group', 'supergroup']:
        return
    
    if not update.message or not update.message.text:
        return
    
    chat_id = update.effective_chat.id
    message_text = update.message.text
    user_id = update.effective_user.id if update.effective_user else None
    message_id = update.message.message_id
    timestamp = int(update.message.date.timestamp()) if update.message.date else int(time.time())
    group_name = update.effective_chat.title or f"Group_{chat_id}" 
    
    # Get or create a group monitor for this chat
    if chat_id not in GROUP_MONITORS:
        GROUP_MONITORS[chat_id] = GroupMonitor(
            str(chat_id),
            group_name,
            auto_snipe=False,  # Default to no auto-sniping
            min_mentions=3     # Default threshold
        )
    
    monitor = GROUP_MONITORS[chat_id]
    
    # Extract token data from the message
    token_data = extract_token_data_from_text(message_text)
    
    # Track this message in group tracker
    if token_data['addresses']:
        # Track the group message (not marking as profitable yet)
        track_group(group_name, message_text)
        logger.info(f"Token mention detected in group {group_name}")
    
    # Process any token addresses found
    new_threshold_tokens = []
    
    if token_data['addresses']:
        # Process each token address
        for addr_info in token_data['addresses']:
            try:
                # Process the address with the group monitor
                result = monitor.process_message(
                    message_text,
                    message_id,
                    timestamp,
                    user_id
                )
                
                # Get any tokens that just reached the threshold
                if result:
                    new_threshold_tokens.extend(result)
                    
                # Record the mention in the database
                try:
                    add_token_mention(
                        chat_id,  # This would be the group_id from the database in production
                        addr_info['address'],
                        token_symbol=None,  # We'd extract this from chain data
                        token_name=None     # We'd extract this from chain data
                    )
                except Exception as e:
                    logger.error(f"Error recording token mention: {str(e)}")
            except Exception as e:
                logger.error(f"Error processing token address {addr_info['address']}: {str(e)}")
    
    # Handle tokens that reached the threshold
    for token_info in new_threshold_tokens:
        await handle_threshold_token(update, context, token_info)
        
    # Save group scores periodically (every 10 messages with a token mention)
    if token_data['addresses'] and sum(1 for g in GROUP_MONITORS.values() for t in g.tokens.values() for m in t['mentions']) % 10 == 0:
        try:
            save_group_scores()
            logger.info("Group scores saved")
        except Exception as e:
            logger.error(f"Error saving group scores: {str(e)}")

async def handle_threshold_token(update: Update, context: ContextTypes.DEFAULT_TYPE, token_info: Dict[str, Any]) -> None:
    """
    Handle a token that just reached the mention threshold.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        token_info: Information about the token that reached the threshold
    """
    # Extract token details
    token_address = token_info['token_address']
    network = token_info['network']
    mentions = token_info['mentions']
    
    # Get users watching this group
    chat_id = update.effective_chat.id
    
    # In a real implementation, we would query the database for users watching this group
    # For now, we'll use a placeholder approach and notify all users
    
    # Check token safety and other details
    try:
        # Get token info
        token_details = get_token_info(token_address)
        
        # Check token safety
        safety_check = check_token_safety(token_address)
        
        # Check liquidity
        has_liquidity, liquidity_amount, liquidity_message = await check_token_liquidity(token_address)
        
        # Prepare notification message
        message = (
            f"🚨 *Token Alert!* 🚨\n\n"
            f"Token `{token_address}` has been mentioned {mentions} times in {update.effective_chat.title}.\n\n"
            f"Network: {network.upper()}\n"
            f"Safety Score: {safety_check.get('score', 'N/A')}/100\n"
            f"Liquidity: {'Available' if has_liquidity else 'Not Available'}\n\n"
        )
        
        # Add warnings if any
        if safety_check.get('warnings'):
            warnings_text = "\n".join([f"⚠️ {w}" for w in safety_check.get('warnings', [])])
            message += f"*Warnings:*\n{warnings_text}\n\n"
        
        # Add buy button
        keyboard = [
            [
                InlineKeyboardButton("🔍 View Token", url=f"https://solscan.io/token/{token_address}"),
                InlineKeyboardButton("💰 Buy Token", callback_data=f"buy_{token_address}")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Send notification to the group (in a real bot, this would be sent to all watching users)
        await context.bot.send_message(
            chat_id=chat_id,
            text=message,
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        
        # Check for auto-snipe settings
        await check_auto_snipe(chat_id, token_address, network, safety_check)
    
    except Exception as e:
        logger.error(f"Error handling threshold token {token_address}: {str(e)}")

async def check_auto_snipe(chat_id: int, token_address: str, network: str, safety_check: Dict[str, Any]) -> None:
    """
    Check if a token should be auto-sniped based on user settings.
    
    Args:
        chat_id: The chat ID where the token was mentioned
        token_address: The token address
        network: The blockchain network
        safety_check: Results of the token safety check
    """
    # In a real implementation, we would query the database for users with auto-snipe enabled
    # For now, we'll use a placeholder approach
    
    # Get group monitor
    monitor = GROUP_MONITORS.get(chat_id)
    if not monitor:
        return
    
    # Check if this token should be auto-sniped
    if not monitor.auto_snipe or not monitor.should_auto_snipe(token_address, network):
        return
    
    # Check safety score threshold (don't auto-snipe potentially unsafe tokens)
    safety_score = safety_check.get('score', 0)
    if safety_score < 70:  # Minimum safety score for auto-sniping
        logger.warning(f"Token {token_address} safety score too low for auto-snipe: {safety_score}")
        return
    
    # Check liquidity
    has_liquidity, liquidity_amount, _ = await check_token_liquidity(token_address)
    if not has_liquidity:
        logger.warning(f"Token {token_address} has no liquidity, skipping auto-snipe")
        return
    
    # Execute auto-snipe (in a real bot, this would use user-specific settings)
    # For demo purposes, we'll use a small amount
    amount_sol = 0.01  # Auto-snipe amount (this would come from user settings)
    
    # Record the snipe transaction in the database
    try:
        # In a real bot, we'd get the user_id from the database
        # For now, we'll use a placeholder user_id
        user_id = 123456789  # Placeholder
        
        # Record the transaction
        snipe = record_snipe_transaction(
            user_id,
            token_address,
            amount_spent=amount_sol,
            is_auto=True,
            platform="solana"
        )
        
        # Execute the trade
        success, message = await execute_trade(token_address, amount_sol)
        
        # Update the transaction status
        if success:
            update_snipe_status(
                snipe.id,
                "completed",
                tx_hash=message,  # The message contains the transaction URL
                error_message=None
            )
            
            # Notify the user
            # In a real bot, we'd send a message to the user
            logger.info(f"Auto-snipe successful for token {token_address}")
        else:
            update_snipe_status(
                snipe.id,
                "failed",
                error_message=message
            )
            
            logger.error(f"Auto-snipe failed for token {token_address}: {message}")
    
    except Exception as e:
        logger.error(f"Error auto-sniping token {token_address}: {str(e)}")

async def handle_buy_button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the callback when a user clicks the 'Buy Token' button.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    await query.answer()
    
    # Extract token address from callback data
    if not query.data or not query.data.startswith("buy_"):
        return
    
    token_address = query.data[4:]  # Remove "buy_" prefix
    
    # Ask for confirmation with amount selection
    keyboard = [
        [
            InlineKeyboardButton("0.01 SOL", callback_data=f"confirm_buy_{token_address}_0.01"),
            InlineKeyboardButton("0.05 SOL", callback_data=f"confirm_buy_{token_address}_0.05"),
            InlineKeyboardButton("0.1 SOL", callback_data=f"confirm_buy_{token_address}_0.1")
        ],
        [
            InlineKeyboardButton("0.5 SOL", callback_data=f"confirm_buy_{token_address}_0.5"),
            InlineKeyboardButton("1 SOL", callback_data=f"confirm_buy_{token_address}_1"),
            InlineKeyboardButton("Cancel", callback_data="cancel_buy")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text=f"How much SOL would you like to spend on token `{token_address}`?",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def handle_profit_marking_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the callback when a user marks a token as profitable.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    await query.answer()
    
    # Extract token address from callback data
    if not query.data or not query.data.startswith("profit_"):
        return
    
    token_address = query.data[7:]  # Remove "profit_" prefix
    
    # Ask user to select which group this profitable token came from
    # First, get recent groups from our tracker
    group_names = list(GROUP_MONITORS.keys())
    group_titles = []
    for chat_id in group_names:
        monitor = GROUP_MONITORS.get(chat_id)
        if monitor and monitor.group_name:
            group_titles.append(monitor.group_name)
    
    # If we don't have any groups yet, inform the user
    if not group_titles:
        await query.edit_message_text(
            text="No groups are currently being monitored. Please add groups to track first.",
            parse_mode="Markdown"
        )
        return
    
    # Create keyboard with group options
    keyboard = []
    row = []
    for i, group_name in enumerate(group_titles):
        # Create rows with 2 buttons each
        row.append(InlineKeyboardButton(group_name, callback_data=f"profitgroup_{token_address}_{i}"))
        if len(row) == 2 or i == len(group_titles) - 1:
            keyboard.append(row)
            row = []
    
    # Add cancel button
    keyboard.append([InlineKeyboardButton("Cancel", callback_data="cancel_profit")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        text=f"Which group mentioned this profitable token `{token_address}`?",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def handle_profit_group_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the callback when a user selects which group provided the profitable token.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    await query.answer()
    
    # Handle cancel action
    if query.data == "cancel_profit":
        await query.edit_message_text("Profit tracking cancelled.")
        return
    
    # Extract token address and group index from callback data
    if not query.data or not query.data.startswith("profitgroup_"):
        return
    
    parts = query.data.split("_")
    if len(parts) < 3:
        return
    
    token_address = parts[1]
    try:
        group_index = int(parts[2])
    except ValueError:
        await query.edit_message_text("Invalid group selection. Operation cancelled.")
        return
    
    # Get group names
    group_titles = []
    for chat_id in GROUP_MONITORS.keys():
        monitor = GROUP_MONITORS.get(chat_id)
        if monitor and monitor.group_name:
            group_titles.append(monitor.group_name)
    
    # Validate group index
    if group_index < 0 or group_index >= len(group_titles):
        await query.edit_message_text("Invalid group selection. Operation cancelled.")
        return
    
    # Get selected group name
    group_name = group_titles[group_index]
    
    # Mark the group as having a profitable token
    track_group(group_name, f"Token: {token_address}", profitable=True)
    save_group_scores()
    
    logger.info(f"Marked group {group_name} as having a profitable token {token_address}")
    
    # Update the message
    await query.edit_message_text(
        text=f"✅ Group '{group_name}' has been marked as having a profitable token mention. This will improve group tracking and recommendations.",
        parse_mode="Markdown"
    )

async def handle_confirm_buy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the confirmation callback when a user selects an amount to buy.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    await query.answer()
    
    # Handle cancel action
    if query.data == "cancel_buy":
        await query.edit_message_text("Purchase cancelled.")
        return
    
    # Extract token address and amount from callback data
    if not query.data or not query.data.startswith("confirm_buy_"):
        return
    
    parts = query.data.split("_")
    if len(parts) < 4:
        return
    
    token_address = parts[2]
    try:
        amount_sol = float(parts[3])
    except ValueError:
        await query.edit_message_text("Invalid amount. Purchase cancelled.")
        return
    
    # Update message to show processing
    await query.edit_message_text(
        text=f"Processing purchase of token `{token_address}` for {amount_sol} SOL...",
        parse_mode="Markdown"
    )
    
    # Identify the group that mentioned this token if possible
    original_message = query.message
    source_group_name = None
    if original_message and original_message.reply_to_message:
        replied_message = original_message.reply_to_message
        if replied_message.chat.type in ['group', 'supergroup'] and replied_message.chat.title:
            source_group_name = replied_message.chat.title
    
    # Record the transaction in the database
    try:
        user_id = update.effective_user.id
        
        # Record the transaction
        snipe = record_snipe_transaction(
            user_id,
            token_address,
            amount_spent=amount_sol,
            is_auto=False,
            platform="solana"
        )
        
        # Execute the trade
        success, message = await execute_trade(token_address, amount_sol)
        
        # Update the transaction status
        if success:
            update_snipe_status(
                snipe.id,
                "completed",
                tx_hash=message,  # The message contains the transaction URL
                error_message=None
            )
            
            # If we know which group this token came from, mark it as profitable
            if source_group_name:
                track_group(source_group_name, f"Token: {token_address}", profitable=True)
                logger.info(f"Marked group {source_group_name} as having a profitable token mention")
                save_group_scores()
            
            # Update the message
            await query.edit_message_text(
                text=f"✅ Purchase successful!\n\nToken: `{token_address}`\nAmount: {amount_sol} SOL\n\nTransaction: {message}",
                parse_mode="Markdown"
            )
            
            # Add a button to mark this token as profitable (for group tracking)
            if not source_group_name:
                keyboard = [
                    [
                        InlineKeyboardButton("📊 Mark as Profitable", callback_data=f"profit_{token_address}"),
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    text=f"✅ Purchase successful!\n\nToken: `{token_address}`\nAmount: {amount_sol} SOL\n\nTransaction: {message}\n\nIf this token was profitable, please mark it to improve group tracking.",
                    reply_markup=reply_markup,
                    parse_mode="Markdown"
                )
        else:
            update_snipe_status(
                snipe.id,
                "failed",
                error_message=message
            )
            
            # Update the message
            await query.edit_message_text(
                text=f"❌ Purchase failed!\n\nToken: `{token_address}`\nAmount: {amount_sol} SOL\n\nError: {message}",
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Error processing purchase for token {token_address}: {str(e)}")
        
        # Update the message
        await query.edit_message_text(
            text=f"❌ An error occurred while processing your purchase:\n\n{str(e)}",
            parse_mode="Markdown"
        )