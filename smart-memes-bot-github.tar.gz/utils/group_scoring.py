"""
Telegram group performance tracking and scoring with resilience features.

This module provides functions for tracking the performance of Telegram groups
based on token mentions and trading outcomes, with resilient error handling
and fallback mechanisms.
"""

import asyncio
import logging
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import json
import os

# Configure logger
logger = logging.getLogger(__name__)

# Path for storing group performance data
DATA_DIR = "data/metrics"
GROUP_METRICS_FILE = os.path.join(DATA_DIR, "group_performance.json")

# In-memory cache for group data
GROUP_CACHE = {}
GROUP_CACHE_LAST_UPDATED = 0
CACHE_TTL = 600  # 10 minutes

# Token result scoring
TOKEN_SCORE = {
    "win": 10,    # Successful token (profit)
    "neutral": 0,  # Neutral outcome
    "loss": -5     # Loss (scam, rug pull, etc.)
}

# Token result memory (to avoid redundant scoring)
TOKEN_RESULT_MEMORY = {}

# Group performance decay factors
SCORE_DECAY = 0.9  # Daily score decay
MENTION_DECAY = 0.8  # Daily mention decay

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

async def get_group_performance(group_id: int) -> Dict[str, Any]:
    """
    Get performance metrics for a group.
    
    Args:
        group_id: Telegram group ID
        
    Returns:
        Dictionary with group performance metrics
    """
    # Load performance data
    performance_data = await _load_performance_data()
    
    # Get or create group data
    group_id_str = str(group_id)
    if group_id_str not in performance_data:
        return {
            "group_id": group_id,
            "score": 0,
            "win_rate": 0,
            "mentions": 0,
            "wins": 0,
            "losses": 0,
            "last_tokens": [],
            "rank": None,
            "adjusted_factor": 1.0  # Default investment factor
        }
    
    group_data = performance_data[group_id_str]
    
    # Calculate win rate
    total_tokens = group_data.get("wins", 0) + group_data.get("losses", 0)
    win_rate = group_data.get("wins", 0) / total_tokens if total_tokens > 0 else 0
    
    # Calculate investment factor based on score and win rate
    score = group_data.get("score", 0)
    adjusted_factor = 1.0  # Default
    
    if score >= 100 and win_rate >= 0.7:
        adjusted_factor = 3.0  # Very high performing group
    elif score >= 50 and win_rate >= 0.6:
        adjusted_factor = 2.0  # High performing group
    elif score >= 20 and win_rate >= 0.5:
        adjusted_factor = 1.5  # Good performing group
    elif score < -20 or win_rate < 0.2:
        adjusted_factor = 0.5  # Poor performing group
    
    # Add calculated fields
    group_data["win_rate"] = win_rate
    group_data["adjusted_factor"] = adjusted_factor
    
    return group_data

async def log_token_mention(group_id: int, token_address: str) -> Dict[str, Any]:
    """
    Log a token mention in a group.
    
    Args:
        group_id: Telegram group ID
        token_address: Token contract address
        
    Returns:
        Updated group data
    """
    # Load performance data
    performance_data = await _load_performance_data()
    
    # Get or create group data
    group_id_str = str(group_id)
    if group_id_str not in performance_data:
        performance_data[group_id_str] = {
            "group_id": group_id,
            "score": 0,
            "mentions": 0,
            "wins": 0,
            "losses": 0,
            "last_tokens": [],
            "last_update": time.time()
        }
    
    group_data = performance_data[group_id_str]
    
    # Update mentions count
    group_data["mentions"] = group_data.get("mentions", 0) + 1
    
    # Add token to last tokens list
    last_tokens = group_data.get("last_tokens", [])
    
    # Check if token is already in the list
    token_exists = False
    for token in last_tokens:
        if token.get("address") == token_address:
            token["mentions"] = token.get("mentions", 0) + 1
            token["last_mention"] = time.time()
            token_exists = True
            break
    
    # Add new token if not already in the list
    if not token_exists:
        last_tokens.append({
            "address": token_address,
            "mentions": 1,
            "last_mention": time.time(),
            "result": None
        })
    
    # Keep only the last 50 tokens
    group_data["last_tokens"] = last_tokens[-50:]
    
    # Save performance data
    group_data["last_update"] = time.time()
    performance_data[group_id_str] = group_data
    await _save_performance_data(performance_data)
    
    return group_data

async def log_token_result(token_address: str, result: str, group_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Log a token trading result (win/loss) for a group.
    
    Args:
        token_address: Token contract address
        result: Result status ("win", "neutral", or "loss")
        group_id: Optional specific group ID
        
    Returns:
        Updated group data or dict of updated groups
    """
    # Check if we've already recorded this result
    token_key = f"{token_address}_{result}"
    if token_key in TOKEN_RESULT_MEMORY:
        logger.info(f"Result for {token_address} already recorded as {result}")
        return TOKEN_RESULT_MEMORY[token_key]
    
    # Load performance data
    performance_data = await _load_performance_data()
    result_score = TOKEN_SCORE.get(result, 0)
    
    # Normalize result
    if result not in TOKEN_SCORE:
        if "win" in result.lower() or "profit" in result.lower():
            result = "win"
        elif "loss" in result.lower() or "fail" in result.lower():
            result = "loss"
        else:
            result = "neutral"
    
    updated_groups = {}
    
    # If group_id is provided, only update that group
    if group_id:
        group_id_str = str(group_id)
        if group_id_str in performance_data:
            updated = await _update_group_for_token(
                performance_data[group_id_str], 
                token_address, 
                result, 
                result_score
            )
            if updated:
                performance_data[group_id_str]["last_update"] = time.time()
                updated_groups[group_id_str] = performance_data[group_id_str]
    else:
        # Update all groups that mentioned this token
        for group_id_str, group_data in performance_data.items():
            updated = await _update_group_for_token(
                group_data, 
                token_address, 
                result, 
                result_score
            )
            if updated:
                performance_data[group_id_str]["last_update"] = time.time()
                updated_groups[group_id_str] = group_data
    
    # Save performance data if any changes were made
    if updated_groups:
        await _save_performance_data(performance_data)
        
        # Store in memory to avoid duplicate processing
        TOKEN_RESULT_MEMORY[token_key] = updated_groups
        
        # Keep memory size reasonable
        if len(TOKEN_RESULT_MEMORY) > 1000:
            # Remove oldest entries
            oldest_keys = sorted(TOKEN_RESULT_MEMORY.keys())[:100]
            for key in oldest_keys:
                del TOKEN_RESULT_MEMORY[key]
    
    return updated_groups

async def _update_group_for_token(group_data: Dict[str, Any], token_address: str, result: str, score_change: int) -> bool:
    """
    Update a group's metrics for a token result.
    
    Args:
        group_data: Group data dictionary
        token_address: Token contract address
        result: Result status ("win" or "loss")
        score_change: Score change amount
        
    Returns:
        Whether the group was updated
    """
    last_tokens = group_data.get("last_tokens", [])
    updated = False
    
    # Find the token in the group's tokens
    for token in last_tokens:
        if token.get("address") == token_address:
            # Skip if already has a result
            if token.get("result"):
                return False
                
            # Update token result
            token["result"] = result
            token["result_time"] = time.time()
            
            # Update group metrics
            if result == "win":
                group_data["wins"] = group_data.get("wins", 0) + 1
            elif result == "loss":
                group_data["losses"] = group_data.get("losses", 0) + 1
                
            group_data["score"] = group_data.get("score", 0) + score_change
            
            updated = True
            break
    
    return updated

async def get_top_groups(limit: int = 10) -> List[Dict[str, Any]]:
    """
    Get the top performing groups.
    
    Args:
        limit: Maximum number of groups to return
        
    Returns:
        List of top group data
    """
    # Load performance data
    performance_data = await _load_performance_data()
    
    # Sort groups by score
    sorted_groups = sorted(
        performance_data.values(), 
        key=lambda g: g.get("score", 0), 
        reverse=True
    )
    
    # Add rank information
    for rank, group in enumerate(sorted_groups):
        group["rank"] = rank + 1
    
    return sorted_groups[:limit]

async def recalculate_all_group_scores() -> Dict[str, Any]:
    """
    Recalculate all group scores with decay factor.
    
    Returns:
        Dictionary with recalculation statistics
    """
    # Load performance data
    performance_data = await _load_performance_data()
    now = time.time()
    
    stats = {
        "groups_updated": 0,
        "inactive_groups_removed": 0,
        "total_groups": len(performance_data)
    }
    
    # Create a new dictionary to avoid modifying during iteration
    updated_performance_data = {}
    
    # Process each group
    for group_id, group_data in performance_data.items():
        # Check if group has been updated in the last 30 days
        last_update = group_data.get("last_update", 0)
        days_since_update = (now - last_update) / (24 * 3600)
        
        # Remove inactive groups (no updates in 30 days)
        if days_since_update > 30:
            stats["inactive_groups_removed"] += 1
            continue
        
        # Apply decay factor based on days since last update
        if days_since_update >= 1:
            decay_factor = SCORE_DECAY ** days_since_update
            
            # Apply decay to score
            group_data["score"] = group_data.get("score", 0) * decay_factor
            
            # Apply decay to mentions
            group_data["mentions"] = group_data.get("mentions", 0) * MENTION_DECAY ** days_since_update
            
            stats["groups_updated"] += 1
        
        # Update last_update timestamp
        group_data["last_update"] = now
        
        # Add to updated dictionary
        updated_performance_data[group_id] = group_data
    
    # Save updated performance data
    await _save_performance_data(updated_performance_data)
    
    return stats

async def _load_performance_data() -> Dict[str, Dict[str, Any]]:
    """
    Load group performance data from file with resilient error handling.
    
    Returns:
        Dictionary with group performance data
    """
    global GROUP_CACHE, GROUP_CACHE_LAST_UPDATED
    
    # Check if cache is valid
    current_time = time.time()
    if GROUP_CACHE and current_time - GROUP_CACHE_LAST_UPDATED < CACHE_TTL:
        return GROUP_CACHE.copy()
    
    # Create default empty data
    performance_data = {}
    
    # Try to load from file
    try:
        if os.path.exists(GROUP_METRICS_FILE):
            with open(GROUP_METRICS_FILE, 'r') as f:
                performance_data = json.load(f)
                
        # Update cache
        GROUP_CACHE = performance_data.copy()
        GROUP_CACHE_LAST_UPDATED = current_time
    except Exception as e:
        logger.error(f"Error loading group performance data: {str(e)}")
        
        # Try to load from backup file
        backup_file = f"{GROUP_METRICS_FILE}.bak"
        if os.path.exists(backup_file):
            try:
                with open(backup_file, 'r') as f:
                    performance_data = json.load(f)
                logger.info("Recovered group performance data from backup file")
            except Exception as e2:
                logger.error(f"Error loading backup performance data: {str(e2)}")
    
    return performance_data

async def _save_performance_data(performance_data: Dict[str, Dict[str, Any]]) -> bool:
    """
    Save group performance data to file with resilient error handling.
    
    Args:
        performance_data: Dictionary with group performance data
        
    Returns:
        Whether the save was successful
    """
    global GROUP_CACHE, GROUP_CACHE_LAST_UPDATED
    
    # Ensure data directory exists
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # Save backup first if the file exists
    if os.path.exists(GROUP_METRICS_FILE):
        try:
            backup_file = f"{GROUP_METRICS_FILE}.bak"
            with open(GROUP_METRICS_FILE, 'r') as src, open(backup_file, 'w') as dst:
                dst.write(src.read())
        except Exception as e:
            logger.error(f"Error creating backup of group performance data: {str(e)}")
    
    # Save new data
    try:
        with open(GROUP_METRICS_FILE, 'w') as f:
            json.dump(performance_data, f, indent=2)
            
        # Update cache
        GROUP_CACHE = performance_data.copy()
        GROUP_CACHE_LAST_UPDATED = time.time()
        
        return True
    except Exception as e:
        logger.error(f"Error saving group performance data: {str(e)}")
        return False

# Start a background task to periodically recalculate scores
async def _background_score_recalculation():
    """Background task to periodically recalculate group scores."""
    while True:
        try:
            # Run once a day
            await asyncio.sleep(24 * 3600)
            
            # Recalculate scores
            stats = await recalculate_all_group_scores()
            logger.info(f"Group score recalculation: {stats}")
        except Exception as e:
            logger.error(f"Error in background score recalculation: {str(e)}")
            await asyncio.sleep(3600)  # Wait an hour and try again