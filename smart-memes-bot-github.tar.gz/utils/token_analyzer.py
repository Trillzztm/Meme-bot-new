"""
Token analyzer utilities for SMART MEMES BOT.

This module provides functions to analyze tokens, their patterns,
potential, and safety.
"""

import logging
import asyncio
import random
import re
import time
from typing import Dict, Any, List, Optional, Tuple

# Configure logger
logger = logging.getLogger(__name__)

# Import token pricing if available
try:
    from utils.pricing import (
        get_token_price, 
        get_token_liquidity, 
        get_price_change, 
        calculate_profit_potential,
        get_token_metrics
    )
    HAS_PRICING = True
except ImportError:
    logger.warning("Pricing module not available for token analyzer")
    HAS_PRICING = False

# Import token safety if available
try:
    from utils.token_safety import check_token_safety
    HAS_SAFETY = True
except ImportError:
    logger.warning("Token safety module not available")
    HAS_SAFETY = False


async def analyze_token(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Comprehensive token analysis combining metrics, safety, and potential.
    This is the main entry point for token analysis.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network
        
    Returns:
        Dictionary with analysis results
    """
    results = {}
    
    # Start multiple tasks in parallel for efficiency
    tasks = []
    
    # Basic token info task
    try:
        from utils.token_info import get_token_info
        tasks.append(("token_info", asyncio.create_task(get_token_info(token_address, network))))
    except ImportError:
        logger.warning("Token info module not available")
        results["token_info"] = {"error": "Token info module not available"}
    
    # Pricing task
    if HAS_PRICING:
        tasks.append(("metrics", asyncio.create_task(get_token_metrics(token_address, network))))
    else:
        results["metrics"] = {"error": "Pricing module not available"}
    
    # Safety check task
    if HAS_SAFETY:
        tasks.append(("safety", asyncio.create_task(check_token_safety(token_address, network))))
    else:
        results["safety"] = {"error": "Safety module not available"}
    
    # Get the traditional analysis as well
    tasks.append(("traditional", asyncio.create_task(analyze_token_traditional(token_address, network))))
    
    # Wait for all tasks to complete
    for name, task in tasks:
        try:
            results[name] = await task
        except Exception as e:
            logger.error(f"Error in {name} analysis: {str(e)}")
            results[name] = {"error": f"Analysis failed: {str(e)}"}
    
    # Combine all results
    combined = {
        "address": token_address,
        "network": network,
    }
    
    # Add token info
    if "token_info" in results and not "error" in results["token_info"]:
        combined.update(results["token_info"])
    
    # Add metrics
    if "metrics" in results and not "error" in results["metrics"]:
        combined.update(results["metrics"])
    
    # Add safety
    if "safety" in results and not "error" in results["safety"]:
        combined["safety_score"] = results["safety"].get("safety_score", 0)
        combined["risk_level"] = results["safety"].get("risk_level", "unknown")
        combined["risks"] = results["safety"].get("risks", [])
    else:
        combined["safety_score"] = 0
        combined["risk_level"] = "unknown"
        combined["risks"] = ["Safety analysis unavailable"]
    
    # Add traditional analysis results
    if "traditional" in results and not "error" in results["traditional"]:
        combined["potential_score"] = results["traditional"].get("potential_score", 0)
        combined["recommendation"] = results["traditional"].get("recommendation", "avoid")
        combined["summary"] = results["traditional"].get("summary", "Analysis unavailable")
    else:
        combined["potential_score"] = 0
        combined["recommendation"] = "avoid"
        combined["summary"] = "Analysis unavailable"
    
    # Calculate final score
    combined["final_score"] = calculate_final_score(combined)
    
    # Add analysis timestamp
    combined["analyzed_at"] = int(time.time())
    
    return combined


def calculate_final_score(analysis: Dict[str, Any]) -> int:
    """
    Calculate the final score for a token based on all metrics.
    
    Args:
        analysis: The combined analysis results
        
    Returns:
        Integer score from 0-100
    """
    # Base scores
    safety_score = analysis.get("safety_score", 0)
    potential_score = analysis.get("potential_score", 0)
    
    # Additional metrics if available
    profit_potential = analysis.get("profit_potential", 0)
    liquidity_score = analysis.get("liquidity_score", 0)
    momentum_score = analysis.get("momentum_score", 0)
    
    # Calculate weighted score
    if profit_potential > 0:
        # We have advanced metrics
        final_score = (
            (safety_score * 0.4) +          # 40% weight on safety
            (potential_score * 0.2) +       # 20% weight on traditional analysis
            (profit_potential * 0.2) +      # 20% weight on profit potential
            (liquidity_score * 0.1) +       # 10% weight on liquidity
            (momentum_score * 0.1)          # 10% weight on momentum
        )
    else:
        # We only have basic metrics
        final_score = (
            (safety_score * 0.6) +          # 60% weight on safety
            (potential_score * 0.4)         # 40% weight on traditional analysis
        )
    
    # Ensure the score is in range 0-100
    return min(100, max(0, int(final_score)))


async def analyze_token_traditional(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Traditional token analysis without AI, using predefined patterns and metrics.
    Used as a fallback when AI is unavailable.
    
    Args:
        token_address: The token address to analyze
        network: Blockchain network
        
    Returns:
        Dictionary with analysis results
    """
    # Initialize with a baseline conservative score
    potential_score = 50  # Neutral starting point
    
    # Initialize accumulator for scoring factors
    factors = []
    
    # Try to get price info if available
    if HAS_PRICING:
        try:
            # Get token price and metrics
            price = await get_token_price(token_address, network)
            liquidity = await get_token_liquidity(token_address, network)
            change_1h = await get_price_change(token_address, network, '1h')
            change_24h = await get_price_change(token_address, network, '24h')
            
            # Factors that improve score
            if liquidity > 1000000:  # More than $1M liquidity
                potential_score += 15
                factors.append("High liquidity (>$1M)")
            elif liquidity > 100000:  # More than $100K liquidity
                potential_score += 5
                factors.append("Moderate liquidity (>$100K)")
            else:
                potential_score -= 10
                factors.append("Low liquidity")
            
            # Price factors
            if change_1h["change_pct"] > 5 and change_24h["change_pct"] > 10:
                potential_score += 10
                factors.append("Strong positive momentum")
            elif change_1h["change_pct"] < -10 and change_24h["change_pct"] < -15:
                potential_score -= 15
                factors.append("Sharp decline")
            
            # Volatility check
            if abs(change_1h["change_pct"]) > 20:
                potential_score -= 5
                factors.append("High volatility")
            
        except Exception as e:
            logger.error(f"Error getting price data: {str(e)}")
            factors.append("Price data unavailable")
    
    # Try to get safety info if available
    if HAS_SAFETY:
        try:
            safety = await check_token_safety(token_address, network)
            safety_score = safety.get("safety_score", 0)
            
            # Adjust score based on safety
            if safety_score > 80:
                potential_score += 15
                factors.append("High safety score")
            elif safety_score > 60:
                potential_score += 5
                factors.append("Moderate safety score")
            elif safety_score < 40:
                potential_score -= 20
                factors.append("Low safety score")
            
            # Specific risk factors
            risks = safety.get("risks", [])
            if risks:
                if "Honeypot risk" in risks or "Rug pull risk" in risks:
                    potential_score -= 30
                    factors.append("Critical security concerns")
        except Exception as e:
            logger.error(f"Error getting safety data: {str(e)}")
            factors.append("Safety data unavailable")
    
    # Ensure the score is within range
    potential_score = min(100, max(0, potential_score))
    
    # Determine recommendation based on score
    if potential_score >= 70:
        recommendation = "buy"
        summary = "Token shows strong potential based on analysis."
    elif potential_score >= 50:
        recommendation = "watch"
        summary = "Token has moderate potential but requires monitoring."
    else:
        recommendation = "avoid"
        summary = "Token shows insufficient potential or has significant risks."
    
    # Return the analysis results
    return {
        "potential_score": potential_score,
        "factors": factors,
        "recommendation": recommendation,
        "summary": summary
    }


async def get_token_info_extended(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Get extended token information combining basic info with metrics.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        Extended token information
    """
    try:
        # Get basic token info
        from utils.token_info import get_token_info
        info = await get_token_info(token_address, network)
        
        # If we have pricing, add price metrics
        if HAS_PRICING:
            try:
                price = await get_token_price(token_address, network)
                liquidity = await get_token_liquidity(token_address, network)
                
                # Add to info
                info["price"] = price
                info["liquidity"] = liquidity
                
                # Try to get price history
                try:
                    price_changes = {}
                    for timeframe in ['1h', '24h', '7d']:
                        change = await get_price_change(token_address, network, timeframe)
                        price_changes[timeframe] = change["change_pct"]
                    
                    info["price_changes"] = price_changes
                except Exception as e:
                    logger.warning(f"Error getting price history: {str(e)}")
            except Exception as e:
                logger.warning(f"Error getting price metrics: {str(e)}")
        
        return info
    except Exception as e:
        logger.error(f"Error in extended token info: {str(e)}")
        return {
            "address": token_address,
            "network": network,
            "name": f"Token-{token_address[:8]}",
            "symbol": token_address[:4].upper(),
            "error": f"Error getting token info: {str(e)}"
        }