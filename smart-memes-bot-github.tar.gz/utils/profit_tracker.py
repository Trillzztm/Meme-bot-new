"""
Enhanced profit tracking module for SMART MEMES BOT.

This module tracks token prices over multiple intervals to evaluate
performance, records historical data, integrates with the profit controller,
and provides price alert notifications.
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any, Set

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    from utils.token_info import get_token_price
    from utils.group_scoring import log_group_result
    from utils.reinvest import update_profit, add_trade_history_entry
    # Try to import advanced profit controller for strategy integration
    try:
        from utils.advanced_profit_controller import get_profit_controller
        ADVANCED_CONTROLLER_AVAILABLE = True
    except ImportError:
        logger.warning("Advanced profit controller not available for integration")
        ADVANCED_CONTROLLER_AVAILABLE = False
except ImportError as e:
    logger.error(f"Failed to import required modules: {e}")
    # Provide basic placeholders for testing/development
    async def get_token_price(address: str) -> float:
        return 0.0
    async def log_group_result(group: str, token: str, pct_change: float) -> None:
        pass
    def update_profit(amount: float) -> Dict[str, Any]:
        return {"current_bag": 0.0, "total_profit": 0.0}
    def add_trade_history_entry(amount: float, token: str, trade_type: str) -> None:
        pass
    ADVANCED_CONTROLLER_AVAILABLE = False
    
# Constants
DEFAULT_INTERVALS = [5, 10, 30, 60, 240]  # Minutes
PRICE_STORAGE_DIR = "data/price_history"
ACTIVE_TRACKING_FILE = "data/price_history/active_tracking.json"
ALERT_THRESHOLDS = [25, 50, 100, 200, 500]  # Percentage thresholds

# Ensure storage directory exists
os.makedirs(PRICE_STORAGE_DIR, exist_ok=True)

# Dict to store detected tokens and their tracking state
detected_tokens = {}
# Set to store currently tracked tokens (to avoid duplicate tracking)
currently_tracked = set()
# Dict to store alert subscriptions
alert_subscriptions = {}

class TokenPriceTracker:
    """Tracks token prices over time and analyzes performance."""
    
    def __init__(self, token_address: str, group_name: str = None, 
                 intervals: List[int] = None, notify_callback: callable = None):
        """
        Initialize token price tracker.
        
        Args:
            token_address: The token address to track
            group_name: Optional group name where token was found
            intervals: List of tracking intervals in minutes (default: [5, 10, 30, 60, 240])
            notify_callback: Optional callback for notifications
        """
        self.token_address = token_address
        self.group_name = group_name or "Unknown Group"
        self.intervals = intervals or DEFAULT_INTERVALS
        self.notify_callback = notify_callback
        
        self.launch_price = 0.0
        self.launch_time = 0.0
        self.last_price = 0.0
        self.update_time = 0.0
        self.price_history = []
        self.notified_thresholds = set()
        self.is_tracking = False
        self.all_time_high = 0.0
        self.all_time_low = float('inf')
        self.tracking_complete = False
        
        # Current interval tracking
        self.next_interval_idx = 0
        self.next_interval_time = 0
    
    async def start_tracking(self):
        """Start tracking token price over time."""
        if self.is_tracking:
            return
        
        self.is_tracking = True
        currently_tracked.add(self.token_address)
        
        try:
            # Snapshot price at launch
            self.launch_price = await get_token_price(self.token_address)
            if not self.launch_price or self.launch_price <= 0:
                logger.warning(f"Invalid launch price for {self.token_address}, aborting tracking")
                self.is_tracking = False
                currently_tracked.remove(self.token_address)
                return
            
            self.launch_time = time.time()
            self.last_price = self.launch_price
            self.update_time = self.launch_time
            self.all_time_high = self.launch_price
            self.all_time_low = self.launch_price
            
            # Add initial price point
            self.price_history.append({
                "timestamp": self.launch_time,
                "datetime": datetime.fromtimestamp(self.launch_time).isoformat(),
                "price": self.launch_price,
                "pct_change": 0.0
            })
            
            # Log tracking start
            logger.info(f"[TRACKING] {self.token_address} launch price: {self.launch_price}")
            self._save_tracking_state()
            
            # Set up the first interval
            if self.intervals and len(self.intervals) > 0:
                self.next_interval_idx = 0
                interval_minutes = self.intervals[0]
                self.next_interval_time = self.launch_time + (interval_minutes * 60)
                
                # Start tracking loop
                asyncio.create_task(self._tracking_loop())
            
        except Exception as e:
            logger.error(f"Error starting price tracking for {self.token_address}: {str(e)}")
            self.is_tracking = False
            if self.token_address in currently_tracked:
                currently_tracked.remove(self.token_address)
    
    async def _tracking_loop(self):
        """Main tracking loop that collects prices at each interval."""
        try:
            while self.is_tracking and self.next_interval_idx < len(self.intervals):
                # Wait until the next interval
                wait_time = max(0, self.next_interval_time - time.time())
                if wait_time > 0:
                    await asyncio.sleep(wait_time)
                
                # Get current price
                current_price = await get_token_price(self.token_address)
                current_time = time.time()
                
                if current_price and current_price > 0:
                    # Calculate metrics
                    pct_change = ((current_price - self.launch_price) / self.launch_price) * 100
                    interval_minutes = self.intervals[self.next_interval_idx]
                    
                    # Update ATH/ATL
                    if current_price > self.all_time_high:
                        self.all_time_high = current_price
                    if current_price < self.all_time_low:
                        self.all_time_low = current_price
                    
                    # Add to history
                    self.price_history.append({
                        "timestamp": current_time,
                        "datetime": datetime.fromtimestamp(current_time).isoformat(),
                        "price": current_price,
                        "pct_change": pct_change,
                        "interval_minutes": interval_minutes
                    })
                    
                    # Log interval metrics
                    logger.info(f"[EVALUATION] {self.token_address} after {interval_minutes} mins: "
                               f"{current_price} ({pct_change:.2f}%)")
                    
                    # Save price history
                    self._save_price_history()
                    
                    # Check if this was the final check at 5 minutes for group scoring
                    if interval_minutes == 5:
                        # Log result to group scoring system
                        await log_group_result(self.group_name, self.token_address, pct_change)
                        
                        # If profit is significant, log it to the profit system
                        if pct_change >= 25:  # 25% profit threshold 
                            profit_amount = 0.05 * (pct_change / 100)  # Simulate small profit based on percentage
                            update_profit(profit_amount)
                            add_trade_history_entry(profit_amount, self.token_address, f"auto_{self.group_name}")
                            logger.info(f"Logged auto profit: {profit_amount:.4f} for {self.token_address}")
                    
                    # Update last price
                    self.last_price = current_price
                    self.update_time = current_time
                    
                    # Check alert thresholds
                    await self._check_alert_thresholds(pct_change)
                    
                    # Update strategy algorithms if available
                    await self._update_strategy_algorithms(current_price, pct_change)
                
                # Move to next interval
                self.next_interval_idx += 1
                if self.next_interval_idx < len(self.intervals):
                    interval_minutes = self.intervals[self.next_interval_idx]
                    self.next_interval_time = self.launch_time + (interval_minutes * 60)
            
            # Tracking complete - all intervals finished
            self.tracking_complete = True
            self.is_tracking = False
            
            # Final save
            self._save_price_history()
            self._save_tracking_state()
            
            # Clean up
            if self.token_address in currently_tracked:
                currently_tracked.remove(self.token_address)
            
            logger.info(f"[COMPLETE] Tracking complete for {self.token_address}")
        
        except Exception as e:
            logger.error(f"Error in tracking loop for {self.token_address}: {str(e)}")
            self.is_tracking = False
            if self.token_address in currently_tracked:
                currently_tracked.remove(self.token_address)
    
    async def _check_alert_thresholds(self, pct_change: float):
        """Check if profit has crossed any alert thresholds and send notifications."""
        if not self.notify_callback:
            return
        
        for threshold in ALERT_THRESHOLDS:
            if threshold not in self.notified_thresholds and pct_change >= threshold:
                # Notify about crossing this threshold
                message = (
                    f"🚀 *Price Alert: {threshold}% Profit* 🚀\n\n"
                    f"Token: `{self.token_address}`\n"
                    f"Group: {self.group_name}\n"
                    f"Current Profit: {pct_change:.2f}%\n"
                    f"Launch Time: {datetime.fromtimestamp(self.launch_time).strftime('%Y-%m-%d %H:%M:%S')}"
                )
                
                await self.notify_callback(message, self.token_address)
                self.notified_thresholds.add(threshold)
    
    async def _update_strategy_algorithms(self, current_price: float, pct_change: float):
        """Update advanced strategy algorithms with price data."""
        if ADVANCED_CONTROLLER_AVAILABLE:
            try:
                controller = get_profit_controller()
                if controller.running:
                    # Add price update to controller
                    if hasattr(controller, 'update_price_data'):
                        await controller.update_price_data(
                            self.token_address,
                            current_price,
                            pct_change,
                            self.all_time_high,
                            self.all_time_low
                        )
            except Exception as e:
                logger.error(f"Error updating strategy algorithms: {str(e)}")
    
    def _save_price_history(self):
        """Save price history to disk."""
        try:
            # Create token-specific file
            history_file = os.path.join(PRICE_STORAGE_DIR, f"{self.token_address}_history.json")
            
            # Save history
            with open(history_file, 'w') as f:
                json.dump({
                    "token_address": self.token_address,
                    "group_name": self.group_name,
                    "launch_price": self.launch_price,
                    "launch_time": self.launch_time,
                    "last_price": self.last_price,
                    "update_time": self.update_time,
                    "all_time_high": self.all_time_high,
                    "all_time_low": self.all_time_low,
                    "price_history": self.price_history
                }, f, indent=2)
        
        except Exception as e:
            logger.error(f"Error saving price history for {self.token_address}: {str(e)}")
    
    def _save_tracking_state(self):
        """Update active tracking state file."""
        try:
            # Load current tracking state
            active_tracking = {}
            if os.path.exists(ACTIVE_TRACKING_FILE):
                try:
                    with open(ACTIVE_TRACKING_FILE, 'r') as f:
                        active_tracking = json.load(f)
                except json.JSONDecodeError:
                    active_tracking = {}
            
            # Update with this token's state
            if self.is_tracking:
                active_tracking[self.token_address] = {
                    "group_name": self.group_name,
                    "launch_time": self.launch_time,
                    "next_interval_idx": self.next_interval_idx,
                    "next_interval_time": self.next_interval_time,
                    "last_updated": time.time()
                }
            elif self.token_address in active_tracking:
                # Remove if tracking is complete
                del active_tracking[self.token_address]
            
            # Save updated state
            with open(ACTIVE_TRACKING_FILE, 'w') as f:
                json.dump(active_tracking, f, indent=2)
        
        except Exception as e:
            logger.error(f"Error saving tracking state: {str(e)}")

async def track_token_price(token_address: str, group_name: str):
    """
    Track token price over time with default settings.
    This is the original function, maintained for backward compatibility.
    
    Args:
        token_address: The token address to track
        group_name: The group name where token was found
    """
    try:
        # Check if token is already being tracked
        if token_address in currently_tracked:
            logger.info(f"Token {token_address} is already being tracked")
            return
        
        # Create tracker and start tracking
        tracker = TokenPriceTracker(token_address, group_name)
        await tracker.start_tracking()
    
    except Exception as e:
        logger.error(f"[ERROR] Profit evaluation failed: {str(e)}")

async def track_token_with_alerts(token_address: str, group_name: str, 
                                notify_callback: callable, intervals: List[int] = None):
    """
    Track token price with custom intervals and notification support.
    
    Args:
        token_address: The token address to track
        group_name: The group name where token was found
        notify_callback: Callback function for notifications
        intervals: List of tracking intervals in minutes
    """
    try:
        # Check if token is already being tracked
        if token_address in currently_tracked:
            logger.info(f"Token {token_address} is already being tracked")
            return
        
        # Create tracker with notification support
        tracker = TokenPriceTracker(
            token_address, 
            group_name, 
            intervals=intervals, 
            notify_callback=notify_callback
        )
        await tracker.start_tracking()
    
    except Exception as e:
        logger.error(f"[ERROR] Enhanced profit tracking failed: {str(e)}")

async def subscribe_to_alerts(user_id: int, token_address: str):
    """
    Subscribe a user to price alerts for a specific token.
    
    Args:
        user_id: Telegram user ID
        token_address: Token address to subscribe to
        
    Returns:
        bool: True if subscription was successful
    """
    try:
        if token_address not in alert_subscriptions:
            alert_subscriptions[token_address] = set()
        
        alert_subscriptions[token_address].add(user_id)
        return True
    
    except Exception as e:
        logger.error(f"Error subscribing to alerts: {str(e)}")
        return False

async def unsubscribe_from_alerts(user_id: int, token_address: str):
    """
    Unsubscribe a user from price alerts for a specific token.
    
    Args:
        user_id: Telegram user ID
        token_address: Token address to unsubscribe from
        
    Returns:
        bool: True if unsubscription was successful
    """
    try:
        if token_address in alert_subscriptions and user_id in alert_subscriptions[token_address]:
            alert_subscriptions[token_address].remove(user_id)
            return True
        return False
    
    except Exception as e:
        logger.error(f"Error unsubscribing from alerts: {str(e)}")
        return False

def get_tracked_token_info(token_address: str) -> Optional[Dict[str, Any]]:
    """
    Get information about a tracked token.
    
    Args:
        token_address: The token address to get info for
        
    Returns:
        Optional[Dict]: Token tracking info or None if not found
    """
    try:
        # Check if token has saved history
        history_file = os.path.join(PRICE_STORAGE_DIR, f"{token_address}_history.json")
        if os.path.exists(history_file):
            with open(history_file, 'r') as f:
                return json.load(f)
        return None
    
    except Exception as e:
        logger.error(f"Error getting token info: {str(e)}")
        return None

def get_active_tracking() -> Dict[str, Dict[str, Any]]:
    """
    Get currently active tracking information.
    
    Returns:
        Dict: Map of token addresses to tracking info
    """
    try:
        if os.path.exists(ACTIVE_TRACKING_FILE):
            with open(ACTIVE_TRACKING_FILE, 'r') as f:
                return json.load(f)
        return {}
    
    except Exception as e:
        logger.error(f"Error getting active tracking: {str(e)}")
        return {}

def get_price_history(token_address: str) -> List[Dict[str, Any]]:
    """
    Get price history for a specific token.
    
    Args:
        token_address: The token address to get history for
        
    Returns:
        List[Dict]: List of price data points or empty list if not found
    """
    token_info = get_tracked_token_info(token_address)
    if token_info and "price_history" in token_info:
        return token_info["price_history"]
    return []

def get_tracked_tokens_list() -> List[str]:
    """
    Get list of all tokens that have been tracked.
    
    Returns:
        List[str]: List of token addresses
    """
    try:
        tokens = []
        for filename in os.listdir(PRICE_STORAGE_DIR):
            if filename.endswith("_history.json"):
                token_address = filename.replace("_history.json", "")
                tokens.append(token_address)
        return tokens
    
    except Exception as e:
        logger.error(f"Error getting tracked tokens list: {str(e)}")
        return []

def calculate_token_performance(token_address: str) -> Dict[str, Any]:
    """
    Calculate comprehensive performance metrics for a token.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Dict: Performance metrics
    """
    token_info = get_tracked_token_info(token_address)
    if not token_info:
        return {}
    
    try:
        launch_price = token_info.get("launch_price", 0)
        last_price = token_info.get("last_price", 0)
        all_time_high = token_info.get("all_time_high", 0)
        all_time_low = token_info.get("all_time_low", float('inf'))
        
        # Avoid division by zero
        if launch_price <= 0:
            return {}
        
        # Calculate metrics
        current_pct_change = ((last_price - launch_price) / launch_price) * 100
        ath_pct_change = ((all_time_high - launch_price) / launch_price) * 100
        atl_pct_change = ((all_time_low - launch_price) / launch_price) * 100
        
        # Get performance at different intervals
        interval_performance = {}
        for entry in token_info.get("price_history", []):
            if "interval_minutes" in entry:
                interval = entry["interval_minutes"]
                interval_performance[f"{interval}min"] = {
                    "price": entry["price"],
                    "pct_change": entry["pct_change"]
                }
        
        return {
            "token_address": token_address,
            "group_name": token_info.get("group_name", "Unknown"),
            "launch_price": launch_price,
            "current_price": last_price,
            "current_pct_change": current_pct_change,
            "all_time_high": all_time_high,
            "ath_pct_change": ath_pct_change,
            "all_time_low": all_time_low,
            "atl_pct_change": atl_pct_change,
            "launch_time": token_info.get("launch_time", 0),
            "update_time": token_info.get("update_time", 0),
            "interval_performance": interval_performance
        }
    
    except Exception as e:
        logger.error(f"Error calculating token performance: {str(e)}")
        return {}