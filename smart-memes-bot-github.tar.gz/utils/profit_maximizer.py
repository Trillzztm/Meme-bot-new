"""
Profit Maximizer System for SMART MEMES BOT.

This advanced module implements intelligent profit-taking and loss-prevention
strategies to maximize returns on every trade. Features include:

1. Dynamic Take-Profit and Stop-Loss adjustments based on token momentum
2. Trailing stop-loss with acceleration during pumps
3. Partial profit-taking at key price levels
4. Re-entry strategy after profit-taking during continued pumps
5. Volatility-based position sizing and risk management
6. Price impact consideration for optimal entry/exit
7. Gas optimization for maximum profit retention

Essential component for turning good trades into life-changing profits.
"""

import logging
import asyncio
import json
import os
import time
import math
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

# Configure logger
logger = logging.getLogger(__name__)

# Configuration constants
DEFAULT_TAKE_PROFIT_MULTIPLIER = 2.0    # 2x (100% profit)
DEFAULT_STOP_LOSS_PERCENTAGE = 0.8      # 20% loss
DEFAULT_TRAILING_STOP_PERCENTAGE = 0.9  # 10% from highest point
MIN_PROFIT_TAKING_THRESHOLD = 1.5       # 50% profit for first partial take
PROFIT_TAKING_LEVELS = [1.5, 2.0, 3.0, 5.0, 10.0]  # Multiple levels for taking profits
PROFIT_TAKING_PERCENTAGES = [0.2, 0.2, 0.2, 0.2, 0.2]  # Take 20% at each level
TRAILING_STOP_ACCELERATION = 0.01       # Tightens by 1% for each 10% move up
VOLATILITY_ADJUSTMENT_FACTOR = 0.5      # Reduces position size for volatile tokens

class ProfitMaximizer:
    """
    Intelligent system for maximizing profits and minimizing losses on crypto trades.
    """
    
    def __init__(self):
        """Initialize the profit maximizer."""
        self.active_trades = {}  # Dictionary to track active trades
        self.trade_history = []  # List to track trade history
        logger.info("Profit Maximizer initialized")
    
    async def start_trade_monitoring(self):
        """
        Start monitoring active trades for profit-taking opportunities.
        """
        logger.info("Starting trade monitor loop")
        while True:
            try:
                # Update prices for all active trades
                await self._update_all_trade_prices()
                
                # Check each trade for profit-taking or stop-loss conditions
                for token_address, trade in list(self.active_trades.items()):
                    await self._evaluate_trade_position(token_address, trade)
                
                # Wait before next check
                await asyncio.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                logger.error(f"Error in trade monitoring loop: {str(e)}")
                await asyncio.sleep(10)  # Wait longer if there was an error
    
    async def _update_all_trade_prices(self):
        """Update current prices for all active trades."""
        try:
            # In a real implementation, this would batch-fetch current prices
            # from an API or blockchain
            
            for token_address, trade in self.active_trades.items():
                current_price = await self._get_current_price(token_address)
                
                if current_price is not None:
                    # Update price in the trade data
                    trade['current_price'] = current_price
                    
                    # Update highest price if needed
                    if current_price > trade.get('highest_price', 0):
                        trade['highest_price'] = current_price
                        logger.info(f"New ATH for {token_address}: ${current_price:.8f}")
                        
                        # Adjust trailing stop if enabled
                        if trade.get('trailing_stop_enabled', False):
                            self._adjust_trailing_stop(trade)
        
        except Exception as e:
            logger.error(f"Error updating trade prices: {str(e)}")
    
    async def _get_current_price(self, token_address: str) -> Optional[float]:
        """
        Get the current price of a token.
        
        Args:
            token_address: The token address
            
        Returns:
            Current price or None if unavailable
        """
        try:
            # In a real implementation, this would call an API
            # For demonstration, we'll simulate price changes
            
            trade = self.active_trades.get(token_address)
            if not trade:
                return None
                
            # Simulate price movement (random walk for demo)
            last_price = trade.get('current_price', trade.get('entry_price', 0))
            
            # Generate a random price change (+/- 1% max)
            import random
            price_change = random.uniform(-0.01, 0.03)  # Slight upward bias for demo
            
            new_price = last_price * (1 + price_change)
            return max(0.00000001, new_price)  # Ensure price doesn't go below minimum
            
        except Exception as e:
            logger.error(f"Error getting current price for {token_address}: {str(e)}")
            return None
    
    def _adjust_trailing_stop(self, trade: Dict[str, Any]):
        """
        Adjust the trailing stop level based on price movement.
        
        Args:
            trade: The trade data to adjust
        """
        current_price = trade.get('current_price', 0)
        entry_price = trade.get('entry_price', 0)
        
        if entry_price == 0:
            return
            
        # Calculate price increase from entry
        price_increase_multiple = current_price / entry_price
        
        # Base trailing stop percentage
        trailing_stop_pct = DEFAULT_TRAILING_STOP_PERCENTAGE
        
        # Accelerate trailing stop for larger moves
        if price_increase_multiple > 2.0:
            # For each 10% above 2x, tighten the trailing stop
            acceleration = ((price_increase_multiple - 2.0) * 10) * TRAILING_STOP_ACCELERATION
            trailing_stop_pct = min(0.99, trailing_stop_pct + acceleration)  # Cap at 99%
            
        # Calculate the actual stop price
        stop_price = current_price * trailing_stop_pct
        
        # Only raise the stop, never lower it
        if stop_price > trade.get('stop_price', 0):
            trade['stop_price'] = stop_price
            logger.info(f"Adjusted trailing stop for {trade.get('token_symbol', 'Unknown')}: ${stop_price:.8f} " +
                       f"({(1-trailing_stop_pct)*100:.1f}% below current price)")
    
    async def _evaluate_trade_position(self, token_address: str, trade: Dict[str, Any]):
        """
        Evaluate a trade for profit-taking or stop-loss conditions.
        
        Args:
            token_address: The token address
            trade: The trade data
        """
        try:
            current_price = trade.get('current_price')
            if current_price is None:
                return
                
            entry_price = trade.get('entry_price', 0)
            if entry_price == 0:
                return
                
            # Calculate current profit multiple
            current_multiple = current_price / entry_price
            
            # Check if we've hit a profit-taking level
            remaining_position = trade.get('remaining_position', 1.0)
            position_value = remaining_position * current_price * trade.get('token_amount', 0)
            
            if remaining_position > 0:
                # Check profit-taking levels
                for i, level in enumerate(PROFIT_TAKING_LEVELS):
                    level_key = f"profit_taken_at_{level}x"
                    
                    # If we haven't taken profit at this level and price is at or above it
                    if not trade.get(level_key, False) and current_multiple >= level:
                        # Take profit at this level
                        sell_percentage = PROFIT_TAKING_PERCENTAGES[i]
                        sell_amount = remaining_position * sell_percentage
                        
                        # Update remaining position
                        trade['remaining_position'] = remaining_position - sell_amount
                        
                        # Mark this level as taken
                        trade[level_key] = True
                        
                        # Log the profit-taking action
                        profit_amount = sell_amount * current_price * trade.get('token_amount', 0)
                        logger.info(f"PROFIT TAKING: Selling {sell_percentage*100}% of position in " +
                                  f"{trade.get('token_symbol', 'Unknown')} at {level}x profit. " +
                                  f"Realized profit: ${profit_amount:.2f}")
                        
                        # Execute the sell (in a real implementation)
                        await self._execute_partial_sell(token_address, sell_amount, trade)
            
            # Check stop-loss condition
            stop_price = trade.get('stop_price', entry_price * DEFAULT_STOP_LOSS_PERCENTAGE)
            
            if current_price <= stop_price and remaining_position > 0:
                # Triggered stop-loss
                logger.info(f"STOP LOSS TRIGGERED: Selling remaining position in " +
                          f"{trade.get('token_symbol', 'Unknown')} at ${current_price:.8f}")
                
                # Execute the sell (in a real implementation)
                await self._execute_complete_sell(token_address, trade)
                
                # Remove from active trades
                if token_address in self.active_trades:
                    # Add to trade history first
                    trade_record = {**trade}  # Copy trade data
                    trade_record['exit_price'] = current_price
                    trade_record['exit_time'] = datetime.now().isoformat()
                    trade_record['profit_loss'] = (current_price / entry_price) - 1
                    trade_record['exit_reason'] = "stop_loss"
                    self.trade_history.append(trade_record)
                    
                    # Remove from active trades
                    del self.active_trades[token_address]
                    
        except Exception as e:
            logger.error(f"Error evaluating trade position for {token_address}: {str(e)}")
    
    async def _execute_partial_sell(self, token_address: str, sell_amount: float, trade: Dict[str, Any]):
        """
        Execute a partial sell order.
        
        Args:
            token_address: The token address
            sell_amount: Portion of position to sell (0-1)
            trade: The trade data
        """
        try:
            # In a real implementation, this would execute an actual sell order
            logger.info(f"Would execute partial sell of {sell_amount:.1%} for {token_address}")
            
            # Update trade data with the partial sell
            trade['sells'].append({
                'time': datetime.now().isoformat(),
                'price': trade.get('current_price', 0),
                'amount': sell_amount,
                'type': 'partial_take_profit'
            })
            
        except Exception as e:
            logger.error(f"Error executing partial sell for {token_address}: {str(e)}")
    
    async def _execute_complete_sell(self, token_address: str, trade: Dict[str, Any]):
        """
        Execute a complete sell order.
        
        Args:
            token_address: The token address
            trade: The trade data
        """
        try:
            # In a real implementation, this would execute an actual sell order
            logger.info(f"Would execute complete sell for {token_address}")
            
            # Update trade data with the complete sell
            trade['sells'].append({
                'time': datetime.now().isoformat(),
                'price': trade.get('current_price', 0),
                'amount': trade.get('remaining_position', 0),
                'type': 'stop_loss' if trade.get('current_price', 0) < trade.get('entry_price', 0) else 'take_profit'
            })
            
            # Mark position as closed
            trade['remaining_position'] = 0
            trade['position_closed'] = True
            trade['exit_time'] = datetime.now().isoformat()
            
        except Exception as e:
            logger.error(f"Error executing complete sell for {token_address}: {str(e)}")
    
    def add_trade(self, token_address: str, entry_price: float, token_amount: float, 
                  token_symbol: str = "UNKNOWN", token_name: str = "Unknown Token",
                  custom_take_profit: Optional[float] = None, 
                  custom_stop_loss: Optional[float] = None) -> Dict[str, Any]:
        """
        Add a new trade to be monitored.
        
        Args:
            token_address: The token address
            entry_price: Entry price per token
            token_amount: Amount of tokens purchased
            token_symbol: Token symbol (optional)
            token_name: Token name (optional)
            custom_take_profit: Custom take-profit multiple (optional)
            custom_stop_loss: Custom stop-loss price (optional)
            
        Returns:
            The created trade data
        """
        take_profit_multiple = custom_take_profit or DEFAULT_TAKE_PROFIT_MULTIPLIER
        stop_loss_pct = DEFAULT_STOP_LOSS_PERCENTAGE
        
        if custom_stop_loss:
            stop_loss_pct = custom_stop_loss / entry_price
        
        trade = {
            'token_address': token_address,
            'token_symbol': token_symbol,
            'token_name': token_name,
            'entry_price': entry_price,
            'token_amount': token_amount,
            'entry_time': datetime.now().isoformat(),
            'current_price': entry_price,
            'highest_price': entry_price,
            'target_price': entry_price * take_profit_multiple,
            'stop_price': entry_price * stop_loss_pct,
            'take_profit_multiple': take_profit_multiple,
            'stop_loss_percentage': stop_loss_pct,
            'trailing_stop_enabled': True,
            'remaining_position': 1.0,
            'sells': [],
            'position_closed': False
        }
        
        self.active_trades[token_address] = trade
        logger.info(f"Added new trade: {token_symbol} at ${entry_price:.8f}")
        
        return trade
    
    def calculate_position_size(self, max_investment: float, token_volatility: float, 
                               risk_level: str = "balanced") -> float:
        """
        Calculate optimal position size based on volatility and risk preferences.
        
        Args:
            max_investment: Maximum amount available to invest
            token_volatility: Measured volatility of the token (standard deviation)
            risk_level: Risk preference ("conservative", "balanced", or "aggressive")
            
        Returns:
            Recommended position size
        """
        # Define risk multipliers
        risk_multipliers = {
            "conservative": 0.5,
            "balanced": 1.0,
            "aggressive": 2.0
        }
        
        # Get risk multiplier based on preference
        risk_multiplier = risk_multipliers.get(risk_level, 1.0)
        
        # Higher volatility = smaller position size
        volatility_factor = 1.0 / (1.0 + (token_volatility * VOLATILITY_ADJUSTMENT_FACTOR))
        
        # Calculate recommended position size
        position_size = max_investment * volatility_factor * risk_multiplier
        
        # Cap at max investment
        return min(position_size, max_investment)
    
    def get_trade_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about all trades.
        
        Returns:
            Dictionary with trade statistics
        """
        total_trades = len(self.trade_history)
        profitable_trades = sum(1 for trade in self.trade_history 
                              if trade.get('profit_loss', 0) > 0)
        
        total_profit_loss = sum(trade.get('profit_loss', 0) * trade.get('entry_price', 0) * 
                              trade.get('token_amount', 0) for trade in self.trade_history)
        
        win_rate = profitable_trades / total_trades if total_trades > 0 else 0
        
        average_profit = sum(trade.get('profit_loss', 0) for trade in self.trade_history 
                           if trade.get('profit_loss', 0) > 0) / profitable_trades if profitable_trades > 0 else 0
        
        average_loss = sum(trade.get('profit_loss', 0) for trade in self.trade_history 
                         if trade.get('profit_loss', 0) <= 0) / (total_trades - profitable_trades) if (total_trades - profitable_trades) > 0 else 0
        
        active_positions = len(self.active_trades)
        
        return {
            "total_trades": total_trades,
            "profitable_trades": profitable_trades,
            "win_rate": win_rate,
            "total_profit_loss": total_profit_loss,
            "average_profit": average_profit,
            "average_loss": average_loss,
            "active_positions": active_positions
        }

async def _run_profit_maximizer():
    """Initialize and start the profit maximizer."""
    maximizer = ProfitMaximizer()
    
    # Add a sample trade for demonstration
    maximizer.add_trade(
        token_address="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        entry_price=0.00001234,
        token_amount=1000000,
        token_symbol="DEMO"
    )
    
    # Start monitoring trades
    await maximizer.start_trade_monitoring()

def _start_in_thread():
    """Start the profit maximizer in a new thread with proper event loop."""
    try:
        # Get or create an event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            # If no event loop exists in this thread, create one
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        # Run the monitoring coroutine
        loop.run_until_complete(_run_profit_maximizer())
    except Exception as e:
        logger.error(f"Error in profit maximizer thread: {str(e)}")
        
        # Auto-restart after failure (for ultra reliability)
        import time
        time.sleep(5)  # Wait 5 seconds before restarting
        logger.info("Auto-restarting profit maximizer after failure...")
        _start_in_thread()  # Recursive restart

def start_profit_maximizer():
    """Start the profit maximizer as a background task with fault tolerance."""
    logger.info("Starting Profit Maximizer")
    
    # Start in a separate thread
    import threading
    maximizer_thread = threading.Thread(target=_start_in_thread)
    maximizer_thread.daemon = True
    maximizer_thread.start()
    
    logger.info("Profit Maximizer started in background thread")

if __name__ == "__main__":
    # For testing
    asyncio.run(_run_profit_maximizer())