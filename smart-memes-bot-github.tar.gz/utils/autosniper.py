"""
Automatic token sniping module for SMART MEMES BOT.

This module detects token mentions in group messages and
automatically executes trades when configured criteria are met.
"""

import logging
import re
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple
from telegram import Update

from utils.token_safety import check_token_safety
from utils.token_info import get_token_info
from utils.token_analysis import get_token_price, get_price_5min_later, analyze_token_performance
from utils.solana_trade import check_token_liquidity, execute_trade

# Configure logger
logger = logging.getLogger(__name__)

# Token address regex pattern - matches Solana addresses (44 chars, alphanumeric)
TOKEN_ADDRESS_PATTERN = r'([A-Za-z0-9]{44})'

async def extract_token_addresses(text: str) -> List[str]:
    """
    Extract potential token addresses from text.
    
    Args:
        text: The text to extract token addresses from
        
    Returns:
        List of potential token addresses
    """
    # Find all matches
    matches = re.findall(TOKEN_ADDRESS_PATTERN, text)
    
    # Return unique matches
    return list(set(matches))

def extract_token_address(text: str) -> Optional[str]:
    """
    Extract a single token address from text.
    Simple version for direct use.
    
    Args:
        text: The text to extract token address from
        
    Returns:
        Token address if found, None otherwise
    """
    for word in text.split():
        if len(word) == 44 and word.isalnum():
            return word
    return None

async def get_token_performance(token_address: str) -> Dict[str, Any]:
    """
    Get token price performance after 5 minutes using real Birdeye data.
    
    Args:
        token_address: The token address to check
        
    Returns:
        Dictionary with performance data
    """
    # Get real price data from Birdeye via our token_analysis module
    try:
        # This will wait 5 minutes and return both prices and performance data
        performance_data = await get_price_5min_later(token_address)
        
        if not performance_data.get('success', False):
            logger.error(f"Failed to get price data: {performance_data.get('error', 'Unknown error')}")
            # Fallback to simulation if API fails
            import random
            return {
                'performance_multiplier': random.uniform(0.7, 2.3),
                'success': False,
                'error': performance_data.get('error', 'API failure'),
                'is_simulated': True  # Mark as simulated data
            }
            
        # Extract the performance multiplier
        performance_multiplier = performance_data.get('performance_multiplier', 1.0)
        
        return {
            'initial_price': performance_data.get('initial', 0),
            'final_price': performance_data.get('after_5min', 0),
            'change_percent': performance_data.get('change_percent', 0),
            'performance_multiplier': performance_multiplier,
            'success': True,
            'is_simulated': False
        }
    except Exception as e:
        logger.error(f"Error getting token performance: {str(e)}")
        # Fallback to simulation
        import random
        return {
            'performance_multiplier': random.uniform(0.7, 2.3),
            'success': False,
            'error': str(e),
            'is_simulated': True  # Mark as simulated data
        }

async def process_token_mention(text: str, update: Update) -> None:
    """
    Process a token mention message and determine if it should be auto-sniped.
    
    Args:
        text: The message text
        update: The Telegram update object
    """
    try:
        # Extract token address
        token_address = extract_token_address(text)
        if not token_address:
            logger.debug("No token address found in message")
            return
        
        logger.info(f"Processing potential token address: {token_address}")
        
        # Step 1: Check token safety with enhanced analysis
        safety_check = await check_token_safety(token_address)
        
        # Skip tokens with safety score below threshold (70%)
        safety_score = safety_check.get('score', 0)
        if not safety_check.get('safe', False) or safety_score < 70:
            logger.warning(f"Token {token_address} failed safety check: {safety_score}/100")
            
            # Get specific warnings to show user
            warnings = safety_check.get('warnings', [])
            if warnings:
                warning_msg = "\n• ".join(warnings)
                await update.message.reply_text(
                    f"⚠️ *Token Safety Alert* ⚠️\n\n"
                    f"Token skipped due to safety concerns (Score: {safety_score}/100)\n\n"
                    f"*Warnings:*\n• {warning_msg}",
                    parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    f"⚠️ *Token Safety Alert* ⚠️\n\n"
                    f"Token skipped due to low safety score: {safety_score}/100",
                    parse_mode="Markdown"
                )
            return
        
        # Check if the token has liquidity
        has_liquidity, liquidity_amount, _ = await check_token_liquidity(token_address)
        
        if not has_liquidity:
            logger.warning(f"Token {token_address} has no liquidity")
            await update.message.reply_text("Token has no liquidity, skipped.")
            return
        
        # Step 2: Execute a small test trade
        await update.message.reply_text(f"Sniping token: `{token_address}`", parse_mode="Markdown")
        
        # Execute the trade (small amount for testing)
        amount_sol = 0.05  # Small test amount
        success, message = await execute_trade(token_address, amount_sol)
        
        if success:
            await update.message.reply_text(f"✅ Test purchase successful!\n{message}")
            
            # Step 3: Wait 5 minutes and check performance
            await update.message.reply_text("Monitoring price performance for 5 minutes...")
            
            # In a real implementation, we would start a background task instead of blocking
            # For now, we'll simulate the delay for demonstration
            await asyncio.sleep(10)  # Reduced to 10 seconds for demonstration
            
            # Get price performance using new real-data function
            performance_data = await get_token_performance(token_address)
            
            # Extract the performance multiplier
            performance_multiplier = performance_data.get('performance_multiplier', 1.0)
            change_percent = performance_data.get('change_percent', 0)
            is_simulated = performance_data.get('is_simulated', True)
            
            # Data source indicator for transparency
            data_source = "simulated" if is_simulated else "real market data (Birdeye API)"
            
            # Report performance
            if performance_multiplier >= 1.5:
                await update.message.reply_text(
                    f"🚀 *Token Performance Analysis* 🚀\n\n"
                    f"Token gained {performance_multiplier:.2f}x in 5 minutes! (+{change_percent:.2f}%)\n"
                    f"Initial price: {performance_data.get('initial_price', 0):.8f}\n"
                    f"Current price: {performance_data.get('final_price', 0):.8f}\n\n"
                    f"*Recommendation:* Consider buying more!\n"
                    f"*Data source:* {data_source}",
                    parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    f"📉 *Token Performance Analysis* 📉\n\n"
                    f"Token only did {performance_multiplier:.2f}x in 5 minutes. ({change_percent:.2f}%)\n"
                    f"Initial price: {performance_data.get('initial_price', 0):.8f}\n"
                    f"Current price: {performance_data.get('final_price', 0):.8f}\n\n"
                    f"*Recommendation:* Monitor for further movement.\n"
                    f"*Data source:* {data_source}",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(f"❌ Test purchase failed: {message}")
    
    except Exception as e:
        logger.error(f"Error processing token mention: {str(e)}")
        await update.message.reply_text(f"Error processing token: {str(e)}")