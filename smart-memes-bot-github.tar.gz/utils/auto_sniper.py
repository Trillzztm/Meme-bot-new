"""
Auto-Sniper System for SMART MEMES BOT.

This module implements an advanced auto-sniping system that:
1. Evaluates tokens using multiple verification sources
2. Makes intelligent trading decisions based on risk assessment
3. Sizes positions according to confidence and available capital
4. Executes trades with optimal timing and parameters
5. Monitors performance and self-adjusts strategy

The auto-sniper combines social proof analysis, smart wallet tracking,
token safety checks, and liquidity monitoring to make informed decisions.
"""

import os
import json
import logging
import time
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set, Union
from dataclasses import dataclass
import aiohttp

# Configure logger
logger = logging.getLogger(__name__)

# Import core components
try:
    from utils.social_proof import analyze_message, MessageAnalysis
    from utils.risk_manager import assess_token_risk, log_trade_performance, should_continue_trading, RiskAssessment
    from utils.smart_wallet_tracker import get_trading_opportunities, monitor_smart_wallets
    from utils.liquidity_scanner import comprehensive_token_analysis, ComprehensiveAnalysis
    from utils.solana_trade import execute_trade, check_token_liquidity
except ImportError as e:
    logger.error(f"Error importing core components: {e}")
    raise

# Import config settings
try:
    from config import (
        AUTO_SNIPE_MIN_MENTIONS,
        AUTO_SNIPE_AMOUNT,
        MAX_AUTO_SNIPE_AMOUNT,
        AUTO_SNIPE_THRESHOLD_SCORE
    )
except ImportError:
    # Default values if config not available
    AUTO_SNIPE_MIN_MENTIONS = 3
    AUTO_SNIPE_AMOUNT = 0.1
    MAX_AUTO_SNIPE_AMOUNT = 0.5
    AUTO_SNIPE_THRESHOLD_SCORE = 7.0
    logger.warning("Config not found, using default auto-sniper settings")


@dataclass
class SnipeCandidate:
    """Data class to hold a token snipe candidate."""
    token_address: str
    token_symbol: Optional[str]
    network: str
    source_type: str  # "group", "wallet", "twitter", etc.
    source_id: str
    score: float  # Combined score (0-10)
    safety_score: float  # Safety score (0-10)
    social_proof_score: float  # Social proof score (0-10)
    liquidity_score: float  # Liquidity score (0-10)
    wallet_interest_score: float  # Wallet interest score (0-10)
    risk_level: str  # "low", "medium", "high", "extreme", "forbidden"
    confidence: float  # 0-1 scale
    position_size: float  # As a fraction of available capital
    max_amount: float  # Maximum amount to spend
    recommended_amount: float  # Recommended amount to spend
    mentions: int  # Number of mentions (for groups)
    important_wallets: List[str]  # Important wallets involved
    verification_sources: List[str]  # Sources that verified this token
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert candidate to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "token_symbol": self.token_symbol,
            "network": self.network,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "score": self.score,
            "safety_score": self.safety_score,
            "social_proof_score": self.social_proof_score,
            "liquidity_score": self.liquidity_score,
            "wallet_interest_score": self.wallet_interest_score,
            "risk_level": self.risk_level,
            "confidence": self.confidence,
            "position_size": self.position_size,
            "max_amount": self.max_amount,
            "recommended_amount": self.recommended_amount,
            "mentions": self.mentions,
            "important_wallets": self.important_wallets,
            "verification_sources": self.verification_sources,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SnipeCandidate':
        """Create candidate object from dictionary."""
        return cls(
            token_address=data["token_address"],
            token_symbol=data["token_symbol"],
            network=data["network"],
            source_type=data["source_type"],
            source_id=data["source_id"],
            score=data["score"],
            safety_score=data["safety_score"],
            social_proof_score=data["social_proof_score"],
            liquidity_score=data["liquidity_score"],
            wallet_interest_score=data["wallet_interest_score"],
            risk_level=data["risk_level"],
            confidence=data["confidence"],
            position_size=data["position_size"],
            max_amount=data["max_amount"],
            recommended_amount=data["recommended_amount"],
            mentions=data["mentions"],
            important_wallets=data["important_wallets"],
            verification_sources=data["verification_sources"],
            timestamp=data["timestamp"]
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the candidate."""
        token_info = f"{self.token_symbol}" if self.token_symbol else f"{self.token_address[-8:]}"
        source_info = f"{self.source_type.capitalize()}: {self.source_id}"
        verification = f"{len(self.verification_sources)} sources" if self.verification_sources else "Single source"
        
        return (
            f"Token: {token_info}\n"
            f"Score: {self.score:.1f}/10\n"
            f"Risk: {self.risk_level.upper()}\n"
            f"Confidence: {self.confidence*100:.1f}%\n"
            f"Source: {source_info}\n"
            f"Verified by: {verification}\n"
            f"Amount: {self.recommended_amount} SOL\n"
            f"Mentions: {self.mentions}"
        )


@dataclass
class SnipeResult:
    """Data class to hold a snipe result."""
    candidate: SnipeCandidate
    success: bool
    transaction_hash: Optional[str]
    amount_spent: float
    tokens_received: Optional[float]
    entry_price: Optional[float]
    error_message: Optional[str]
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for storage."""
        return {
            "candidate": self.candidate.to_dict(),
            "success": self.success,
            "transaction_hash": self.transaction_hash,
            "amount_spent": self.amount_spent,
            "tokens_received": self.tokens_received,
            "entry_price": self.entry_price,
            "error_message": self.error_message,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SnipeResult':
        """Create result object from dictionary."""
        return cls(
            candidate=SnipeCandidate.from_dict(data["candidate"]),
            success=data["success"],
            transaction_hash=data["transaction_hash"],
            amount_spent=data["amount_spent"],
            tokens_received=data["tokens_received"],
            entry_price=data["entry_price"],
            error_message=data["error_message"],
            timestamp=data["timestamp"]
        )


# Track processed tokens to avoid duplicates
_processed_tokens = set()

# Cache of recent snipe results
_recent_snipes = []

# Cache of pending verification tokens
_pending_verification = {}

# Global state for auto-sniper
_auto_sniper_state = {
    "enabled": True,
    "available_capital": 10.0,  # SOL
    "total_positions": 0,
    "total_capital_deployed": 0.0,
    "last_performance_check": 0,
    "recent_profit_rate": 0.0,
    "snipe_count": 0,
    "successful_snipes": 0
}


async def evaluate_token_from_group(
    token_address: str,
    group_id: str,
    message_analysis: MessageAnalysis,
    mentions: int = 1,
    available_capital: float = 1.0
) -> Optional[SnipeCandidate]:
    """
    Evaluate a token mentioned in a group.
    
    Args:
        token_address: The token address to evaluate
        group_id: The group ID where the token was mentioned
        message_analysis: Analysis of the message mentioning the token
        mentions: Number of times the token has been mentioned
        available_capital: Available capital for investment
        
    Returns:
        SnipeCandidate if the token passes evaluation, None otherwise
    """
    # Skip if already processed
    if token_address in _processed_tokens:
        logger.debug(f"Token {token_address} already processed, skipping")
        return None
    
    logger.info(f"Evaluating token {token_address} from group {group_id} with {mentions} mentions")
    
    try:
        # Check if minimum mentions threshold is met
        if mentions < AUTO_SNIPE_MIN_MENTIONS:
            logger.debug(f"Token {token_address} has only {mentions} mentions, minimum is {AUTO_SNIPE_MIN_MENTIONS}")
            return None
        
        # Get social proof score from message analysis
        social_proof_score = message_analysis.score
        
        # Skip if social proof score is too low
        if social_proof_score < 5.0:
            logger.debug(f"Token {token_address} social proof score is too low: {social_proof_score}")
            return None
        
        # Perform comprehensive token analysis
        token_analysis = await comprehensive_token_analysis(token_address)
        
        # Skip if token analysis indicates high risk or forbidden
        if token_analysis.risk_level in ["forbidden"]:
            logger.warning(f"Token {token_address} failed safety checks: {token_analysis.risk_level}")
            _processed_tokens.add(token_address)  # Mark as processed to avoid re-evaluation
            return None
        
        # Get token safety score
        safety_score = token_analysis.safety_analysis.safety_score
        
        # Get token liquidity score
        liquidity_score = token_analysis.liquidity_analysis.liquidity_score
        
        # Check if safety score meets threshold
        if safety_score < 5.0:
            logger.debug(f"Token {token_address} safety score is too low: {safety_score}")
            return None
        
        # Check if liquidity score meets threshold
        if liquidity_score < 4.0:
            logger.debug(f"Token {token_address} liquidity score is too low: {liquidity_score}")
            return None
        
        # Check wallet interest (if any)
        wallet_interest_score = 0.0
        important_wallets = []
        
        # Perform risk assessment
        risk_assessment = await assess_token_risk(
            token_address=token_address,
            social_proof_score=social_proof_score,
            safety_score=safety_score,
            source_id=group_id,
            source_type="group",
            available_capital=available_capital
        )
        
        # Calculate combined score - weighted average
        combined_score = (
            social_proof_score * 0.35 +  # 35% weight for social proof
            safety_score * 0.3 +         # 30% weight for safety
            liquidity_score * 0.25 +     # 25% weight for liquidity
            wallet_interest_score * 0.1   # 10% weight for wallet interest
        )
        
        # Calculate recommended amount based on position size and available capital
        recommended_amount = risk_assessment.position_size * available_capital
        
        # Cap at max auto-snipe amount
        recommended_amount = min(recommended_amount, MAX_AUTO_SNIPE_AMOUNT)
        
        # Create a snipe candidate
        candidate = SnipeCandidate(
            token_address=token_address,
            token_symbol=token_analysis.token_symbol,
            network="solana",  # Default to Solana for now
            source_type="group",
            source_id=group_id,
            score=combined_score,
            safety_score=safety_score,
            social_proof_score=social_proof_score,
            liquidity_score=liquidity_score,
            wallet_interest_score=wallet_interest_score,
            risk_level=risk_assessment.risk_level,
            confidence=risk_assessment.confidence,
            position_size=risk_assessment.position_size,
            max_amount=risk_assessment.max_amount,
            recommended_amount=recommended_amount,
            mentions=mentions,
            important_wallets=important_wallets,
            verification_sources=[f"group:{group_id}"],
            timestamp=time.time()
        )
        
        return candidate
    
    except Exception as e:
        logger.error(f"Error evaluating token {token_address} from group {group_id}: {e}")
        return None


async def evaluate_token_from_wallet(
    token_address: str,
    wallet_addresses: List[str],
    opportunity_score: float,
    available_capital: float = 1.0
) -> Optional[SnipeCandidate]:
    """
    Evaluate a token discovered through wallet tracking.
    
    Args:
        token_address: The token address to evaluate
        wallet_addresses: Addresses of wallets that bought the token
        opportunity_score: Interest score from wallet tracking (0-10)
        available_capital: Available capital for investment
        
    Returns:
        SnipeCandidate if the token passes evaluation, None otherwise
    """
    # Skip if already processed
    if token_address in _processed_tokens:
        logger.debug(f"Token {token_address} already processed, skipping")
        return None
    
    primary_wallet = wallet_addresses[0] if wallet_addresses else "unknown"
    logger.info(f"Evaluating token {token_address} from wallet {primary_wallet}")
    
    try:
        # Perform comprehensive token analysis
        token_analysis = await comprehensive_token_analysis(token_address)
        
        # Skip if token analysis indicates high risk or forbidden
        if token_analysis.risk_level in ["forbidden"]:
            logger.warning(f"Token {token_address} failed safety checks: {token_analysis.risk_level}")
            _processed_tokens.add(token_address)  # Mark as processed to avoid re-evaluation
            return None
        
        # Get token safety score
        safety_score = token_analysis.safety_analysis.safety_score
        
        # Get token liquidity score
        liquidity_score = token_analysis.liquidity_analysis.liquidity_score
        
        # Check if safety score meets threshold
        if safety_score < 6.0:
            logger.debug(f"Token {token_address} safety score is too low: {safety_score}")
            return None
        
        # Check if liquidity score meets threshold
        if liquidity_score < 5.0:
            logger.debug(f"Token {token_address} liquidity score is too low: {liquidity_score}")
            return None
        
        # Wallet interest score (from opportunity score)
        wallet_interest_score = opportunity_score
        
        # Use a default social proof score for wallet discoveries
        social_proof_score = 6.0  # Moderate default
        
        # Perform risk assessment
        risk_assessment = await assess_token_risk(
            token_address=token_address,
            social_proof_score=social_proof_score,
            safety_score=safety_score,
            source_id=primary_wallet,
            source_type="wallet",
            available_capital=available_capital
        )
        
        # Calculate combined score - weighted average with higher weight for wallet interest
        combined_score = (
            social_proof_score * 0.15 +  # 15% weight for social proof (lower for wallet discoveries)
            safety_score * 0.3 +         # 30% weight for safety
            liquidity_score * 0.25 +     # 25% weight for liquidity
            wallet_interest_score * 0.3   # 30% weight for wallet interest (higher for wallet discoveries)
        )
        
        # Calculate recommended amount based on position size and available capital
        recommended_amount = risk_assessment.position_size * available_capital
        
        # Cap at max auto-snipe amount
        recommended_amount = min(recommended_amount, MAX_AUTO_SNIPE_AMOUNT)
        
        # Create a snipe candidate
        candidate = SnipeCandidate(
            token_address=token_address,
            token_symbol=token_analysis.token_symbol,
            network="solana",  # Default to Solana for now
            source_type="wallet",
            source_id=primary_wallet,
            score=combined_score,
            safety_score=safety_score,
            social_proof_score=social_proof_score,
            liquidity_score=liquidity_score,
            wallet_interest_score=wallet_interest_score,
            risk_level=risk_assessment.risk_level,
            confidence=risk_assessment.confidence,
            position_size=risk_assessment.position_size,
            max_amount=risk_assessment.max_amount,
            recommended_amount=recommended_amount,
            mentions=0,  # Not applicable for wallet discoveries
            important_wallets=wallet_addresses,
            verification_sources=[f"wallet:{wallet}" for wallet in wallet_addresses[:3]],
            timestamp=time.time()
        )
        
        return candidate
    
    except Exception as e:
        logger.error(f"Error evaluating token {token_address} from wallet {primary_wallet}: {e}")
        return None


async def evaluate_token_from_twitter(
    token_address: str,
    twitter_account: str,
    tweet_text: str,
    available_capital: float = 1.0
) -> Optional[SnipeCandidate]:
    """
    Evaluate a token discovered through Twitter monitoring.
    
    Args:
        token_address: The token address to evaluate
        twitter_account: Twitter account that mentioned the token
        tweet_text: Text of the tweet mentioning the token
        available_capital: Available capital for investment
        
    Returns:
        SnipeCandidate if the token passes evaluation, None otherwise
    """
    # Skip if already processed
    if token_address in _processed_tokens:
        logger.debug(f"Token {token_address} already processed, skipping")
        return None
    
    logger.info(f"Evaluating token {token_address} from Twitter {twitter_account}")
    
    try:
        # Analyze the tweet text for social proof
        message_analysis = analyze_message(tweet_text)
        
        # Get social proof score from message analysis
        social_proof_score = message_analysis.score
        
        # Skip if social proof score is too low for Twitter
        if social_proof_score < 5.5:
            logger.debug(f"Token {token_address} Twitter social proof score is too low: {social_proof_score}")
            return None
        
        # Perform comprehensive token analysis
        token_analysis = await comprehensive_token_analysis(token_address)
        
        # Skip if token analysis indicates high risk or forbidden
        if token_analysis.risk_level in ["forbidden"]:
            logger.warning(f"Token {token_address} failed safety checks: {token_analysis.risk_level}")
            _processed_tokens.add(token_address)  # Mark as processed to avoid re-evaluation
            return None
        
        # Get token safety score
        safety_score = token_analysis.safety_analysis.safety_score
        
        # Get token liquidity score
        liquidity_score = token_analysis.liquidity_analysis.liquidity_score
        
        # Check if safety score meets threshold
        if safety_score < 6.0:
            logger.debug(f"Token {token_address} safety score is too low: {safety_score}")
            return None
        
        # Check if liquidity score meets threshold
        if liquidity_score < 5.0:
            logger.debug(f"Token {token_address} liquidity score is too low: {liquidity_score}")
            return None
        
        # Default wallet interest for Twitter discoveries
        wallet_interest_score = 5.0  # Moderate default
        important_wallets = []
        
        # Perform risk assessment
        risk_assessment = await assess_token_risk(
            token_address=token_address,
            social_proof_score=social_proof_score,
            safety_score=safety_score,
            source_id=twitter_account,
            source_type="twitter",
            available_capital=available_capital
        )
        
        # Calculate combined score - weighted average
        combined_score = (
            social_proof_score * 0.3 +  # 30% weight for social proof
            safety_score * 0.35 +       # 35% weight for safety (higher for Twitter)
            liquidity_score * 0.25 +    # 25% weight for liquidity
            wallet_interest_score * 0.1  # 10% weight for wallet interest
        )
        
        # Calculate recommended amount based on position size and available capital
        recommended_amount = risk_assessment.position_size * available_capital
        
        # Cap at max auto-snipe amount with lower cap for Twitter discoveries
        recommended_amount = min(recommended_amount, MAX_AUTO_SNIPE_AMOUNT * 0.8)
        
        # Create a snipe candidate
        candidate = SnipeCandidate(
            token_address=token_address,
            token_symbol=token_analysis.token_symbol,
            network="solana",  # Default to Solana for now
            source_type="twitter",
            source_id=twitter_account,
            score=combined_score,
            safety_score=safety_score,
            social_proof_score=social_proof_score,
            liquidity_score=liquidity_score,
            wallet_interest_score=wallet_interest_score,
            risk_level=risk_assessment.risk_level,
            confidence=risk_assessment.confidence,
            position_size=risk_assessment.position_size,
            max_amount=risk_assessment.max_amount,
            recommended_amount=recommended_amount,
            mentions=1,  # Single Twitter mention
            important_wallets=important_wallets,
            verification_sources=[f"twitter:{twitter_account}"],
            timestamp=time.time()
        )
        
        return candidate
    
    except Exception as e:
        logger.error(f"Error evaluating token {token_address} from Twitter {twitter_account}: {e}")
        return None


async def add_verification_source(
    token_address: str,
    source_type: str,
    source_id: str,
    score: float
) -> None:
    """
    Add a verification source for a token.
    
    Args:
        token_address: The token address
        source_type: Type of source ("group", "wallet", "twitter")
        source_id: Source identifier
        score: Score from this source (0-10)
    """
    # Initialize if needed
    if token_address not in _pending_verification:
        _pending_verification[token_address] = {
            "sources": [],
            "scores": [],
            "last_updated": time.time()
        }
    
    # Add to sources if not already present
    source_key = f"{source_type}:{source_id}"
    if source_key not in _pending_verification[token_address]["sources"]:
        _pending_verification[token_address]["sources"].append(source_key)
        _pending_verification[token_address]["scores"].append(score)
    
    # Update timestamp
    _pending_verification[token_address]["last_updated"] = time.time()


async def check_verified_tokens() -> List[str]:
    """
    Check for tokens that have been verified by multiple sources.
    
    Returns:
        List of token addresses that have sufficient verification
    """
    verified_tokens = []
    
    # Current time for age check
    current_time = time.time()
    
    # Check each pending token
    for token_address, data in list(_pending_verification.items()):
        # Skip if already processed
        if token_address in _processed_tokens:
            continue
        
        # Check number of verification sources
        if len(data["sources"]) >= 2:
            logger.info(f"Token {token_address} verified by {len(data['sources'])} sources")
            verified_tokens.append(token_address)
            continue
        
        # Check average score - if very high, might not need multiple sources
        if len(data["scores"]) > 0:
            avg_score = sum(data["scores"]) / len(data["scores"])
            if avg_score >= 8.5:
                logger.info(f"Token {token_address} verified with high score: {avg_score}")
                verified_tokens.append(token_address)
                continue
        
        # Check age - if more than 2 hours old with only one source, remove
        if current_time - data["last_updated"] > 7200:
            logger.debug(f"Removing unverified token {token_address} from pending verification")
            del _pending_verification[token_address]
    
    return verified_tokens


async def execute_snipe(candidate: SnipeCandidate) -> SnipeResult:
    """
    Execute a token snipe.
    
    Args:
        candidate: The SnipeCandidate to snipe
        
    Returns:
        SnipeResult with the outcome
    """
    # Mark token as processed
    _processed_tokens.add(candidate.token_address)
    
    # Log the snipe attempt
    logger.info(f"Executing snipe for {candidate.token_address} with {candidate.recommended_amount} SOL")
    
    try:
        # Check that trading should continue
        should_continue, reason, profit_rate = await should_continue_trading()
        
        if not should_continue:
            logger.warning(f"Skipping snipe due to trading pause: {reason}")
            return SnipeResult(
                candidate=candidate,
                success=False,
                transaction_hash=None,
                amount_spent=0.0,
                tokens_received=None,
                entry_price=None,
                error_message=f"Trading paused: {reason}",
                timestamp=time.time()
            )
        
        # Update profit rate in auto-sniper state
        _auto_sniper_state["recent_profit_rate"] = profit_rate
        
        # Execute the trade
        trade_result = await execute_trade(
            token_address=candidate.token_address,
            amount=candidate.recommended_amount,
            slippage=1.0  # Default slippage
        )
        
        if trade_result and trade_result.get("success", False):
            # Trade successful
            _auto_sniper_state["total_positions"] += 1
            _auto_sniper_state["total_capital_deployed"] += candidate.recommended_amount
            _auto_sniper_state["snipe_count"] += 1
            _auto_sniper_state["successful_snipes"] += 1
            
            result = SnipeResult(
                candidate=candidate,
                success=True,
                transaction_hash=trade_result.get("transaction_hash"),
                amount_spent=candidate.recommended_amount,
                tokens_received=trade_result.get("tokens_received"),
                entry_price=trade_result.get("price"),
                error_message=None,
                timestamp=time.time()
            )
        else:
            # Trade failed
            _auto_sniper_state["snipe_count"] += 1
            
            result = SnipeResult(
                candidate=candidate,
                success=False,
                transaction_hash=None,
                amount_spent=0.0,
                tokens_received=None,
                entry_price=None,
                error_message=trade_result.get("error", "Unknown error"),
                timestamp=time.time()
            )
    
    except Exception as e:
        logger.error(f"Error executing snipe for {candidate.token_address}: {e}")
        
        # Increment snipe count
        _auto_sniper_state["snipe_count"] += 1
        
        result = SnipeResult(
            candidate=candidate,
            success=False,
            transaction_hash=None,
            amount_spent=0.0,
            tokens_received=None,
            entry_price=None,
            error_message=str(e),
            timestamp=time.time()
        )
    
    # Add to recent snipes
    _recent_snipes.append(result)
    
    # Limit recent snipes to last 50
    if len(_recent_snipes) > 50:
        _recent_snipes.pop(0)
    
    return result


async def evaluate_and_snipe_token_from_group(
    token_address: str,
    group_id: str,
    message_text: str,
    mentions: int = 1
) -> Optional[SnipeResult]:
    """
    Evaluate and potentially snipe a token mentioned in a group.
    
    Args:
        token_address: The token address to evaluate
        group_id: The group ID where the token was mentioned
        message_text: Text of the message mentioning the token
        mentions: Number of times the token has been mentioned
        
    Returns:
        SnipeResult if the token was sniped, None otherwise
    """
    # Skip if auto-sniper is disabled
    if not _auto_sniper_state["enabled"]:
        logger.debug("Auto-sniper is disabled, skipping")
        return None
    
    # Skip if already processed
    if token_address in _processed_tokens:
        logger.debug(f"Token {token_address} already processed, skipping")
        return None
    
    try:
        # Analyze the message
        message_analysis = analyze_message(message_text, group_id)
        
        # Evaluate the token
        candidate = await evaluate_token_from_group(
            token_address=token_address,
            group_id=group_id,
            message_analysis=message_analysis,
            mentions=mentions,
            available_capital=_auto_sniper_state["available_capital"]
        )
        
        # If token meets criteria, execute snipe
        if candidate and candidate.score >= AUTO_SNIPE_THRESHOLD_SCORE:
            return await execute_snipe(candidate)
        
        # If token is promising but doesn't meet auto-snipe threshold, add to verification
        elif candidate and candidate.score >= 6.0:
            await add_verification_source(
                token_address=token_address,
                source_type="group",
                source_id=group_id,
                score=candidate.score
            )
        
        return None
    
    except Exception as e:
        logger.error(f"Error evaluating and sniping token {token_address} from group {group_id}: {e}")
        return None


async def check_and_execute_verified_tokens() -> List[SnipeResult]:
    """
    Check for verified tokens and execute snipes for eligible ones.
    
    Returns:
        List of SnipeResult objects for executed snipes
    """
    results = []
    
    # Skip if auto-sniper is disabled
    if not _auto_sniper_state["enabled"]:
        logger.debug("Auto-sniper is disabled, skipping")
        return results
    
    try:
        # Get verified tokens
        verified_tokens = await check_verified_tokens()
        
        for token_address in verified_tokens:
            # Skip if already processed
            if token_address in _processed_tokens:
                continue
            
            # Get verification data
            data = _pending_verification[token_address]
            
            # Calculate average score
            avg_score = sum(data["scores"]) / len(data["scores"])
            
            if avg_score >= AUTO_SNIPE_THRESHOLD_SCORE:
                logger.info(f"Auto-sniping verified token {token_address} with score {avg_score}")
                
                # Perform comprehensive token analysis
                token_analysis = await comprehensive_token_analysis(token_address)
                
                # Create a candidate
                candidate = SnipeCandidate(
                    token_address=token_address,
                    token_symbol=token_analysis.token_symbol,
                    network="solana",  # Default to Solana for now
                    source_type="multi",
                    source_id="verified",
                    score=avg_score,
                    safety_score=token_analysis.safety_analysis.safety_score,
                    social_proof_score=avg_score,
                    liquidity_score=token_analysis.liquidity_analysis.liquidity_score,
                    wallet_interest_score=5.0,  # Default
                    risk_level=token_analysis.risk_level,
                    confidence=0.8,  # High confidence for multi-verified tokens
                    position_size=0.1,  # Default
                    max_amount=1.0,  # Default
                    recommended_amount=AUTO_SNIPE_AMOUNT,
                    mentions=len(data["sources"]),
                    important_wallets=[],
                    verification_sources=data["sources"],
                    timestamp=time.time()
                )
                
                # Execute the snipe
                result = await execute_snipe(candidate)
                results.append(result)
                
                # Remove from pending verification
                del _pending_verification[token_address]
    
    except Exception as e:
        logger.error(f"Error checking verified tokens: {e}")
    
    return results


async def evaluate_and_snipe_from_wallets() -> List[SnipeResult]:
    """
    Check for tokens being accumulated by smart wallets and execute snipes.
    
    Returns:
        List of SnipeResult objects for executed snipes
    """
    results = []
    
    # Skip if auto-sniper is disabled
    if not _auto_sniper_state["enabled"]:
        logger.debug("Auto-sniper is disabled, skipping")
        return results
    
    try:
        # Find trading opportunities from wallet monitoring
        opportunities = await get_trading_opportunities()
        
        # Process each opportunity
        for opportunity in opportunities:
            token_address = opportunity["token_address"]
            
            # Skip if already processed
            if token_address in _processed_tokens:
                continue
            
            # Skip if opportunity score is too low
            if opportunity["opportunity_score"] < 7.5:
                logger.debug(f"Wallet opportunity score for {token_address} is too low: {opportunity['opportunity_score']}")
                continue
            
            # Evaluate the token
            candidate = await evaluate_token_from_wallet(
                token_address=token_address,
                wallet_addresses=opportunity["important_wallets"],
                opportunity_score=opportunity["opportunity_score"],
                available_capital=_auto_sniper_state["available_capital"]
            )
            
            # If token meets criteria, execute snipe
            if candidate and candidate.score >= AUTO_SNIPE_THRESHOLD_SCORE:
                result = await execute_snipe(candidate)
                results.append(result)
            
            # If token is promising but doesn't meet auto-snipe threshold, add to verification
            elif candidate and candidate.score >= 6.5:
                for wallet in opportunity["important_wallets"][:3]:
                    await add_verification_source(
                        token_address=token_address,
                        source_type="wallet",
                        source_id=wallet,
                        score=candidate.score
                    )
    
    except Exception as e:
        logger.error(f"Error evaluating tokens from wallets: {e}")
    
    return results


async def monitor_and_snipe_from_twitter(twitter_accounts: List[str]) -> List[SnipeResult]:
    """
    Monitor Twitter accounts for token mentions and execute snipes.
    
    Args:
        twitter_accounts: List of Twitter accounts to monitor
        
    Returns:
        List of SnipeResult objects for executed snipes
    """
    results = []
    
    # Skip if auto-sniper is disabled
    if not _auto_sniper_state["enabled"]:
        logger.debug("Auto-sniper is disabled, skipping")
        return results
    
    # In a real implementation, this would use the Twitter API
    # For now, we'll simulate finding tokens
    
    # Skip actual implementation since this is just a simulation
    
    return results


async def adjust_auto_sniper_state() -> None:
    """
    Adjust auto-sniper state based on performance and market conditions.
    """
    try:
        # Check if enough time has passed since last adjustment (hourly)
        if time.time() - _auto_sniper_state["last_performance_check"] < 3600:
            return
        
        logger.info("Adjusting auto-sniper state based on performance")
        
        # Check trading performance
        should_continue, reason, profit_rate = await should_continue_trading(lookback_hours=24)
        
        # Update state
        _auto_sniper_state["enabled"] = should_continue
        _auto_sniper_state["recent_profit_rate"] = profit_rate
        _auto_sniper_state["last_performance_check"] = time.time()
        
        # Log adjustment
        if should_continue:
            logger.info(f"Auto-sniper will continue trading: {reason}")
        else:
            logger.warning(f"Auto-sniper paused: {reason}")
        
        # Adjust threshold based on performance
        if profit_rate >= 30:
            # Doing well, can be slightly more aggressive
            new_threshold = max(6.5, AUTO_SNIPE_THRESHOLD_SCORE - 0.5)
            logger.info(f"Adjusting auto-snipe threshold to {new_threshold} due to good performance")
        elif profit_rate <= 0:
            # Not doing well, be more conservative
            new_threshold = min(8.0, AUTO_SNIPE_THRESHOLD_SCORE + 0.5)
            logger.info(f"Adjusting auto-snipe threshold to {new_threshold} due to poor performance")
        
        # Calculate success rate
        if _auto_sniper_state["snipe_count"] > 0:
            success_rate = _auto_sniper_state["successful_snipes"] / _auto_sniper_state["snipe_count"]
            logger.info(f"Auto-sniper success rate: {success_rate:.1%}")
    
    except Exception as e:
        logger.error(f"Error adjusting auto-sniper state: {e}")


async def run_auto_sniper_cycle() -> None:
    """
    Run a complete auto-sniper cycle.
    """
    try:
        logger.info("Running auto-sniper cycle")
        
        # Adjust state based on performance
        await adjust_auto_sniper_state()
        
        # Skip further processing if disabled
        if not _auto_sniper_state["enabled"]:
            logger.info("Auto-sniper is disabled, skipping cycle")
            return
        
        # Check verified tokens
        verified_results = await check_and_execute_verified_tokens()
        
        # Check wallet opportunities
        wallet_results = await evaluate_and_snipe_from_wallets()
        
        # Log results
        logger.info(f"Auto-sniper cycle completed: {len(verified_results)} verified snipes, {len(wallet_results)} wallet snipes")
    
    except Exception as e:
        logger.error(f"Error in auto-sniper cycle: {e}")


# Test functions
async def test_auto_sniper():
    # Simulate message from group
    group_id = "12345"
    message_text = """
    🚀🚀 JUST LAUNCHED: $GEM Token 🚀🚀
    
    💎 The next 100x gem has arrived! 💎
    
    Contract: EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v
    
    ✅ Liquidity locked for 1 year
    ✅ Contract verified and audited
    ✅ Strong team with previous successful projects
    
    📊 Chart: https://dextools.io/app/token/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v
    🌐 Website: https://gemtoken.io
    💬 Telegram: https://t.me/gemtoken
    
    DON'T MISS THIS OPPORTUNITY! We're going to the MOON!! 🚀🌙
    """
    
    # Test the evaluation
    result = await evaluate_and_snipe_token_from_group(
        token_address="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        group_id=group_id,
        message_text=message_text,
        mentions=3
    )
    
    if result:
        print(f"Snipe Result: {'Success' if result.success else 'Failed'}")
        if result.success:
            print(f"Transaction Hash: {result.transaction_hash}")
            print(f"Amount Spent: {result.amount_spent} SOL")
            print(f"Tokens Received: {result.tokens_received}")
            print(f"Entry Price: {result.entry_price}")
        else:
            print(f"Error: {result.error_message}")
    else:
        print("Token did not meet snipe criteria")
    
    # Test the auto-sniper cycle
    await run_auto_sniper_cycle()


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_auto_sniper())