"""
Advanced Trading Core for SMART MEMES BOT.

This module integrates all the advanced trading features:
1. Whale detection for early position entry
2. AI-powered market prediction for trend analysis and timing
3. Cross-DEX arbitrage for risk-free profits
4. Advanced token analysis and safety verification
5. Unified trade execution with multi-endpoint support
"""

import logging
import asyncio
import time
from typing import Dict, Any, List, Tuple, Optional
import json

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our advanced modules
from utils.whale_detector import whale_detector, start_whale_detector, stop_whale_detector
from utils.market_ai_predictor import market_predictor, start_market_predictor, stop_market_predictor
from utils.arbitrage_detector import arbitrage_detector, start_arbitrage_detector, stop_arbitrage_detector
from utils.token_analyzer import analyze_token
from utils.enhanced_solana_trade import execute_trade, check_token_safety, check_token_liquidity

# Database imports
from database import (
    session_scope, record_snipe_transaction, update_snipe_status,
    get_user_settings, update_user_settings
)

# Config imports
from config import (
    PERFORMANCE_TRACKING_ENABLED, AUTO_ADJUST_STRATEGY,
    AUTO_TRADE_ON_AI_SIGNAL, AI_SIGNAL_TRADE_AMOUNT,
    WHALE_AUTO_BUY_DEFAULT, WHALE_DEFAULT_BUY_AMOUNT,
    AUTO_EXECUTE_ARBITRAGE
)

class AdvancedTradingCore:
    """Core trading engine that integrates all advanced features"""
    
    def __init__(self):
        """Initialize the advanced trading core"""
        self.running = False
        self.task = None
        self.performance_metrics = {}
    
    async def start(self):
        """Start all advanced trading subsystems"""
        if self.running:
            logger.warning("Advanced trading core already running")
            return
            
        self.running = True
        
        # Start all subsystems
        logger.info("Starting advanced trading subsystems...")
        
        # Start whale detector
        await start_whale_detector()
        
        # Start market predictor
        await start_market_predictor()
        
        # Start arbitrage detector
        await start_arbitrage_detector()
        
        # Start performance monitoring task
        if PERFORMANCE_TRACKING_ENABLED:
            self.task = asyncio.create_task(self._monitor_performance())
        
        logger.info("Advanced trading core started")
    
    async def stop(self):
        """Stop all advanced trading subsystems"""
        if not self.running:
            return
            
        self.running = False
        
        # Stop all subsystems
        logger.info("Stopping advanced trading subsystems...")
        
        # Stop performance monitoring task
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
        
        # Stop whale detector
        await stop_whale_detector()
        
        # Stop market predictor
        await stop_market_predictor()
        
        # Stop arbitrage detector
        await stop_arbitrage_detector()
        
        logger.info("Advanced trading core stopped")
    
    async def _monitor_performance(self):
        """Monitor trading performance and adjust strategies as needed"""
        try:
            while self.running:
                try:
                    # Analyze recent trading performance
                    if AUTO_ADJUST_STRATEGY:
                        await self._analyze_and_adjust_strategies()
                    
                    # Wait before next analysis
                    await asyncio.sleep(3600)  # Check every hour
                    
                except Exception as e:
                    logger.error(f"Error in performance monitoring: {e}")
                    await asyncio.sleep(60)  # Shorter wait on error
                
        except asyncio.CancelledError:
            logger.info("Performance monitoring task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in performance monitoring: {e}")
            self.running = False
    
    async def _analyze_and_adjust_strategies(self):
        """Analyze trading performance and adapt strategies"""
        try:
            # Get recent transactions from database
            with session_scope() as session:
                # This would query recent trades and their performance
                recent_trades = session.query("SELECT * FROM snipe_transactions ORDER BY timestamp DESC LIMIT 100").all()
                
                # Calculate performance metrics
                profit_trades = 0
                loss_trades = 0
                total_profit = 0
                total_loss = 0
                
                for trade in recent_trades:
                    if trade.profit_loss is not None:
                        if trade.profit_loss >= 0:
                            profit_trades += 1
                            total_profit += trade.profit_loss
                        else:
                            loss_trades += 1
                            total_loss += abs(trade.profit_loss)
                
                total_trades = profit_trades + loss_trades
                if total_trades == 0:
                    return
                
                # Calculate metrics
                win_rate = profit_trades / total_trades if total_trades > 0 else 0
                avg_profit = total_profit / profit_trades if profit_trades > 0 else 0
                avg_loss = total_loss / loss_trades if loss_trades > 0 else 0
                profit_factor = total_profit / total_loss if total_loss > 0 else 0
                
                # Store metrics
                self.performance_metrics = {
                    "win_rate": win_rate,
                    "avg_profit": avg_profit,
                    "avg_loss": avg_loss,
                    "profit_factor": profit_factor,
                    "total_trades": total_trades
                }
                
                # Adjust strategies based on performance
                # This is highly simplified - a real implementation would be more sophisticated
                
                # Example adjustment: If win rate is below 40%, increase safety threshold
                if win_rate < 0.4 and total_trades >= 10:
                    logger.info("Adjusting strategy: Increasing safety threshold due to low win rate")
                    # Update safety thresholds in user settings
                    
                # Example adjustment: If profit factor is above 2, slightly increase position sizes
                if profit_factor > 2 and total_trades >= 20:
                    logger.info("Adjusting strategy: Increasing position sizes due to high profit factor")
                    # Update position sizing in user settings
                
        except Exception as e:
            logger.error(f"Error analyzing and adjusting strategies: {e}")
    
    async def execute_advanced_trade(
        self, 
        token_address: str, 
        amount: float,
        user_id: int = 0,
        slippage: float = 0.5,
        auto_sell: Optional[float] = None,
        stop_loss: Optional[float] = None,
        transaction_type: str = "manual"
    ) -> Dict[str, Any]:
        """
        Execute a trade with advanced safety checks and tracking
        
        Args:
            token_address: Token address to trade
            amount: Amount in SOL to spend
            user_id: User ID for tracking (0 for system)
            slippage: Slippage tolerance percentage
            auto_sell: Auto-sell profit percentage (e.g., 200 for 2x)
            stop_loss: Stop-loss percentage (e.g., 50 for 50% loss)
            transaction_type: Type of transaction (manual, auto, etc.)
            
        Returns:
            Transaction result details
        """
        try:
            # Step 1: Record transaction as pending
            transaction_id = record_snipe_transaction(
                telegram_id=user_id,
                token_address=token_address,
                amount_spent=float(amount),
                status="pending",
                slippage=slippage,
                is_auto=(transaction_type != "manual")
            )
            
            # Step 2: Get token information and do advanced safety checks
            safety_score, safety_summary, token_data = await analyze_token(token_address)
            
            # Check if token passes safety threshold
            if safety_score < 3:  # Critical safety issues
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="failed",
                    error_message=f"Token safety check failed (score: {safety_score}/10). {safety_summary}"
                )
                
                return {
                    "success": False,
                    "error": f"Token safety check failed (score: {safety_score}/10)",
                    "safety_summary": safety_summary,
                    "transaction_id": transaction_id
                }
            
            # Step 3: Check liquidity
            has_liquidity, liquidity_amount, liquidity_message = await check_token_liquidity(token_address)
            
            if not has_liquidity:
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="failed",
                    error_message=f"Insufficient liquidity: {liquidity_message}"
                )
                
                return {
                    "success": False,
                    "error": f"Insufficient liquidity: {liquidity_message}",
                    "transaction_id": transaction_id
                }
            
            # Step 4: Check market prediction for timing (informational only)
            prediction = None
            try:
                prediction = await market_predictor.predict_price_movement(token_address, "24h")
            except Exception as pred_error:
                logger.error(f"Error getting price prediction: {pred_error}")
            
            # Step 5: Execute the trade
            trade_result = await execute_trade(token_address, amount, slippage)
            
            # Step 6: Handle the trade result
            if trade_result.get("success"):
                # Extract information from the result
                tx_hash = trade_result.get("transaction_hash", "Unknown")
                tokens_received = trade_result.get("tokens_received", 0)
                entry_price = trade_result.get("price_per_token", 0)
                
                # Update transaction in database
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="completed",
                    tx_hash=tx_hash,
                    tokens_received=tokens_received,
                    current_price=entry_price
                )
                
                # Extract token name
                token_name = token_data.get("name") or token_data.get("symbol") or token_address[:10] + "..."
                
                # Build response with advanced insights
                response = {
                    "success": True,
                    "transaction_id": transaction_id,
                    "token_address": token_address,
                    "token_name": token_name,
                    "amount_spent": amount,
                    "tokens_received": tokens_received,
                    "entry_price": entry_price,
                    "transaction_hash": tx_hash,
                    "safety_score": safety_score,
                    "liquidity": liquidity_amount
                }
                
                # Add AI prediction if available
                if prediction and prediction.get("success"):
                    response["prediction"] = {
                        "direction": prediction.get("direction"),
                        "predicted_change_percent": prediction.get("predicted_change_percent"),
                        "confidence": prediction.get("confidence")
                    }
                
                # Add profit protection settings if configured
                if auto_sell is not None:
                    response["auto_sell"] = {
                        "percent": auto_sell,
                        "target_price": entry_price * (auto_sell / 100)
                    }
                
                if stop_loss is not None:
                    response["stop_loss"] = {
                        "percent": stop_loss,
                        "trigger_price": entry_price * ((100 - stop_loss) / 100)
                    }
                
                # Add any warnings
                if safety_score < 7:
                    response["warnings"] = token_data.get("warnings", [])
                
                return response
            else:
                # Trade failed
                error_message = trade_result.get("error", "Unknown error")
                
                # Update transaction in database
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="failed",
                    error_message=error_message
                )
                
                return {
                    "success": False,
                    "error": error_message,
                    "transaction_id": transaction_id
                }
            
        except Exception as e:
            logger.error(f"Error in advanced trade execution: {e}")
            
            # Update transaction if it was created
            if 'transaction_id' in locals() and transaction_id:
                try:
                    update_snipe_status(
                        snipe_id=transaction_id,
                        status="failed",
                        error_message=str(e)
                    )
                except Exception as update_error:
                    logger.error(f"Error updating transaction: {update_error}")
            
            return {
                "success": False,
                "error": f"Trade execution failed: {str(e)}"
            }
    
    async def get_ai_trading_signals(self, include_low_confidence: bool = False) -> List[Dict[str, Any]]:
        """
        Get current AI trading signals for tracked tokens
        
        Args:
            include_low_confidence: Whether to include low confidence predictions
            
        Returns:
            List of trading signals
        """
        try:
            # This would typically get tracked tokens from the database
            # and run predictions on them
            
            # For now, we'll return a placeholder
            return []
            
        except Exception as e:
            logger.error(f"Error getting AI trading signals: {e}")
            return []

# Create global instance
trading_core = AdvancedTradingCore()

# API functions
async def start_trading_core():
    """Start the advanced trading core"""
    await trading_core.start()

async def stop_trading_core():
    """Stop the advanced trading core"""
    await trading_core.stop()

async def execute_smart_trade(
    token_address: str, 
    amount: float,
    user_id: int = 0,
    slippage: float = 0.5,
    auto_sell: Optional[float] = None,
    stop_loss: Optional[float] = None,
    transaction_type: str = "manual"
) -> Dict[str, Any]:
    """
    Execute a trade with all advanced features
    
    Args:
        token_address: Token address to trade
        amount: Amount in SOL to spend
        user_id: User ID for tracking (0 for system)
        slippage: Slippage tolerance percentage
        auto_sell: Auto-sell profit percentage
        stop_loss: Stop-loss percentage
        transaction_type: Type of transaction
        
    Returns:
        Transaction result details
    """
    return await trading_core.execute_advanced_trade(
        token_address=token_address,
        amount=amount,
        user_id=user_id,
        slippage=slippage,
        auto_sell=auto_sell,
        stop_loss=stop_loss,
        transaction_type=transaction_type
    )

async def get_performance_metrics() -> Dict[str, Any]:
    """Get current trading performance metrics"""
    return trading_core.performance_metrics