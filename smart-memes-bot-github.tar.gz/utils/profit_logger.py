"""
Profit Logger Module for SMART MEMES BOT.

This module handles profit tracking and logging for all trading activities,
including token snipes, manual trades, and automated trading strategies.
"""

import os
import time
import json
import logging
import datetime
from typing import Dict, Any, List, Optional, Tuple, Union
from decimal import Decimal

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Import database functionality
try:
    from database import db
    DATABASE_AVAILABLE = True
    logger.info("Database functionality available for profit logging")
except ImportError:
    DATABASE_AVAILABLE = False
    logger.warning("Database functionality not available for profit logging")

class ProfitLogger:
    """Class for logging and tracking profits from various trading strategies."""
    
    def __init__(self):
        """Initialize the profit logger."""
        self.profit_history = []
        self.active_trades = {}
        self.total_profit = Decimal('0.0')
        self.total_trades = 0
        self.successful_trades = 0
        
        # Load history from database if available
        if DATABASE_AVAILABLE:
            self._load_from_database()
    
    def _load_from_database(self):
        """Load profit history from database."""
        try:
            if DATABASE_AVAILABLE:
                from models import ProfitRecord, Trade
                
                # Get all profit records
                profit_records = ProfitRecord.query.all()
                
                # Convert to dictionary format
                for record in profit_records:
                    profit_entry = {
                        'id': record.id,
                        'token_address': record.token_address,
                        'token_symbol': record.token_symbol,
                        'entry_price': float(record.entry_price),
                        'exit_price': float(record.exit_price),
                        'amount': float(record.amount),
                        'profit': float(record.profit),
                        'profit_percentage': float(record.profit_percentage),
                        'duration_seconds': record.duration_seconds,
                        'timestamp': record.timestamp.timestamp() if record.timestamp else time.time()
                    }
                    self.profit_history.append(profit_entry)
                
                # Calculate totals
                self.total_profit = sum(Decimal(str(entry['profit'])) for entry in self.profit_history)
                self.total_trades = len(self.profit_history)
                self.successful_trades = sum(1 for entry in self.profit_history if Decimal(str(entry['profit'])) > 0)
                
                logger.info(f"Loaded {len(profit_records)} profit records from database")
        
        except Exception as e:
            logger.error(f"Error loading profit history from database: {e}")
    
    def record_snipe(self, token_address: str, token_symbol: str, source: str, 
                    entry_price: float, amount: float) -> int:
        """
        Record a token snipe.
        
        Args:
            token_address: Token address
            token_symbol: Token symbol
            source: Source of the snipe (e.g., 'telegram', 'manual', etc.)
            entry_price: Entry price
            amount: Amount of tokens
            
        Returns:
            Snipe ID
        """
        try:
            snipe_id = len(self.active_trades) + 1
            
            # Record in database if available
            if DATABASE_AVAILABLE:
                try:
                    from models import TokenSnipe, TokenInfo
                    
                    # Check if token exists in database
                    token = TokenInfo.query.filter_by(address=token_address).first()
                    if not token:
                        token = TokenInfo(
                            address=token_address,
                            symbol=token_symbol,
                            created_at=datetime.datetime.utcnow()
                        )
                        db.session.add(token)
                    
                    # Create snipe record
                    snipe = TokenSnipe(
                        token_address=token_address,
                        token_symbol=token_symbol,
                        source=source,
                        entry_price=entry_price,
                        amount=amount,
                        timestamp=datetime.datetime.utcnow(),
                        success=True
                    )
                    db.session.add(snipe)
                    db.session.commit()
                    
                    snipe_id = snipe.id
                    logger.info(f"Recorded snipe in database: {token_symbol} (ID: {snipe_id})")
                
                except Exception as e:
                    logger.error(f"Error recording snipe in database: {e}")
                    if 'db' in locals():
                        db.session.rollback()
            
            # Record in memory
            timestamp = time.time()
            self.active_trades[snipe_id] = {
                'token_address': token_address,
                'token_symbol': token_symbol,
                'source': source,
                'entry_price': entry_price,
                'amount': amount,
                'entry_time': timestamp
            }
            
            logger.info(f"Recorded snipe: {token_symbol} at {entry_price}")
            return snipe_id
        
        except Exception as e:
            logger.error(f"Error recording snipe: {e}")
            return -1
    
    def record_profit(self, trade_id: int, exit_price: float, profit: float, 
                     profit_percentage: float) -> bool:
        """
        Record profit from a completed trade.
        
        Args:
            trade_id: Trade ID
            exit_price: Exit price
            profit: Profit amount
            profit_percentage: Profit percentage
            
        Returns:
            Success status
        """
        try:
            # Get trade details
            if trade_id not in self.active_trades:
                logger.error(f"Trade ID {trade_id} not found in active trades")
                return False
            
            trade = self.active_trades[trade_id]
            token_address = trade['token_address']
            token_symbol = trade['token_symbol']
            entry_price = trade['entry_price']
            amount = trade['amount']
            entry_time = trade['entry_time']
            
            # Calculate duration
            exit_time = time.time()
            duration_seconds = exit_time - entry_time
            
            # Record in database if available
            if DATABASE_AVAILABLE:
                try:
                    from models import ProfitRecord
                    
                    # Create profit record
                    profit_record = ProfitRecord(
                        token_address=token_address,
                        token_symbol=token_symbol,
                        entry_price=entry_price,
                        exit_price=exit_price,
                        amount=amount,
                        profit=profit,
                        profit_percentage=profit_percentage,
                        duration_seconds=duration_seconds,
                        timestamp=datetime.datetime.utcnow()
                    )
                    db.session.add(profit_record)
                    db.session.commit()
                    
                    logger.info(f"Recorded profit in database: {token_symbol} - {profit_percentage:.2f}%")
                
                except Exception as e:
                    logger.error(f"Error recording profit in database: {e}")
                    if 'db' in locals():
                        db.session.rollback()
            
            # Record in memory
            profit_entry = {
                'token_address': token_address,
                'token_symbol': token_symbol,
                'entry_price': entry_price,
                'exit_price': exit_price,
                'amount': amount,
                'profit': profit,
                'profit_percentage': profit_percentage,
                'duration_seconds': duration_seconds,
                'timestamp': exit_time
            }
            self.profit_history.append(profit_entry)
            
            # Update statistics
            self.total_profit += Decimal(str(profit))
            self.total_trades += 1
            if profit > 0:
                self.successful_trades += 1
            
            # Remove from active trades
            del self.active_trades[trade_id]
            
            logger.info(f"Recorded profit: {token_symbol} - {profit_percentage:.2f}%")
            return True
        
        except Exception as e:
            logger.error(f"Error recording profit: {e}")
            return False
    
    def record_wallet_activity(self, wallet_address: str, token_address: str, token_symbol: str,
                              activity_type: str, amount: float) -> bool:
        """
        Record wallet activity.
        
        Args:
            wallet_address: Wallet address
            token_address: Token address
            token_symbol: Token symbol
            activity_type: Activity type (e.g., 'buy', 'sell', etc.)
            amount: Amount of tokens
            
        Returns:
            Success status
        """
        try:
            # Record in database if available
            if DATABASE_AVAILABLE:
                try:
                    from models import WalletActivity
                    
                    # Create wallet activity record
                    activity = WalletActivity(
                        wallet_address=wallet_address,
                        token_address=token_address,
                        token_symbol=token_symbol,
                        activity_type=activity_type,
                        amount=amount,
                        timestamp=datetime.datetime.utcnow(),
                        success=True
                    )
                    db.session.add(activity)
                    db.session.commit()
                    
                    logger.info(f"Recorded wallet activity in database: {wallet_address[:10]}... - {activity_type} - {token_symbol}")
                
                except Exception as e:
                    logger.error(f"Error recording wallet activity in database: {e}")
                    if 'db' in locals():
                        db.session.rollback()
                    return False
            
            logger.info(f"Recorded wallet activity: {wallet_address[:10]}... - {activity_type} - {token_symbol}")
            return True
        
        except Exception as e:
            logger.error(f"Error recording wallet activity: {e}")
            return False
    
    def get_profit_statistics(self) -> Dict[str, Any]:
        """
        Get profit statistics.
        
        Returns:
            Dictionary of profit statistics
        """
        try:
            # Calculate statistics
            total_profit = float(self.total_profit)
            total_trades = self.total_trades
            successful_trades = self.successful_trades
            success_rate = (successful_trades / total_trades) * 100 if total_trades > 0 else 0
            
            # Get top trades
            top_trades = sorted(self.profit_history, key=lambda x: x['profit_percentage'], reverse=True)[:5]
            
            # Calculate average profit percentage
            average_profit = sum(entry['profit_percentage'] for entry in self.profit_history) / len(self.profit_history) if self.profit_history else 0
            
            # Calculate daily, weekly, and monthly profits
            now = time.time()
            day_ago = now - (24 * 60 * 60)
            week_ago = now - (7 * 24 * 60 * 60)
            month_ago = now - (30 * 24 * 60 * 60)
            
            daily_profit = sum(float(entry['profit']) for entry in self.profit_history if entry['timestamp'] >= day_ago)
            weekly_profit = sum(float(entry['profit']) for entry in self.profit_history if entry['timestamp'] >= week_ago)
            monthly_profit = sum(float(entry['profit']) for entry in self.profit_history if entry['timestamp'] >= month_ago)
            
            # If database available, get from database for accuracy
            if DATABASE_AVAILABLE:
                try:
                    from models import ProfitRecord
                    from sqlalchemy import func
                    from datetime import datetime, timedelta
                    
                    # Get profits from database
                    now_dt = datetime.utcnow()
                    day_ago_dt = now_dt - timedelta(days=1)
                    week_ago_dt = now_dt - timedelta(days=7)
                    month_ago_dt = now_dt - timedelta(days=30)
                    
                    # Get daily, weekly, and monthly profits
                    daily_profit_result = db.session.query(func.sum(ProfitRecord.profit)).filter(ProfitRecord.timestamp >= day_ago_dt).first()
                    weekly_profit_result = db.session.query(func.sum(ProfitRecord.profit)).filter(ProfitRecord.timestamp >= week_ago_dt).first()
                    monthly_profit_result = db.session.query(func.sum(ProfitRecord.profit)).filter(ProfitRecord.timestamp >= month_ago_dt).first()
                    
                    daily_profit = daily_profit_result[0] if daily_profit_result[0] is not None else 0
                    weekly_profit = weekly_profit_result[0] if weekly_profit_result[0] is not None else 0
                    monthly_profit = monthly_profit_result[0] if monthly_profit_result[0] is not None else 0
                
                except Exception as e:
                    logger.error(f"Error getting profits from database: {e}")
            
            # Return statistics
            return {
                'total_profit': total_profit,
                'total_trades': total_trades,
                'successful_trades': successful_trades,
                'success_rate': success_rate,
                'average_profit': average_profit,
                'daily_profit': daily_profit,
                'weekly_profit': weekly_profit,
                'monthly_profit': monthly_profit,
                'top_trades': top_trades,
                'active_trades': len(self.active_trades)
            }
        
        except Exception as e:
            logger.error(f"Error getting profit statistics: {e}")
            return {
                'total_profit': 0,
                'total_trades': 0,
                'successful_trades': 0,
                'success_rate': 0,
                'average_profit': 0,
                'daily_profit': 0,
                'weekly_profit': 0,
                'monthly_profit': 0,
                'top_trades': [],
                'active_trades': 0
            }
    
    def get_top_tokens(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get top performing tokens.
        
        Args:
            limit: Maximum number of tokens to return
            
        Returns:
            List of top performing tokens
        """
        try:
            # Group by token address
            token_profits = {}
            for entry in self.profit_history:
                token_address = entry['token_address']
                token_symbol = entry['token_symbol']
                profit = entry['profit']
                profit_percentage = entry['profit_percentage']
                
                if token_address not in token_profits:
                    token_profits[token_address] = {
                        'token_address': token_address,
                        'token_symbol': token_symbol,
                        'total_profit': profit,
                        'total_trades': 1,
                        'successful_trades': 1 if profit > 0 else 0,
                        'average_profit_percentage': profit_percentage
                    }
                else:
                    token_profit = token_profits[token_address]
                    token_profit['total_profit'] += profit
                    token_profit['total_trades'] += 1
                    token_profit['successful_trades'] += 1 if profit > 0 else 0
                    token_profit['average_profit_percentage'] = (token_profit['average_profit_percentage'] + profit_percentage) / 2
            
            # Convert to list and sort
            top_tokens = list(token_profits.values())
            top_tokens.sort(key=lambda x: x['total_profit'], reverse=True)
            
            # Limit results
            top_tokens = top_tokens[:limit]
            
            # If database available, get from database for accuracy
            if DATABASE_AVAILABLE:
                try:
                    from models import ProfitRecord
                    from sqlalchemy import func
                    
                    # Get top tokens from database
                    top_tokens_query = db.session.query(
                        ProfitRecord.token_address,
                        ProfitRecord.token_symbol,
                        func.sum(ProfitRecord.profit).label('total_profit'),
                        func.count(ProfitRecord.id).label('total_trades'),
                        func.avg(ProfitRecord.profit_percentage).label('average_profit_percentage')
                    ).group_by(
                        ProfitRecord.token_address,
                        ProfitRecord.token_symbol
                    ).order_by(
                        func.sum(ProfitRecord.profit).desc()
                    ).limit(limit).all()
                    
                    top_tokens = [
                        {
                            'token_address': token[0],
                            'token_symbol': token[1],
                            'total_profit': float(token[2]),
                            'total_trades': int(token[3]),
                            'average_profit_percentage': float(token[4])
                        }
                        for token in top_tokens_query
                    ]
                    
                    # Get successful trades
                    for token in top_tokens:
                        successful_trades_count = db.session.query(
                            func.count(ProfitRecord.id)
                        ).filter(
                            ProfitRecord.token_address == token['token_address'],
                            ProfitRecord.profit > 0
                        ).scalar()
                        token['successful_trades'] = successful_trades_count
                
                except Exception as e:
                    logger.error(f"Error getting top tokens from database: {e}")
            
            return top_tokens
        
        except Exception as e:
            logger.error(f"Error getting top tokens: {e}")
            return []
    
    def get_profit_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get profit history.
        
        Args:
            limit: Maximum number of entries to return
            
        Returns:
            List of profit history entries
        """
        try:
            # Sort by timestamp
            sorted_history = sorted(self.profit_history, key=lambda x: x['timestamp'], reverse=True)
            
            # Limit results
            return sorted_history[:limit]
        
        except Exception as e:
            logger.error(f"Error getting profit history: {e}")
            return []
    
    def get_active_trades(self) -> Dict[int, Dict[str, Any]]:
        """
        Get active trades.
        
        Returns:
            Dictionary of active trades
        """
        return self.active_trades
    
    def export_profit_history(self, file_path: str) -> bool:
        """
        Export profit history to a file.
        
        Args:
            file_path: File path
            
        Returns:
            Success status
        """
        try:
            with open(file_path, 'w') as f:
                json.dump(self.profit_history, f, indent=2)
            
            logger.info(f"Exported profit history to {file_path}")
            return True
        
        except Exception as e:
            logger.error(f"Error exporting profit history: {e}")
            return False

# Create a global instance
profit_logger = ProfitLogger()

if __name__ == "__main__":
    # Test the profit logger
    snipe_id = profit_logger.record_snipe(
        token_address="0x1234567890abcdef1234567890abcdef12345678",
        token_symbol="TEST",
        source="manual",
        entry_price=1.0,
        amount=100.0
    )
    
    profit_logger.record_profit(
        trade_id=snipe_id,
        exit_price=1.5,
        profit=50.0,
        profit_percentage=50.0
    )
    
    stats = profit_logger.get_profit_statistics()
    print(f"Profit Statistics: {json.dumps(stats, indent=2)}")