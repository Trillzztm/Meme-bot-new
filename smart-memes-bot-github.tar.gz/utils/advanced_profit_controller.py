"""
Advanced Profit Controller for SMART MEMES BOT.

This module provides a centralized controller for managing all advanced
profit-generation systems, including Flash Loan Arbitrage, MEV Optimization,
Enhanced Token Safety, Twitter Signal Enhancement, and AI-Enhanced Trading.

It acts as the coordinator for the Ultimate Pro profit system, managing
risk profiles, capital allocation, and strategy execution.
"""

import os
import json
import time
import asyncio
import logging
import datetime
from typing import Dict, List, Tuple, Optional, Union, Any

# Import profit strategies
try:
    from utils.flash_loan_arbitrage import (
        get_arbitrage_engine, start_arbitrage_monitoring,
        stop_arbitrage_monitoring, get_arbitrage_statistics
    )
    ARBITRAGE_AVAILABLE = True
except ImportError:
    ARBITRAGE_AVAILABLE = False
    logging.warning("Flash loan arbitrage not available")

try:
    from utils.mev_optimizer import (
        get_mev_optimizer, protect_transaction,
        create_mev_bundle, get_mev_statistics
    )
    MEV_AVAILABLE = True
except ImportError:
    MEV_AVAILABLE = False
    logging.warning("MEV optimization not available")

try:
    from utils.enhanced_token_safety import (
        analyze_token_safety, get_safety_recommendation
    )
    ENHANCED_SAFETY_AVAILABLE = True
except ImportError:
    ENHANCED_SAFETY_AVAILABLE = False
    logging.warning("Enhanced token safety not available")

try:
    from utils.twitter_signal_enhancement import (
        start_twitter_monitoring, stop_twitter_monitoring,
        get_recent_signals, record_signal_performance
    )
    TWITTER_ENHANCEMENT_AVAILABLE = True
except ImportError:
    TWITTER_ENHANCEMENT_AVAILABLE = False
    logging.warning("Twitter signal enhancement not available")

try:
    from ai.trade_parameter_optimizer import (
        optimize_trade_parameters, record_transaction_result
    )
    TRADE_OPTIMIZER_AVAILABLE = True
except ImportError:
    TRADE_OPTIMIZER_AVAILABLE = False
    logging.warning("AI trade parameter optimizer not available")

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Constants
CONFIG_FILE = "data/config/advanced_profit_config.json"
DEFAULT_CONFIG = {
    "risk_profile": "balanced",  # conservative, balanced, aggressive
    "max_capital_allocation": 2.0,  # SOL
    "auto_compound": True,
    "reinvest_percentage": 50,  # 50% of profits reinvested
    "strategies": {
        "flash_loan_arbitrage": {
            "enabled": True,
            "weight": 1.0,
            "description": "Risk-free arbitrage using flash loans"
        },
        "mev_optimization": {
            "enabled": True,
            "weight": 0.8,
            "description": "Extract value from transaction ordering"
        },
        "signal_based_trading": {
            "enabled": True,
            "weight": 0.7,
            "description": "Trade based on enhanced social signals"
        },
        "smart_parameter_trading": {
            "enabled": True,
            "weight": 0.9,
            "description": "Trade with AI-optimized parameters"
        }
    },
    "capital_allocation": {
        "flash_loan_arbitrage": 0.3,  # 30% of capital
        "mev_optimization": 0.3,  # 30% of capital
        "signal_based_trading": 0.2,  # 20% of capital
        "smart_parameter_trading": 0.2  # 20% of capital
    }
}

# Risk profiles
RISK_PROFILES = {
    "conservative": {
        "max_position_size": 0.1,  # SOL
        "max_positions": 5,
        "auto_confirm_threshold": 0.8,  # Only auto-confirm high-confidence trades
        "stop_loss": 0.1,  # 10% stop loss
        "take_profit": 0.2,  # 20% take profit
        "safety_threshold": 80,  # Minimum safety score to trade
    },
    "balanced": {
        "max_position_size": 0.2,  # SOL
        "max_positions": 10,
        "auto_confirm_threshold": 0.7,  # Auto-confirm medium-high confidence trades
        "stop_loss": 0.15,  # 15% stop loss
        "take_profit": 0.3,  # 30% take profit
        "safety_threshold": 70,  # Minimum safety score to trade
    },
    "aggressive": {
        "max_position_size": 0.4,  # SOL
        "max_positions": 15,
        "auto_confirm_threshold": 0.6,  # Auto-confirm medium confidence trades
        "stop_loss": 0.2,  # 20% stop loss
        "take_profit": 0.5,  # 50% take profit
        "safety_threshold": 60,  # Minimum safety score to trade
    }
}

class AdvancedProfitController:
    """
    Central controller for all advanced profit-generation systems.
    """
    
    def __init__(self):
        """Initialize the controller."""
        self.running = False
        self.config = self._load_config()
        self.active_trades = {}
        self.trade_history = []
        self.stats_cache = {}
        self.last_stats_update = 0
        
        # Create needed directories
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Load configuration from file or initialize with defaults.
        
        Returns:
            Configuration dictionary
        """
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded advanced profit configuration")
                return config
            else:
                # Create default config
                with open(CONFIG_FILE, 'w') as f:
                    json.dump(DEFAULT_CONFIG, f, indent=2)
                logger.info("Created default advanced profit configuration")
                return DEFAULT_CONFIG
        except Exception as e:
            logger.error(f"Error loading profit configuration: {e}")
            return DEFAULT_CONFIG.copy()
    
    def _save_config(self):
        """Save configuration to file."""
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving profit configuration: {e}")
    
    async def start(self) -> bool:
        """
        Start all enabled profit systems.
        
        Returns:
            Success status
        """
        if self.running:
            logger.warning("Advanced profit systems already running")
            return True
        
        logger.info("Starting advanced profit systems")
        
        try:
            # Start arbitrage system if enabled
            if (ARBITRAGE_AVAILABLE and 
                self.config["strategies"]["flash_loan_arbitrage"]["enabled"]):
                await start_arbitrage_monitoring()
                logger.info("Flash loan arbitrage monitoring started")
            
            # Start Twitter signal monitoring if enabled
            if (TWITTER_ENHANCEMENT_AVAILABLE and 
                self.config["strategies"]["signal_based_trading"]["enabled"]):
                await start_twitter_monitoring()
                logger.info("Twitter signal enhancement started")
            
            # Mark as running
            self.running = True
            
            # Start the background monitoring task
            self._monitoring_task = asyncio.create_task(self._monitor_opportunities())
            
            logger.info("All advanced profit systems started successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error starting profit systems: {e}")
            # Attempt to clean up
            await self.stop()
            return False
    
    async def stop(self) -> bool:
        """
        Stop all profit systems.
        
        Returns:
            Success status
        """
        if not self.running:
            logger.warning("Advanced profit systems not running")
            return True
        
        logger.info("Stopping advanced profit systems")
        
        try:
            # Stop arbitrage system if it was started
            if ARBITRAGE_AVAILABLE:
                await stop_arbitrage_monitoring()
                logger.info("Flash loan arbitrage monitoring stopped")
            
            # Stop Twitter signal monitoring if it was started
            if TWITTER_ENHANCEMENT_AVAILABLE:
                await stop_twitter_monitoring()
                logger.info("Twitter signal enhancement stopped")
            
            # Cancel the monitoring task
            if hasattr(self, '_monitoring_task'):
                self._monitoring_task.cancel()
                try:
                    await self._monitoring_task
                except asyncio.CancelledError:
                    pass
            
            # Mark as not running
            self.running = False
            
            logger.info("All advanced profit systems stopped successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error stopping profit systems: {e}")
            return False
    
    async def _monitor_opportunities(self):
        """Background task to monitor for profit opportunities."""
        try:
            while self.running:
                logger.debug("Checking for profit opportunities")
                
                # Monitor for various opportunities
                try:
                    # Flash loan arbitrage opportunities
                    if (ARBITRAGE_AVAILABLE and 
                        self.config["strategies"]["flash_loan_arbitrage"]["enabled"]):
                        # Arbitrage monitoring is handled by its own background process
                        pass
                    
                    # Twitter signal-based opportunities
                    if (TWITTER_ENHANCEMENT_AVAILABLE and 
                        self.config["strategies"]["signal_based_trading"]["enabled"]):
                        await self._check_twitter_signals()
                    
                    # Update stats cache occasionally
                    if time.time() - self.last_stats_update > 3600:  # Once per hour
                        await self._update_stats_cache()
                    
                except Exception as e:
                    logger.error(f"Error in opportunity monitoring: {e}")
                
                # Wait before next check
                await asyncio.sleep(60)  # Check every minute
                
        except asyncio.CancelledError:
            logger.info("Opportunity monitoring cancelled")
            raise
        
        except Exception as e:
            logger.error(f"Unexpected error in opportunity monitoring: {e}")
            raise
    
    async def _check_twitter_signals(self):
        """Check for actionable Twitter signals."""
        if not TWITTER_ENHANCEMENT_AVAILABLE:
            return
        
        try:
            # Get risk profile settings
            risk_profile = self.config["risk_profile"]
            risk_settings = RISK_PROFILES[risk_profile]
            
            # Get recent high-confidence signals
            signals = await get_recent_signals(
                min_confidence=risk_settings["auto_confirm_threshold"]
            )
            
            for signal in signals:
                # Skip if not a buy signal
                if signal["trading_action"] != "buy":
                    continue
                
                token_address = signal["token_address"]
                
                # Skip if we already have an active trade for this token
                if token_address in self.active_trades:
                    continue
                
                # Check token safety
                if ENHANCED_SAFETY_AVAILABLE:
                    safety_score, safety_details = await analyze_token_safety(token_address)
                    
                    if safety_score < risk_settings["safety_threshold"]:
                        logger.info(f"Skipping token {token_address} due to low safety score: {safety_score}")
                        continue
                
                # Determine position size
                capital_allocation = self.config["capital_allocation"]["signal_based_trading"]
                max_capital = float(self.config["max_capital_allocation"])
                available_capital = max_capital * capital_allocation
                
                confidence = signal["confidence"]
                
                # Scale position size based on confidence
                position_size = min(
                    risk_settings["max_position_size"],
                    available_capital * (confidence / 2)  # Scale by confidence, but no more than half of available capital
                )
                
                # Check if we want to execute this trade
                if confidence >= risk_settings["auto_confirm_threshold"]:
                    logger.info(f"Auto-executing trade for {token_address} based on Twitter signal. Position size: {position_size} SOL")
                    
                    # In a real implementation, this would execute the trade
                    # For simulation, just log it
                    self.active_trades[token_address] = {
                        "entry_time": datetime.datetime.now().isoformat(),
                        "position_size": position_size,
                        "entry_price": 0.0,  # Would get from the actual trade
                        "strategy": "signal_based_trading",
                        "signal": signal,
                        "stop_loss": risk_settings["stop_loss"],
                        "take_profit": risk_settings["take_profit"]
                    }
                    
                    logger.info(f"Added new signal-based trade for {token_address} to active trades")
                
        except Exception as e:
            logger.error(f"Error checking Twitter signals: {e}")
    
    async def set_risk_profile(self, profile: str) -> bool:
        """
        Set the risk profile for all profit systems.
        
        Args:
            profile: Risk profile (conservative, balanced, aggressive)
            
        Returns:
            Success status
        """
        if profile not in RISK_PROFILES:
            logger.error(f"Invalid risk profile: {profile}")
            return False
        
        try:
            self.config["risk_profile"] = profile
            self._save_config()
            logger.info(f"Set risk profile to {profile}")
            return True
        except Exception as e:
            logger.error(f"Error setting risk profile: {e}")
            return False
    
    async def enable_strategy(self, strategy: str, enabled: bool) -> bool:
        """
        Enable or disable a profit strategy.
        
        Args:
            strategy: Strategy name
            enabled: Whether to enable or disable the strategy
            
        Returns:
            Success status
        """
        if strategy not in self.config["strategies"]:
            logger.error(f"Unknown strategy: {strategy}")
            return False
        
        try:
            # Check if this is a change
            current_setting = self.config["strategies"][strategy]["enabled"]
            if current_setting == enabled:
                return True  # No change needed
            
            # Update the setting
            self.config["strategies"][strategy]["enabled"] = enabled
            self._save_config()
            
            logger.info(f"{'Enabled' if enabled else 'Disabled'} strategy: {strategy}")
            
            # Re-apply settings if we're running
            if self.running:
                await self._apply_strategy_settings()
            
            return True
        except Exception as e:
            logger.error(f"Error {'enabling' if enabled else 'disabling'} strategy: {e}")
            return False
    
    async def _apply_strategy_settings(self):
        """Apply strategy settings to the running systems."""
        try:
            # Apply Flash Loan Arbitrage settings
            if ARBITRAGE_AVAILABLE:
                if self.config["strategies"]["flash_loan_arbitrage"]["enabled"]:
                    await start_arbitrage_monitoring()
                else:
                    await stop_arbitrage_monitoring()
            
            # Apply Twitter signal monitoring settings
            if TWITTER_ENHANCEMENT_AVAILABLE:
                if self.config["strategies"]["signal_based_trading"]["enabled"]:
                    await start_twitter_monitoring()
                else:
                    await stop_twitter_monitoring()
            
        except Exception as e:
            logger.error(f"Error applying strategy settings: {e}")
    
    async def process_trade(self, trade_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a trade with enhanced parameters and protections.
        
        Args:
            trade_data: Trade information including token, amount, side
            
        Returns:
            Enhanced trade data
        """
        try:
            token_address = trade_data.get("token_address")
            enhanced_trade = trade_data.copy()
            
            # Apply AI-enhanced trade parameters
            if TRADE_OPTIMIZER_AVAILABLE and self.config["strategies"]["smart_parameter_trading"]["enabled"]:
                optimized_params = await optimize_trade_parameters(trade_data)
                enhanced_trade.update(optimized_params)
                logger.info(f"Applied AI-optimized parameters to trade for {token_address}")
            
            # Apply MEV protection
            if MEV_AVAILABLE and self.config["strategies"]["mev_optimization"]["enabled"]:
                protected_trade = await protect_transaction(enhanced_trade)
                enhanced_trade.update(protected_trade)
                logger.info(f"Applied MEV protection to trade for {token_address}")
            
            return enhanced_trade
            
        except Exception as e:
            logger.error(f"Error processing trade: {e}")
            return trade_data  # Return original if there was an error
    
    async def record_trade_result(self, token_address: str, result_data: Dict[str, Any]) -> bool:
        """
        Record the results of a trade for learning and statistics.
        
        Args:
            token_address: Token address
            result_data: Result information including success status, profit/loss
            
        Returns:
            Success status
        """
        try:
            # Get the active trade (if any)
            trade = self.active_trades.pop(token_address, None)
            
            if not trade:
                logger.warning(f"No active trade found for {token_address}")
                return False
            
            # Record result in trade history
            result = {
                "token_address": token_address,
                "entry_time": trade["entry_time"],
                "exit_time": datetime.datetime.now().isoformat(),
                "position_size": trade["position_size"],
                "entry_price": trade.get("entry_price", 0),
                "exit_price": result_data.get("exit_price", 0),
                "strategy": trade["strategy"],
                "profit": result_data.get("profit", 0),
                "profit_percentage": result_data.get("profit_percentage", 0),
                "success": result_data.get("success", False)
            }
            
            self.trade_history.append(result)
            
            # Trim history if it gets too large
            if len(self.trade_history) > 1000:
                self.trade_history = self.trade_history[-1000:]
            
            # Record for specific strategies
            if trade["strategy"] == "signal_based_trading" and TWITTER_ENHANCEMENT_AVAILABLE:
                # Record for Twitter signal performance tracking
                await record_signal_performance(token_address, result_data)
            
            if TRADE_OPTIMIZER_AVAILABLE:
                # Record for AI parameter optimization
                await record_transaction_result(trade, result_data)
            
            # Update stats cache
            self.stats_cache = {}  # Force regeneration
            
            logger.info(f"Recorded trade result for {token_address}: profit={result_data.get('profit', 0):.4f} SOL")
            return True
            
        except Exception as e:
            logger.error(f"Error recording trade result: {e}")
            return False
    
    def get_stats(self, days: int = 30) -> Dict[str, Any]:
        """
        Get performance statistics for the profit systems.
        
        Args:
            days: Number of days to include in the statistics
            
        Returns:
            Dictionary of statistics
        """
        # Check if we have cached stats for this time range
        cache_key = f"stats_{days}"
        if cache_key in self.stats_cache:
            return self.stats_cache[cache_key]
        
        try:
            # Filter trades based on time range
            current_time = datetime.datetime.now()
            start_time = current_time - datetime.timedelta(days=days)
            start_time_str = start_time.isoformat()
            
            filtered_trades = [
                trade for trade in self.trade_history 
                if trade.get("exit_time", "") >= start_time_str
            ]
            
            # Calculate statistics
            total_trades = len(filtered_trades)
            successful_trades = sum(1 for trade in filtered_trades if trade.get("success", False))
            win_rate = (successful_trades / total_trades * 100) if total_trades > 0 else 0
            
            total_profit = sum(trade.get("profit", 0) for trade in filtered_trades)
            
            # Calculate profits by strategy
            profit_by_strategy = {}
            for trade in filtered_trades:
                strategy = trade.get("strategy", "unknown")
                profit = trade.get("profit", 0)
                profit_by_strategy[strategy] = profit_by_strategy.get(strategy, 0) + profit
            
            # Calculate daily profits
            daily_profits = {}
            for trade in filtered_trades:
                exit_time_str = trade.get("exit_time", "")
                if exit_time_str:
                    exit_time = datetime.datetime.fromisoformat(exit_time_str)
                    date_str = exit_time.strftime("%Y-%m-%d")
                    profit = trade.get("profit", 0)
                    daily_profits[date_str] = daily_profits.get(date_str, 0) + profit
            
            # Gather arbitrage stats if available
            arbitrage_stats = {}
            if ARBITRAGE_AVAILABLE:
                try:
                    arbitrage_stats = await get_arbitrage_statistics()
                except:
                    arbitrage_stats = {}
            
            # Gather MEV stats if available
            mev_stats = {}
            if MEV_AVAILABLE:
                try:
                    mev_stats = await get_mev_statistics()
                except:
                    mev_stats = {}
            
            # Combine all stats
            stats = {
                "total_trades": total_trades,
                "successful_trades": successful_trades,
                "win_rate": win_rate,
                "total_profit": total_profit,
                "profit_by_strategy": profit_by_strategy,
                "daily_profits": daily_profits,
                "arbitrage": arbitrage_stats,
                "mev": mev_stats,
                "days": days,
                "generated_at": current_time.isoformat()
            }
            
            # Cache the stats
            self.stats_cache[cache_key] = stats
            
            return stats
            
        except Exception as e:
            logger.error(f"Error calculating statistics: {e}")
            return {
                "error": str(e),
                "total_trades": 0,
                "successful_trades": 0,
                "win_rate": 0,
                "total_profit": 0,
                "profit_by_strategy": {},
                "daily_profits": {},
                "days": days
            }
    
    async def _update_stats_cache(self):
        """Update the stats cache for common time ranges."""
        try:
            for days in [1, 7, 30]:
                self.get_stats(days)
            self.last_stats_update = time.time()
            logger.debug("Updated stats cache")
        except Exception as e:
            logger.error(f"Error updating stats cache: {e}")

# Singleton instance
_controller = None

async def get_profit_controller() -> AdvancedProfitController:
    """
    Get the profit controller instance.
    
    Returns:
        AdvancedProfitController instance
    """
    global _controller
    
    if _controller is None:
        _controller = AdvancedProfitController()
    
    return _controller