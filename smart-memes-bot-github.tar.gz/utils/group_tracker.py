"""
Group tracker for monitoring and scoring Telegram groups.

This module provides functionality to:
1. Track mentions and profitable calls from different groups
2. Score and rank groups based on performance
3. Persist and load tracking data
"""

import logging
import json
import os
import time
from typing import Dict, List, Tuple, Any, Optional
from datetime import datetime

# Configure logger
logger = logging.getLogger(__name__)

# Global dictionary to track group statistics
# Format: {group_name: {'mentions': int, 'wins': int, 'last_active': timestamp}}
group_scores = {}

def process_group_message(group_name: str, message: str, profitable: bool = False):
    """
    Process a message from a group and update statistics.
    
    Args:
        group_name (str): The name or ID of the Telegram group
        message (str): The message content 
        profitable (bool): Whether the token mention resulted in profit
    """
    global group_scores
    
    # Initialize group entry if it doesn't exist
    if group_name not in group_scores:
        group_scores[group_name] = {
            'mentions': 0,
            'wins': 0,
            'last_active': int(time.time())
        }
    
    # Update statistics
    group_scores[group_name]['mentions'] += 1
    if profitable:
        group_scores[group_name]['wins'] += 1
    group_scores[group_name]['last_active'] = int(time.time())
    
    logger.info(f"Updated statistics for group {group_name}: {group_scores[group_name]}")
    
    # Periodically save scores
    if sum(stats['mentions'] for stats in group_scores.values()) % 10 == 0:
        save_group_scores()

def get_top_groups(threshold=2):
    """
    Get top performing groups based on profitable calls.
    
    Args:
        threshold (int): Minimum number of profitable calls required
        
    Returns:
        list: Sorted list of tuples containing (group_name, stats)
    """
    # Filter groups that meet the threshold
    qualified_groups = []
    for group_name, stats in group_scores.items():
        if stats.get('wins', 0) >= threshold:
            qualified_groups.append((group_name, stats))
    
    # Sort by win rate (wins / mentions)
    sorted_groups = sorted(
        qualified_groups,
        key=lambda x: (x[1]['wins'] / x[1]['mentions'] if x[1]['mentions'] > 0 else 0),
        reverse=True
    )
    
    return sorted_groups

def get_group_win_rate(group_name):
    """
    Calculate the win rate for a specific group.
    
    Args:
        group_name (str): The name or ID of the Telegram group
        
    Returns:
        float: Win rate as a percentage, or 0 if no mentions
    """
    if group_name not in group_scores:
        return 0.0
    
    stats = group_scores[group_name]
    if stats.get('mentions', 0) == 0:
        return 0.0
    
    return (stats.get('wins', 0) / stats.get('mentions', 1)) * 100

def save_group_scores(path="data/group_scores.json"):
    """
    Save group scores to a JSON file.
    
    Args:
        path (str): Path to save the JSON file
    """
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Convert last_active timestamps to strings for readability
        serializable_scores = {}
        for group_name, stats in group_scores.items():
            serializable_stats = stats.copy()
            if 'last_active' in serializable_stats:
                last_active = serializable_stats['last_active']
                if isinstance(last_active, int):
                    serializable_stats['last_active'] = datetime.fromtimestamp(last_active).isoformat()
            serializable_scores[group_name] = serializable_stats
        
        # Save to file
        with open(path, 'w') as f:
            json.dump(serializable_scores, f, indent=2)
        
        logger.info(f"Group scores saved to {path}")
    except Exception as e:
        logger.error(f"Error saving group scores: {str(e)}")

def load_group_scores(path="data/group_scores.json"):
    """
    Load group scores from a JSON file.
    
    Args:
        path (str): Path to the JSON file
    """
    global group_scores
    
    try:
        if os.path.exists(path):
            with open(path, 'r') as f:
                loaded_scores = json.load(f)
            
            # Convert string timestamps back to integers
            for group_name, stats in loaded_scores.items():
                if 'last_active' in stats and isinstance(stats['last_active'], str):
                    try:
                        dt = datetime.fromisoformat(stats['last_active'])
                        stats['last_active'] = int(dt.timestamp())
                    except ValueError:
                        # If conversion fails, use current time
                        stats['last_active'] = int(time.time())
            
            group_scores = loaded_scores
            logger.info(f"Group scores loaded from {path}")
        else:
            logger.info(f"No group scores file found at {path}")
    except Exception as e:
        logger.error(f"Error loading group scores: {str(e)}")

def get_group_stats_summary():
    """
    Generate a human-readable summary of group statistics.
    
    Returns:
        str: Formatted summary of group performance
    """
    if not group_scores:
        return "No group statistics available yet."
    
    total_groups = len(group_scores)
    total_mentions = sum(stats.get('mentions', 0) for stats in group_scores.values())
    total_wins = sum(stats.get('wins', 0) for stats in group_scores.values())
    
    win_rate = (total_wins / total_mentions) * 100 if total_mentions > 0 else 0
    
    summary = f"📊 *Group Statistics Summary*\n\n"
    summary += f"Total groups tracked: {total_groups}\n"
    summary += f"Total token mentions: {total_mentions}\n"
    summary += f"Profitable calls: {total_wins}\n"
    summary += f"Overall win rate: {win_rate:.1f}%\n\n"
    
    # Add top 3 groups
    top_groups = get_top_groups(threshold=1)[:3]
    if top_groups:
        summary += "*Top Performing Groups:*\n"
        for i, (group_name, stats) in enumerate(top_groups):
            group_win_rate = (stats.get('wins', 0) / stats.get('mentions', 1)) * 100
            summary += f"{i+1}. {group_name}: {group_win_rate:.1f}% win rate\n"
    
    return summary

# Load existing scores when the module is imported
load_group_scores()