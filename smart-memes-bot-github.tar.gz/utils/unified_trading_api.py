"""
Unified Trading API for SMART MEMES BOT.

This module provides a simplified high-level API that integrates all our
profit-making systems into a unified trading interface. It coordinates among
different components and provides a simple set of functions for executing
trades with maximum profit potential.
"""

import os
import time
import asyncio
import logging
import json
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta

# Import our profit-making systems
try:
    from utils.enhanced_token_safety import analyze_token_safety
    SAFETY_AVAILABLE = True
except ImportError:
    SAFETY_AVAILABLE = False

try:
    from utils.twitter_signal_enhancement import (
        get_signal_for_token, get_recent_signals
    )
    TWITTER_ENHANCEMENT_AVAILABLE = True
except ImportError:
    TWITTER_ENHANCEMENT_AVAILABLE = False

try:
    from utils.advanced_slippage_management import (
        calculate_optimal_slippage, analyze_liquidity_depth,
        optimize_transaction_for_slippage
    )
    SLIPPAGE_MANAGEMENT_AVAILABLE = True
except ImportError:
    SLIPPAGE_MANAGEMENT_AVAILABLE = False

try:
    from utils.transaction_speed_enhancement import (
        enhance_transaction_speed, execute_transaction_with_retries,
        get_recommended_priority_fee
    )
    SPEED_ENHANCEMENT_AVAILABLE = True
except ImportError:
    SPEED_ENHANCEMENT_AVAILABLE = False

try:
    from utils.mev_optimizer import protect_transaction
    MEV_AVAILABLE = True
except ImportError:
    MEV_AVAILABLE = False

try:
    from utils.flash_loan_arbitrage import get_arbitrage_statistics
    ARBITRAGE_AVAILABLE = True
except ImportError:
    ARBITRAGE_AVAILABLE = False

try:
    from utils.cross_chain_arbitrage import get_cc_arbitrage_statistics
    CROSS_CHAIN_ARBITRAGE_AVAILABLE = True
except ImportError:
    CROSS_CHAIN_ARBITRAGE_AVAILABLE = False

try:
    from utils.ai_trade_fallback import execute_trade_with_fallback
    FALLBACK_AVAILABLE = True
except ImportError:
    FALLBACK_AVAILABLE = False

try:
    from ai.trade_parameter_optimizer import optimize_trade_parameters
    AI_OPTIMIZATION_AVAILABLE = True
except ImportError:
    AI_OPTIMIZATION_AVAILABLE = False

try:
    from utils.enhanced_smart_sniper import smart_snipe
    SMART_SNIPER_AVAILABLE = True
except ImportError:
    SMART_SNIPER_AVAILABLE = False

# Configure logging
logger = logging.getLogger(__name__)

# Default settings
DEFAULT_SETTINGS = {
    "risk_profile": "balanced",  # conservative, balanced, aggressive
    "chain": "solana",           # solana, ethereum, etc.
    "max_slippage": 0.03,        # 3% max slippage
    "priority_tier": "normal",   # low, normal, high, urgent
    "use_twitter_signals": True,
    "use_enhanced_safety": True,
    "use_mev_protection": True,
    "use_slippage_optimization": True,
    "use_speed_enhancement": True,
    "use_ai_optimization": True,
    "use_fallback": True,
    "auto_compound": True,
    "auto_stake_rewards": False
}

# Trade result cache (to avoid double-processing)
trade_results_cache = {}

class UnifiedTradingAPI:
    """
    Unified Trading API that integrates all profit-making systems.
    """
    
    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        """
        Initialize the Unified Trading API.
        
        Args:
            settings: Optional custom settings to override defaults
        """
        self.settings = DEFAULT_SETTINGS.copy()
        if settings:
            self.settings.update(settings)
        
        self.trade_history = []
        self.pending_trades = []
    
    async def analyze_token(self, token_address: str, 
                          token_symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Perform comprehensive token analysis using all available systems.
        
        Args:
            token_address: Token address to analyze
            token_symbol: Optional token symbol
            
        Returns:
            Comprehensive analysis results
        """
        analysis = {
            "token_address": token_address,
            "token_symbol": token_symbol,
            "timestamp": time.time(),
            "risk_profile": self.settings["risk_profile"],
            "systems_used": [],
            "trade_recommendation": {}
        }
        
        # 1. Safety analysis if available
        if SAFETY_AVAILABLE and self.settings["use_enhanced_safety"]:
            try:
                safety_score, safety_details = await analyze_token_safety(token_address)
                analysis["safety_score"] = safety_score
                analysis["safety_details"] = safety_details
                analysis["systems_used"].append("enhanced_safety")
                
                # Initial buy/sell recommendation based on safety
                if safety_score >= 0.8:
                    analysis["trade_recommendation"]["action"] = "buy"
                    analysis["trade_recommendation"]["confidence"] = safety_score
                elif safety_score <= 0.2:
                    analysis["trade_recommendation"]["action"] = "sell"
                    analysis["trade_recommendation"]["confidence"] = 1.0 - safety_score
                else:
                    analysis["trade_recommendation"]["action"] = "hold"
                    analysis["trade_recommendation"]["confidence"] = 0.5
                
            except Exception as e:
                logger.error(f"Error in safety analysis: {str(e)}")
                analysis["safety_error"] = str(e)
        
        # 2. Twitter signal analysis if available
        if TWITTER_ENHANCEMENT_AVAILABLE and self.settings["use_twitter_signals"]:
            try:
                signal = await get_signal_for_token(token_address)
                if signal:
                    analysis["twitter_signal"] = signal
                    analysis["systems_used"].append("twitter_enhancement")
                    
                    # Update recommendation based on Twitter signal
                    if "trade_recommendation" in analysis:
                        # Blend existing recommendation with Twitter signal
                        existing_action = analysis["trade_recommendation"].get("action", "hold")
                        existing_confidence = analysis["trade_recommendation"].get("confidence", 0.5)
                        
                        signal_action = signal.get("trading_action", "hold")
                        signal_confidence = signal.get("confidence", 0.5)
                        
                        # If actions align, boost confidence
                        if existing_action == signal_action:
                            new_confidence = (existing_confidence + signal_confidence) / 2
                            analysis["trade_recommendation"]["confidence"] = new_confidence
                        # If actions conflict, go with higher confidence
                        elif signal_confidence > existing_confidence:
                            analysis["trade_recommendation"]["action"] = signal_action
                            analysis["trade_recommendation"]["confidence"] = signal_confidence
            
            except Exception as e:
                logger.error(f"Error in Twitter signal analysis: {str(e)}")
                analysis["twitter_error"] = str(e)
        
        # 3. Liquidity analysis if available
        if SLIPPAGE_MANAGEMENT_AVAILABLE and self.settings["use_slippage_optimization"]:
            try:
                liquidity_analysis = await analyze_liquidity_depth(token_address)
                analysis["liquidity_analysis"] = liquidity_analysis
                analysis["systems_used"].append("slippage_management")
                
                # Update recommendation based on liquidity
                if "trade_recommendation" in analysis and "total_liquidity" in liquidity_analysis:
                    # Adjust confidence based on liquidity
                    total_liquidity = liquidity_analysis["total_liquidity"]
                    if total_liquidity < 10000:  # Less than $10K liquidity is risky
                        analysis["trade_recommendation"]["confidence"] *= 0.7
                        analysis["trade_recommendation"]["liquidity_warning"] = "low_liquidity"
                    elif total_liquidity > 1000000:  # Over $1M liquidity is good
                        analysis["trade_recommendation"]["confidence"] *= 1.2
                        analysis["trade_recommendation"]["confidence"] = min(1.0, analysis["trade_recommendation"]["confidence"])
                
                # Add slippage recommendation
                if token_symbol:
                    slippage = await calculate_optimal_slippage(token_address, token_symbol)
                    analysis["recommended_slippage"] = slippage
            
            except Exception as e:
                logger.error(f"Error in liquidity analysis: {str(e)}")
                analysis["liquidity_error"] = str(e)
        
        # 4. Check for arbitrage opportunities if available
        if CROSS_CHAIN_ARBITRAGE_AVAILABLE:
            try:
                # In a real implementation, this would check for cross-chain opportunities
                # For now, just note that we checked
                analysis["systems_used"].append("cross_chain_arbitrage")
            except Exception as e:
                logger.error(f"Error checking cross-chain arbitrage: {str(e)}")
        
        # 5. Use AI optimization if available to refine recommendation
        if AI_OPTIMIZATION_AVAILABLE and self.settings["use_ai_optimization"]:
            try:
                # Pass analysis to AI for final recommendations
                analysis["systems_used"].append("ai_optimization")
                
                # In a real implementation, this would call AI optimization
                # For demo purposes, just improve the confidence slightly
                if "trade_recommendation" in analysis:
                    analysis["trade_recommendation"]["ai_enhanced"] = True
                    # Add position sizing recommendation
                    action = analysis["trade_recommendation"].get("action", "hold")
                    confidence = analysis["trade_recommendation"].get("confidence", 0.5)
                    
                    if action == "buy":
                        # Scale position size recommendation with confidence
                        max_position = {
                            "conservative": 0.5,
                            "balanced": 1.0,
                            "aggressive": 2.0
                        }.get(self.settings["risk_profile"], 1.0)
                        
                        recommended_position = max_position * confidence
                        analysis["trade_recommendation"]["position_size"] = recommended_position
            
            except Exception as e:
                logger.error(f"Error in AI optimization: {str(e)}")
                analysis["ai_error"] = str(e)
        
        # Final risk assessment based on risk profile
        risk_thresholds = {
            "conservative": 0.8,  # 80% confidence minimum
            "balanced": 0.7,      # 70% confidence minimum
            "aggressive": 0.6     # 60% confidence minimum
        }
        
        risk_threshold = risk_thresholds.get(self.settings["risk_profile"], 0.7)
        
        if "trade_recommendation" in analysis:
            confidence = analysis["trade_recommendation"].get("confidence", 0)
            action = analysis["trade_recommendation"].get("action", "hold")
            
            if action == "buy" and confidence >= risk_threshold:
                analysis["trade_recommendation"]["execute"] = True
            else:
                analysis["trade_recommendation"]["execute"] = False
        
        return analysis
    
    async def execute_trade(self, token_address: str, 
                          side: str = "buy",
                          amount: Optional[float] = None,
                          token_symbol: Optional[str] = None,
                          slippage: Optional[float] = None) -> Dict[str, Any]:
        """
        Execute a trade with optimal parameters using all available systems.
        
        Args:
            token_address: Token address
            side: Trade side ("buy" or "sell")
            amount: Amount to trade (optional, will use recommended amount if not provided)
            token_symbol: Optional token symbol
            slippage: Optional custom slippage value
            
        Returns:
            Trade execution result
        """
        # Create base trade data
        trade_data = {
            "token_address": token_address,
            "token_symbol": token_symbol,
            "side": side,
            "timestamp": time.time(),
            "chain": self.settings["chain"],
            "systems_used": []
        }
        
        try:
            # 1. Analyze token first for safety
            analysis = await self.analyze_token(token_address, token_symbol)
            trade_data["analysis"] = analysis
            
            # 2. Determine trade amount if not provided
            if amount is None:
                if "trade_recommendation" in analysis and "position_size" in analysis["trade_recommendation"]:
                    amount = analysis["trade_recommendation"]["position_size"]
                else:
                    # Default amount based on risk profile
                    amount = {
                        "conservative": 0.2,
                        "balanced": 0.5,
                        "aggressive": 1.0
                    }.get(self.settings["risk_profile"], 0.5)
            
            trade_data["amount"] = amount
            
            # 3. Check if trade should proceed based on analysis
            if side == "buy" and (
                "trade_recommendation" not in analysis or
                not analysis["trade_recommendation"].get("execute", False)
            ):
                return {
                    "success": False,
                    "error": "Token analysis suggests not to execute this trade",
                    "analysis": analysis,
                    "trade_data": trade_data
                }
            
            # 4. Set slippage if not provided
            if slippage is None:
                if "recommended_slippage" in analysis:
                    slippage = analysis["recommended_slippage"]
                else:
                    slippage = self.settings["max_slippage"]
            
            trade_data["slippage_percentage"] = slippage
            
            # 5. Add priority fee recommendation
            if SPEED_ENHANCEMENT_AVAILABLE and self.settings["use_speed_enhancement"]:
                priority_fee = await get_recommended_priority_fee(
                    self.settings["chain"], 
                    self.settings["priority_tier"]
                )
                trade_data["priority_fee"] = priority_fee
                trade_data["priority_tier"] = self.settings["priority_tier"]
                trade_data["systems_used"].append("speed_enhancement")
            
            # 6. Apply slippage optimization if available
            if SLIPPAGE_MANAGEMENT_AVAILABLE and self.settings["use_slippage_optimization"]:
                optimized_trade = await optimize_transaction_for_slippage(trade_data)
                trade_data.update(optimized_trade)
                trade_data["systems_used"].append("slippage_management")
            
            # 7. Apply AI parameter optimization if available
            if AI_OPTIMIZATION_AVAILABLE and self.settings["use_ai_optimization"]:
                optimized_params = await optimize_trade_parameters(trade_data)
                trade_data.update(optimized_params)
                trade_data["systems_used"].append("ai_optimization")
            
            # 8. Apply MEV protection if available
            if MEV_AVAILABLE and self.settings["use_mev_protection"]:
                protected_trade = await protect_transaction(trade_data)
                trade_data.update(protected_trade)
                trade_data["systems_used"].append("mev_protection")
            
            # 9. Apply transaction speed enhancement if available
            if SPEED_ENHANCEMENT_AVAILABLE and self.settings["use_speed_enhancement"]:
                enhanced_trade = await enhance_transaction_speed(trade_data)
                trade_data.update(enhanced_trade)
                # Already added to systems_used
            
            # 10. Execute the trade with fallback if available
            if FALLBACK_AVAILABLE and self.settings["use_fallback"]:
                result = await execute_trade_with_fallback(trade_data)
                trade_data["systems_used"].append("ai_trade_fallback")
            else:
                # Execute with retries if speed enhancement is available
                if SPEED_ENHANCEMENT_AVAILABLE and self.settings["use_speed_enhancement"]:
                    result = await execute_transaction_with_retries(trade_data)
                else:
                    # Simulate execution for demo purposes
                    # In a real implementation, this would call the trading module
                    result = {
                        "success": True,
                        "token_address": token_address,
                        "token_symbol": token_symbol,
                        "amount": amount,
                        "executed_price": 1.0,  # Simulated price
                        "executed_amount": amount * 0.98,  # Account for fees
                        "transaction_hash": f"simulated_tx_{int(time.time())}"
                    }
            
            # 11. Record the trade
            trade_record = {
                "token_address": token_address,
                "token_symbol": token_symbol,
                "side": side,
                "amount": amount,
                "result": result,
                "trade_data": trade_data,
                "timestamp": time.time()
            }
            
            self.trade_history.append(trade_record)
            
            # 12. Return the result with trade data
            return {
                "success": result.get("success", False),
                "token_address": token_address,
                "token_symbol": token_symbol,
                "side": side,
                "amount": amount,
                "result": result,
                "trade_data": trade_data,
                "systems_used": trade_data["systems_used"]
            }
            
        except Exception as e:
            logger.error(f"Error executing trade: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "token_address": token_address,
                "token_symbol": token_symbol,
                "side": side,
                "amount": amount
            }
    
    async def smart_trade(self, token_address: str,
                        token_symbol: Optional[str] = None,
                        group_score: float = 0.0,
                        wallet_score: float = 0.0,
                        message_text: str = "") -> Dict[str, Any]:
        """
        Execute a smart trade based on comprehensive analysis and sniper logic.
        
        Args:
            token_address: Token address
            token_symbol: Optional token symbol
            group_score: Score for the group where token was mentioned
            wallet_score: Score for the wallet that created the token
            message_text: Text of the message that mentioned the token
            
        Returns:
            Trade result
        """
        # Use the smart sniper if available
        if SMART_SNIPER_AVAILABLE:
            try:
                # Evaluate the opportunity with the sniper
                sniper_result = await smart_snipe(
                    token_address=token_address,
                    token_symbol=token_symbol,
                    group_score=group_score,
                    wallet_score=wallet_score,
                    message_text=message_text,
                    risk_profile=self.settings["risk_profile"]
                )
                
                # If sniper recommends sniping, execute the trade
                if sniper_result["snipe_scheduled"]:
                    position_size = sniper_result["position_size"]
                    
                    # Execute the trade
                    trade_result = await self.execute_trade(
                        token_address=token_address,
                        side="buy",
                        amount=position_size,
                        token_symbol=token_symbol
                    )
                    
                    # Add sniper evaluation to result
                    trade_result["sniper_evaluation"] = sniper_result["evaluation"]
                    
                    return trade_result
                else:
                    # Return rejection from sniper
                    return {
                        "success": False,
                        "snipe_rejected": True,
                        "token_address": token_address,
                        "token_symbol": token_symbol,
                        "reasons": sniper_result.get("reasons", ["Unknown"]),
                        "evaluation": sniper_result.get("evaluation", {})
                    }
            
            except Exception as e:
                logger.error(f"Error in smart trade with sniper: {str(e)}")
                
                # Fall back to normal trade execution
                logger.info("Falling back to normal trade execution")
        
        # If sniper not available or failed, perform normal analysis and trade
        try:
            # Analyze the token
            analysis = await self.analyze_token(token_address, token_symbol)
            
            # Check if trade is recommended
            if "trade_recommendation" in analysis and analysis["trade_recommendation"].get("execute", False):
                amount = analysis["trade_recommendation"].get("position_size", 0.5)
                
                # Execute the trade
                trade_result = await self.execute_trade(
                    token_address=token_address,
                    side="buy",
                    amount=amount,
                    token_symbol=token_symbol
                )
                
                return trade_result
            else:
                # Return rejection based on analysis
                return {
                    "success": False,
                    "analysis_rejected": True,
                    "token_address": token_address,
                    "token_symbol": token_symbol,
                    "analysis": analysis
                }
        
        except Exception as e:
            logger.error(f"Error in smart trade: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "token_address": token_address,
                "token_symbol": token_symbol
            }
    
    def get_trade_history(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent trade history.
        
        Args:
            count: Number of trades to return
            
        Returns:
            List of recent trades
        """
        return self.trade_history[-count:]
    
    def get_pending_trades(self) -> List[Dict[str, Any]]:
        """
        Get list of pending trades.
        
        Returns:
            List of pending trades
        """
        return self.pending_trades

# Singleton instance
_trading_api = None

def get_trading_api(settings: Optional[Dict[str, Any]] = None) -> UnifiedTradingAPI:
    """
    Get the Unified Trading API instance.
    
    Args:
        settings: Optional custom settings
        
    Returns:
        UnifiedTradingAPI instance
    """
    global _trading_api
    
    if _trading_api is None:
        _trading_api = UnifiedTradingAPI(settings)
    elif settings:
        _trading_api.settings.update(settings)
    
    return _trading_api

async def analyze_token(token_address: str, token_symbol: Optional[str] = None) -> Dict[str, Any]:
    """
    Analyze a token using all available systems.
    
    Args:
        token_address: Token address
        token_symbol: Optional token symbol
        
    Returns:
        Analysis results
    """
    api = get_trading_api()
    return await api.analyze_token(token_address, token_symbol)

async def execute_trade(token_address: str, 
                       side: str = "buy",
                       amount: Optional[float] = None,
                       token_symbol: Optional[str] = None,
                       slippage: Optional[float] = None) -> Dict[str, Any]:
    """
    Execute a trade with optimal parameters.
    
    Args:
        token_address: Token address
        side: Trade side ("buy" or "sell")
        amount: Amount to trade
        token_symbol: Optional token symbol
        slippage: Optional custom slippage value
        
    Returns:
        Trade result
    """
    api = get_trading_api()
    return await api.execute_trade(token_address, side, amount, token_symbol, slippage)

async def smart_trade(token_address: str,
                     token_symbol: Optional[str] = None,
                     group_score: float = 0.0,
                     wallet_score: float = 0.0,
                     message_text: str = "") -> Dict[str, Any]:
    """
    Execute a smart trade based on comprehensive analysis.
    
    Args:
        token_address: Token address
        token_symbol: Optional token symbol
        group_score: Score for the group where token was mentioned
        wallet_score: Score for the wallet that created the token
        message_text: Text of the message that mentioned the token
        
    Returns:
        Trade result
    """
    api = get_trading_api()
    return await api.smart_trade(token_address, token_symbol, group_score, wallet_score, message_text)

# Example usage
async def test_unified_trading_api():
    """
    Test the unified trading API functionality.
    """
    logger.info("Testing Unified Trading API")
    
    # Set custom settings for testing
    settings = {
        "risk_profile": "balanced",
        "max_slippage": 0.01,  # 1% max slippage
        "priority_tier": "high"
    }
    
    api = get_trading_api(settings)
    
    # Test token address (USDC on Solana)
    token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    token_symbol = "USDC"
    
    # Test token analysis
    logger.info(f"Analyzing token {token_symbol} ({token_address})...")
    analysis = await api.analyze_token(token_address, token_symbol)
    
    logger.info(f"Analysis result: {json.dumps(analysis, indent=2)}")
    
    # Test trade execution
    logger.info(f"Executing test trade for {token_symbol}...")
    trade_result = await api.execute_trade(
        token_address=token_address,
        side="buy",
        amount=0.1,
        token_symbol=token_symbol
    )
    
    logger.info(f"Trade result: {json.dumps(trade_result, indent=2)}")
    
    # Test smart trade
    logger.info(f"Testing smart trade for {token_symbol}...")
    smart_result = await api.smart_trade(
        token_address=token_address,
        token_symbol=token_symbol,
        group_score=0.9,
        wallet_score=0.85,
        message_text="New token launched! Looking very promising, great team and roadmap."
    )
    
    logger.info(f"Smart trade result: {json.dumps(smart_result, indent=2)}")
    
    # Get trade history
    history = api.get_trade_history()
    logger.info(f"Trade history: {len(history)} trades")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_unified_trading_api())