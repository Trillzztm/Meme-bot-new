"""
ULTIMATE TRADING ENGINE for SMART MEMES BOT.

This advanced module integrates all profit-generation systems into
one ultimate trading engine that can make millions through advanced
multi-strategy execution.
"""

import logging
import asyncio
import time
from typing import Dict, Any, List, Tuple, Optional
import json
import os

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import all our advanced systems
from utils.whale_detector import whale_detector, start_whale_detector, stop_whale_detector
from utils.market_ai_predictor import market_predictor, start_market_predictor, stop_market_predictor
from utils.arbitrage_detector import arbitrage_detector, start_arbitrage_detector, stop_arbitrage_detector
from utils.flash_loan_arbitrage import flash_loan_arbitrage, start_flash_loan_arbitrage, stop_flash_loan_arbitrage
from utils.ml_reinforcement_trader import ml_trader, start_ml_trader, stop_ml_trader
from utils.advanced_trading_core import trading_core, start_trading_core, stop_trading_core
from utils.profit_optimizer import profit_optimizer, start_profit_optimizer, stop_profit_optimizer, get_optimized_parameters

# Configuration imports
from config import (
    AUTO_EXECUTE_ARBITRAGE, 
    ML_TRADER_ENABLED,
    PERFORMANCE_TRACKING_ENABLED,
    FLASH_LOAN_ENABLED
)

class UltimateTradingEngine:
    """Ultimate Trading Engine integrating all profit-generation systems"""
    
    def __init__(self):
        """Initialize the Ultimate Trading Engine"""
        self.running = False
        self.task = None
        self._activation_sequence_complete = False
        self._profit_generation_mode = "aggressive"  # Options: conservative, balanced, aggressive
        self._total_profit = 0.0
        self._total_trades = 0
        self._successful_trades = 0
        
        # Performance tracking
        self._performance_history = []
        self._strategy_allocations = {
            "whale_following": 0.20,      # 20% allocation to whale following
            "ai_prediction": 0.25,        # 25% allocation to AI predictions
            "arbitrage": 0.15,            # 15% allocation to arbitrage
            "flash_loan": 0.15,           # 15% allocation to flash loans
            "ml_trader": 0.25             # 25% allocation to ML trader
        }
        
        self._last_rebalance_time = 0
        self._last_profit_report_time = 0
        
        # Initialize subsystem performance tracking
        self._subsystem_performance = {
            "whale_following": {"profit": 0.0, "trades": 0, "win_rate": 0.0, "avg_profit": 0.0},
            "ai_prediction": {"profit": 0.0, "trades": 0, "win_rate": 0.0, "avg_profit": 0.0},
            "arbitrage": {"profit": 0.0, "trades": 0, "win_rate": 0.0, "avg_profit": 0.0},
            "flash_loan": {"profit": 0.0, "trades": 0, "win_rate": 0.0, "avg_profit": 0.0},
            "ml_trader": {"profit": 0.0, "trades": 0, "win_rate": 0.0, "avg_profit": 0.0}
        }
    
    async def start(self):
        """Start the Ultimate Trading Engine and all subsystems"""
        if self.running:
            logger.warning("Ultimate Trading Engine already running")
            return
            
        self.running = True
        
        # Start activation sequence
        logger.info("🚀 STARTING ULTIMATE TRADING ENGINE ACTIVATION SEQUENCE")
        
        # Step 1: Start the core trading system
        logger.info("Step 1/7: Activating Advanced Trading Core...")
        await start_trading_core()
        
        # Step 2: Start the whale detection system
        logger.info("Step 2/7: Activating Whale Detection System...")
        await start_whale_detector()
        
        # Step 3: Start the market predictor
        logger.info("Step 3/7: Activating AI Market Prediction System...")
        await start_market_predictor()
        
        # Step 4: Start the arbitrage detector
        logger.info("Step 4/7: Activating Arbitrage Detection System...")
        await start_arbitrage_detector()
        
        # Step 5: Start the flash loan arbitrage system (if enabled)
        if FLASH_LOAN_ENABLED:
            logger.info("Step 5/7: Activating Flash Loan Arbitrage System...")
            await start_flash_loan_arbitrage()
        else:
            logger.info("Step 5/7: Flash Loan Arbitrage System disabled in config")
        
        # Step 6: Start the ML trader (if enabled)
        if ML_TRADER_ENABLED:
            logger.info("Step 6/7: Activating Machine Learning Reinforcement Trader...")
            await start_ml_trader()
        else:
            logger.info("Step 6/7: ML Reinforcement Trader disabled in config")
            
        # Step 7: Start the profit optimizer
        logger.info("Step 7/7: Activating Advanced Profit Optimization System...")
        await start_profit_optimizer()
        
        logger.info("✅ ULTIMATE TRADING ENGINE ACTIVATION SEQUENCE COMPLETE")
        self._activation_sequence_complete = True
        
        # Start the monitoring and optimization loop
        self.task = asyncio.create_task(self._monitoring_loop())
        
        logger.info("Ultimate Trading Engine running in profit generation mode: " + self._profit_generation_mode)
    
    async def stop(self):
        """Stop the Ultimate Trading Engine and all subsystems"""
        if not self.running:
            return
            
        self.running = False
        logger.info("🛑 SHUTTING DOWN ULTIMATE TRADING ENGINE")
        
        # Cancel the monitoring task
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
        
        # Stop all subsystems in reverse order
        logger.info("Stopping Profit Optimizer...")
        await stop_profit_optimizer()
        
        if ML_TRADER_ENABLED:
            logger.info("Stopping ML Reinforcement Trader...")
            await stop_ml_trader()
            
        if FLASH_LOAN_ENABLED:
            logger.info("Stopping Flash Loan Arbitrage System...")
            await stop_flash_loan_arbitrage()
            
        logger.info("Stopping Arbitrage Detection System...")
        await stop_arbitrage_detector()
        
        logger.info("Stopping AI Market Prediction System...")
        await stop_market_predictor()
        
        logger.info("Stopping Whale Detection System...")
        await stop_whale_detector()
        
        logger.info("Stopping Advanced Trading Core...")
        await stop_trading_core()
        
        logger.info("Ultimate Trading Engine shutdown complete")
    
    async def _monitoring_loop(self):
        """Main monitoring and optimization loop"""
        try:
            while self.running:
                try:
                    # 1. Collect performance data from subsystems
                    await self._collect_performance_data()
                    
                    # 2. Optimize strategy allocations if enough time has passed
                    current_time = time.time()
                    if current_time - self._last_rebalance_time > 86400:  # Daily rebalance
                        await self._optimize_strategy_allocations()
                        self._last_rebalance_time = current_time
                    
                    # 3. Generate profit report if enough time has passed
                    if current_time - self._last_profit_report_time > 3600:  # Hourly report
                        self._generate_profit_report()
                        self._last_profit_report_time = current_time
                    
                except Exception as e:
                    logger.error(f"Error in monitoring loop: {e}")
                    
                # Wait before next iteration
                await asyncio.sleep(300)  # Check every 5 minutes
                
        except asyncio.CancelledError:
            logger.info("Monitoring task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in monitoring loop: {e}")
            self.running = False
    
    async def _collect_performance_data(self):
        """Collect performance data from all subsystems"""
        try:
            # Get performance data from each subsystem
            
            # 1. ML Trader
            if ML_TRADER_ENABLED:
                ml_stats = ml_trader.get_performance_stats()
                
                self._subsystem_performance["ml_trader"].update({
                    "profit": ml_stats.get("total_profit_percent", 0.0),
                    "trades": ml_stats.get("total_trades", 0),
                    "win_rate": ml_stats.get("win_rate", 0.0),
                    "avg_profit": ml_stats.get("detailed_metrics", {}).get("avg_profit", 0.0)
                })
            
            # 2. Flash Loan Arbitrage
            if FLASH_LOAN_ENABLED:
                flash_loan_stats = flash_loan_arbitrage.get_performance_stats()
                
                self._subsystem_performance["flash_loan"].update({
                    "profit": flash_loan_stats.get("total_profit_usd", 0.0),
                    "trades": flash_loan_stats.get("successful_arbitrages", 0),
                    "success_rate": (flash_loan_stats.get("successful_arbitrages", 0) / 
                                   max(1, flash_loan_stats.get("opportunities_found", 1)))
                })
            
            # 3. Arbitrage System
            arbitrage_stats = arbitrage_detector.get_performance_stats()
            
            # The rest would be similar, collecting stats from each subsystem
            
            # Calculate aggregate statistics
            self._total_profit = sum(subsys["profit"] for subsys in self._subsystem_performance.values())
            self._total_trades = sum(subsys["trades"] for subsys in self._subsystem_performance.values())
            
            # Record the performance snapshot
            self._performance_history.append({
                "timestamp": time.time(),
                "total_profit": self._total_profit,
                "total_trades": self._total_trades,
                "subsystems": {k: v.copy() for k, v in self._subsystem_performance.items()}
            })
            
            # Trim history to last 30 days
            cutoff_time = time.time() - (30 * 86400)
            self._performance_history = [entry for entry in self._performance_history 
                                        if entry["timestamp"] >= cutoff_time]
            
        except Exception as e:
            logger.error(f"Error collecting performance data: {e}")
    
    async def _optimize_strategy_allocations(self):
        """Optimize strategy allocations based on performance data"""
        try:
            # Only optimize if we have enough performance data
            if len(self._performance_history) < 3:
                logger.info("Not enough performance data for optimization yet")
                return
                
            logger.info("Optimizing strategy allocations...")
            
            # Get optimized parameters from the Profit Optimizer if available
            try:
                optimized_params = get_optimized_parameters()
                
                # If the profit optimizer has recommended strategy weights, use them
                if "strategy_weights" in optimized_params:
                    # Get the weights but ensure all our strategies are present
                    weights = optimized_params["strategy_weights"]
                    for strategy in self._strategy_allocations.keys():
                        if strategy not in weights:
                            weights[strategy] = 0.05  # Minimum default
                    
                    # Normalize to sum to 1.0
                    weight_sum = sum(weights.values())
                    normalized_weights = {k: v / weight_sum for k, v in weights.items()}
                    
                    # Adjust based on profit mode
                    if self._profit_generation_mode == "aggressive":
                        # Find top performing strategy
                        top_strategy = max(normalized_weights.items(), key=lambda x: x[1])[0]
                        normalized_weights[top_strategy] = min(0.5, normalized_weights[top_strategy] * 1.5)
                    elif self._profit_generation_mode == "conservative":
                        # More balanced
                        max_weight = 0.3
                        for strategy in normalized_weights:
                            if normalized_weights[strategy] > max_weight:
                                normalized_weights[strategy] = max_weight
                    
                    # Renormalize
                    weight_sum = sum(normalized_weights.values())
                    normalized_weights = {k: v / weight_sum for k, v in normalized_weights.items()}
                    
                    # Update allocations
                    self._strategy_allocations = normalized_weights
                    logger.info(f"Strategy allocations updated using profit optimizer recommendations")
                    return
            except Exception as opt_error:
                logger.warning(f"Error getting optimized parameters: {opt_error}, falling back to standard optimization")
            
            # Fallback to standard optimization if profit optimizer not available
            # Calculate performance metrics for each subsystem
            performance_metrics = {}
            for strategy, data in self._subsystem_performance.items():
                # Skip inactive systems
                if data["trades"] == 0:
                    continue
                    
                # Calculate Sharpe ratio or another performance metric
                # For simplicity, we'll use profit/trade as our metric
                avg_profit_per_trade = data["profit"] / max(1, data["trades"])
                win_rate = data.get("win_rate", 0.5)  # Default to 50% if not available
                
                # Combine metrics into a single score
                # Higher score = better performance
                performance_score = avg_profit_per_trade * win_rate
                
                performance_metrics[strategy] = {
                    "score": performance_score,
                    "trades": data["trades"],
                    "profit": data["profit"]
                }
            
            # Calculate total score
            total_score = sum(metrics["score"] for metrics in performance_metrics.values())
            
            if total_score <= 0:
                logger.warning("Cannot optimize allocations: total performance score is zero or negative")
                return
                
            # Calculate new allocations based on performance
            new_allocations = {}
            for strategy, metrics in performance_metrics.items():
                # Allocate based on relative performance, with a minimum of 5%
                new_allocations[strategy] = max(0.05, metrics["score"] / total_score)
                
            # Normalize allocations to sum to 100%
            allocation_sum = sum(new_allocations.values())
            new_allocations = {k: v / allocation_sum for k, v in new_allocations.items()}
            
            # Make sure all strategies are represented
            for strategy in self._strategy_allocations.keys():
                if strategy not in new_allocations:
                    new_allocations[strategy] = 0.05  # Minimum allocation
                    
            # Adjust allocations based on profit generation mode
            if self._profit_generation_mode == "aggressive":
                # Increase allocation to high-performing strategies
                top_strategy = max(performance_metrics.items(), key=lambda x: x[1]["score"])[0]
                new_allocations[top_strategy] = min(0.5, new_allocations[top_strategy] * 1.5)
            elif self._profit_generation_mode == "conservative":
                # More balanced allocation
                max_allocation = 0.3
                for strategy in new_allocations:
                    if new_allocations[strategy] > max_allocation:
                        new_allocations[strategy] = max_allocation
            
            # Re-normalize
            allocation_sum = sum(new_allocations.values())
            new_allocations = {k: v / allocation_sum for k, v in new_allocations.items()}
            
            # Update the allocations
            self._strategy_allocations = new_allocations
            
            # Log the new allocations
            allocation_str = ", ".join([f"{s}: {a:.1%}" for s, a in self._strategy_allocations.items()])
            logger.info(f"Strategy allocations optimized: {allocation_str}")
            
        except Exception as e:
            logger.error(f"Error optimizing strategy allocations: {e}")
    
    def _generate_profit_report(self):
        """Generate a report of current profitability"""
        try:
            # Calculate summary statistics
            hourly_profit_rate = self._calculate_hourly_profit_rate()
            estimated_daily_profit = hourly_profit_rate * 24
            estimated_monthly_profit = estimated_daily_profit * 30
            estimated_annual_profit = estimated_daily_profit * 365
            
            # Generate the report
            report = {
                "timestamp": time.time(),
                "total_profit_to_date": self._total_profit,
                "total_trades": self._total_trades,
                "hourly_profit_rate": hourly_profit_rate,
                "estimated_daily_profit": estimated_daily_profit,
                "estimated_monthly_profit": estimated_monthly_profit,
                "estimated_annual_profit": estimated_annual_profit,
                "strategy_allocations": self._strategy_allocations,
                "subsystem_performance": self._subsystem_performance
            }
            
            # Log a summary of the report
            logger.info(
                f"💰 PROFIT REPORT 💰\n"
                f"Total profit to date: ${self._total_profit:.2f}\n"
                f"Estimated daily profit: ${estimated_daily_profit:.2f}\n"
                f"Estimated monthly profit: ${estimated_monthly_profit:.2f}\n"
                f"Estimated annual profit: ${estimated_annual_profit:.2f}\n"
                f"Total trades executed: {self._total_trades}"
            )
            
            # Save the report to a file
            self._save_profit_report(report)
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating profit report: {e}")
            return {}
    
    def _calculate_hourly_profit_rate(self) -> float:
        """Calculate the hourly profit rate based on recent performance"""
        try:
            # Need at least two data points
            if len(self._performance_history) < 2:
                return 0.0
                
            # Get the most recent record and one from an hour ago
            latest = self._performance_history[-1]
            
            # Find a record from approximately an hour ago
            hour_ago = time.time() - 3600
            record_hour_ago = None
            
            for record in reversed(self._performance_history):
                if record["timestamp"] <= hour_ago:
                    record_hour_ago = record
                    break
            
            # If no record an hour ago, use the oldest available
            if not record_hour_ago:
                record_hour_ago = self._performance_history[0]
            
            # Calculate profit gained during this period
            profit_gained = latest["total_profit"] - record_hour_ago["total_profit"]
            time_elapsed = (latest["timestamp"] - record_hour_ago["timestamp"]) / 3600  # Convert to hours
            
            if time_elapsed <= 0:
                return 0.0
                
            hourly_rate = profit_gained / time_elapsed
            return hourly_rate
            
        except Exception as e:
            logger.error(f"Error calculating hourly profit rate: {e}")
            return 0.0
    
    def _save_profit_report(self, report: Dict[str, Any]):
        """Save the profit report to a file"""
        try:
            # Create reports directory if it doesn't exist
            os.makedirs("reports", exist_ok=True)
            
            # Format timestamp for filename
            timestamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(report["timestamp"]))
            filename = f"reports/profit_report_{timestamp}.json"
            
            # Write the report to a file
            with open(filename, "w") as file:
                json.dump(report, file, indent=2)
                
            logger.info(f"Profit report saved to {filename}")
            
        except Exception as e:
            logger.error(f"Error saving profit report: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get the current status of the Ultimate Trading Engine
        
        Returns:
            Dictionary with status information
        """
        return {
            "running": self.running,
            "activation_complete": self._activation_sequence_complete,
            "profit_mode": self._profit_generation_mode,
            "total_profit": self._total_profit,
            "total_trades": self._total_trades,
            "strategy_allocations": self._strategy_allocations,
            "hourly_profit_rate": self._calculate_hourly_profit_rate()
        }
    
    def set_profit_mode(self, mode: str) -> bool:
        """
        Set the profit generation mode
        
        Args:
            mode: Profit generation mode ("conservative", "balanced", or "aggressive")
            
        Returns:
            Success status
        """
        valid_modes = ["conservative", "balanced", "aggressive"]
        if mode not in valid_modes:
            logger.error(f"Invalid profit mode: {mode}. Valid modes: {', '.join(valid_modes)}")
            return False
            
        self._profit_generation_mode = mode
        logger.info(f"Profit generation mode set to: {mode}")
        
        # Trigger reallocation
        self._last_rebalance_time = 0
        
        return True

# Create global instance
ultimate_engine = UltimateTradingEngine()

# API functions
async def start_ultimate_engine():
    """Start the Ultimate Trading Engine"""
    await ultimate_engine.start()

async def stop_ultimate_engine():
    """Stop the Ultimate Trading Engine"""
    await ultimate_engine.stop()

async def get_ultimate_engine_status() -> Dict[str, Any]:
    """Get current status of the Ultimate Trading Engine"""
    return ultimate_engine.get_status()

async def set_profit_mode(mode: str) -> bool:
    """Set the profit generation mode"""
    return ultimate_engine.set_profit_mode(mode)