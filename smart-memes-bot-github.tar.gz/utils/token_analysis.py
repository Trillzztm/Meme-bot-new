"""
Advanced token analysis module for SMART MEMES BOT.

This module provides comprehensive token analysis including:
- Real-time price tracking
- Price change monitoring
- Performance analysis
- Technical indicators

Uses Birdeye API for Solana token data.
"""

import aiohttp
import time
import asyncio
import logging
import os
from typing import Dict, Any, Optional, List

# Configure logger
logger = logging.getLogger(__name__)

# API key for Birdeye - using environment variable for security
BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY", "birdeye_demo_key")

async def get_token_price(token_address: str) -> Dict[str, Any]:
    """
    Get current token price from Birdeye API.
    
    Args:
        token_address: The token address to check
        
    Returns:
        Dictionary with token price data
    """
    async with aiohttp.ClientSession() as session:
        try:
            # Get current price from Birdeye API
            url = f"https://public-api.birdeye.so/public/price?address={token_address}"
            headers = {"X-API-KEY": BIRDEYE_API_KEY}
            
            async with session.get(url, headers=headers) as res:
                if res.status != 200:
                    logger.error(f"Birdeye API error: {res.status}")
                    return {"error": f"API returned status {res.status}"}
                
                data = await res.json()
                if "data" not in data or "value" not in data["data"]:
                    logger.error(f"Unexpected Birdeye API response: {data}")
                    return {"error": "Invalid API response format"}
                
                return {
                    "price": data["data"]["value"],
                    "timestamp": int(time.time()),
                    "success": True
                }

        except Exception as e:
            logger.error(f"Error getting token price: {str(e)}")
            return {"error": str(e), "success": False}

async def get_price_5min_later(token_address: str) -> Dict[str, Any]:
    """
    Get price data now and after 5 minutes to track performance.
    
    Args:
        token_address: The token address to check
        
    Returns:
        Dictionary with initial and 5-minute prices and change percentage
    """
    try:
        # Get current price
        initial_data = await get_token_price(token_address)
        if "error" in initial_data:
            return initial_data
        
        current_price = initial_data["price"]
        logger.info(f"Initial price for {token_address}: {current_price}")
        
        # Wait 5 minutes
        await asyncio.sleep(300)  # 5 minutes
        
        # Get new price
        new_data = await get_token_price(token_address)
        if "error" in new_data:
            return {
                "initial": current_price,
                "error_after_5min": new_data["error"],
                "success": False
            }
        
        new_price = new_data["price"]
        
        # Calculate change percentage
        if current_price > 0:
            price_change = ((new_price - current_price) / current_price) * 100
        else:
            price_change = 0
            
        # Calculate performance multiplier (e.g., 1.5x means 50% gain)
        performance_multiplier = new_price / current_price if current_price > 0 else 0
        
        return {
            "initial": current_price,
            "after_5min": new_price,
            "change_percent": round(price_change, 2),
            "performance_multiplier": round(performance_multiplier, 2),
            "success": True,
            "timestamp": int(time.time())
        }

    except Exception as e:
        logger.error(f"Error in price monitoring: {str(e)}")
        return {"error": str(e), "success": False}

async def get_token_info(token_address: str) -> Dict[str, Any]:
    """
    Get comprehensive token information from Birdeye API.
    
    Args:
        token_address: The token address to check
        
    Returns:
        Dictionary with detailed token information
    """
    async with aiohttp.ClientSession() as session:
        try:
            # Get token info from Birdeye API
            url = f"https://public-api.birdeye.so/public/token_list?address={token_address}"
            headers = {"X-API-KEY": BIRDEYE_API_KEY}
            
            async with session.get(url, headers=headers) as res:
                if res.status != 200:
                    logger.error(f"Birdeye API error: {res.status}")
                    return {"error": f"API returned status {res.status}"}
                
                data = await res.json()
                return {
                    "data": data["data"],
                    "timestamp": int(time.time()),
                    "success": True
                }

        except Exception as e:
            logger.error(f"Error getting token info: {str(e)}")
            return {"error": str(e), "success": False}

async def get_price_history(token_address: str, days: int = 1) -> Dict[str, Any]:
    """
    Get historical price data for token.
    
    Args:
        token_address: The token address to check
        days: Number of days of history to fetch (default: 1)
        
    Returns:
        Dictionary with historical price data
    """
    async with aiohttp.ClientSession() as session:
        try:
            # Determine time interval based on days
            if days <= 1:
                interval = "1H"  # 1 hour intervals for 1 day
            elif days <= 7:
                interval = "4H"  # 4 hour intervals for up to 7 days
            else:
                interval = "1D"  # 1 day intervals for longer periods
                
            # Calculate start timestamp
            end_time = int(time.time())
            start_time = end_time - (days * 24 * 60 * 60)
            
            # Get price history from Birdeye API
            url = f"https://public-api.birdeye.so/public/history?address={token_address}&interval={interval}&type=price"
            headers = {"X-API-KEY": BIRDEYE_API_KEY}
            
            async with session.get(url, headers=headers) as res:
                if res.status != 200:
                    logger.error(f"Birdeye API error: {res.status}")
                    return {"error": f"API returned status {res.status}"}
                
                data = await res.json()
                return {
                    "history": data["data"],
                    "interval": interval,
                    "days": days,
                    "success": True
                }

        except Exception as e:
            logger.error(f"Error getting price history: {str(e)}")
            return {"error": str(e), "success": False}

async def analyze_token_performance(token_address: str) -> Dict[str, Any]:
    """
    Comprehensive token performance analysis.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Dictionary with detailed performance analysis
    """
    try:
        # Get current price
        price_data = await get_token_price(token_address)
        if "error" in price_data:
            return price_data
            
        # Get token info
        info_data = await get_token_info(token_address)
        if "error" in info_data:
            info_data = {"data": {}}  # Use empty data if error
            
        # Get 24hr price history
        history_data = await get_price_history(token_address, 1)
        if "error" in history_data:
            history_data = {"history": []}  # Use empty history if error
            
        # Extract data for analysis
        current_price = price_data.get("price", 0)
        token_info = info_data.get("data", {})
        price_history = history_data.get("history", [])
        
        # Calculate metrics if we have history data
        if price_history and len(price_history) > 1:
            # Get oldest and newest prices in the history
            oldest_price = price_history[0]["value"] if price_history else current_price
            
            # Calculate 24hr change
            price_change_24h = ((current_price - oldest_price) / oldest_price * 100) if oldest_price > 0 else 0
            
            # Calculate volatility (standard deviation of price changes)
            if len(price_history) > 2:
                price_changes = []
                for i in range(1, len(price_history)):
                    prev_price = price_history[i-1]["value"]
                    curr_price = price_history[i]["value"]
                    if prev_price > 0:
                        pct_change = (curr_price - prev_price) / prev_price * 100
                        price_changes.append(pct_change)
                
                import numpy as np
                volatility = np.std(price_changes) if price_changes else 0
            else:
                volatility = 0
                
            # Determine trend
            if price_change_24h > 5:
                trend = "Strong Uptrend"
            elif price_change_24h > 2:
                trend = "Uptrend"
            elif price_change_24h < -5:
                trend = "Strong Downtrend"
            elif price_change_24h < -2:
                trend = "Downtrend"
            else:
                trend = "Sideways"
        else:
            price_change_24h = 0
            volatility = 0
            trend = "Unknown"
            
        # Build analysis results
        analysis = {
            "token_address": token_address,
            "current_price": current_price,
            "price_change_24h": round(price_change_24h, 2),
            "volatility": round(volatility, 2),
            "trend": trend,
            "token_name": token_info.get("name", "Unknown"),
            "token_symbol": token_info.get("symbol", "Unknown"),
            "analysis_timestamp": int(time.time()),
            "success": True
        }
        
        return analysis
            
    except Exception as e:
        logger.error(f"Error analyzing token performance: {str(e)}")
        return {"error": str(e), "success": False}

# Example usage
async def example():
    # Test with a real Solana token address
    token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC on Solana
    
    # Get current price
    price = await get_token_price(token_address)
    print(f"Current price: {price}")
    
    # Get comprehensive analysis
    analysis = await analyze_token_performance(token_address)
    print(f"Analysis: {analysis}")
    
if __name__ == "__main__":
    # For testing
    asyncio.run(example())