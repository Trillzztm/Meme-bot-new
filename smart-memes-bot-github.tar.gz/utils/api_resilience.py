"""
API resilience utilities for SMART MEMES BOT.

This module provides utilities for enhancing API resilience, including:
- Retry mechanisms with exponential backoff
- Circuit breakers for failing APIs
- Fallback mechanisms for multiple data sources
- Health monitoring and reporting
"""

import time
import asyncio
import logging
import random
from typing import Callable, Dict, Any, Optional, List, Tuple, TypeVar, Union
from functools import wraps
import json
import os

# Configure logger
logger = logging.getLogger(__name__)

# Type for return value of wrapped functions
T = TypeVar('T')

# API health status storage
API_STATUS = {
    "last_updated": 0,
    "services": {}
}

# Directory for storing API status
DATA_DIR = "data/metrics"
API_STATUS_FILE = os.path.join(DATA_DIR, "api_status.json")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

class CircuitBreaker:
    """
    Circuit breaker pattern implementation.
    
    This prevents repeatedly calling failing APIs and allows them to recover.
    """
    
    def __init__(self, name: str, failure_threshold: int = 5, recovery_timeout: int = 60):
        """
        Initialize a circuit breaker.
        
        Args:
            name: Name of the API/service
            failure_threshold: Number of failures before opening the circuit
            recovery_timeout: Time to wait (seconds) before trying again
        """
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        
        self.failure_count = 0
        self.last_failure_time = 0
        self.state = "closed"  # closed, open, half-open
    
    def record_success(self):
        """Record a successful API call."""
        if self.state == "half-open":
            # On success in half-open state, close the circuit
            self.state = "closed"
            
        # Reset failure count on success
        self.failure_count = 0
    
    def record_failure(self):
        """Record a failed API call."""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        # If we've reached the threshold, open the circuit
        if self.state == "closed" and self.failure_count >= self.failure_threshold:
            self.state = "open"
            logger.warning(f"Circuit breaker for {self.name} is now OPEN due to {self.failure_count} failures")
    
    def can_execute(self) -> bool:
        """
        Check if the API call can be executed.
        
        Returns:
            Whether the call can proceed
        """
        if self.state == "closed":
            return True
            
        if self.state == "open":
            # Check if recovery timeout has passed
            if time.time() - self.last_failure_time > self.recovery_timeout:
                # Transition to half-open state
                self.state = "half-open"
                logger.info(f"Circuit breaker for {self.name} is now HALF-OPEN after recovery timeout")
                return True
            return False
            
        if self.state == "half-open":
            # In half-open state, we allow one test request
            return True
            
        return True  # Default to allowing execution

# Global registry of circuit breakers
CIRCUIT_BREAKERS = {}

def get_circuit_breaker(name: str) -> CircuitBreaker:
    """
    Get or create a circuit breaker for an API.
    
    Args:
        name: Name of the API/service
        
    Returns:
        CircuitBreaker instance
    """
    if name not in CIRCUIT_BREAKERS:
        CIRCUIT_BREAKERS[name] = CircuitBreaker(name)
    return CIRCUIT_BREAKERS[name]

def with_circuit_breaker(api_name: str):
    """
    Decorator to apply circuit breaker pattern to API calls.
    
    Args:
        api_name: Name of the API/service
        
    Returns:
        Decorated function
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            circuit_breaker = get_circuit_breaker(api_name)
            
            # Check if circuit is open
            if not circuit_breaker.can_execute():
                logger.warning(f"Circuit breaker for {api_name} is open, skipping call")
                return None
            
            try:
                # Execute the function
                result = await func(*args, **kwargs)
                
                # Record success
                circuit_breaker.record_success()
                return result
            except Exception as e:
                # Record failure
                circuit_breaker.record_failure()
                logger.error(f"API call to {api_name} failed: {str(e)}")
                # Re-raise the exception
                raise
                
        return wrapper
    return decorator

def with_retry(max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 10.0, backoff_factor: float = 2.0):
    """
    Decorator to retry API calls with exponential backoff.
    
    Args:
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries (seconds)
        max_delay: Maximum delay between retries (seconds)
        backoff_factor: Factor to increase delay with each retry
        
    Returns:
        Decorated function
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            retries = 0
            delay = base_delay
            
            while True:
                try:
                    # Execute the function
                    return await func(*args, **kwargs)
                except Exception as e:
                    retries += 1
                    
                    # If we've reached max retries, re-raise the exception
                    if retries >= max_retries:
                        logger.error(f"Max retries ({max_retries}) reached for {func.__name__}: {str(e)}")
                        raise
                    
                    # Add jitter to delay
                    jitter = random.uniform(0.8, 1.2)
                    actual_delay = min(delay * jitter, max_delay)
                    
                    logger.warning(f"Retry {retries}/{max_retries} for {func.__name__} after {actual_delay:.2f}s: {str(e)}")
                    
                    # Wait before retrying
                    await asyncio.sleep(actual_delay)
                    
                    # Increase delay for next retry
                    delay = min(delay * backoff_factor, max_delay)
                    
        return wrapper
    return decorator

def with_fallback(fallback_func: Optional[Callable] = None, default_value: Any = None):
    """
    Decorator to provide fallback for API calls.
    
    Args:
        fallback_func: Function to call as fallback
        default_value: Default value to return if fallback also fails
        
    Returns:
        Decorated function
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                # Execute the primary function
                return await func(*args, **kwargs)
            except Exception as primary_error:
                # Log the primary error
                logger.error(f"Primary function {func.__name__} failed: {str(primary_error)}")
                
                # If a fallback function is provided, try it
                if fallback_func:
                    try:
                        logger.info(f"Trying fallback for {func.__name__}")
                        return await fallback_func(*args, **kwargs)
                    except Exception as fallback_error:
                        logger.error(f"Fallback for {func.__name__} also failed: {str(fallback_error)}")
                
                # Return default value if all else fails
                return default_value
                
        return wrapper
    return decorator

async def api_health_check(api_name: str, check_func: Callable[[], Any]) -> Dict[str, Any]:
    """
    Check the health of an API.
    
    Args:
        api_name: Name of the API/service
        check_func: Function to call to check API health
        
    Returns:
        Dictionary with health check results
    """
    result = {
        "name": api_name,
        "status": "unknown",
        "response_time_ms": 0,
        "last_checked": time.time(),
        "error": None
    }
    
    # Check the circuit breaker first
    circuit_breaker = get_circuit_breaker(api_name)
    if not circuit_breaker.can_execute():
        result["status"] = "circuit_open"
        result["error"] = f"Circuit breaker is open (failures: {circuit_breaker.failure_count})"
        return result
    
    # Perform the health check
    start_time = time.time()
    try:
        # Call the check function
        await check_func()
        
        # Record success
        result["status"] = "operational"
        circuit_breaker.record_success()
    except Exception as e:
        # Record failure
        result["status"] = "error"
        result["error"] = str(e)
        circuit_breaker.record_failure()
    finally:
        # Calculate response time
        result["response_time_ms"] = int((time.time() - start_time) * 1000)
    
    # Update API status
    API_STATUS["services"][api_name] = result
    API_STATUS["last_updated"] = time.time()
    
    # Save status to file
    try:
        with open(API_STATUS_FILE, 'w') as f:
            json.dump(API_STATUS, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving API status: {str(e)}")
    
    return result

async def get_api_status(api_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Get the current status of APIs.
    
    Args:
        api_name: Optional specific API name
        
    Returns:
        Dictionary with API status
    """
    # Try to load from file if not recently updated
    if time.time() - API_STATUS.get("last_updated", 0) > 300:  # 5 minutes
        try:
            if os.path.exists(API_STATUS_FILE):
                with open(API_STATUS_FILE, 'r') as f:
                    loaded_status = json.load(f)
                    # Merge with current status
                    for service, status in loaded_status.get("services", {}).items():
                        if service not in API_STATUS["services"]:
                            API_STATUS["services"][service] = status
        except Exception as e:
            logger.error(f"Error loading API status: {str(e)}")
    
    # Return specific API status if requested
    if api_name:
        return API_STATUS["services"].get(api_name, {"status": "unknown"})
    
    # Calculate summary
    operational_count = sum(1 for status in API_STATUS["services"].values() 
                          if status.get("status") == "operational")
    total_count = len(API_STATUS["services"])
    
    # Return overall status
    return {
        "last_updated": API_STATUS.get("last_updated", 0),
        "services": API_STATUS.get("services", {}),
        "operational_count": operational_count,
        "total_count": total_count,
        "status": "healthy" if operational_count == total_count else 
                 "degraded" if operational_count > 0 else "outage"
    }

# Combined decorator for resilient API calls
def resilient_api_call(
    api_name: str, 
    max_retries: int = 3, 
    fallback_func: Optional[Callable] = None, 
    default_value: Any = None
):
    """
    Combined decorator for resilient API calls.
    
    This applies circuit breaker, retry, and fallback patterns.
    
    Args:
        api_name: Name of the API/service
        max_retries: Maximum number of retry attempts
        fallback_func: Function to call as fallback
        default_value: Default value to return if fallback also fails
        
    Returns:
        Decorated function
    """
    def decorator(func):
        # Apply decorators in the correct order
        @wraps(func)
        @with_circuit_breaker(api_name)
        @with_retry(max_retries=max_retries)
        @with_fallback(fallback_func=fallback_func, default_value=default_value)
        async def wrapper(*args, **kwargs):
            return await func(*args, **kwargs)
            
        return wrapper
    return decorator