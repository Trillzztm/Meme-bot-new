"""
Social Proof Analysis System for SMART MEMES BOT.

This module implements the intelligent analysis of token mentions in Telegram groups
and other social channels to score and evaluate the legitimacy and potential of tokens.

The scoring system uses a weighted approach:
- Keywords (launch, presale, etc.): +3 points
- Chart links (dextools, dexscreener): +2 points
- Twitter or website links: +2 points
- Multiple emojis (rockets, moons): +1 point
- Detected excitement level: 0-2 points
- Message length and formatting: 0-1 points

A score ≥ 6 is considered high quality and worth investigating.
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import json
import asyncio
import time

# Configure logger
logger = logging.getLogger(__name__)

# Scoring weights
KEYWORD_SCORE = 3
CHART_LINK_SCORE = 2
WEBSITE_LINK_SCORE = 2
SOCIAL_LINK_SCORE = 2
EMOJI_SCORE = 1
EXCITEMENT_SCORE_MAX = 2
FORMATTING_SCORE_MAX = 1

# Keywords that indicate a potential launch or significant event
LAUNCH_KEYWORDS = [
    "launch", "launching", "launched", "listing", "listed", "presale",
    "stealth", "fair launch", "just launched", "new gem", "moonshot",
    "potential", "moonshot", "going live", "airdrop", "early", "x100",
    "100x", "1000x", "moon", "sending", "massive", "first", "liquidity",
    "lp locked", "safu", "based", "dev", "marketing", "elon", "breakout"
]

# Regex patterns
TOKEN_ADDRESS_PATTERN = r'(?:0x)?[A-Za-z0-9]{32,44}'
CHART_LINK_PATTERN = r'(?:https?://)?(?:www\.)?(?:dextools\.io|dexscreener\.com|poocoin\.app|bogged\.finance|tradingview\.com)'
WEBSITE_LINK_PATTERN = r'(?:https?://)?(?:www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(?:\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(?::\d+)?(?:/\S*)?'
SOCIAL_LINK_PATTERN = r'(?:https?://)?(?:www\.)?(?:twitter\.com|t\.me|medium\.com|github\.com|reddit\.com)'
EMOJI_PATTERN = r'[\U0001F300-\U0001F64F\U0001F680-\U0001F6FF\U0001F700-\U0001F77F\U0001F780-\U0001F7FF\U0001F800-\U0001F8FF\U0001F900-\U0001F9FF\U0001FA00-\U0001FA6F\U0001FA70-\U0001FAFF\U00002702-\U000027B0\U000024C2-\U0001F251]+'

# Excitement indicators
EXCITEMENT_INDICATORS = [
    r'!!+',                      # Multiple exclamation marks
    r'\b(?:LFG|WAGMI|APE|FOMO)\b',  # Crypto slang
    r'\b(?:GEM|HIDDEN GEM)\b',   # Gem references
    r'\b(?:EASY|CRAZY|INSANE|MASSIVE)\b',  # Hyperbole
    r'🚀{2,}',                   # Multiple rocket emojis
    r'💎{2,}',                   # Multiple diamond emojis
    r'🔥{2,}',                   # Multiple fire emojis
    r'\bx(?:10|100|1000|10000)\b',  # Multiplication references
    r'\b(?:MOON|MOONING)\b',     # Moon references
    r'\bDONT MISS\b',            # FOMO inducement
    r'\bALL IN\b',               # Commitment references
    r'\bLOW MC\b',               # Market cap references
    r'\bWILL EXPLODE\b',         # Explosive growth references
    r'\bNEXT 1000X\b'            # Extreme growth claims
]

@dataclass
class MessageAnalysis:
    """Data class to hold message analysis results."""
    message_text: str
    token_addresses: List[str]
    score: float
    score_components: Dict[str, float]
    hype_level: int  # 1-10 scale
    hype_indicators: List[str]
    detected_keywords: List[str]
    links: List[str]
    risk_indicators: List[str]
    timestamp: float
    group_id: Optional[int] = None
    msg_id: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert analysis to dictionary for storage."""
        return {
            "message_text": self.message_text[:200] + ("..." if len(self.message_text) > 200 else ""),
            "token_addresses": self.token_addresses,
            "score": self.score,
            "score_components": self.score_components,
            "hype_level": self.hype_level,
            "hype_indicators": self.hype_indicators,
            "detected_keywords": self.detected_keywords,
            "links": self.links,
            "risk_indicators": self.risk_indicators,
            "timestamp": self.timestamp,
            "group_id": self.group_id,
            "msg_id": self.msg_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MessageAnalysis':
        """Create analysis object from dictionary."""
        return cls(
            message_text=data["message_text"],
            token_addresses=data["token_addresses"],
            score=data["score"],
            score_components=data["score_components"],
            hype_level=data["hype_level"],
            hype_indicators=data["hype_indicators"],
            detected_keywords=data["detected_keywords"],
            links=data["links"],
            risk_indicators=data["risk_indicators"],
            timestamp=data["timestamp"],
            group_id=data.get("group_id"),
            msg_id=data.get("msg_id")
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the analysis."""
        components = []
        for name, value in self.score_components.items():
            if value > 0:
                components.append(f"{name}: +{value}")
        
        tokens = ", ".join(self.token_addresses[:2])
        if len(self.token_addresses) > 2:
            tokens += f" and {len(self.token_addresses) - 2} more"
            
        return (
            f"Score: {self.score:.1f}/10 [{', '.join(components)}]\n"
            f"Hype: {self.hype_level}/10\n"
            f"Tokens: {tokens}\n"
            f"Keywords: {', '.join(self.detected_keywords[:5])}"
        )


def analyze_message(message_text: str, group_id: Optional[int] = None, msg_id: Optional[int] = None) -> MessageAnalysis:
    """
    Analyze a message for token addresses and compute a social proof score.
    
    Args:
        message_text: The text message to analyze
        group_id: Optional group ID where the message was posted
        msg_id: Optional message ID
        
    Returns:
        MessageAnalysis object with detailed scoring
    """
    # Initialize score components
    score_components = {
        "keywords": 0.0,
        "chart_links": 0.0,
        "website_links": 0.0,
        "social_links": 0.0,
        "emojis": 0.0,
        "excitement": 0.0,
        "formatting": 0.0
    }
    
    # Extract token addresses
    token_addresses = extract_token_addresses(message_text)
    
    # No tokens found, return minimal analysis
    if not token_addresses:
        return MessageAnalysis(
            message_text=message_text,
            token_addresses=[],
            score=0.0,
            score_components=score_components,
            hype_level=0,
            hype_indicators=[],
            detected_keywords=[],
            links=[],
            risk_indicators=["no_token_address"],
            timestamp=time.time(),
            group_id=group_id,
            msg_id=msg_id
        )
    
    # Check for launch keywords
    detected_keywords = []
    for keyword in LAUNCH_KEYWORDS:
        if re.search(r'\b' + re.escape(keyword) + r'\b', message_text.lower()):
            detected_keywords.append(keyword)
            
    if detected_keywords:
        score_components["keywords"] = min(len(detected_keywords) * 0.5, 3.0)
    
    # Check for chart links
    chart_links = re.findall(CHART_LINK_PATTERN, message_text, re.IGNORECASE)
    if chart_links:
        score_components["chart_links"] = min(len(chart_links), 2) * CHART_LINK_SCORE / 2
    
    # Check for website links
    website_links = re.findall(WEBSITE_LINK_PATTERN, message_text, re.IGNORECASE)
    website_links = [link for link in website_links if not re.search(CHART_LINK_PATTERN, link, re.IGNORECASE)]
    website_links = [link for link in website_links if not re.search(SOCIAL_LINK_PATTERN, link, re.IGNORECASE)]
    if website_links:
        score_components["website_links"] = min(len(website_links), 2) * WEBSITE_LINK_SCORE / 2
    
    # Check for social links
    social_links = re.findall(SOCIAL_LINK_PATTERN, message_text, re.IGNORECASE)
    if social_links:
        score_components["social_links"] = min(len(social_links), 2) * SOCIAL_LINK_SCORE / 2
    
    # Check for emojis
    emojis = re.findall(EMOJI_PATTERN, message_text)
    if emojis:
        # More emojis = higher score, up to 3 emojis for max score
        score_components["emojis"] = min(len(emojis) / 3, 1.0) * EMOJI_SCORE
    
    # Check for excitement indicators
    hype_indicators = []
    for pattern in EXCITEMENT_INDICATORS:
        if re.search(pattern, message_text, re.IGNORECASE):
            hype_indicators.append(pattern)
            
    if hype_indicators:
        # More hype indicators = higher score, up to 5 indicators for max score
        score_components["excitement"] = min(len(hype_indicators) / 5, 1.0) * EXCITEMENT_SCORE_MAX
    
    # Check for good formatting
    if message_text.count('\n') > 3:  # Message has multiple paragraphs
        score_components["formatting"] = 0.5
    if re.search(r'\*\*.*\*\*', message_text) or re.search(r'__.*__', message_text):  # Bold formatting
        score_components["formatting"] += 0.5
    score_components["formatting"] = min(score_components["formatting"], FORMATTING_SCORE_MAX)
    
    # Calculate total score, normalize to 0-10 scale
    total_score = sum(score_components.values())
    normalized_score = min(total_score, 10.0)
    
    # Calculate hype level (1-10)
    hype_level = calculate_hype_level(message_text, hype_indicators)
    
    # Collect all links
    all_links = chart_links + website_links + social_links
    
    # Check for risk indicators
    risk_indicators = check_risk_indicators(message_text)
    
    return MessageAnalysis(
        message_text=message_text,
        token_addresses=token_addresses,
        score=normalized_score,
        score_components=score_components,
        hype_level=hype_level,
        hype_indicators=hype_indicators,
        detected_keywords=detected_keywords,
        links=all_links,
        risk_indicators=risk_indicators,
        timestamp=time.time(),
        group_id=group_id,
        msg_id=msg_id
    )


def extract_token_addresses(text: str) -> List[str]:
    """
    Extract token addresses from message text.
    Handles multiple formats including 0x prefixes and bare addresses.
    
    Args:
        text: The message text to extract from
        
    Returns:
        List of extracted token addresses
    """
    addresses = re.findall(TOKEN_ADDRESS_PATTERN, text)
    # Deduplicate and filter obvious non-addresses (like long text strings that match the pattern)
    return list(set(addr for addr in addresses if is_valid_address(addr)))


def is_valid_address(address: str) -> bool:
    """
    Validate that a string looks like a real blockchain address.
    
    Args:
        address: The address to validate
        
    Returns:
        True if it looks like a valid address, False otherwise
    """
    # Basic validation - would be expanded to check for network-specific patterns
    # For Ethereum-style:
    if address.startswith('0x'):
        return len(address) == 42 and all(c in '0123456789abcdefABCDEF' for c in address[2:])
    
    # For Solana-style:
    return len(address) >= 32 and len(address) <= 44 and all(c in '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz' for c in address)


def calculate_hype_level(message_text: str, hype_indicators: List[str]) -> int:
    """
    Calculate the hype level for a message on a scale of 1-10.
    
    Args:
        message_text: The message text to analyze
        hype_indicators: Previously detected hype indicators
        
    Returns:
        Hype level from 1-10
    """
    hype_score = 0
    
    # Base score from number of hype indicators
    hype_score += min(len(hype_indicators) * 1.5, 6)
    
    # Additional points for excessive capitalization
    uppercase_ratio = sum(1 for c in message_text if c.isupper()) / max(1, len([c for c in message_text if c.isalpha()]))
    if uppercase_ratio > 0.7 and len(message_text) > 20:
        hype_score += 2
    
    # Additional points for excessive exclamation marks
    exclamation_count = message_text.count('!')
    if exclamation_count > 3:
        hype_score += min(exclamation_count / 3, 2)
    
    # Cap and return as integer
    return min(round(hype_score), 10)


def check_risk_indicators(message_text: str) -> List[str]:
    """
    Check for risk indicators in the message.
    
    Args:
        message_text: The message to check
        
    Returns:
        List of detected risk indicators
    """
    risk_indicators = []
    
    # Check for pump and dump indicators
    if re.search(r'\b(?:pump|pumping|pumped|moon|mooning|100x|1000x)\b', message_text.lower()):
        if not re.search(r'\b(?:fundamentals|utility|usecase|development|team|roadmap)\b', message_text.lower()):
            risk_indicators.append("pump_language_without_substance")
    
    # Check for urgency without details
    if re.search(r'\b(?:urgent|hurry|don\'t miss|last chance|act now)\b', message_text.lower()):
        if len(message_text) < 100:
            risk_indicators.append("urgency_without_details")
    
    # Check for unrealistic promises
    if re.search(r'\b(?:guaranteed|certain|definitely|absolutely|no risk)\b', message_text.lower()):
        risk_indicators.append("unrealistic_promises")
    
    # Check for inconsistencies
    if re.search(r'\b(?:low risk|safe)\b', message_text.lower()) and re.search(r'\b(?:1000x|100x|explosive)\b', message_text.lower()):
        risk_indicators.append("contradictory_claims")
        
    return risk_indicators


def score_to_recommendation(score: float, risk_indicators: List[str]) -> Tuple[str, bool]:
    """
    Convert a social proof score to a trading recommendation.
    
    Args:
        score: The message's social proof score
        risk_indicators: List of detected risk indicators
        
    Returns:
        Tuple of (recommendation text, is_actionable)
    """
    if score >= 8.5:
        if not risk_indicators:
            return "Very high quality - immediate investigation recommended", True
        else:
            return "High score but risk indicators detected - manual review required", False
    elif score >= 6.5:
        if not risk_indicators:
            return "High quality - investigation recommended", True
        else:
            return "Good score but risk indicators detected - proceed with caution", False
    elif score >= 4.5:
        return "Moderate quality - monitor for additional signals", False
    else:
        return "Low quality - not worth investigating", False


# Cache for recent message scores to avoid duplicates
_recent_messages = {}

async def log_message_analysis(analysis: MessageAnalysis) -> None:
    """
    Log a message analysis to the database for learning purposes.
    
    Args:
        analysis: The message analysis to log
    """
    # This function would log the analysis to a database for future learning
    # For now we'll just log it to the console if it's a high-scoring message
    if analysis.score >= 6.0:
        logger.info(f"High scoring message ({analysis.score}) with tokens: {analysis.token_addresses}")
        
        # In a real implementation, we would save this to a database for historical analysis
        # and continuous improvement of the algorithm
        
        # For demonstration, we add to an in-memory cache
        message_key = f"{analysis.group_id}:{','.join(analysis.token_addresses)}"
        _recent_messages[message_key] = analysis.to_dict()


async def analyze_and_log_message(message_text: str, group_id: Optional[int] = None, msg_id: Optional[int] = None) -> MessageAnalysis:
    """
    Analyze a message and log the results if significant.
    
    Args:
        message_text: The message text to analyze
        group_id: Optional group ID where the message was posted
        msg_id: Optional message ID
        
    Returns:
        The message analysis
    """
    analysis = analyze_message(message_text, group_id, msg_id)
    
    # If it has a token and meets minimum score threshold, log it
    if analysis.token_addresses and analysis.score >= 3.0:
        await log_message_analysis(analysis)
        
    return analysis


async def get_recent_high_scoring_mentions(group_id: Optional[int] = None, min_score: float = 6.0) -> List[MessageAnalysis]:
    """
    Get recent high-scoring token mentions.
    
    Args:
        group_id: Optional group ID to filter by
        min_score: Minimum score threshold
        
    Returns:
        List of high-scoring message analyses
    """
    # This would typically fetch from a database
    # For now, we use our in-memory cache
    results = []
    
    for key, analysis_dict in _recent_messages.items():
        analysis = MessageAnalysis.from_dict(analysis_dict)
        
        if analysis.score >= min_score:
            if group_id is None or analysis.group_id == group_id:
                results.append(analysis)
                
    # Sort by score (highest first)
    results.sort(key=lambda a: a.score, reverse=True)
    
    return results


async def get_token_mention_stats(token_address: str) -> Dict[str, Any]:
    """
    Get mention statistics for a specific token.
    
    Args:
        token_address: The token address to check
        
    Returns:
        Dictionary with mention statistics
    """
    # This would typically aggregate data from a database
    # For now, we use our in-memory cache
    mentions = []
    
    for key, analysis_dict in _recent_messages.items():
        analysis = MessageAnalysis.from_dict(analysis_dict)
        
        if token_address in analysis.token_addresses:
            mentions.append(analysis)
                
    if not mentions:
        return {
            "token_address": token_address,
            "total_mentions": 0,
            "average_score": 0,
            "max_score": 0,
            "high_quality_mentions": 0,
            "groups": []
        }
        
    # Calculate statistics
    total_mentions = len(mentions)
    average_score = sum(m.score for m in mentions) / total_mentions
    max_score = max(m.score for m in mentions)
    high_quality_mentions = sum(1 for m in mentions if m.score >= 6.0)
    
    # Group by source
    groups = {}
    for mention in mentions:
        group_id = mention.group_id or 0
        if group_id not in groups:
            groups[group_id] = 0
        groups[group_id] += 1
        
    return {
        "token_address": token_address,
        "total_mentions": total_mentions,
        "average_score": average_score,
        "max_score": max_score,
        "high_quality_mentions": high_quality_mentions,
        "groups": groups
    }


# Test the analyzer
def test_analyzer():
    # Test with a high-quality message
    high_quality = """
    🚀🚀 JUST LAUNCHED: $GALAXY Token 🚀🚀
    
    💎 The next 100x gem has arrived! 💎
    
    Contract: 0x1234567890123456789012345678901234567890
    
    ✅ Liquidity locked for 1 year
    ✅ Contract verified and audited
    ✅ Strong team with previous successful projects
    
    📊 Chart: https://dextools.io/app/token/0x1234567890123456789012345678901234567890
    🌐 Website: https://galaxytoken.io
    💬 Telegram: https://t.me/galaxytoken
    
    DON'T MISS THIS OPPORTUNITY! We're going to the MOON!! 🚀🌙
    """
    
    analysis = analyze_message(high_quality)
    print(f"High quality score: {analysis.score}")
    print(f"Components: {analysis.score_components}")
    print(f"Hype level: {analysis.hype_level}")
    print(f"Token addresses: {analysis.token_addresses}")
    print(f"Recommendation: {score_to_recommendation(analysis.score, analysis.risk_indicators)}")
    
    # Test with a low-quality message
    low_quality = "Check out this token 0x1234567890123456789012345678901234567890"
    
    analysis = analyze_message(low_quality)
    print(f"\nLow quality score: {analysis.score}")
    print(f"Components: {analysis.score_components}")
    print(f"Recommendation: {score_to_recommendation(analysis.score, analysis.risk_indicators)}")


if __name__ == "__main__":
    test_analyzer()