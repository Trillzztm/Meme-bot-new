"""
Message monitoring utilities for SMART MEMES BOT.

This module provides functions to monitor Telegram messages for token addresses
and other indicators of token mentions, enabling the watchgroup functionality.
"""

import logging
import re
from typing import Dict, Any, List, Optional, Set, Tuple

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Regular expressions for matching token addresses
SOLANA_ADDRESS_PATTERN = r'\b[1-9A-HJ-NP-Za-km-z]{32,44}\b'
ETH_ADDRESS_PATTERN = r'\b0x[a-fA-F0-9]{40}\b'

# Keywords that might indicate token mentions
TOKEN_KEYWORDS = {
    'gem', 'moonshot', 'x1000', '100x', 'pump', 'airdrop', 'presale', 'launch',
    'listing', 'liquidity', 'token', 'coin', 'crypto', 'buy', 'dyor', 'nfa',
    'bullish', 'ape', 'rugpull', 'safu', 'contract'
}

# Keywords that might indicate scams
SCAM_KEYWORDS = {
    'send me', 'dm me', 'double your', 'claim your tokens', 'verify your wallet',
    'connect wallet', 'validate your', 'whitelist', 'presale', 'private sale',
    'seed sale', 'free mint', 'claim now'
}

class TokenMention:
    """Class to track token mentions in messages."""
    
    def __init__(self, token_address: str, network: str, message_text: str, user_id: Optional[int] = None):
        self.token_address = token_address
        self.network = network
        self.message_text = message_text
        self.user_id = user_id
        self.mentions = 1
        self.message_ids = set()
        self.safety_score = 0.0  # 0.0 to 1.0, higher is safer
        self.context_keywords = set()
        self.first_seen_timestamp = None
        self.last_seen_timestamp = None
    
    def increment(self, message_text: str, message_id: int, timestamp: int, user_id: Optional[int] = None):
        """Increment the mention count and update metadata."""
        self.mentions += 1
        if message_id:
            self.message_ids.add(message_id)
        if user_id:
            self.user_id = user_id
        if timestamp:
            if not self.first_seen_timestamp:
                self.first_seen_timestamp = timestamp
            self.last_seen_timestamp = timestamp
            
        # Extract context keywords
        self.extract_context_keywords(message_text)
    
    def extract_context_keywords(self, message_text: str):
        """Extract context keywords from a message."""
        if not message_text:
            return
            
        words = set(re.findall(r'\b\w+\b', message_text.lower()))
        self.context_keywords.update(words.intersection(TOKEN_KEYWORDS))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage or serialization."""
        return {
            'token_address': self.token_address,
            'network': self.network,
            'mentions': self.mentions,
            'message_ids': list(self.message_ids),
            'safety_score': self.safety_score,
            'context_keywords': list(self.context_keywords),
            'first_seen_timestamp': self.first_seen_timestamp,
            'last_seen_timestamp': self.last_seen_timestamp,
            'user_id': self.user_id
        }


class GroupMonitor:
    """Class to monitor messages in a Telegram group for token mentions."""
    
    def __init__(self, group_id: str, group_name: Optional[str] = None, 
                 auto_snipe: bool = False, min_mentions: int = 3):
        self.group_id = group_id
        self.group_name = group_name or group_id
        self.auto_snipe = auto_snipe
        self.min_mentions = min_mentions
        self.token_mentions = {}  # Dict[str, TokenMention]
        self.message_count = 0
        self.last_message_timestamp = None
    
    def extract_addresses(self, text: str) -> List[Tuple[str, str]]:
        """Extract token addresses from a message text."""
        addresses = []
        
        # Check for Solana addresses
        solana_matches = re.findall(SOLANA_ADDRESS_PATTERN, text)
        for addr in solana_matches:
            addresses.append((addr, 'solana'))
        
        # Check for Ethereum/EVM addresses
        eth_matches = re.findall(ETH_ADDRESS_PATTERN, text)
        for addr in eth_matches:
            addresses.append((addr, 'ethereum'))
        
        return addresses
    
    def process_message(self, message_text: str, message_id: int, 
                        timestamp: int, user_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Process a message to detect token mentions.
        
        Args:
            message_text: The text of the message
            message_id: The ID of the message
            timestamp: The Unix timestamp of the message
            user_id: The user ID who sent the message
            
        Returns:
            List of new tokens that reached the minimum mention threshold
        """
        self.message_count += 1
        self.last_message_timestamp = timestamp
        
        if not message_text:
            return []
        
        # Extract token addresses
        addresses = self.extract_addresses(message_text)
        
        # Update token mentions
        new_threshold_tokens = []
        
        for addr, network in addresses:
            key = f"{network}:{addr}"
            
            if key in self.token_mentions:
                # Token was already mentioned, increment counter
                mention = self.token_mentions[key]
                old_mentions = mention.mentions
                mention.increment(message_text, message_id, timestamp, user_id)
                
                # Check if this token just reached the threshold
                if old_mentions < self.min_mentions and mention.mentions >= self.min_mentions:
                    new_threshold_tokens.append(mention.to_dict())
            else:
                # New token mention
                mention = TokenMention(addr, network, message_text, user_id)
                mention.first_seen_timestamp = timestamp
                mention.last_seen_timestamp = timestamp
                if message_id:
                    mention.message_ids.add(message_id)
                mention.extract_context_keywords(message_text)
                self.token_mentions[key] = mention
                
                # Check if this token already reached the threshold (unlikely but possible)
                if mention.mentions >= self.min_mentions:
                    new_threshold_tokens.append(mention.to_dict())
        
        return new_threshold_tokens
    
    def get_active_mentions(self, min_count: int = 1) -> List[Dict[str, Any]]:
        """Get token mentions that have at least min_count mentions."""
        return [
            mention.to_dict() for mention in self.token_mentions.values()
            if mention.mentions >= min_count
        ]
    
    def should_auto_snipe(self, token_address: str, network: str) -> bool:
        """
        Check if a token should be auto-sniped.
        
        Args:
            token_address: The token address
            network: The blockchain network
            
        Returns:
            True if the token should be auto-sniped, False otherwise
        """
        if not self.auto_snipe:
            return False
            
        key = f"{network}:{token_address}"
        if key not in self.token_mentions:
            return False
            
        mention = self.token_mentions[key]
        return mention.mentions >= self.min_mentions


def check_scam_indicators(text: str) -> Tuple[bool, List[str]]:
    """
    Check if a message contains indicators of scams.
    
    Args:
        text: The message text
        
    Returns:
        Tuple[bool, List[str]]: (is_likely_scam, reasons)
    """
    if not text:
        return False, []
    
    text_lower = text.lower()
    found_indicators = []
    
    # Check for scam keywords
    for keyword in SCAM_KEYWORDS:
        if keyword in text_lower:
            found_indicators.append(f"Contains scam indicator: '{keyword}'")
    
    # Check for excessive use of emojis
    emoji_count = len(re.findall(r'[\U00010000-\U0010ffff]', text))
    if emoji_count > 10:
        found_indicators.append(f"Excessive emojis ({emoji_count})")
    
    # Check for excessive capitalization
    caps_count = len(re.findall(r'[A-Z]', text))
    if len(text) > 20 and caps_count / len(text) > 0.5:
        found_indicators.append("Excessive capitalization")
    
    # Check for repetitive punctuation
    if re.search(r'[!?]{3,}', text):
        found_indicators.append("Excessive punctuation")
    
    return len(found_indicators) > 0, found_indicators


def extract_token_data_from_text(text: str) -> Dict[str, Any]:
    """
    Extract potential token data from a message text.
    
    Args:
        text: The message text
        
    Returns:
        Dictionary with potential token data
    """
    data = {
        'addresses': [],
        'tickers': [],
        'keywords': [],
        'urls': [],
        'scam_indicators': []
    }
    
    if not text:
        return data
    
    # Extract addresses
    solana_matches = re.findall(SOLANA_ADDRESS_PATTERN, text)
    eth_matches = re.findall(ETH_ADDRESS_PATTERN, text)
    
    data['addresses'] = [
        {'address': addr, 'network': 'solana'} for addr in solana_matches
    ] + [
        {'address': addr, 'network': 'ethereum'} for addr in eth_matches
    ]
    
    # Extract potential tickers (uppercase 2-10 character sequences)
    tickers = re.findall(r'\$([A-Z0-9]{2,10})\b', text)
    data['tickers'] = list(set(tickers))
    
    # Extract keywords
    words = set(re.findall(r'\b\w+\b', text.lower()))
    data['keywords'] = list(words.intersection(TOKEN_KEYWORDS))
    
    # Extract URLs
    urls = re.findall(r'https?://\S+', text)
    data['urls'] = urls
    
    # Check for scam indicators
    is_scam, indicators = check_scam_indicators(text)
    data['scam_indicators'] = indicators
    
    return data