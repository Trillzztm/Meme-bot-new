"""
Enhanced Profit Maximizer for SMART MEMES BOT.

This module provides sophisticated exit strategies and profit-taking mechanisms
that maximize returns while protecting capital using dynamic thresholds,
trailing stops, and market-aware profit targets.
"""

import os
import time
import asyncio
import logging
import json
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta

# Import trading API if available
try:
    from utils.unified_trading_api import execute_trade
    TRADING_API_AVAILABLE = True
except ImportError:
    TRADING_API_AVAILABLE = False
    logging.warning("Unified Trading API not available, profit maximizer will operate in standalone mode")

# Configure logging
logger = logging.getLogger(__name__)

# Profit target tiers with sell percentages
DEFAULT_PROFIT_TARGETS = {
    # Profit multiplier: Sell percentage
    1.5: 0.2,  # 50% profit => Sell 20%
    2.0: 0.3,  # 100% profit (2x) => Sell 30%
    3.0: 0.5,  # 200% profit (3x) => Sell 50%
    5.0: 0.7,  # 400% profit (5x) => Sell 70%
    10.0: 0.9, # 900% profit (10x) => Sell 90%
    20.0: 1.0  # 1900% profit (20x) => Sell 100%
}

# Dynamic trailing stop settings
TRAILING_STOP_SETTINGS = {
    # Price multiplier: Stop distance percentage
    1.0: 0.10,   # Initial 10% trailing stop
    1.5: 0.08,   # At 50% profit: 8% trailing stop
    2.0: 0.07,   # At 100% profit: 7% trailing stop
    3.0: 0.06,   # At 200% profit: 6% trailing stop
    5.0: 0.04,   # At 400% profit: 4% trailing stop
    10.0: 0.02,  # At 900% profit: 2% trailing stop
    20.0: 0.01   # At 1900% profit: 1% trailing stop
}

class EnhancedProfitMaximizer:
    """
    Enhanced Profit Maximizer with advanced exit strategies.
    """
    
    def __init__(self, risk_profile: str = "balanced"):
        """
        Initialize the Enhanced Profit Maximizer.
        
        Args:
            risk_profile: Risk profile (conservative, balanced, aggressive)
        """
        self.risk_profile = risk_profile
        self.active_positions = {}
        self.sell_history = []
        self.running = False
        self.monitoring_task = None
        
        # Adjust profit targets based on risk profile
        self.profit_targets = self._get_adjusted_profit_targets()
    
    def _get_adjusted_profit_targets(self) -> Dict[float, float]:
        """
        Get adjusted profit targets based on risk profile.
        
        Returns:
            Dictionary of profit targets and sell percentages
        """
        targets = DEFAULT_PROFIT_TARGETS.copy()
        
        if self.risk_profile == "conservative":
            # Conservative: Take profits earlier
            return {
                1.3: 0.2,   # 30% profit => Sell 20%
                1.5: 0.3,   # 50% profit => Sell 30%
                2.0: 0.5,   # 100% profit => Sell 50%
                3.0: 0.7,   # 200% profit => Sell 70%
                5.0: 0.9,   # 400% profit => Sell 90%
                7.0: 1.0    # 600% profit => Sell 100%
            }
        elif self.risk_profile == "aggressive":
            # Aggressive: Hold for higher profits
            return {
                2.0: 0.2,   # 100% profit => Sell 20%
                3.0: 0.3,   # 200% profit => Sell 30%
                5.0: 0.5,   # 400% profit => Sell 50%
                10.0: 0.7,  # 900% profit => Sell 70%
                20.0: 0.9,  # 1900% profit => Sell 90%
                50.0: 1.0   # 4900% profit => Sell 100%
            }
        else:
            # Balanced: Use default targets
            return targets
    
    async def start_monitoring(self):
        """Start monitoring active positions for profit-taking opportunities."""
        if self.running:
            logger.warning("Profit maximizer is already running")
            return
        
        self.running = True
        logger.info(f"Starting Enhanced Profit Maximizer with {self.risk_profile} risk profile")
        
        # Start the background monitoring task
        self.monitoring_task = asyncio.create_task(self._monitor_positions())
    
    async def stop_monitoring(self):
        """Stop monitoring active positions."""
        if not self.running:
            logger.warning("Profit maximizer is not running")
            return
        
        self.running = False
        logger.info("Stopping Enhanced Profit Maximizer")
        
        # Cancel the monitoring task
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
    
    async def add_position(self, token_address: str, token_symbol: str, 
                         entry_price: float, amount: float, 
                         custom_targets: Optional[Dict[float, float]] = None) -> str:
        """
        Add a new position to monitor for profit-taking.
        
        Args:
            token_address: Token address
            token_symbol: Token symbol
            entry_price: Entry price
            amount: Amount of tokens
            custom_targets: Optional custom profit targets
            
        Returns:
            Position ID
        """
        position_id = f"pos_{int(time.time())}_{token_address[-6:]}"
        
        # Create position record
        position = {
            "id": position_id,
            "token_address": token_address,
            "token_symbol": token_symbol,
            "entry_price": entry_price,
            "current_price": entry_price,
            "initial_amount": amount,
            "remaining_amount": amount,
            "entry_time": time.time(),
            "last_updated": time.time(),
            "highest_price": entry_price,
            "trailing_stop": entry_price * (1 - TRAILING_STOP_SETTINGS[1.0]),
            "profit_targets": custom_targets or self.profit_targets.copy(),
            "sells": [],
            "status": "active"
        }
        
        # Add to active positions
        self.active_positions[position_id] = position
        
        logger.info(f"Added position {position_id} for {token_symbol} at {entry_price:.8f}")
        return position_id
    
    async def update_position_price(self, position_id: str, current_price: float) -> Dict[str, Any]:
        """
        Update the current price of a position and check for profit-taking opportunities.
        
        Args:
            position_id: Position ID
            current_price: Current token price
            
        Returns:
            Updated position data
        """
        if position_id not in self.active_positions:
            logger.warning(f"Position {position_id} not found")
            return {}
        
        position = self.active_positions[position_id]
        position["current_price"] = current_price
        position["last_updated"] = time.time()
        
        # Calculate current profit multiplier
        entry_price = position["entry_price"]
        profit_multiplier = current_price / entry_price
        
        # Update highest price if new ATH
        if current_price > position["highest_price"]:
            position["highest_price"] = current_price
            
            # Update trailing stop based on profit level
            for level, stop_percentage in sorted(TRAILING_STOP_SETTINGS.items(), reverse=True):
                if profit_multiplier >= level:
                    new_stop = current_price * (1 - stop_percentage)
                    if new_stop > position["trailing_stop"]:
                        old_stop = position["trailing_stop"]
                        position["trailing_stop"] = new_stop
                        logger.info(f"New ATH for {position['token_address']}: ${current_price:.8f}")
                        logger.info(f"Adjusted trailing stop for {position['token_symbol']}: ${new_stop:.8f} ({stop_percentage*100:.1f}% below current price)")
                    break
        
        # Check if we need to execute any sells
        await self._check_profit_targets(position, profit_multiplier)
        await self._check_trailing_stop(position)
        
        return position
    
    async def _check_profit_targets(self, position: Dict[str, Any], profit_multiplier: float) -> bool:
        """
        Check if any profit targets have been hit and execute sells accordingly.
        
        Args:
            position: Position data
            profit_multiplier: Current profit multiplier
            
        Returns:
            True if a sell was executed, False otherwise
        """
        if position["remaining_amount"] <= 0 or position["status"] != "active":
            return False
        
        # Check each profit target in descending order (highest first)
        executed_sell = False
        for target, sell_percentage in sorted(position["profit_targets"].items(), reverse=True):
            if profit_multiplier >= target:
                # Check if we've already taken profit at this level
                target_key = f"target_{target}"
                if target_key in position:
                    continue
                
                # Calculate sell amount
                sell_amount = position["initial_amount"] * sell_percentage
                if sell_amount > position["remaining_amount"]:
                    sell_amount = position["remaining_amount"]
                
                # Execute the sell
                if sell_amount > 0:
                    sell_result = await self._execute_sell(
                        position=position,
                        amount=sell_amount,
                        reason=f"profit_target_{target}x",
                        profit_multiplier=profit_multiplier
                    )
                    
                    if sell_result["success"]:
                        # Mark this target as taken
                        position[target_key] = {
                            "time": time.time(),
                            "price": position["current_price"],
                            "amount": sell_amount,
                            "profit_multiplier": profit_multiplier
                        }
                        
                        # Remove higher targets we've skipped
                        for higher_target in [t for t in position["profit_targets"] if t > target]:
                            position["profit_targets"].pop(higher_target, None)
                        
                        # Remove this target
                        position["profit_targets"].pop(target, None)
                        
                        executed_sell = True
                        logger.info(f"PROFIT TAKING: Selling {sell_percentage*100:.1f}% of position in {position['token_symbol']} at {profit_multiplier:.1f}x profit. Realized profit: ${(sell_amount * position['current_price'] - sell_amount * position['entry_price']):.2f}")
                        break
        
        return executed_sell
    
    async def _check_trailing_stop(self, position: Dict[str, Any]) -> bool:
        """
        Check if the trailing stop has been hit and execute a full sell if needed.
        
        Args:
            position: Position data
            
        Returns:
            True if the trailing stop was hit, False otherwise
        """
        if position["remaining_amount"] <= 0 or position["status"] != "active":
            return False
        
        current_price = position["current_price"]
        trailing_stop = position["trailing_stop"]
        
        if current_price <= trailing_stop:
            # Trailing stop hit, sell remaining position
            sell_result = await self._execute_sell(
                position=position,
                amount=position["remaining_amount"],
                reason="trailing_stop",
                profit_multiplier=current_price / position["entry_price"]
            )
            
            if sell_result["success"]:
                logger.info(f"TRAILING STOP: Selling remaining {position['remaining_amount']} {position['token_symbol']} at {current_price:.8f}")
                position["status"] = "closed"
                return True
        
        return False
    
    async def _execute_sell(self, position: Dict[str, Any], 
                          amount: float, reason: str, 
                          profit_multiplier: float) -> Dict[str, Any]:
        """
        Execute a sell order for a position.
        
        Args:
            position: Position data
            amount: Amount to sell
            reason: Reason for selling
            profit_multiplier: Current profit multiplier
            
        Returns:
            Sell result
        """
        token_address = position["token_address"]
        token_symbol = position["token_symbol"]
        current_price = position["current_price"]
        
        # Create sell record
        sell_record = {
            "position_id": position["id"],
            "token_address": token_address,
            "token_symbol": token_symbol,
            "amount": amount,
            "price": current_price,
            "timestamp": time.time(),
            "reason": reason,
            "profit_multiplier": profit_multiplier,
            "profit_usd": (current_price - position["entry_price"]) * amount
        }
        
        # Execute the sell if trading API is available
        if TRADING_API_AVAILABLE:
            try:
                sell_result = await execute_trade(
                    token_address=token_address,
                    side="sell",
                    amount=amount,
                    token_symbol=token_symbol
                )
                
                sell_record["success"] = sell_result["success"]
                sell_record["result"] = sell_result
                
                if sell_result["success"]:
                    # Update remaining amount
                    position["remaining_amount"] -= amount
                    
                    # Add sell record to position
                    position["sells"].append(sell_record)
                    
                    # Add to global sell history
                    self.sell_history.append(sell_record)
                    
                    # If sold everything, mark position as closed
                    if position["remaining_amount"] <= 0:
                        position["status"] = "closed"
                    
                    return sell_result
                else:
                    logger.warning(f"Failed to execute sell for {token_symbol}: {sell_result.get('error')}")
                    return sell_result
                
            except Exception as e:
                logger.error(f"Error executing sell: {str(e)}")
                sell_record["success"] = False
                sell_record["error"] = str(e)
                return {
                    "success": False,
                    "error": str(e)
                }
        else:
            # Simulate successful sell for demo/testing
            logger.info(f"Would execute sell of {amount} {token_symbol} at {current_price:.8f}")
            
            # Update remaining amount
            position["remaining_amount"] -= amount
            
            # Add sell record to position
            sell_record["success"] = True
            position["sells"].append(sell_record)
            
            # Add to global sell history
            self.sell_history.append(sell_record)
            
            # If sold everything, mark position as closed
            if position["remaining_amount"] <= 0:
                position["status"] = "closed"
            
            return {
                "success": True,
                "simulated": True,
                "token_address": token_address,
                "token_symbol": token_symbol,
                "amount": amount,
                "price": current_price
            }
    
    async def _monitor_positions(self):
        """Background task to monitor positions for profit-taking opportunities."""
        try:
            while self.running:
                # Check active positions
                for position_id, position in list(self.active_positions.items()):
                    if position["status"] != "active":
                        continue
                    
                    # In a real implementation, we would fetch the current price here
                    # For demonstration, we'll use a simulated price that increases over time
                    token_address = position["token_address"]
                    current_time = time.time()
                    elapsed_hours = (current_time - position["entry_time"]) / 3600
                    
                    # Simulate price movement for testing
                    entry_price = position["entry_price"]
                    
                    # Generate some random-but-realistic price movement
                    # This is just for demonstration purposes
                    import random
                    import math
                    
                    # Base growth factor based on token address (deterministic)
                    addr_sum = sum(ord(c) for c in token_address)
                    base_growth = (addr_sum % 10) / 100 + 0.01  # 1-10% hourly growth
                    
                    # Apply some randomness and time-based growth
                    random.seed(int(current_time / 60))  # Change seed every minute
                    volatility = random.uniform(0.8, 1.2)
                    growth_factor = base_growth * volatility
                    
                    # Calculate simulated price
                    simulated_price = entry_price * (1 + growth_factor) ** elapsed_hours
                    
                    # Add some noise/volatility
                    price_noise = random.uniform(0.98, 1.02)
                    simulated_price *= price_noise
                    
                    # Update position with simulated price
                    await self.update_position_price(position_id, simulated_price)
                
                # Wait before next check
                await asyncio.sleep(10)  # Check every 10 seconds
                
        except asyncio.CancelledError:
            logger.info("Position monitoring cancelled")
            raise
        
        except Exception as e:
            logger.error(f"Unexpected error in position monitoring: {str(e)}")
            raise
    
    def get_active_positions(self) -> List[Dict[str, Any]]:
        """
        Get all active positions.
        
        Returns:
            List of active positions
        """
        return [pos for pos in self.active_positions.values() if pos["status"] == "active"]
    
    def get_closed_positions(self) -> List[Dict[str, Any]]:
        """
        Get all closed positions.
        
        Returns:
            List of closed positions
        """
        return [pos for pos in self.active_positions.values() if pos["status"] == "closed"]
    
    def get_sell_history(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent sell history.
        
        Args:
            count: Number of sells to return
            
        Returns:
            List of recent sells
        """
        return self.sell_history[-count:]
    
    def get_position(self, position_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific position by ID.
        
        Args:
            position_id: Position ID
            
        Returns:
            Position data or None if not found
        """
        return self.active_positions.get(position_id)
    
    def set_risk_profile(self, profile: str):
        """
        Set the risk profile.
        
        Args:
            profile: Risk profile (conservative, balanced, aggressive)
        """
        self.risk_profile = profile
        self.profit_targets = self._get_adjusted_profit_targets()
        logger.info(f"Updated risk profile to {profile}")

# Singleton instance
_profit_maximizer = None

async def get_profit_maximizer(risk_profile: str = "balanced") -> EnhancedProfitMaximizer:
    """
    Get the Enhanced Profit Maximizer instance.
    
    Args:
        risk_profile: Risk profile to use
        
    Returns:
        EnhancedProfitMaximizer instance
    """
    global _profit_maximizer
    
    if _profit_maximizer is None:
        _profit_maximizer = EnhancedProfitMaximizer(risk_profile)
        await _profit_maximizer.start_monitoring()
    elif _profit_maximizer.risk_profile != risk_profile:
        _profit_maximizer.set_risk_profile(risk_profile)
    
    return _profit_maximizer

async def insta_profit_smart_sell_enhanced(
    token_address: str,
    token_symbol: str,
    initial_price: float,
    amount: float,
    risk_profile: str = "balanced",
    custom_targets: Optional[Dict[float, float]] = None
) -> str:
    """
    Enhanced version of insta_profit_smart_sell that integrates with the profit maximizer.
    
    Args:
        token_address: Token address
        token_symbol: Token symbol
        initial_price: Initial purchase price
        amount: Amount of tokens
        risk_profile: Risk profile to use
        custom_targets: Optional custom profit targets
        
    Returns:
        Position ID for tracking
    """
    # Get profit maximizer instance
    maximizer = await get_profit_maximizer(risk_profile)
    
    # Add position to monitor
    position_id = await maximizer.add_position(
        token_address=token_address,
        token_symbol=token_symbol,
        entry_price=initial_price,
        amount=amount,
        custom_targets=custom_targets
    )
    
    logger.info(f"Added position {position_id} to profit maximizer for automatic profit-taking")
    return position_id

# Legacy function for backwards compatibility
def insta_profit_smart_sell(initial_price, current_price, amount, bought_time):
    """
    Legacy insta_profit_smart_sell function for backwards compatibility.
    
    Args:
        initial_price: Initial purchase price
        current_price: Current token price
        amount: Amount of tokens
        bought_time: When the token was purchased (timestamp)
        
    Returns:
        True if sold, False otherwise
    """
    # Create a deterministic token address and symbol for the position
    token_address = f"legacy_{bought_time}_{amount}"
    token_symbol = "LEGACY"
    
    # Call async function in a blocking way
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        # Create a new event loop if one doesn't exist
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    # Add position to profit maximizer
    position_id = loop.run_until_complete(
        insta_profit_smart_sell_enhanced(
            token_address=token_address,
            token_symbol=token_symbol,
            initial_price=initial_price,
            amount=amount,
            # Use default risk profile
        )
    )
    
    # Update current price to check if we should sell
    profit_maximizer = loop.run_until_complete(get_profit_maximizer())
    position = loop.run_until_complete(
        profit_maximizer.update_position_price(position_id, current_price)
    )
    
    # Check if any sells were executed
    return len(position.get("sells", [])) > 0

# Example usage
async def test_profit_maximizer():
    """
    Test the profit maximizer functionality.
    """
    logger.info("Testing Enhanced Profit Maximizer")
    
    # Test with different risk profiles
    for risk_profile in ["conservative", "balanced", "aggressive"]:
        logger.info(f"Testing with {risk_profile} risk profile")
        
        # Get profit maximizer instance
        maximizer = await get_profit_maximizer(risk_profile)
        
        # Add a test position
        token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC on Solana
        token_symbol = "TEST"
        entry_price = 0.00001
        amount = 100000
        
        position_id = await maximizer.add_position(
            token_address=token_address,
            token_symbol=token_symbol,
            entry_price=entry_price,
            amount=amount
        )
        
        logger.info(f"Added test position {position_id}")
        
        # Simulate price increases and profit-taking
        price_multipliers = [1.1, 1.5, 2.0, 3.0, 5.0, 10.0]
        
        for multiplier in price_multipliers:
            current_price = entry_price * multiplier
            logger.info(f"Updating price to {current_price:.8f} ({multiplier}x)")
            
            position = await maximizer.update_position_price(position_id, current_price)
            
            # Get remaining amount
            remaining = position["remaining_amount"]
            initial = position["initial_amount"]
            percent_remaining = (remaining / initial) * 100
            
            logger.info(f"Remaining: {remaining} ({percent_remaining:.1f}% of initial)")
            
            # Show sells if any
            if position["sells"]:
                logger.info("Recent sells:")
                for sell in position["sells"][-3:]:
                    logger.info(f"  Sold {sell['amount']} at {sell['price']:.8f} for {sell['profit_multiplier']:.2f}x profit ({sell['reason']})")
            
            await asyncio.sleep(1)  # Brief pause between updates
        
        logger.info(f"Final position status: {position['status']}")
        logger.info("---")
    
    logger.info("Test completed")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_profit_maximizer())