"""
Enhanced Token Safety Analysis for SMART MEMES BOT.

This module provides comprehensive security analysis for cryptocurrency tokens,
detecting potential scams, honeypots, and other high-risk indicators. It uses
multiple evaluation methods including contract analysis, liquidity checks,
ownership verification, and historical data to produce a robust safety score.
"""

import os
import time
import asyncio
import logging
import json
from typing import Dict, List, Tuple, Set, Optional, Union, Any
from datetime import datetime, timedelta

# Try to import enhanced API resilience
try:
    from utils.api_resilience import resilient_request
    API_RESILIENCE_AVAILABLE = True
except ImportError:
    API_RESILIENCE_AVAILABLE = False
    logging.warning("API resilience not available for token safety checks")

# Legacy imports for fallback
try:
    from utils.token_info import check_token_safety as legacy_check_safety
    LEGACY_SAFETY_AVAILABLE = True
except ImportError:
    LEGACY_SAFETY_AVAILABLE = False
    logging.warning("Legacy token safety not available")

# Configure logging
logger = logging.getLogger(__name__)

# Default settings
DEFAULT_SETTINGS = {
    "cache_duration": 300,         # Cache token results for 5 minutes
    "max_cache_size": 1000,        # Maximum tokens in cache
    "min_liquidity": 1000,         # Minimum liquidity in USD
    "min_holders": 10,             # Minimum number of holders
    "max_concentration": 80,       # Maximum % held by top holder (excluding LP)
    "enable_contract_analysis": True,  # Enable smart contract code analysis
    "enable_liquidity_analysis": True, # Enable liquidity analysis
    "enable_holder_analysis": True,    # Enable holder analysis
    "enable_social_proof": True,       # Enable social proof analysis
    "enable_historical_data": True,    # Enable historical data analysis
    "solana_rpc_url": os.environ.get("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com"),
    "birdeye_api_key": os.environ.get("BIRDEYE_API_KEY", "")
}

# Token safety cache
_token_safety_cache = {}

# Security patterns to check in contract source code
SECURITY_RED_FLAGS = [
    "selfdestruct",
    "suicide",
    "hiddenMint",
    "mintHidden",
    "transferOwnership",
    "onlyOwner",
    "freezeAccount",
    "blacklist",
    "honeypot",
    "disable_trading",
    "disableTrading",
    "excludeFromFee",
    "includeInFee"
]

# Honeypot patterns indicating potential scams
HONEYPOT_PATTERNS = [
    "cantSell",
    "lockTrading",
    "blockSelling",
    "preventSell",
    "_sellBlocked",
    "transferFrozen",
    "tradingPaused",
    "maxSellAmount",
    "maxSellLimit"
]

class EnhancedTokenSafety:
    """
    Enhanced Token Safety Analysis system with multi-layered checks.
    """
    
    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        """
        Initialize the Enhanced Token Safety system.
        
        Args:
            settings: Optional custom settings
        """
        self.settings = DEFAULT_SETTINGS.copy()
        if settings:
            self.settings.update(settings)
            
        # Load token reputation data if available
        self.token_reputation = self._load_token_reputation()
        
        # Initialize analysis components
        self.last_cache_cleanup = time.time()
        
        logger.info("Enhanced Token Safety system initialized")
    
    def _load_token_reputation(self) -> Dict[str, Dict[str, Any]]:
        """
        Load token reputation data from storage.
        
        Returns:
            Dictionary of token reputation data
        """
        reputation_file = "data/config/token_reputation.json"
        
        try:
            if os.path.exists(reputation_file):
                with open(reputation_file, 'r') as f:
                    reputation = json.load(f)
                logger.info(f"Loaded reputation data for {len(reputation)} tokens")
                return reputation
            else:
                # Create empty file
                os.makedirs(os.path.dirname(reputation_file), exist_ok=True)
                with open(reputation_file, 'w') as f:
                    json.dump({}, f)
                logger.info("Created empty token reputation file")
                return {}
        except Exception as e:
            logger.error(f"Error loading token reputation data: {str(e)}")
            return {}
    
    def _save_token_reputation(self):
        """Save token reputation data to storage."""
        reputation_file = "data/config/token_reputation.json"
        
        try:
            os.makedirs(os.path.dirname(reputation_file), exist_ok=True)
            with open(reputation_file, 'w') as f:
                json.dump(self.token_reputation, f, indent=2)
            logger.info(f"Saved reputation data for {len(self.token_reputation)} tokens")
        except Exception as e:
            logger.error(f"Error saving token reputation data: {str(e)}")
    
    def _cleanup_cache(self):
        """Clean up expired cache entries."""
        global _token_safety_cache
        
        current_time = time.time()
        # Only cleanup periodically
        if current_time - self.last_cache_cleanup < 60:  # Once per minute at most
            return
            
        self.last_cache_cleanup = current_time
        
        # Find expired entries
        expired_keys = []
        for token_address, cache_entry in _token_safety_cache.items():
            if current_time - cache_entry["timestamp"] > self.settings["cache_duration"]:
                expired_keys.append(token_address)
        
        # Remove expired entries
        for key in expired_keys:
            del _token_safety_cache[key]
        
        # If still too large, remove oldest entries
        if len(_token_safety_cache) > self.settings["max_cache_size"]:
            # Sort by timestamp (oldest first)
            sorted_cache = sorted(_token_safety_cache.items(), key=lambda x: x[1]["timestamp"])
            # Remove oldest entries
            to_remove = len(sorted_cache) - self.settings["max_cache_size"]
            for i in range(to_remove):
                del _token_safety_cache[sorted_cache[i][0]]
        
        logger.debug(f"Cleaned {len(expired_keys)} expired entries from token safety cache")
    
    async def analyze_token_safety(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Perform comprehensive token safety analysis.
        
        Args:
            token_address: Token address to analyze
            
        Returns:
            Tuple of (safety score, detailed analysis)
        """
        # Check cache first
        global _token_safety_cache
        if token_address in _token_safety_cache:
            cache_entry = _token_safety_cache[token_address]
            # Check if cache is still valid
            if time.time() - cache_entry["timestamp"] < self.settings["cache_duration"]:
                logger.debug(f"Using cached safety analysis for {token_address}")
                return cache_entry["score"], cache_entry["details"]
        
        # Clean up cache periodically
        self._cleanup_cache()
        
        # Check if we have reputation data for this token
        if token_address in self.token_reputation:
            reputation = self.token_reputation[token_address]
            
            # If token is explicitly marked as safe or unsafe, use that
            if reputation.get("verified_safe", False):
                logger.info(f"Token {token_address} is verified safe in reputation database")
                result = (1.0, {"reputation": "verified_safe", "source": "reputation_database"})
                
                # Add to cache
                _token_safety_cache[token_address] = {
                    "score": result[0],
                    "details": result[1],
                    "timestamp": time.time()
                }
                
                return result
                
            if reputation.get("verified_scam", False):
                logger.info(f"Token {token_address} is verified scam in reputation database")
                result = (0.0, {"reputation": "verified_scam", "source": "reputation_database"})
                
                # Add to cache
                _token_safety_cache[token_address] = {
                    "score": result[0],
                    "details": result[1],
                    "timestamp": time.time()
                }
                
                return result
        
        # Perform full analysis with all available methods
        analysis_results = {}
        score_weights = {}
        
        # Contract analysis
        if self.settings["enable_contract_analysis"]:
            try:
                contract_score, contract_details = await self._analyze_contract(token_address)
                analysis_results["contract"] = contract_details
                score_weights["contract"] = 0.35  # 35% weight
            except Exception as e:
                logger.error(f"Error in contract analysis: {str(e)}")
                # If contract analysis fails, still continue with other checks
        
        # Liquidity analysis
        if self.settings["enable_liquidity_analysis"]:
            try:
                liquidity_score, liquidity_details = await self._analyze_liquidity(token_address)
                analysis_results["liquidity"] = liquidity_details
                score_weights["liquidity"] = 0.25  # 25% weight
            except Exception as e:
                logger.error(f"Error in liquidity analysis: {str(e)}")
        
        # Holder analysis
        if self.settings["enable_holder_analysis"]:
            try:
                holder_score, holder_details = await self._analyze_holders(token_address)
                analysis_results["holders"] = holder_details
                score_weights["holders"] = 0.20  # 20% weight
            except Exception as e:
                logger.error(f"Error in holder analysis: {str(e)}")
        
        # Social proof analysis
        if self.settings["enable_social_proof"]:
            try:
                social_score, social_details = await self._analyze_social_proof(token_address)
                analysis_results["social"] = social_details
                score_weights["social"] = 0.10  # 10% weight
            except Exception as e:
                logger.error(f"Error in social proof analysis: {str(e)}")
        
        # Historical data analysis
        if self.settings["enable_historical_data"]:
            try:
                historical_score, historical_details = await self._analyze_historical_data(token_address)
                analysis_results["historical"] = historical_details
                score_weights["historical"] = 0.10  # 10% weight
            except Exception as e:
                logger.error(f"Error in historical data analysis: {str(e)}")
        
        # If all analyses failed, fall back to legacy method
        if not analysis_results:
            return await self._legacy_safety_check(token_address)
        
        # Calculate weighted average score
        total_weight = sum(score_weights.values())
        if total_weight == 0:
            # If all weights are zero, use simple average
            safety_score = sum(r[0] for r in [
                (contract_score, contract_details),
                (liquidity_score, liquidity_details),
                (holder_score, holder_details),
                (social_score, social_details),
                (historical_score, historical_details)
            ] if r[1] is not None) / len([r for r in [
                (contract_score, contract_details),
                (liquidity_score, liquidity_details),
                (holder_score, holder_details),
                (social_score, social_details),
                (historical_score, historical_details)
            ] if r[1] is not None])
        else:
            # Calculate weighted average
            safety_score = sum(analysis_results[key]["score"] * score_weights[key] for key in analysis_results) / total_weight
        
        # Final safety check - if any critical issues, cap the score
        critical_issues = []
        
        # Check for critical contract issues
        if "contract" in analysis_results and analysis_results["contract"].get("critical_issues"):
            critical_issues.extend(analysis_results["contract"]["critical_issues"])
        
        # Check for critical liquidity issues
        if "liquidity" in analysis_results:
            if analysis_results["liquidity"].get("liquidity_usd", 0) < self.settings["min_liquidity"]:
                critical_issues.append(f"Insufficient liquidity: ${analysis_results['liquidity'].get('liquidity_usd', 0)}")
        
        # Check for critical holder issues
        if "holders" in analysis_results:
            if analysis_results["holders"].get("top_holder_percentage", 0) > self.settings["max_concentration"]:
                critical_issues.append(f"High concentration: Top holder owns {analysis_results['holders'].get('top_holder_percentage', 0)}%")
        
        # If any critical issues, cap score at 0.3
        if critical_issues:
            safety_score = min(safety_score, 0.3)
            analysis_results["critical_issues"] = critical_issues
        
        # Add risk level based on score
        if safety_score >= 0.8:
            risk_level = "low"
        elif safety_score >= 0.5:
            risk_level = "medium"
        elif safety_score >= 0.3:
            risk_level = "high"
        else:
            risk_level = "extreme"
        
        # Add overall results
        final_details = {
            "safety_score": safety_score,
            "risk_level": risk_level,
            "analysis_timestamp": time.time(),
            "analysis_methods": list(analysis_results.keys()),
            "critical_issues": critical_issues,
            **analysis_results
        }
        
        # Add to cache
        _token_safety_cache[token_address] = {
            "score": safety_score,
            "details": final_details,
            "timestamp": time.time()
        }
        
        logger.info(f"Completed safety analysis for {token_address}: Score {safety_score:.2f}, Risk {risk_level}")
        
        return safety_score, final_details
    
    async def _analyze_contract(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Analyze token smart contract for security issues.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        # This would connect to a blockchain explorer API or use a local copy
        # of verified contract source code to analyze it
        
        # For testing/simulation, we'll use a generated result
        
        # In real implementation, you would:
        # 1. Get contract source code from blockchain explorer API
        # 2. Analyze for red flags, security issues, etc.
        # 3. Check if contract is verified
        # 4. Check ownership structure
        # 5. Check for malicious functions
        
        try:
            # Simulate API call to get contract data
            if API_RESILIENCE_AVAILABLE:
                # Use resilient request wrapper
                contract_data = await resilient_request(
                    "get_contract_data",
                    token_address
                )
            else:
                # For testing, generate synthetic data
                import random
                random.seed(token_address)  # Make it deterministic for testing
                
                contract_data = {
                    "verified": random.random() > 0.2,  # 80% are verified
                    "proxy": random.random() > 0.7,     # 30% are proxy contracts
                    "owner": "OwnerWallet" + str(random.randint(1000, 9999)),
                    "implementation": "ImplWallet" + str(random.randint(1000, 9999)) if random.random() > 0.7 else None,
                    "creation_date": time.time() - random.randint(86400, 8640000),  # 1-100 days old
                    "compiler_version": "0.8." + str(random.randint(0, 17)),
                    "has_timelock": random.random() > 0.7,
                    "renounced": random.random() > 0.6,
                    "functions": random.sample([
                        "transfer", "approve", "transferFrom", "balanceOf", "mint", "burn",
                        "pause", "unpause", "setFee", "excludeFromFee", "updateMaxTxAmount"
                    ], random.randint(5, 10))
                }
                
                # Slight chance of adding a malicious function
                if random.random() < 0.1:
                    malicious = random.choice(SECURITY_RED_FLAGS)
                    contract_data["functions"].append(malicious)
                
                # Very slight chance of adding a honeypot function
                if random.random() < 0.05:
                    honeypot = random.choice(HONEYPOT_PATTERNS)
                    contract_data["functions"].append(honeypot)
            
            # Analyze the contract data
            security_issues = []
            critical_issues = []
            security_strengths = []
            
            # Check for red flags in functions
            for func in contract_data.get("functions", []):
                if func in SECURITY_RED_FLAGS:
                    security_issues.append(f"Potentially harmful function: {func}")
                
                if func in HONEYPOT_PATTERNS:
                    critical_issues.append(f"Potential honeypot function: {func}")
            
            # Check contract verification
            if not contract_data.get("verified", False):
                security_issues.append("Contract source code not verified")
            else:
                security_strengths.append("Contract source code verified")
            
            # Check ownership
            if contract_data.get("renounced", False):
                security_strengths.append("Ownership renounced")
            
            if contract_data.get("has_timelock", False):
                security_strengths.append("Has timelock on sensitive functions")
            
            # Calculate score based on issues and strengths
            base_score = 0.7  # Start with a base score
            
            # Deduct for security issues
            issue_penalty = 0.1 * len(security_issues)
            # Larger penalty for critical issues
            critical_penalty = 0.3 * len(critical_issues)
            
            # Bonus for security strengths
            strength_bonus = 0.1 * len(security_strengths)
            
            # Calculate final score
            contract_score = max(0.0, min(1.0, base_score - issue_penalty - critical_penalty + strength_bonus))
            
            # Prepare result details
            details = {
                "score": contract_score,
                "security_issues": security_issues,
                "critical_issues": critical_issues,
                "security_strengths": security_strengths,
                "verified": contract_data.get("verified", False),
                "owner_renounced": contract_data.get("renounced", False),
                "has_timelock": contract_data.get("has_timelock", False),
                "proxy": contract_data.get("proxy", False),
                "creation_date": contract_data.get("creation_date", 0)
            }
            
            return contract_score, details
            
        except Exception as e:
            logger.error(f"Error analyzing contract for {token_address}: {str(e)}")
            # Return a neutral score with error details
            return 0.5, {
                "score": 0.5,
                "error": f"Error analyzing contract: {str(e)}",
                "analysis_status": "failed"
            }
    
    async def _analyze_liquidity(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Analyze token liquidity.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        try:
            # Simulate API call to get liquidity data
            if API_RESILIENCE_AVAILABLE:
                # Use resilient request wrapper
                liquidity_data = await resilient_request(
                    "get_token_liquidity",
                    token_address
                )
            else:
                # For testing, generate synthetic data
                import random
                random.seed(token_address + "liquidity")  # Make it deterministic for testing
                
                liquidity_data = {
                    "liquidity_usd": random.uniform(100, 50000),
                    "liquidity_locked": random.random() > 0.3,  # 70% are locked
                    "lock_duration_days": random.randint(30, 365) if random.random() > 0.3 else 0,
                    "lock_percentage": random.uniform(70, 100) if random.random() > 0.3 else random.uniform(0, 70),
                    "lp_holders": random.randint(1, 10),
                    "top_lp_percentage": random.uniform(50, 100)
                }
            
            # Analyze the liquidity data
            liquidity_issues = []
            critical_issues = []
            liquidity_strengths = []
            
            # Check liquidity amount
            liquidity_usd = liquidity_data.get("liquidity_usd", 0)
            if liquidity_usd < self.settings["min_liquidity"]:
                if liquidity_usd < self.settings["min_liquidity"] / 10:
                    critical_issues.append(f"Very low liquidity: ${liquidity_usd:.2f}")
                else:
                    liquidity_issues.append(f"Low liquidity: ${liquidity_usd:.2f}")
            elif liquidity_usd > self.settings["min_liquidity"] * 10:
                liquidity_strengths.append(f"Strong liquidity: ${liquidity_usd:.2f}")
            else:
                liquidity_strengths.append(f"Adequate liquidity: ${liquidity_usd:.2f}")
            
            # Check if liquidity is locked
            if liquidity_data.get("liquidity_locked", False):
                lock_duration = liquidity_data.get("lock_duration_days", 0)
                lock_percentage = liquidity_data.get("lock_percentage", 0)
                
                if lock_duration > 180 and lock_percentage > 90:
                    liquidity_strengths.append(f"Excellent liquidity lock: {lock_percentage:.1f}% for {lock_duration} days")
                elif lock_duration > 90 and lock_percentage > 70:
                    liquidity_strengths.append(f"Good liquidity lock: {lock_percentage:.1f}% for {lock_duration} days")
                elif lock_duration > 30 and lock_percentage > 50:
                    liquidity_strengths.append(f"Basic liquidity lock: {lock_percentage:.1f}% for {lock_duration} days")
                else:
                    liquidity_issues.append(f"Weak liquidity lock: {lock_percentage:.1f}% for {lock_duration} days")
            else:
                liquidity_issues.append("Liquidity not locked")
            
            # Check LP concentration
            top_lp_percentage = liquidity_data.get("top_lp_percentage", 100)
            if top_lp_percentage > 95:
                liquidity_issues.append(f"High LP concentration: {top_lp_percentage:.1f}% held by top holder")
            
            # Calculate score based on issues and strengths
            base_score = 0.7  # Start with a base score
            
            # Liquidity amount score component
            if liquidity_usd < self.settings["min_liquidity"]:
                liq_amount_score = min(0.6, liquidity_usd / self.settings["min_liquidity"])
            else:
                liq_amount_score = min(1.0, 0.6 + 0.4 * min(1.0, liquidity_usd / (self.settings["min_liquidity"] * 10)))
            
            # Liquidity lock score component
            if liquidity_data.get("liquidity_locked", False):
                lock_duration = liquidity_data.get("lock_duration_days", 0)
                lock_percentage = liquidity_data.get("lock_percentage", 0)
                lock_score = min(1.0, (lock_duration / 365) * (lock_percentage / 100))
            else:
                lock_score = 0.0
            
            # LP concentration score component
            top_lp_percentage = liquidity_data.get("top_lp_percentage", 100)
            concentration_score = 1.0 - (top_lp_percentage / 100)
            
            # Calculate final score as weighted average of components
            liquidity_score = 0.4 * liq_amount_score + 0.4 * lock_score + 0.2 * concentration_score
            
            # Prepare result details
            details = {
                "score": liquidity_score,
                "liquidity_usd": liquidity_usd,
                "liquidity_locked": liquidity_data.get("liquidity_locked", False),
                "lock_duration_days": liquidity_data.get("lock_duration_days", 0),
                "lock_percentage": liquidity_data.get("lock_percentage", 0),
                "lp_holders": liquidity_data.get("lp_holders", 1),
                "top_lp_percentage": top_lp_percentage,
                "liquidity_issues": liquidity_issues,
                "critical_issues": critical_issues,
                "liquidity_strengths": liquidity_strengths
            }
            
            return liquidity_score, details
            
        except Exception as e:
            logger.error(f"Error analyzing liquidity for {token_address}: {str(e)}")
            # Return a neutral score with error details
            return 0.5, {
                "score": 0.5,
                "error": f"Error analyzing liquidity: {str(e)}",
                "analysis_status": "failed"
            }
    
    async def _analyze_holders(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Analyze token holder distribution.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        try:
            # Simulate API call to get holder data
            if API_RESILIENCE_AVAILABLE:
                # Use resilient request wrapper
                holder_data = await resilient_request(
                    "get_token_holders",
                    token_address
                )
            else:
                # For testing, generate synthetic data
                import random
                random.seed(token_address + "holders")  # Make it deterministic for testing
                
                # Generate top holders
                top_holders = []
                remaining_percentage = 100.0
                
                # First holder (excluding LP)
                top_percentage = random.uniform(10, 60)
                top_holders.append({
                    "address": "Wallet" + str(random.randint(1000, 9999)),
                    "percentage": top_percentage,
                    "is_contract": random.random() > 0.8
                })
                remaining_percentage -= top_percentage
                
                # LP holder
                lp_percentage = random.uniform(10, remaining_percentage * 0.8)
                top_holders.append({
                    "address": "LPWallet" + str(random.randint(1000, 9999)),
                    "percentage": lp_percentage,
                    "is_contract": True,
                    "is_lp": True
                })
                remaining_percentage -= lp_percentage
                
                # Add more holders
                num_additional_holders = random.randint(5, 20)
                for i in range(num_additional_holders):
                    if remaining_percentage < 0.1:
                        break
                    
                    holder_pct = random.uniform(0.1, remaining_percentage * 0.5)
                    top_holders.append({
                        "address": "Wallet" + str(random.randint(1000, 9999)),
                        "percentage": holder_pct,
                        "is_contract": random.random() > 0.8
                    })
                    remaining_percentage -= holder_pct
                
                # Add long tail of small holders
                holder_data = {
                    "total_holders": random.randint(max(self.settings["min_holders"], len(top_holders)), 1000),
                    "top_holders": top_holders,
                    "excluded_from_circulation": random.uniform(0, 20),  # % excluded from circulation (burned, etc.)
                    "verified_teams": []  # Known project team wallets
                }
                
                # Maybe add some verified team wallets
                if random.random() > 0.7:  # 30% chance
                    num_team_wallets = random.randint(1, 3)
                    for i in range(num_team_wallets):
                        holder_data["verified_teams"].append({
                            "address": "TeamWallet" + str(random.randint(1000, 9999)),
                            "percentage": top_holders[0]["percentage"] if i == 0 else random.uniform(1, 10),
                            "team_name": "Project Team"
                        })
            
            # Analyze the holder data
            holder_issues = []
            critical_issues = []
            holder_strengths = []
            
            # Check number of holders
            total_holders = holder_data.get("total_holders", 0)
            if total_holders < self.settings["min_holders"]:
                holder_issues.append(f"Very few holders: {total_holders}")
            elif total_holders > self.settings["min_holders"] * 10:
                holder_strengths.append(f"Large holder base: {total_holders}")
            
            # Check holder concentration
            top_holders = holder_data.get("top_holders", [])
            non_lp_holders = [h for h in top_holders if not h.get("is_lp", False)]
            
            if non_lp_holders:
                top_holder = non_lp_holders[0]
                top_holder_percentage = top_holder.get("percentage", 0)
                
                # Check if top holder is a verified team wallet
                is_team = False
                for team in holder_data.get("verified_teams", []):
                    if team.get("address") == top_holder.get("address"):
                        is_team = True
                        holder_strengths.append(f"Top holder is verified team: {team.get('team_name', 'Unknown')} ({top_holder_percentage:.1f}%)")
                        break
                
                if not is_team:
                    if top_holder_percentage > self.settings["max_concentration"]:
                        critical_issues.append(f"Extreme concentration: Top holder owns {top_holder_percentage:.1f}%")
                    elif top_holder_percentage > self.settings["max_concentration"] * 0.7:
                        holder_issues.append(f"High concentration: Top holder owns {top_holder_percentage:.1f}%")
            
            # Calculate score based on holder distribution
            
            # Number of holders score component
            if total_holders < self.settings["min_holders"]:
                holders_count_score = min(0.6, total_holders / self.settings["min_holders"])
            else:
                holders_count_score = min(1.0, 0.6 + 0.4 * min(1.0, total_holders / (self.settings["min_holders"] * 10)))
            
            # Concentration score component
            top_holder_percentage = non_lp_holders[0].get("percentage", 0) if non_lp_holders else 0
            
            # Adjusted concentration score - lower is better (less concentrated)
            concentration_score = 1.0 - (top_holder_percentage / 100.0)
            
            # Verify if top wallet is team
            team_adjustment = 0.0
            for team in holder_data.get("verified_teams", []):
                if non_lp_holders and team.get("address") == non_lp_holders[0].get("address"):
                    # If top wallet is verified team, increase score
                    team_adjustment = 0.2
                    break
            
            # Calculate final score as weighted average of components
            holder_score = 0.4 * holders_count_score + 0.6 * concentration_score + team_adjustment
            holder_score = min(1.0, max(0.0, holder_score))  # Ensure between 0 and 1
            
            # Prepare result details
            details = {
                "score": holder_score,
                "total_holders": total_holders,
                "top_holder_percentage": top_holder_percentage,
                "excluded_from_circulation": holder_data.get("excluded_from_circulation", 0),
                "verified_team_wallets": holder_data.get("verified_teams", []),
                "holder_issues": holder_issues,
                "critical_issues": critical_issues,
                "holder_strengths": holder_strengths
            }
            
            return holder_score, details
            
        except Exception as e:
            logger.error(f"Error analyzing holders for {token_address}: {str(e)}")
            # Return a neutral score with error details
            return 0.5, {
                "score": 0.5,
                "error": f"Error analyzing holders: {str(e)}",
                "analysis_status": "failed"
            }
    
    async def _analyze_social_proof(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Analyze token social proof.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        try:
            # Simulate API call to get social data
            if API_RESILIENCE_AVAILABLE:
                # Use resilient request wrapper
                social_data = await resilient_request(
                    "get_token_social",
                    token_address
                )
            else:
                # For testing, generate synthetic data
                import random
                random.seed(token_address + "social")  # Make it deterministic for testing
                
                has_website = random.random() > 0.2
                has_telegram = random.random() > 0.1
                has_twitter = random.random() > 0.3
                has_github = random.random() > 0.7
                
                social_data = {
                    "website": "https://example.com/" + token_address[:8] if has_website else None,
                    "telegram": "t.me/token" + token_address[:8] if has_telegram else None,
                    "twitter": "twitter.com/token" + token_address[:8] if has_twitter else None,
                    "telegram_members": random.randint(100, 20000) if has_telegram else 0,
                    "twitter_followers": random.randint(100, 50000) if has_twitter else 0,
                    "github": "github.com/token" + token_address[:8] if has_github else None,
                    "verified_on": [
                        "coingecko" if random.random() > 0.7 else None,
                        "coinmarketcap" if random.random() > 0.8 else None
                    ],
                    "listing_count": random.randint(0, 5)
                }
                social_data["verified_on"] = [v for v in social_data["verified_on"] if v]
            
            # Analyze the social data
            social_issues = []
            social_strengths = []
            
            # Check presence of website, social media, etc.
            has_website = bool(social_data.get("website"))
            has_telegram = bool(social_data.get("telegram"))
            has_twitter = bool(social_data.get("twitter"))
            
            if not has_website:
                social_issues.append("No website found")
            else:
                social_strengths.append("Has website")
            
            if not has_telegram and not has_twitter:
                social_issues.append("No social media presence")
            
            if has_telegram:
                telegram_members = social_data.get("telegram_members", 0)
                if telegram_members > 10000:
                    social_strengths.append(f"Large Telegram community: {telegram_members} members")
                elif telegram_members > 1000:
                    social_strengths.append(f"Good Telegram community: {telegram_members} members")
                elif telegram_members < 100:
                    social_issues.append(f"Small Telegram community: {telegram_members} members")
            
            if has_twitter:
                twitter_followers = social_data.get("twitter_followers", 0)
                if twitter_followers > 10000:
                    social_strengths.append(f"Large Twitter following: {twitter_followers} followers")
                elif twitter_followers > 1000:
                    social_strengths.append(f"Good Twitter following: {twitter_followers} followers")
                elif twitter_followers < 100:
                    social_issues.append(f"Small Twitter following: {twitter_followers} followers")
            
            # Check verifications
            verified_on = social_data.get("verified_on", [])
            if "coingecko" in verified_on:
                social_strengths.append("Verified on CoinGecko")
            
            if "coinmarketcap" in verified_on:
                social_strengths.append("Verified on CoinMarketCap")
            
            # Calculate score based on social presence
            # Base score from number of social channels
            channels = sum([
                1 if has_website else 0,
                1 if has_telegram else 0,
                1 if has_twitter else 0,
                1 if social_data.get("github") else 0
            ])
            
            base_score = min(0.7, channels * 0.2)
            
            # Adjust for community size
            community_score = 0.0
            if has_telegram:
                telegram_members = social_data.get("telegram_members", 0)
                community_score += min(0.15, (telegram_members / 10000) * 0.15)
            
            if has_twitter:
                twitter_followers = social_data.get("twitter_followers", 0)
                community_score += min(0.15, (twitter_followers / 10000) * 0.15)
            
            # Adjust for verifications
            verification_score = len(verified_on) * 0.1
            
            # Calculate final score
            social_score = min(1.0, base_score + community_score + verification_score)
            
            # Prepare result details
            details = {
                "score": social_score,
                "website": social_data.get("website"),
                "telegram": social_data.get("telegram"),
                "twitter": social_data.get("twitter"),
                "github": social_data.get("github"),
                "telegram_members": social_data.get("telegram_members", 0),
                "twitter_followers": social_data.get("twitter_followers", 0),
                "verified_on": verified_on,
                "listing_count": social_data.get("listing_count", 0),
                "social_issues": social_issues,
                "social_strengths": social_strengths
            }
            
            return social_score, details
            
        except Exception as e:
            logger.error(f"Error analyzing social proof for {token_address}: {str(e)}")
            # Return a neutral score with error details
            return 0.5, {
                "score": 0.5,
                "error": f"Error analyzing social proof: {str(e)}",
                "analysis_status": "failed"
            }
    
    async def _analyze_historical_data(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Analyze token historical trading data.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        try:
            # Simulate API call to get historical data
            if API_RESILIENCE_AVAILABLE:
                # Use resilient request wrapper
                historical_data = await resilient_request(
                    "get_token_history",
                    token_address
                )
            else:
                # For testing, generate synthetic data
                import random
                random.seed(token_address + "history")  # Make it deterministic for testing
                
                age_days = random.randint(1, 180)
                price_change_24h = random.uniform(-25, 25)
                price_change_7d = random.uniform(-40, 60)
                
                trading_volume = []
                price_data = []
                
                base_price = random.uniform(0.000001, 0.1)
                current_price = base_price
                
                # Generate historical data for the past week
                for i in range(7):
                    day_change = random.uniform(-15, 20) / 100  # -15% to +20%
                    current_price *= (1 + day_change)
                    
                    price_data.append({
                        "timestamp": time.time() - (86400 * (7 - i)),
                        "price": current_price
                    })
                    
                    trading_volume.append({
                        "timestamp": time.time() - (86400 * (7 - i)),
                        "volume_usd": random.uniform(1000, 100000)
                    })
                
                historical_data = {
                    "age_days": age_days,
                    "price_change_24h": price_change_24h,
                    "price_change_7d": price_change_7d,
                    "price_history": price_data,
                    "volume_history": trading_volume,
                    "total_transactions": random.randint(100, 10000),
                    "unique_traders": random.randint(50, 1000),
                    "historical_alerts": []
                }
                
                # Add some historical alerts randomly
                if random.random() > 0.7:
                    alert_types = [
                        "price_manipulation", "wash_trading", "large_sell_off",
                        "unusual_trading", "whale_accumulation", "liquidity_change"
                    ]
                    
                    num_alerts = random.randint(0, 3)
                    for i in range(num_alerts):
                        alert_type = random.choice(alert_types)
                        historical_data["historical_alerts"].append({
                            "timestamp": time.time() - random.randint(1, age_days * 86400),
                            "type": alert_type,
                            "description": f"Detected {alert_type.replace('_', ' ')}"
                        })
            
            # Analyze the historical data
            historical_issues = []
            historical_strengths = []
            
            # Check token age
            age_days = historical_data.get("age_days", 0)
            if age_days < 3:
                historical_issues.append(f"Very new token: {age_days} days old")
            elif age_days > 90:
                historical_strengths.append(f"Established token: {age_days} days old")
            
            # Check price stability
            price_change_24h = historical_data.get("price_change_24h", 0)
            price_change_7d = historical_data.get("price_change_7d", 0)
            
            if abs(price_change_24h) > 30:
                historical_issues.append(f"High 24h price volatility: {price_change_24h:.1f}%")
            
            if price_change_7d < -50:
                historical_issues.append(f"Significant 7d price decline: {price_change_7d:.1f}%")
            elif price_change_7d > 200:
                if price_change_24h > 100:
                    historical_issues.append("Potential pump and dump pattern")
                else:
                    historical_strengths.append(f"Strong 7d growth: {price_change_7d:.1f}%")
            
            # Check trading activity
            total_transactions = historical_data.get("total_transactions", 0)
            unique_traders = historical_data.get("unique_traders", 0)
            
            if unique_traders < 20:
                historical_issues.append(f"Very few unique traders: {unique_traders}")
            elif unique_traders > 500:
                historical_strengths.append(f"Large trader community: {unique_traders} unique traders")
            
            # Check for historical alerts
            historical_alerts = historical_data.get("historical_alerts", [])
            for alert in historical_alerts:
                alert_type = alert.get("type", "")
                if alert_type in ["price_manipulation", "wash_trading"]:
                    historical_issues.append(f"Historical alert: {alert.get('description', alert_type)}")
            
            # Calculate score based on historical data
            
            # Age score component (0-0.2)
            age_score = min(0.2, age_days / 100 * 0.2)
            
            # Volatility score component (0-0.3)
            volatility_penalty = min(0.3, (abs(price_change_24h) / 100) * 0.3)
            volatility_score = 0.3 - volatility_penalty
            
            # Trading activity score component (0-0.3)
            if total_transactions < 100:
                activity_score = total_transactions / 100 * 0.3
            else:
                activity_score = min(0.3, 0.15 + (total_transactions - 100) / 1000 * 0.15)
            
            # Unique traders score component (0-0.2)
            if unique_traders < 50:
                traders_score = unique_traders / 50 * 0.2
            else:
                traders_score = min(0.2, 0.1 + (unique_traders - 50) / 500 * 0.1)
            
            # Historical alerts penalty
            alerts_penalty = len(historical_alerts) * 0.1
            
            # Calculate final score
            historical_score = age_score + volatility_score + activity_score + traders_score - alerts_penalty
            historical_score = min(1.0, max(0.0, historical_score))  # Ensure between 0 and 1
            
            # Prepare result details
            details = {
                "score": historical_score,
                "age_days": age_days,
                "price_change_24h": price_change_24h,
                "price_change_7d": price_change_7d,
                "total_transactions": total_transactions,
                "unique_traders": unique_traders,
                "historical_alerts": historical_alerts,
                "historical_issues": historical_issues,
                "historical_strengths": historical_strengths
            }
            
            return historical_score, details
            
        except Exception as e:
            logger.error(f"Error analyzing historical data for {token_address}: {str(e)}")
            # Return a neutral score with error details
            return 0.5, {
                "score": 0.5,
                "error": f"Error analyzing historical data: {str(e)}",
                "analysis_status": "failed"
            }
    
    async def _legacy_safety_check(self, token_address: str) -> Tuple[float, Dict[str, Any]]:
        """
        Perform legacy token safety check.
        
        Args:
            token_address: Token address
            
        Returns:
            Tuple of (score, details)
        """
        if LEGACY_SAFETY_AVAILABLE:
            try:
                safety_score = await legacy_check_safety(token_address)
                
                # Legacy returns score as 0-100, convert to 0-1 for consistency
                normalized_score = safety_score / 100.0
                
                result = {
                    "score": normalized_score,
                    "legacy_score": safety_score,
                    "analysis_method": "legacy",
                    "analysis_timestamp": time.time()
                }
                
                return normalized_score, result
            except Exception as e:
                logger.error(f"Error in legacy safety check: {str(e)}")
                return 0.5, {
                    "score": 0.5,
                    "error": f"Error in legacy safety check: {str(e)}",
                    "analysis_method": "legacy_failed",
                    "analysis_timestamp": time.time()
                }
        else:
            logger.warning("No safety check system available, using neutral score")
            return 0.5, {
                "score": 0.5,
                "analysis_method": "unavailable",
                "analysis_timestamp": time.time()
            }
    
    def update_token_reputation(self, token_address: str, status: str, source: str) -> bool:
        """
        Update token reputation database.
        
        Args:
            token_address: Token address
            status: Reputation status (verified_safe, verified_scam, etc.)
            source: Source of the reputation update
            
        Returns:
            True if updated successfully, False otherwise
        """
        try:
            # Update reputation data
            if token_address not in self.token_reputation:
                self.token_reputation[token_address] = {}
            
            self.token_reputation[token_address][status] = True
            self.token_reputation[token_address]["source"] = source
            self.token_reputation[token_address]["last_updated"] = time.time()
            
            # Save to disk
            self._save_token_reputation()
            
            logger.info(f"Updated token reputation for {token_address}: {status} from {source}")
            return True
        except Exception as e:
            logger.error(f"Error updating token reputation: {str(e)}")
            return False

# Singleton instance
_token_safety = None

async def get_token_safety(settings: Optional[Dict[str, Any]] = None) -> EnhancedTokenSafety:
    """
    Get the Enhanced Token Safety instance.
    
    Args:
        settings: Optional custom settings
        
    Returns:
        EnhancedTokenSafety instance
    """
    global _token_safety
    
    if _token_safety is None:
        _token_safety = EnhancedTokenSafety(settings)
    elif settings:
        _token_safety.settings.update(settings)
    
    return _token_safety

# Primary analysis function for external use
async def analyze_token_safety(token_address: str) -> Tuple[float, Dict[str, Any]]:
    """
    Analyze token safety using the enhanced system.
    
    Args:
        token_address: Token address to analyze
        
    Returns:
        Tuple of (safety score, detailed analysis)
    """
    token_safety = await get_token_safety()
    return await token_safety.analyze_token_safety(token_address)

# Legacy compatibility function
async def check_token_safety(token_address: str) -> float:
    """
    Legacy check_token_safety function for backwards compatibility.
    
    Args:
        token_address: Token address to check
        
    Returns:
        Safety score (0-100)
    """
    token_safety = await get_token_safety()
    score, _ = await token_safety.analyze_token_safety(token_address)
    
    # Convert from 0-1 to 0-100 for backwards compatibility
    return score * 100

# Example usage
async def test_token_safety():
    """
    Test the token safety analysis functionality.
    """
    logger.info("Testing Enhanced Token Safety")
    
    # Initialize token safety
    token_safety = await get_token_safety()
    
    # Test with some example tokens
    test_tokens = [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC on Solana (for testing)
        "TEST_SCAM_TOKEN123",
        "TEST_GOOD_TOKEN456"
    ]
    
    for token in test_tokens:
        logger.info(f"Analyzing token: {token}")
        
        score, details = await token_safety.analyze_token_safety(token)
        
        logger.info(f"Safety score: {score:.2f}")
        logger.info(f"Risk level: {details.get('risk_level', 'unknown')}")
        
        # Log critical issues if any
        critical_issues = details.get("critical_issues", [])
        if critical_issues:
            logger.info(f"Critical issues found: {len(critical_issues)}")
            for issue in critical_issues:
                logger.info(f"  - {issue}")
        
        # Log strengths if any
        strengths = []
        for key in details:
            if key.endswith("_strengths"):
                strengths.extend(details[key])
        
        if strengths:
            logger.info(f"Strengths: {len(strengths)}")
            for strength in strengths[:3]:  # Show top 3
                logger.info(f"  + {strength}")
        
        logger.info("---")
    
    logger.info("Token safety test completed")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_token_safety())