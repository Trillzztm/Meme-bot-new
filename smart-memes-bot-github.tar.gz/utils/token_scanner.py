"""
Token scanner utilities for SMART MEMES BOT.

This module provides utilities for extracting and validating token addresses
from text messages, handling different blockchain formats.
"""

import logging
import os
import re
from typing import List, Optional, Dict, Any, Set

# Configure logging
logger = logging.getLogger(__name__)

# Constants for pattern matching
SOLANA_TOKEN_PATTERN = r'\b[1-9A-HJ-NP-Za-km-z]{32,44}\b'
ETH_TOKEN_PATTERN = r'\b0x[a-fA-F0-9]{40}\b'
COMMON_DOMAINS = {
    'raydium', 'birdeye', 'dexscreener', 'solscan', 'debank', 'etherscan', 'bscscan', 'polygonscan',
    'jupiter', 'orca', 'saber', 'dextools', 'coingecko', 'coinmarketcap'
}

def extract_token_address(text: str) -> List[str]:
    """
    Extract potential token addresses from a text string.
    
    Args:
        text: The text to scan for token addresses
        
    Returns:
        List of extracted token addresses
    """
    try:
        # Combined pattern for Solana and Ethereum-like addresses
        combined_pattern = f"({SOLANA_TOKEN_PATTERN}|{ETH_TOKEN_PATTERN})"
        
        # Find all matches
        matches = re.findall(combined_pattern, text)
        
        # Flatten results if tuple returns from parenthesized groups
        extracted = []
        for match in matches:
            if isinstance(match, tuple):
                extracted.extend([m for m in match if m])
            else:
                extracted.append(match)
                
        # Filter out URLs and other common false positives
        filtered = []
        for addr in extracted:
            if is_likely_address(addr) and is_valid_token_address(addr):
                filtered.append(addr)
                
        logger.debug(f"Extracted {len(filtered)} token addresses from text")
        return filtered
        
    except Exception as e:
        logger.error(f"Error extracting token addresses: {e}")
        return []

def is_likely_address(text: str) -> bool:
    """
    Check if a string is likely to be a token address and not a URL part.
    
    Args:
        text: The text to check
        
    Returns:
        Boolean indicating if it's likely a token address
    """
    # Check if it contains common domain names
    lower_text = text.lower()
    for domain in COMMON_DOMAINS:
        if domain in lower_text:
            return False
            
    # Check for URL components
    if '://' in text or '.com' in text or '.io' in text:
        return False
        
    # Check if it's a reasonable length for a token address
    if len(text) < 30 or len(text) > 50:
        return False
        
    # For Ethereum-like addresses, must start with 0x
    if text.startswith('0x') and len(text) != 42:
        return False
        
    return True

def is_valid_token_address(address: str) -> bool:
    """
    Check if a string is a valid token address format.
    
    Args:
        address: The address to validate
        
    Returns:
        Boolean indicating if it's a valid token address format
    """
    try:
        # Strip any surrounding whitespace
        address = address.strip()
        
        # Check Solana address format
        if re.match(f"^{SOLANA_TOKEN_PATTERN}$", address):
            # Solana addresses are base58 encoded
            return True
            
        # Check Ethereum-like address format
        if re.match(f"^{ETH_TOKEN_PATTERN}$", address):
            # Check for valid hex characters
            return all(c in '0123456789abcdefABCDEF' for c in address[2:])
            
        return False
        
    except Exception as e:
        logger.error(f"Error validating token address: {e}")
        return False

def identify_network(address: str) -> str:
    """
    Identify which blockchain network an address belongs to.
    
    Args:
        address: The token address
        
    Returns:
        Network identifier ('solana', 'ethereum', 'bsc', 'polygon', 'unknown')
    """
    try:
        address = address.strip()
        
        # Check Solana address format
        if re.match(f"^{SOLANA_TOKEN_PATTERN}$", address):
            return 'solana'
            
        # Check Ethereum-like address format
        if re.match(f"^{ETH_TOKEN_PATTERN}$", address):
            # Here we would ideally check against network-specific APIs or patterns
            # For now, default to ethereum for 0x addresses
            return 'ethereum'
            
        return 'unknown'
        
    except Exception as e:
        logger.error(f"Error identifying network: {e}")
        return 'unknown'

def extract_addresses_from_messages(messages: List[str]) -> Dict[str, int]:
    """
    Extract token addresses from a list of messages with frequency count.
    
    Args:
        messages: List of message strings
        
    Returns:
        Dictionary with addresses as keys and mention counts as values
    """
    try:
        address_counts = {}
        
        for message in messages:
            addresses = extract_token_address(message)
            
            for addr in addresses:
                if addr in address_counts:
                    address_counts[addr] += 1
                else:
                    address_counts[addr] = 1
                    
        # Sort by count for convenience
        sorted_counts = {k: v for k, v in sorted(
            address_counts.items(), key=lambda item: item[1], reverse=True
        )}
        
        return sorted_counts
        
    except Exception as e:
        logger.error(f"Error extracting addresses from messages: {e}")
        return {}

def extract_from_group_messages(group_messages: Dict[int, List[str]]) -> Dict[str, Dict[str, Any]]:
    """
    Extract token addresses from messages grouped by chat ID.
    
    Args:
        group_messages: Dictionary with group IDs as keys and message lists as values
        
    Returns:
        Dictionary with addresses as keys and stats as values
    """
    try:
        all_addresses = {}
        
        for group_id, messages in group_messages.items():
            addresses = extract_addresses_from_messages(messages)
            
            for addr, count in addresses.items():
                if addr in all_addresses:
                    all_addresses[addr]['total_mentions'] += count
                    all_addresses[addr]['groups'].add(group_id)
                else:
                    all_addresses[addr] = {
                        'total_mentions': count,
                        'groups': {group_id},
                        'network': identify_network(addr)
                    }
                    
        # Convert group sets to lists for JSON compatibility
        for addr in all_addresses:
            all_addresses[addr]['groups'] = list(all_addresses[addr]['groups'])
            all_addresses[addr]['group_count'] = len(all_addresses[addr]['groups'])
            
        return all_addresses
        
    except Exception as e:
        logger.error(f"Error extracting from group messages: {e}")
        return {}

def format_address_for_display(address: str, max_length: int = 12) -> str:
    """
    Format a token address for display, truncating if needed.
    
    Args:
        address: The token address
        max_length: Maximum length to display
        
    Returns:
        Formatted address string
    """
    if not address:
        return ""
        
    if len(address) <= max_length:
        return address
        
    # For Ethereum-like addresses, keep 0x prefix and some middle characters
    if address.startswith('0x'):
        return f"{address[:6]}...{address[-4:]}"
    
    # For Solana addresses, keep some start and end characters
    half = max_length // 2
    return f"{address[:half]}...{address[-half:]}"