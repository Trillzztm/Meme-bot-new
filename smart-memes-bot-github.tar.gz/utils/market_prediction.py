"""
Market prediction module for SMART MEMES BOT.

This module provides AI-powered price prediction and market analysis
to help users make informed trading decisions.
"""

import logging
import json
import time
import numpy as np
import os
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timedelta
import requests

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our utilities
from utils.token_info import get_token_price_history, get_token_info
from utils.token_safety import check_token_safety

# Constants
PRICE_INTERVALS = {
    "1h": {"hours": 1, "points": 60, "interval": "1m"},
    "24h": {"hours": 24, "points": 24, "interval": "1h"},
    "7d": {"days": 7, "points": 168, "interval": "1h"},
    "30d": {"days": 30, "points": 30, "interval": "1d"}
}

class TimeSeriesPredictor:
    """Simple time series predictor using moving averages and regression."""
    
    def __init__(self, data: List[Dict[str, Any]]):
        """Initialize with price data."""
        self.data = data
        self.prices = [point.get("price", 0) for point in data]
        self.times = [
            datetime.fromisoformat(point.get("time", "").replace("Z", "+00:00")) 
            for point in data
        ]
    
    def calculate_moving_averages(self) -> Dict[str, List[float]]:
        """Calculate moving averages for different windows."""
        prices = np.array(self.prices)
        return {
            "ma_7": self._moving_average(prices, 7),
            "ma_14": self._moving_average(prices, 14),
            "ma_30": self._moving_average(prices, 30)
        }
    
    def _moving_average(self, data: np.ndarray, window: int) -> List[float]:
        """Calculate moving average for a given window."""
        if len(data) < window:
            return [np.nan] * len(data)
        
        return list(np.convolve(data, np.ones(window)/window, mode='valid'))
    
    def predict_price(self, hours_ahead: int = 24) -> Dict[str, Any]:
        """Predict price for a future time point."""
        if len(self.prices) < 3:
            return {
                "success": False,
                "error": "Not enough data for prediction",
                "predicted_price": None
            }
        
        try:
            # Use simple linear regression for demonstration
            x = np.array(range(len(self.prices)))
            y = np.array(self.prices)
            
            # Fit line: y = mx + b
            m, b = np.polyfit(x, y, 1)
            
            # Predict future price
            future_x = len(self.prices) + (hours_ahead * 60 // len(self.prices))
            predicted_price = m * future_x + b
            
            # Calculate confidence metrics
            residuals = y - (m * x + b)
            mse = np.mean(residuals ** 2)
            variance = np.var(y)
            r_squared = 1 - (mse / variance) if variance != 0 else 0
            
            # Ensure prediction is positive
            predicted_price = max(0, predicted_price)
            
            # Calculate percent change
            current_price = self.prices[-1] if self.prices else 0
            percent_change = (
                ((predicted_price - current_price) / current_price) * 100 
                if current_price > 0 else 0
            )
            
            trend = "up" if percent_change > 5 else "down" if percent_change < -5 else "sideways"
            confidence = r_squared * 100  # Convert to percentage
            
            return {
                "success": True,
                "current_price": current_price,
                "predicted_price": predicted_price,
                "percent_change": percent_change,
                "hours_ahead": hours_ahead,
                "confidence": confidence,
                "trend": trend,
                "prediction_time": datetime.now().isoformat(),
                "target_time": (datetime.now() + timedelta(hours=hours_ahead)).isoformat()
            }
        except Exception as e:
            logger.error(f"Error predicting price: {e}")
            return {
                "success": False,
                "error": str(e),
                "predicted_price": None
            }
    
    def detect_patterns(self) -> List[Dict[str, Any]]:
        """Detect common chart patterns in the price data."""
        if len(self.prices) < 10:
            return []
        
        patterns = []
        
        # Check for rising wedge (bearish)
        if self._detect_rising_wedge():
            patterns.append({
                "name": "Rising Wedge",
                "type": "bearish",
                "confidence": 70,
                "description": "Price is making higher highs and higher lows, but the rate of higher highs is slower than the rate of higher lows."
            })
        
        # Check for falling wedge (bullish)
        if self._detect_falling_wedge():
            patterns.append({
                "name": "Falling Wedge",
                "type": "bullish",
                "confidence": 65,
                "description": "Price is making lower lows and lower highs, but the rate of lower lows is slower than the rate of lower highs."
            })
        
        # Check for double bottom (bullish)
        if self._detect_double_bottom():
            patterns.append({
                "name": "Double Bottom",
                "type": "bullish",
                "confidence": 75,
                "description": "Price reaches a low, rebounds, and then returns to the same low before increasing again."
            })
        
        # Check for double top (bearish)
        if self._detect_double_top():
            patterns.append({
                "name": "Double Top",
                "type": "bearish",
                "confidence": 75,
                "description": "Price reaches a high, pulls back, and then returns to the same high before falling again."
            })
        
        return patterns
    
    def _detect_rising_wedge(self) -> bool:
        """Detect rising wedge pattern."""
        # Simplified detection algorithm for demonstration
        if len(self.prices) < 15:
            return False
        
        # This would typically analyze local highs and lows with trend lines
        # For demonstration, using a simple heuristic
        return self.prices[-1] > self.prices[0] and self.prices[-5] < self.prices[-1]
    
    def _detect_falling_wedge(self) -> bool:
        """Detect falling wedge pattern."""
        # Simplified detection algorithm for demonstration
        if len(self.prices) < 15:
            return False
        
        # This would typically analyze local highs and lows with trend lines
        # For demonstration, using a simple heuristic
        return self.prices[-1] < self.prices[0] and self.prices[-5] > self.prices[-1]
    
    def _detect_double_bottom(self) -> bool:
        """Detect double bottom pattern."""
        # Simplified detection algorithm for demonstration
        if len(self.prices) < 20:
            return False
        
        # This would typically look for two similar lows with a rebound in between
        # For demonstration, using a simple heuristic
        return False  # Placeholder
    
    def _detect_double_top(self) -> bool:
        """Detect double top pattern."""
        # Simplified detection algorithm for demonstration
        if len(self.prices) < 20:
            return False
        
        # This would typically look for two similar highs with a pullback in between
        # For demonstration, using a simple heuristic
        return False  # Placeholder

class SentimentAnalyzer:
    """Analyze market sentiment from social and news sources."""
    
    def __init__(self, token_address: str):
        """Initialize with token address."""
        self.token_address = token_address
    
    def analyze_sentiment(self) -> Dict[str, Any]:
        """Analyze sentiment from various sources."""
        # In a real implementation, this would:
        # 1. Check social media mentions (Twitter, Telegram, Discord)
        # 2. Analyze news sentiment
        # 3. Check GitHub activity (if open source)
        # 4. Analyze forum discussions
        
        # For demonstration, returning mock data
        return {
            "overall_sentiment": 65,  # 0-100 scale, higher is more positive
            "sentiment_change_24h": 5,  # Percentage points
            "mention_count_24h": 125,
            "social_breakdown": {
                "twitter": 70,
                "telegram": 60,
                "discord": 65,
                "reddit": 55
            },
            "trending_platforms": ["twitter", "telegram"],
            "trending_keywords": ["moon", "gem", "buy", "launch"],
            "news_sentiment": 60,
            "developer_activity": "medium",
            "timestamp": int(time.time())
        }

def predict_token_price(
    token_address: str,
    time_frame: str = "24h",
    prediction_hours: int = 24
) -> Dict[str, Any]:
    """
    Predict token price for a future time point.
    
    Args:
        token_address: The token address to analyze
        time_frame: The time frame to use for prediction (1h, 24h, 7d, 30d)
        prediction_hours: How many hours ahead to predict
        
    Returns:
        Dictionary with prediction results
    """
    logger.info(f"Predicting price for {token_address}, time_frame={time_frame}, prediction_hours={prediction_hours}")
    
    try:
        # Get historical price data
        price_history = get_token_price_history(token_address, days=30)
        
        # Create predictor
        predictor = TimeSeriesPredictor(price_history)
        
        # Make prediction
        prediction = predictor.predict_price(hours_ahead=prediction_hours)
        
        # Detect chart patterns
        patterns = predictor.detect_patterns()
        
        # Add basic token info
        token_info = get_token_info(token_address)
        basic_info = {
            "token_address": token_address,
            "token_name": token_info.get("name", "Unknown"),
            "token_symbol": token_info.get("symbol", "Unknown"),
            "token_decimals": token_info.get("decimals", 0),
            "token_liquidity": token_info.get("liquidity", "Unknown")
        }
        
        # Combine all data
        result = {
            "success": prediction.get("success", False),
            "token_info": basic_info,
            "prediction": prediction,
            "patterns": patterns,
            "time_frame": time_frame,
            "data_points": len(price_history),
            "timestamp": int(time.time())
        }
        
        # Add error message if prediction failed
        if not prediction.get("success", False):
            result["error"] = prediction.get("error", "Unknown prediction error")
        
        return result
    
    except Exception as e:
        logger.error(f"Error predicting token price: {e}")
        return {
            "success": False,
            "error": str(e),
            "token_address": token_address
        }

def get_market_sentiment(token_address: str) -> Dict[str, Any]:
    """
    Get market sentiment analysis for a token.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Dictionary with sentiment analysis results
    """
    logger.info(f"Getting market sentiment for {token_address}")
    
    try:
        # Analyze sentiment
        analyzer = SentimentAnalyzer(token_address)
        sentiment = analyzer.analyze_sentiment()
        
        # Add token safety score for context
        safety_data = check_token_safety(token_address, detailed=False)
        safety_score = safety_data.get("safety_score", 0)
        
        # Get basic token info
        token_info = get_token_info(token_address)
        
        # Calculate market impact
        sentiment_score = sentiment.get("overall_sentiment", 0)
        mention_count = sentiment.get("mention_count_24h", 0)
        
        # Simple market impact formula (would be more sophisticated in reality)
        market_impact = (sentiment_score / 100) * min(1, mention_count / 1000) * 10
        
        return {
            "success": True,
            "token_address": token_address,
            "token_name": token_info.get("name", "Unknown"),
            "token_symbol": token_info.get("symbol", "Unknown"),
            "sentiment": sentiment,
            "safety_score": safety_score,
            "market_impact_score": market_impact,
            "investment_recommendation": get_investment_recommendation(sentiment_score, safety_score, market_impact),
            "timestamp": int(time.time())
        }
    
    except Exception as e:
        logger.error(f"Error getting market sentiment: {e}")
        return {
            "success": False,
            "error": str(e),
            "token_address": token_address
        }

def get_investment_recommendation(sentiment_score: float, safety_score: float, market_impact: float) -> Dict[str, Any]:
    """
    Generate investment recommendation based on analysis.
    
    Args:
        sentiment_score: The sentiment score (0-100)
        safety_score: The safety score (0-10)
        market_impact: The market impact score (0-10)
        
    Returns:
        Dictionary with recommendation
    """
    # Calculate combined score (weighted)
    combined_score = (
        sentiment_score * 0.3 +  # 30% sentiment
        safety_score * 10 * 0.5 +  # 50% safety (normalize to 0-100)
        market_impact * 10 * 0.2  # 20% market impact (normalize to 0-100)
    )
    
    # Determine recommendation
    if safety_score < 3:
        action = "AVOID"
        reasoning = "Critical security concerns detected"
        confidence = 90
    elif combined_score < 40:
        action = "AVOID"
        reasoning = "Poor sentiment and market outlook"
        confidence = 75
    elif combined_score < 50:
        action = "HOLD"
        reasoning = "Mixed signals with slightly negative bias"
        confidence = 60
    elif combined_score < 60:
        action = "HOLD"
        reasoning = "Mixed signals with slightly positive bias"
        confidence = 60
    elif combined_score < 70:
        action = "CONSIDER BUYING"
        reasoning = "Positive outlook with moderate confidence"
        confidence = 70
    else:
        action = "BUY"
        reasoning = "Strong positive signals across metrics"
        confidence = 80
    
    # Adjust confidence based on safety score
    if safety_score < 5:
        confidence = max(30, confidence - 20)
    
    return {
        "action": action,
        "reasoning": reasoning,
        "confidence": confidence,
        "combined_score": combined_score,
        "time_horizon": "Short-term"
    }

def format_price_prediction(prediction_data: Dict[str, Any], compact: bool = False) -> str:
    """
    Format price prediction data into a readable report.
    
    Args:
        prediction_data: Price prediction results
        compact: Whether to use a compact format
        
    Returns:
        Formatted report string
    """
    if not prediction_data.get("success", False):
        return f"❌ Error predicting price: {prediction_data.get('error', 'Unknown error')}"
    
    prediction = prediction_data.get("prediction", {})
    patterns = prediction_data.get("patterns", [])
    token_info = prediction_data.get("token_info", {})
    
    current_price = prediction.get("current_price", 0)
    predicted_price = prediction.get("predicted_price", 0)
    percent_change = prediction.get("percent_change", 0)
    confidence = prediction.get("confidence", 0)
    trend = prediction.get("trend", "unknown")
    hours_ahead = prediction.get("hours_ahead", 24)
    
    # Trend emoji
    trend_emoji = "🚀" if trend == "up" else "📉" if trend == "down" else "↔️"
    
    if compact:
        return (
            f"{trend_emoji} *Price Prediction ({hours_ahead}h):* "
            f"{current_price:.8f} → {predicted_price:.8f} "
            f"({percent_change:+.2f}%) [Confidence: {confidence:.1f}%]"
        )
    
    # Full report
    report = (
        f"📊 *Token Price Prediction*\n\n"
        f"*Token:* {token_info.get('token_symbol', 'Unknown')} "
        f"({token_info.get('token_name', 'Unknown')})\n"
        f"*Address:* `{token_info.get('token_address', 'Unknown')}`\n\n"
        f"*Current Price:* {current_price:.8f}\n"
        f"*Predicted Price ({hours_ahead}h):* {predicted_price:.8f}\n"
        f"*Expected Change:* {trend_emoji} {percent_change:+.2f}%\n"
        f"*Prediction Confidence:* {confidence:.1f}%\n\n"
    )
    
    # Add pattern analysis if available
    if patterns:
        report += "*Chart Patterns Detected:*\n"
        for pattern in patterns:
            pattern_type = pattern.get("type", "neutral")
            pattern_emoji = "🟢" if pattern_type == "bullish" else "🔴" if pattern_type == "bearish" else "⚪"
            report += f"{pattern_emoji} {pattern.get('name', 'Unknown')} - {pattern.get('confidence', 0)}% confidence\n"
        
        report += "\n"
    
    # Add trading advice
    if percent_change > 20 and confidence > 60:
        report += "💰 *Trading Opportunity:* Strong potential for significant gains\n"
    elif percent_change > 10 and confidence > 50:
        report += "💰 *Trading Opportunity:* Moderate potential for gains\n"
    elif percent_change < -20 and confidence > 60:
        report += "⚠️ *Trading Warning:* High probability of significant losses\n"
    elif percent_change < -10 and confidence > 50:
        report += "⚠️ *Trading Warning:* Moderate probability of losses\n"
    else:
        report += "📉 *Trading Outlook:* Neutral or uncertain trend\n"
    
    # Add disclaimer
    report += "\n*Disclaimer:* This prediction is based on historical data and technical analysis. Cryptocurrency markets are highly volatile and unpredictable. Always do your own research before trading."
    
    return report

def format_sentiment_analysis(sentiment_data: Dict[str, Any], compact: bool = False) -> str:
    """
    Format sentiment analysis data into a readable report.
    
    Args:
        sentiment_data: Sentiment analysis results
        compact: Whether to use a compact format
        
    Returns:
        Formatted report string
    """
    if not sentiment_data.get("success", False):
        return f"❌ Error analyzing sentiment: {sentiment_data.get('error', 'Unknown error')}"
    
    sentiment = sentiment_data.get("sentiment", {})
    recommendation = sentiment_data.get("investment_recommendation", {})
    
    sentiment_score = sentiment.get("overall_sentiment", 0)
    sentiment_change = sentiment.get("sentiment_change_24h", 0)
    mention_count = sentiment.get("mention_count_24h", 0)
    
    # Sentiment emoji
    sentiment_emoji = "🟢" if sentiment_score > 65 else "🟠" if sentiment_score > 45 else "🔴"
    trend_emoji = "📈" if sentiment_change > 0 else "📉" if sentiment_change < 0 else "↔️"
    
    if compact:
        return (
            f"{sentiment_emoji} *Market Sentiment:* {sentiment_score}/100 "
            f"{trend_emoji} {sentiment_change:+.1f}% (24h)"
        )
    
    # Full report
    report = (
        f"🔍 *Market Sentiment Analysis*\n\n"
        f"*Token:* {sentiment_data.get('token_symbol', 'Unknown')} "
        f"({sentiment_data.get('token_name', 'Unknown')})\n"
        f"*Address:* `{sentiment_data.get('token_address', 'Unknown')}`\n\n"
        f"*Overall Sentiment:* {sentiment_emoji} {sentiment_score}/100\n"
        f"*24h Change:* {trend_emoji} {sentiment_change:+.1f}%\n"
        f"*Mentions (24h):* {mention_count}\n"
        f"*Safety Score:* {sentiment_data.get('safety_score', 0)}/10\n\n"
    )
    
    # Add social breakdown
    social_breakdown = sentiment.get("social_breakdown", {})
    if social_breakdown:
        report += "*Social Sentiment:*\n"
        for platform, score in social_breakdown.items():
            platform_emoji = "🟢" if score > 65 else "🟠" if score > 45 else "🔴"
            report += f"{platform_emoji} {platform.capitalize()}: {score}/100\n"
        
        report += "\n"
    
    # Add recommendation
    action = recommendation.get("action", "UNKNOWN")
    reasoning = recommendation.get("reasoning", "")
    confidence = recommendation.get("confidence", 0)
    
    action_emoji = "🟢" if action in ["BUY", "CONSIDER BUYING"] else "🟠" if action == "HOLD" else "🔴"
    
    report += (
        f"*Recommendation:* {action_emoji} {action}\n"
        f"*Reasoning:* {reasoning}\n"
        f"*Confidence:* {confidence}%\n\n"
    )
    
    # Add trending keywords
    trending_keywords = sentiment.get("trending_keywords", [])
    if trending_keywords:
        report += f"*Trending Keywords:* {', '.join(trending_keywords)}\n\n"
    
    # Add disclaimer
    report += "*Disclaimer:* This sentiment analysis is based on social media and news sources, which may not accurately reflect market fundamentals. Always do your own research before trading."
    
    return report