"""
Price tracking utilities for SMART MEMES BOT.

This module provides price tracking functionality for tokens, including
real-time tracking, profit calculation, and automated take-profit/stop-loss execution.
"""

import logging
import os
import asyncio
import time
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta

# Configure logging
logger = logging.getLogger(__name__)

# Constants
PRICE_CHECK_INTERVAL = 60  # seconds
TRANSACTION_TRACKING_TIME = 24 * 60 * 60  # 24 hours in seconds
TAKE_PROFIT_LEVELS = [0.25, 0.5, 1.0]  # 25%, 50%, 100% profit levels
STOP_LOSS_LEVEL = 0.1  # 10% loss

# Active price tracking tasks
_active_tracking_tasks = {}
_transaction_data = {}

# Try importing required modules
try:
    from utils.pricing import get_token_price
    from utils.trading import execute_trade, calculate_profit_loss
    from database import record_token_price, log_token_result, update_transaction_status
    HAS_DEPENDENCIES = True
    logger.info("Price tracker dependencies loaded successfully")
except ImportError as e:
    HAS_DEPENDENCIES = False
    logger.warning(f"Price tracker running in limited mode, missing dependencies: {e}")


def schedule_price_check(token_address: str, transaction_id: int, entry_price: float,
                        tokens_received: float) -> bool:
    """
    Schedule a price check for a token purchase.
    
    Args:
        token_address: The token address to track
        transaction_id: Database transaction ID to update
        entry_price: The entry price
        tokens_received: The number of tokens received
        
    Returns:
        Boolean indicating if scheduling was successful
    """
    try:
        global _transaction_data
        
        # Check if already tracking this transaction
        task_key = f"{token_address}_{transaction_id}"
        if task_key in _active_tracking_tasks:
            logger.info(f"Already tracking transaction {transaction_id}")
            return True
            
        # Store transaction data
        _transaction_data[task_key] = {
            'token_address': token_address,
            'transaction_id': transaction_id,
            'entry_price': entry_price,
            'tokens_received': tokens_received,
            'start_time': int(time.time()),
            'take_profit_triggered': [False, False, False],  # Corresponding to 3 TP levels
            'stop_loss_triggered': False
        }
        
        # Get or create an event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
        # Start a background task to track this token
        task = loop.create_task(track_token_price(task_key))
        _active_tracking_tasks[task_key] = task
        
        logger.info(f"Scheduled price tracking for {token_address} (Transaction ID: {transaction_id})")
        return True
        
    except Exception as e:
        logger.error(f"Error scheduling price check: {e}")
        return False


async def track_token_price(task_key: str) -> None:
    """
    Track token price and execute take-profit/stop-loss.
    
    Args:
        task_key: The task key to track
    """
    try:
        # Get transaction data
        if task_key not in _transaction_data:
            logger.error(f"No transaction data found for task key: {task_key}")
            return
            
        data = _transaction_data[task_key]
        token_address = data['token_address']
        transaction_id = data['transaction_id']
        entry_price = data['entry_price']
        tokens_received = data['tokens_received']
        start_time = data['start_time']
        
        logger.info(f"Starting price tracking for {token_address} (Transaction ID: {transaction_id})")
        
        while True:
            try:
                # Check if we've been tracking for too long
                now = int(time.time())
                if now - start_time > TRANSACTION_TRACKING_TIME:
                    logger.info(f"Finished tracking {token_address} (Transaction ID: {transaction_id}) after 24 hours")
                    break
                    
                # Get current price
                current_price = await get_token_price(token_address, force_refresh=True)
                
                # Calculate profit percentage
                if entry_price > 0:
                    profit_percent = (current_price - entry_price) / entry_price
                else:
                    profit_percent = 0
                    
                # Record price in database
                if HAS_DEPENDENCIES:
                    await record_token_price(token_address, current_price)
                    
                # Log current status
                logger.info(f"Token {token_address} - Current Price: {current_price:.10f}, " +
                          f"Profit: {profit_percent*100:.2f}%")
                
                # Check take profit levels
                tp_triggered = False
                for i, level in enumerate(TAKE_PROFIT_LEVELS):
                    if profit_percent >= level and not data['take_profit_triggered'][i]:
                        # Calculate how many tokens to sell at this level
                        if i == 0:  # First level, sell 30%
                            sell_percentage = 0.3
                        elif i == 1:  # Second level, sell 30%
                            sell_percentage = 0.3
                        else:  # Third level, sell 40%
                            sell_percentage = 0.4
                            
                        tokens_to_sell = tokens_received * sell_percentage
                        
                        # Mark as triggered
                        data['take_profit_triggered'][i] = True
                        tp_triggered = True
                        
                        logger.info(f"TAKE PROFIT TRIGGERED - Level {i+1} ({level*100:.0f}%) " +
                                  f"for {token_address} - Selling {sell_percentage*100:.0f}% of position")
                        
                        # Execute sell if we have dependencies
                        if HAS_DEPENDENCIES:
                            # Execute sell
                            result = await execute_trade(
                                token_address=token_address,
                                amount=tokens_to_sell,
                                is_buy=False
                            )
                            
                            if result.get('success'):
                                # Update transaction status
                                await update_transaction_status(
                                    transaction_id=transaction_id,
                                    status=f"partial_profit_{i+1}",
                                    exit_price=current_price,
                                    profit_loss=profit_percent
                                )
                                
                                # Log result
                                await log_token_result(
                                    token_address=token_address,
                                    result="profit",
                                    group_id=None,  # We don't know the group ID here
                                    profit_percent=profit_percent*100
                                )
                                
                                logger.info(f"Successfully sold {tokens_to_sell:.2f} tokens " +
                                          f"of {token_address} at {current_price:.10f}")
                            else:
                                logger.error(f"Failed to sell {token_address} at profit level {i+1}: " +
                                           f"{result.get('error', 'Unknown error')}")
                        
                # Check stop loss
                if profit_percent <= -STOP_LOSS_LEVEL and not data['stop_loss_triggered']:
                    # Mark as triggered
                    data['stop_loss_triggered'] = True
                    
                    # Calculate remaining tokens to sell
                    remaining_percentage = 1.0
                    for i, triggered in enumerate(data['take_profit_triggered']):
                        if triggered:
                            if i == 0 or i == 1:
                                remaining_percentage -= 0.3
                            else:
                                remaining_percentage -= 0.4
                                
                    tokens_to_sell = tokens_received * remaining_percentage
                    
                    logger.info(f"STOP LOSS TRIGGERED ({STOP_LOSS_LEVEL*100:.0f}%) " +
                              f"for {token_address} - Selling remaining {remaining_percentage*100:.0f}% of position")
                    
                    # Execute sell if we have dependencies
                    if HAS_DEPENDENCIES and tokens_to_sell > 0:
                        # Execute sell
                        result = await execute_trade(
                            token_address=token_address,
                            amount=tokens_to_sell,
                            is_buy=False
                        )
                        
                        if result.get('success'):
                            # Update transaction status
                            await update_transaction_status(
                                transaction_id=transaction_id,
                                status="stop_loss",
                                exit_price=current_price,
                                profit_loss=profit_percent
                            )
                            
                            # Log result
                            await log_token_result(
                                token_address=token_address,
                                result="loss",
                                group_id=None,  # We don't know the group ID here
                                profit_percent=profit_percent*100
                            )
                            
                            logger.info(f"Successfully sold {tokens_to_sell:.2f} tokens " +
                                      f"of {token_address} at {current_price:.10f}")
                        else:
                            logger.error(f"Failed to sell {token_address} at stop loss: " +
                                       f"{result.get('error', 'Unknown error')}")
                    
                # If all take profit levels triggered or stop loss triggered, we're done
                if all(data['take_profit_triggered']) or data['stop_loss_triggered']:
                    logger.info(f"All targets hit for {token_address} (Transaction ID: {transaction_id}), stopping tracking")
                    break
                    
                # Wait for next check
                await asyncio.sleep(PRICE_CHECK_INTERVAL)
                
            except asyncio.CancelledError:
                logger.info(f"Price tracking task for {token_address} was cancelled")
                break
            except Exception as e:
                logger.error(f"Error during price tracking for {token_address}: {e}")
                await asyncio.sleep(PRICE_CHECK_INTERVAL)  # Continue despite errors
                
        # Clean up
        if task_key in _active_tracking_tasks:
            del _active_tracking_tasks[task_key]
        if task_key in _transaction_data:
            del _transaction_data[task_key]
                
    except Exception as e:
        logger.error(f"Error in token tracking task: {e}")


def cancel_price_tracking(token_address: str, transaction_id: Optional[int] = None) -> bool:
    """
    Cancel price tracking for a token.
    
    Args:
        token_address: The token address
        transaction_id: Optional transaction ID to be more specific
        
    Returns:
        Boolean indicating if cancellation was successful
    """
    try:
        cancelled = False
        keys_to_remove = []
        
        for task_key, task in _active_tracking_tasks.items():
            if transaction_id is None:
                # Match just by token address
                if token_address in task_key:
                    task.cancel()
                    keys_to_remove.append(task_key)
                    cancelled = True
            else:
                # Match by token address and transaction ID
                if task_key == f"{token_address}_{transaction_id}":
                    task.cancel()
                    keys_to_remove.append(task_key)
                    cancelled = True
                    break
                    
        # Remove cancelled tasks
        for key in keys_to_remove:
            del _active_tracking_tasks[key]
            if key in _transaction_data:
                del _transaction_data[key]
                
        if cancelled:
            logger.info(f"Cancelled price tracking for {token_address}")
        else:
            logger.warning(f"No active price tracking found for {token_address}")
            
        return cancelled
        
    except Exception as e:
        logger.error(f"Error cancelling price tracking: {e}")
        return False


def get_active_tracking_tokens() -> List[str]:
    """
    Get list of tokens currently being tracked.
    
    Returns:
        List of token addresses
    """
    try:
        tokens = set()
        for task_key in _active_tracking_tasks:
            if task_key in _transaction_data:
                tokens.add(_transaction_data[task_key]['token_address'])
        return list(tokens)
    except Exception as e:
        logger.error(f"Error getting active tracking tokens: {e}")
        return []


def get_tracking_status(token_address: str) -> List[Dict[str, Any]]:
    """
    Get tracking status for a token.
    
    Args:
        token_address: The token address
        
    Returns:
        List of status dictionaries
    """
    try:
        status_list = []
        
        for task_key, data in _transaction_data.items():
            if data['token_address'] == token_address:
                status = {
                    'token_address': data['token_address'],
                    'transaction_id': data['transaction_id'],
                    'entry_price': data['entry_price'],
                    'tokens_received': data['tokens_received'],
                    'start_time': data['start_time'],
                    'duration': int(time.time()) - data['start_time'],
                    'take_profit_triggered': data['take_profit_triggered'],
                    'stop_loss_triggered': data['stop_loss_triggered']
                }
                status_list.append(status)
                
        return status_list
        
    except Exception as e:
        logger.error(f"Error getting tracking status: {e}")
        return []