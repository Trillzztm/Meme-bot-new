"""
Risk Management System for SMART MEMES BOT.

This module implements a sophisticated risk management framework that:
1. Categorizes sources (groups, wallets) into risk tiers
2. Determines appropriate position sizes based on risk profile
3. Dynamically adjusts risk tolerance based on performance
4. Implements multi-layered verification for trade execution

The risk tier system categorizes sources as high/medium/low risk with
corresponding investment limits and minimum score requirements.
"""

import os
import json
import logging
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import asyncio

# Configure logger
logger = logging.getLogger(__name__)

# Risk tier definitions
RISK_TIERS = {
    "low": {
        "max_position_size": 0.05,  # 5% of available capital
        "max_positions": 5,
        "min_social_proof": 8.0,
        "min_safety_score": 8.0,
        "confirmation_sources": 3,
        "description": "Low risk - conservative approach"
    },
    "medium": {
        "max_position_size": 0.10,  # 10% of available capital
        "max_positions": 10,
        "min_social_proof": 6.5,
        "min_safety_score": 7.0,
        "confirmation_sources": 2,
        "description": "Medium risk - balanced approach"
    },
    "high": {
        "max_position_size": 0.20,  # 20% of available capital
        "max_positions": 15,
        "min_social_proof": 5.0,
        "min_safety_score": 6.0,
        "confirmation_sources": 1,
        "description": "High risk - aggressive approach"
    }
}

# Source reliability ratings cache
_source_reliability = {}

# Performance tracking cache
_performance_history = {}


@dataclass
class RiskAssessment:
    """Data class to hold risk assessment results."""
    token_address: str
    risk_level: str  # "low", "medium", "high", "extreme", "forbidden"
    position_size: float
    max_amount: float
    confidence: float  # 0-1 scale
    reasons: List[str]
    verification_sources: List[str]
    risk_factors: Dict[str, Any]
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert assessment to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "risk_level": self.risk_level,
            "position_size": self.position_size,
            "max_amount": self.max_amount,
            "confidence": self.confidence,
            "reasons": self.reasons,
            "verification_sources": self.verification_sources,
            "risk_factors": self.risk_factors,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RiskAssessment':
        """Create assessment object from dictionary."""
        return cls(
            token_address=data["token_address"],
            risk_level=data["risk_level"],
            position_size=data["position_size"],
            max_amount=data["max_amount"],
            confidence=data["confidence"],
            reasons=data["reasons"],
            verification_sources=data["verification_sources"],
            risk_factors=data["risk_factors"],
            timestamp=data["timestamp"]
        )
    
    @property
    def summary(self) -> str:
        """Get a human-readable summary of the assessment."""
        return (
            f"Risk Level: {self.risk_level.upper()}\n"
            f"Position Size: {self.position_size*100:.1f}% (max {self.max_amount} SOL)\n"
            f"Confidence: {self.confidence*100:.1f}%\n"
            f"Reasons: {', '.join(self.reasons[:3])}"
        )


@dataclass
class SourceReliability:
    """Data class to hold source reliability information."""
    source_id: str  # Group ID or wallet address
    source_type: str  # "group", "wallet", "twitter", etc.
    name: str
    reliability_score: float  # 0-10 scale
    risk_tier: str  # "low", "medium", "high"
    total_signals: int
    successful_signals: int
    profitable_signals: int
    average_profit: float
    last_updated: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert reliability to dictionary for storage."""
        return {
            "source_id": self.source_id,
            "source_type": self.source_type,
            "name": self.name,
            "reliability_score": self.reliability_score,
            "risk_tier": self.risk_tier,
            "total_signals": self.total_signals,
            "successful_signals": self.successful_signals,
            "profitable_signals": self.profitable_signals,
            "average_profit": self.average_profit,
            "last_updated": self.last_updated
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SourceReliability':
        """Create reliability object from dictionary."""
        return cls(
            source_id=data["source_id"],
            source_type=data["source_type"],
            name=data["name"],
            reliability_score=data["reliability_score"],
            risk_tier=data["risk_tier"],
            total_signals=data["total_signals"],
            successful_signals=data["successful_signals"],
            profitable_signals=data["profitable_signals"],
            average_profit=data["average_profit"],
            last_updated=data["last_updated"]
        )


async def assess_token_risk(
    token_address: str,
    social_proof_score: float,
    safety_score: float,
    source_id: str,
    source_type: str,
    available_capital: float
) -> RiskAssessment:
    """
    Perform a comprehensive risk assessment for a token.
    
    Args:
        token_address: The token address to assess
        social_proof_score: Social proof score (0-10)
        safety_score: Token safety score (0-10)
        source_id: Source identifier (group ID, wallet address)
        source_type: Type of source ("group", "wallet", "twitter")
        available_capital: Available capital for investment
        
    Returns:
        RiskAssessment object with detailed assessment
    """
    reasons = []
    verification_sources = [f"{source_type}:{source_id}"]
    risk_factors = {}
    
    # Get source reliability
    source = await get_source_reliability(source_id, source_type)
    source_tier = source.risk_tier
    
    # Default to source's risk tier
    risk_level = source_tier
    risk_factors["source_tier"] = source_tier
    reasons.append(f"Source reliability tier: {source_tier}")
    
    # Adjust risk level based on scores
    tier_settings = RISK_TIERS[source_tier]
    
    # Check if social proof score meets minimum for this tier
    if social_proof_score < tier_settings["min_social_proof"]:
        risk_level = "high" if risk_level == "medium" else "extreme"
        reasons.append(f"Social proof score ({social_proof_score}) below tier minimum ({tier_settings['min_social_proof']})")
        risk_factors["social_proof_warning"] = True
    else:
        reasons.append(f"Strong social proof score: {social_proof_score}")
        risk_factors["social_proof_warning"] = False
    
    # Check if safety score meets minimum for this tier
    if safety_score < tier_settings["min_safety_score"]:
        risk_level = "high" if risk_level == "medium" else "extreme"
        reasons.append(f"Safety score ({safety_score}) below tier minimum ({tier_settings['min_safety_score']})")
        risk_factors["safety_warning"] = True
    else:
        reasons.append(f"Good safety score: {safety_score}")
        risk_factors["safety_warning"] = False
    
    # Determine position size based on risk level, scores and available capital
    position_size, max_amount = calculate_position_size(
        risk_level, 
        social_proof_score, 
        safety_score, 
        source.reliability_score,
        available_capital
    )
    
    # Calculate confidence based on multiple factors
    confidence = calculate_confidence(
        social_proof_score,
        safety_score,
        source.reliability_score,
        risk_level
    )
    
    # Check for insufficient confirmation sources
    if tier_settings["confirmation_sources"] > 1:
        reasons.append(f"Requires {tier_settings['confirmation_sources']} confirmation sources")
        # In a real implementation, we would check other sources here
    
    # Create and return assessment
    return RiskAssessment(
        token_address=token_address,
        risk_level=risk_level,
        position_size=position_size,
        max_amount=max_amount,
        confidence=confidence,
        reasons=reasons,
        verification_sources=verification_sources,
        risk_factors=risk_factors,
        timestamp=time.time()
    )


def calculate_position_size(
    risk_level: str,
    social_proof_score: float,
    safety_score: float,
    reliability_score: float,
    available_capital: float
) -> Tuple[float, float]:
    """
    Calculate the appropriate position size based on risk assessment.
    
    Args:
        risk_level: Risk level category
        social_proof_score: Social proof score (0-10)
        safety_score: Token safety score (0-10)
        reliability_score: Source reliability score (0-10)
        available_capital: Available capital for investment
        
    Returns:
        Tuple of (position size as fraction, maximum amount)
    """
    # Base position size from risk tier
    if risk_level in RISK_TIERS:
        base_position = RISK_TIERS[risk_level]["max_position_size"]
    elif risk_level == "extreme":
        base_position = 0.05  # Very small position for extreme risk
    else:  # "forbidden"
        return 0.0, 0.0
    
    # Adjust based on scores - higher scores can increase position size
    score_multiplier = 1.0
    
    # Social proof adjustment (±30%)
    if social_proof_score >= 8.5:
        score_multiplier += 0.3  # Boost for very high social proof
    elif social_proof_score >= 7.0:
        score_multiplier += 0.15  # Smaller boost for good social proof
    elif social_proof_score < 6.0:
        score_multiplier -= 0.2  # Reduce for lower social proof
    
    # Safety score adjustment (±30%)
    if safety_score >= 8.5:
        score_multiplier += 0.3  # Boost for very safe tokens
    elif safety_score >= 7.0:
        score_multiplier += 0.15  # Smaller boost for reasonably safe tokens
    elif safety_score < 6.0:
        score_multiplier -= 0.2  # Reduce for less safe tokens
    
    # Source reliability adjustment (±20%)
    if reliability_score >= 8.0:
        score_multiplier += 0.2  # Boost for highly reliable sources
    elif reliability_score >= 6.5:
        score_multiplier += 0.1  # Smaller boost for reliable sources
    elif reliability_score < 5.0:
        score_multiplier -= 0.15  # Reduce for less reliable sources
    
    # Calculate final position size
    adjusted_position = base_position * score_multiplier
    
    # Apply caps based on risk level
    if risk_level == "low":
        adjusted_position = min(adjusted_position, 0.10)  # Max 10% for low risk
    elif risk_level == "medium":
        adjusted_position = min(adjusted_position, 0.15)  # Max 15% for medium risk
    elif risk_level == "high":
        adjusted_position = min(adjusted_position, 0.25)  # Max 25% for high risk
    elif risk_level == "extreme":
        adjusted_position = min(adjusted_position, 0.10)  # Max 10% for extreme risk
    
    # Calculate maximum amount
    max_amount = available_capital * adjusted_position
    
    # Apply absolute caps based on risk level
    if risk_level == "low":
        max_amount = min(max_amount, 0.5)  # Max 0.5 SOL for low risk
    elif risk_level == "medium":
        max_amount = min(max_amount, 1.0)  # Max 1 SOL for medium risk
    elif risk_level == "high":
        max_amount = min(max_amount, 2.0)  # Max 2 SOL for high risk
    elif risk_level == "extreme":
        max_amount = min(max_amount, 0.5)  # Max 0.5 SOL for extreme risk
    
    return adjusted_position, max_amount


def calculate_confidence(
    social_proof_score: float,
    safety_score: float,
    reliability_score: float,
    risk_level: str
) -> float:
    """
    Calculate the confidence level for a trade.
    
    Args:
        social_proof_score: Social proof score (0-10)
        safety_score: Token safety score (0-10)
        reliability_score: Source reliability score (0-10)
        risk_level: Risk level category
        
    Returns:
        Confidence level as a fraction (0-1)
    """
    # Base components weighted by importance
    social_proof_component = social_proof_score / 10 * 0.4  # 40% weight
    safety_component = safety_score / 10 * 0.35  # 35% weight
    reliability_component = reliability_score / 10 * 0.25  # 25% weight
    
    # Calculate base confidence
    base_confidence = social_proof_component + safety_component + reliability_component
    
    # Apply risk level adjustments
    if risk_level == "low":
        confidence = base_confidence * 1.1  # Boost for low risk
    elif risk_level == "medium":
        confidence = base_confidence * 1.0  # No adjustment
    elif risk_level == "high":
        confidence = base_confidence * 0.9  # Slight reduction
    elif risk_level == "extreme":
        confidence = base_confidence * 0.7  # Significant reduction
    else:  # "forbidden"
        confidence = 0.0
    
    # Cap at 1.0
    return min(confidence, 1.0)


async def get_source_reliability(source_id: str, source_type: str) -> SourceReliability:
    """
    Get reliability information for a source.
    
    Args:
        source_id: Source identifier (group ID, wallet address)
        source_type: Type of source ("group", "wallet", "twitter")
        
    Returns:
        SourceReliability object with reliability data
    """
    # Check cache first
    cache_key = f"{source_type}:{source_id}"
    if cache_key in _source_reliability:
        return _source_reliability[cache_key]
    
    # In a real implementation, we would fetch from a database
    # For now, we'll create some default values based on source type
    
    if source_type == "group":
        # Default values for Telegram groups
        reliability = SourceReliability(
            source_id=source_id,
            source_type=source_type,
            name=f"Group {source_id[-4:]}",
            reliability_score=6.5,  # Moderate reliability
            risk_tier="medium",  # Default to medium risk
            total_signals=10,
            successful_signals=6,
            profitable_signals=5,
            average_profit=25.0,
            last_updated=time.time()
        )
    
    elif source_type == "wallet":
        # Default values for tracked wallets
        reliability = SourceReliability(
            source_id=source_id,
            source_type=source_type,
            name=f"Wallet {source_id[-4:]}",
            reliability_score=7.5,  # Higher reliability for wallets
            risk_tier="low",  # Default to low risk
            total_signals=15,
            successful_signals=10,
            profitable_signals=8,
            average_profit=35.0,
            last_updated=time.time()
        )
    
    elif source_type == "twitter":
        # Default values for Twitter sources
        reliability = SourceReliability(
            source_id=source_id,
            source_type=source_type,
            name=f"Twitter {source_id[-4:]}",
            reliability_score=6.0,  # Moderate reliability
            risk_tier="medium",  # Default to medium risk
            total_signals=8,
            successful_signals=4,
            profitable_signals=3,
            average_profit=20.0,
            last_updated=time.time()
        )
    
    else:
        # Default for other source types
        reliability = SourceReliability(
            source_id=source_id,
            source_type=source_type,
            name=f"Source {source_id[-4:]}",
            reliability_score=5.0,  # Lower reliability for unknown sources
            risk_tier="high",  # Default to high risk
            total_signals=5,
            successful_signals=2,
            profitable_signals=1,
            average_profit=15.0,
            last_updated=time.time()
        )
    
    # Cache for future use
    _source_reliability[cache_key] = reliability
    
    return reliability


async def update_source_reliability(
    source_id: str,
    source_type: str,
    token_address: str,
    was_successful: bool,
    profit_percent: Optional[float] = None
) -> SourceReliability:
    """
    Update the reliability score for a source based on a trade outcome.
    
    Args:
        source_id: Source identifier (group ID, wallet address)
        source_type: Type of source ("group", "wallet", "twitter")
        token_address: Token address that was traded
        was_successful: Whether the trade was successful
        profit_percent: Optional profit percentage
        
    Returns:
        Updated SourceReliability object
    """
    # Get current reliability
    reliability = await get_source_reliability(source_id, source_type)
    
    # Update statistics
    reliability.total_signals += 1
    
    if was_successful:
        reliability.successful_signals += 1
        
        if profit_percent is not None and profit_percent > 0:
            reliability.profitable_signals += 1
            
            # Update average profit
            total_profit = reliability.average_profit * (reliability.profitable_signals - 1)
            total_profit += profit_percent
            reliability.average_profit = total_profit / reliability.profitable_signals
    
    # Calculate success rate
    success_rate = reliability.successful_signals / reliability.total_signals
    
    # Calculate profit rate
    profit_rate = reliability.profitable_signals / reliability.total_signals
    
    # Calculate new reliability score (0-10 scale)
    reliability_score = (
        success_rate * 5.0 +  # 0-5 points for success rate
        profit_rate * 3.0 +   # 0-3 points for profit rate
        min(reliability.average_profit / 50, 1.0) * 2.0  # 0-2 points for average profit
    )
    
    # Update reliability score
    reliability.reliability_score = reliability_score
    
    # Update risk tier based on reliability score
    if reliability_score >= 8.0:
        reliability.risk_tier = "low"
    elif reliability_score >= 6.0:
        reliability.risk_tier = "medium"
    else:
        reliability.risk_tier = "high"
    
    # Update timestamp
    reliability.last_updated = time.time()
    
    # Cache updated reliability
    cache_key = f"{source_type}:{source_id}"
    _source_reliability[cache_key] = reliability
    
    # In a real implementation, we would save to a database
    
    return reliability


async def log_trade_performance(
    token_address: str,
    risk_assessment: RiskAssessment,
    trade_successful: bool,
    profit_percent: Optional[float] = None
) -> None:
    """
    Log trade performance for learning and improvement.
    
    Args:
        token_address: Token address that was traded
        risk_assessment: The risk assessment used for the trade
        trade_successful: Whether the trade was successful
        profit_percent: Optional profit percentage
    """
    # In a real implementation, we would save to a database
    
    # Update source reliability for all verification sources
    for source in risk_assessment.verification_sources:
        try:
            source_type, source_id = source.split(":", 1)
            await update_source_reliability(
                source_id,
                source_type,
                token_address,
                trade_successful,
                profit_percent
            )
        except Exception as e:
            logger.error(f"Error updating source reliability: {e}")
    
    # Add to performance history
    _performance_history[token_address] = {
        "token_address": token_address,
        "risk_level": risk_assessment.risk_level,
        "confidence": risk_assessment.confidence,
        "successful": trade_successful,
        "profit_percent": profit_percent,
        "timestamp": time.time()
    }


async def should_continue_trading(lookback_hours: int = 24) -> Tuple[bool, str, float]:
    """
    Determine if automated trading should continue based on recent performance.
    
    Args:
        lookback_hours: Hours to look back for performance analysis
        
    Returns:
        Tuple of (should_continue, reason, profit_rate)
    """
    # In a real implementation, we would query a database
    # For now, use in-memory performance history
    
    # Calculate lookback time
    lookback_time = time.time() - (lookback_hours * 3600)
    
    # Filter recent trades
    recent_trades = [
        trade for trade in _performance_history.values()
        if trade["timestamp"] >= lookback_time
    ]
    
    # If no recent trades, continue trading
    if not recent_trades:
        return True, "No recent trades to analyze", 0.0
    
    # Calculate success and profit rates
    total_trades = len(recent_trades)
    successful_trades = sum(1 for trade in recent_trades if trade["successful"])
    profitable_trades = sum(1 for trade in recent_trades 
                           if trade["successful"] and trade.get("profit_percent", 0) > 0)
    
    success_rate = successful_trades / total_trades
    profit_rate = profitable_trades / total_trades
    
    # Calculate average profit percentage
    profit_percentages = [trade.get("profit_percent", 0) for trade in recent_trades 
                         if trade["successful"] and trade.get("profit_percent") is not None]
    
    average_profit = sum(profit_percentages) / len(profit_percentages) if profit_percentages else 0
    
    # Decision logic based on metrics
    if average_profit >= 30.0 and success_rate >= 0.5:
        return True, "Strong performance, continuing trading", average_profit
    
    if average_profit >= 20.0 and success_rate >= 0.4:
        return True, "Good performance, continuing trading", average_profit
    
    if average_profit < 0 and success_rate < 0.3:
        return False, "Poor performance, pausing trading", average_profit
    
    if success_rate < 0.25:
        return False, "Low success rate, pausing trading", average_profit
    
    # Default to continue
    return True, "Acceptable performance, continuing trading", average_profit


# Test functions
async def test_risk_manager():
    # Test with different risk scenarios
    
    # High quality token, reliable source
    assessment = await assess_token_risk(
        token_address="0x1234567890123456789012345678901234567890",
        social_proof_score=8.5,
        safety_score=9.0,
        source_id="12345",
        source_type="wallet",
        available_capital=10.0
    )
    
    print("High quality assessment:")
    print(f"Risk level: {assessment.risk_level}")
    print(f"Position size: {assessment.position_size*100:.1f}%")
    print(f"Max amount: {assessment.max_amount} SOL")
    print(f"Confidence: {assessment.confidence*100:.1f}%")
    print(f"Reasons: {assessment.reasons}")
    
    # Medium quality token, less reliable source
    assessment = await assess_token_risk(
        token_address="0x1234567890123456789012345678901234567891",
        social_proof_score=6.5,
        safety_score=7.0,
        source_id="67890",
        source_type="group",
        available_capital=10.0
    )
    
    print("\nMedium quality assessment:")
    print(f"Risk level: {assessment.risk_level}")
    print(f"Position size: {assessment.position_size*100:.1f}%")
    print(f"Max amount: {assessment.max_amount} SOL")
    print(f"Confidence: {assessment.confidence*100:.1f}%")
    print(f"Reasons: {assessment.reasons}")
    
    # Low quality token, unreliable source
    assessment = await assess_token_risk(
        token_address="0x1234567890123456789012345678901234567892",
        social_proof_score=4.0,
        safety_score=5.0,
        source_id="13579",
        source_type="twitter",
        available_capital=10.0
    )
    
    print("\nLow quality assessment:")
    print(f"Risk level: {assessment.risk_level}")
    print(f"Position size: {assessment.position_size*100:.1f}%")
    print(f"Max amount: {assessment.max_amount} SOL")
    print(f"Confidence: {assessment.confidence*100:.1f}%")
    print(f"Reasons: {assessment.reasons}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_risk_manager())