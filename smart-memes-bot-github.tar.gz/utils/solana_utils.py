"""
Solana blockchain utilities for real-time interactions
"""

import os
import base58
import logging
import time
from typing import Dict, Any, Tuple, List, Optional, Union

# Try to support both new and old versions of the Solana library
try:
    # New Solana library structure (solana-py >= 0.27.0)
    from solders.keypair import Keypair
    from solders.pubkey import Pubkey as PublicKey
    from solana.rpc.api import Client
    from solana.transaction import Transaction
    from solana.transaction import TransactionInstruction
    from solana.system_program import transfer, TransferParams
    SOLDERS_IMPORTED = True
except ImportError:
    try:
        # Old Solana library structure (solana-py < 0.27.0)
        from solana.keypair import Keypair
        from solana.publickey import PublicKey
        from solana.rpc.api import Client
        from solana.rpc.types import TxOpts
        from solana.transaction import Transaction
        from solana.system_program import transfer, TransferParams
        SOLDERS_IMPORTED = False
    except ImportError:
        logging.warning("Solana libraries not available, using simplified implementation")
        # Define stub classes as fallbacks
        class Keypair:
            @classmethod
            def from_secret_key(cls, secret_key):
                return cls()
                
            @property
            def public_key(self):
                return PublicKey("11111111111111111111111111111111")
                
        class PublicKey:
            def __init__(self, address):
                self.address = address
                
        class Client:
            def __init__(self, endpoint):
                self.endpoint = endpoint
                
            def get_balance(self, pubkey):
                return {"result": {"value": 0}}
                
        class TxOpts:
            def __init__(self, **kwargs):
                self.kwargs = kwargs
                
        class Transaction:
            def add(self, instruction):
                return self
                
        def transfer(*args, **kwargs):
            return None
            
        class TransferParams:
            def __init__(self, **kwargs):
                self.kwargs = kwargs

# Configure logging
logger = logging.getLogger(__name__)

# Initialize Solana client
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")

solana_client = Client(SOLANA_RPC_URL)

def get_keypair_from_private_key(private_key: Optional[str] = None) -> Keypair:
    """
    Create a Solana keypair from a private key.
    
    Args:
        private_key: Base58 encoded private key string. If None, uses environment variable.
        
    Returns:
        Solana Keypair object
    """
    try:
        if not private_key:
            private_key = SOLANA_PRIVATE_KEY
            
        if not private_key:
            logger.error("No Solana private key provided")
            raise ValueError("Solana private key is required")
            
        # Convert Base58 private key to bytes
        private_key_bytes = base58.b58decode(private_key)
        
        # Create keypair from private key bytes
        return Keypair.from_secret_key(private_key_bytes)
    except Exception as e:
        logger.error(f"Failed to create keypair: {str(e)}")
        raise

def get_keypair_from_mnemonic(mnemonic_phrase: str) -> Keypair:
    """
    Create a Solana keypair from a mnemonic (seed phrase).
    
    Args:
        mnemonic_phrase: 12 or 24-word mnemonic phrase
        
    Returns:
        Solana Keypair object
    """
    try:
        # For newer solana library, import directly
        try:
            from solana.mnemonic import Mnemonic
            seed = Mnemonic.to_seed(mnemonic_phrase)
            return Keypair.from_seed(seed[:32])
        except ImportError:
            # For older versions or using solders
            try:
                from bip39 import bip39_to_seed
                seed = bip39_to_seed(mnemonic_phrase, "")
                return Keypair.from_seed(seed[:32])
            except ImportError:
                logger.error("Could not import mnemonic libraries")
                raise ImportError("Required libraries for mnemonic handling not available")
    except Exception as e:
        logger.error(f"Failed to create keypair from mnemonic: {str(e)}")
        raise

def get_wallet_balance(wallet_address: str) -> float:
    """
    Get the SOL balance of a wallet.
    
    Args:
        wallet_address: The wallet's public key as string
        
    Returns:
        Float balance in SOL
    """
    try:
        pubkey = PublicKey(wallet_address)
        response = solana_client.get_balance(pubkey)
        if "result" in response and "value" in response["result"]:
            # Convert lamports to SOL (1 SOL = 10^9 lamports)
            return response["result"]["value"] / 1_000_000_000
        else:
            logger.error(f"Invalid response from get_balance: {response}")
            return 0.0
    except Exception as e:
        logger.error(f"Error getting wallet balance: {str(e)}")
        return 0.0

# Alias function used by advanced profit systems
check_wallet_balance = get_wallet_balance

def get_token_account_info(token_mint_address: str, owner_address: str) -> Dict[str, Any]:
    """
    Get information about a token account.
    
    Args:
        token_mint_address: Token mint address
        owner_address: Owner wallet address
        
    Returns:
        Dict with token account information
    """
    try:
        # This is a simplified implementation
        # In a real-world scenario, you would need to find the associated token account
        # and query its data
        
        # Get token accounts by owner
        response = solana_client.get_token_accounts_by_owner(
            PublicKey(owner_address),
            {"mint": PublicKey(token_mint_address)}
        )
        
        if "result" in response and "value" in response["result"] and response["result"]["value"]:
            account_data = response["result"]["value"][0]
            return {
                "pubkey": account_data["pubkey"],
                "account": account_data["account"],
                "exists": True
            }
        else:
            return {"exists": False, "error": "Token account not found"}
    except Exception as e:
        logger.error(f"Error getting token account info: {str(e)}")
        return {"exists": False, "error": str(e)}

def transfer_sol(
    from_keypair: Keypair, 
    to_address: str, 
    amount_sol: float
) -> Dict[str, Any]:
    """
    Transfer SOL from one account to another.
    
    Args:
        from_keypair: Keypair of the sender
        to_address: Recipient's public key as string
        amount_sol: Amount in SOL to transfer
        
    Returns:
        Dict with transaction result
    """
    try:
        # Convert SOL to lamports
        lamports = int(amount_sol * 1_000_000_000)
        
        # Create transfer instruction
        transfer_instruction = transfer(
            TransferParams(
                from_pubkey=from_keypair.public_key,
                to_pubkey=PublicKey(to_address),
                lamports=lamports
            )
        )
        
        # Create and sign transaction
        transaction = Transaction().add(transfer_instruction)
        tx_opts = TxOpts(skip_preflight=False)
        
        # Send transaction
        result = solana_client.send_transaction(
            transaction, 
            from_keypair,
            opts=tx_opts
        )
        
        if "result" in result:
            return {
                "success": True,
                "signature": result["result"],
                "amount_sol": amount_sol
            }
        else:
            return {
                "success": False,
                "error": f"Transaction failed: {result}"
            }
    except Exception as e:
        logger.error(f"Error transferring SOL: {str(e)}")
        return {
            "success": False,
            "error": str(e)
        }

def is_valid_solana_address(address: str) -> bool:
    """
    Check if a string is a valid Solana address.
    
    Args:
        address: Address to validate
        
    Returns:
        Boolean indicating if address is valid
    """
    try:
        PublicKey(address)
        return True
    except Exception:
        return False

# Example function to test connectivity
def test_solana_connection() -> bool:
    """
    Test connection to Solana blockchain.
    
    Returns:
        Boolean indicating if connection is successful
    """
    try:
        response = solana_client.get_version()
        return "result" in response
    except Exception as e:
        logger.error(f"Solana connection test failed: {str(e)}")
        return False

def get_transaction_history(wallet_address: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Get recent transactions for a wallet address.
    
    Args:
        wallet_address: The wallet's public key as string
        limit: Maximum number of transactions to return
        
    Returns:
        List of transaction information dictionaries
    """
    try:
        # Validate the wallet address
        if not is_valid_solana_address(wallet_address):
            logger.error(f"Invalid wallet address: {wallet_address}")
            return []
            
        # Get recent transaction signatures for the address
        response = solana_client.get_signatures_for_address(
            PublicKey(wallet_address),
            limit=limit
        )
        
        if "result" not in response:
            logger.error(f"Invalid response from get_signatures_for_address: {response}")
            return []
            
        # Get detailed transaction info for each signature
        transactions = []
        for sig_info in response["result"]:
            signature = sig_info["signature"]
            timestamp = sig_info.get("blockTime", None)
            
            # Get the transaction details
            tx_response = solana_client.get_transaction(signature)
            if "result" in tx_response and tx_response["result"]:
                tx_result = tx_response["result"]
                
                # Extract basic transaction info
                tx_info = {
                    "signature": signature,
                    "timestamp": timestamp,
                    "status": "confirmed" if tx_result.get("meta", {}).get("err") is None else "failed",
                    "fee": tx_result.get("meta", {}).get("fee", 0),
                }
                
                transactions.append(tx_info)
            
        return transactions
    except Exception as e:
        logger.error(f"Error getting transaction history: {str(e)}")
        return []

async def execute_sniper_buy(token_address: str, amount_sol: float, slippage: float = 2.0) -> Dict[str, Any]:
    """
    Execute a token purchase with sniping configuration.
    
    Args:
        token_address: Token mint address
        amount_sol: Amount of SOL to spend
        slippage: Slippage tolerance percentage
        
    Returns:
        Dict with transaction result
    """
    try:
        logger.info(f"Executing sniper buy for token {token_address} with {amount_sol} SOL")
        
        # Get wallet keypair
        keypair = get_keypair_from_private_key()
        
        # Validate token address
        if not is_valid_solana_address(token_address):
            return {
                "success": False,
                "error": "Invalid token address format"
            }
        
        # In a real implementation, this would connect to a DEX (like Jupiter or Raydium)
        # and execute a swap transaction. For now, we'll use a simplified implementation
        # that pretends to execute the trade.
        
        # Simulated transaction hash (in a real implementation, this would be returned from the DEX)
        tx_signature = f"simulated_{token_address[:8]}_{int(time.time())}"
        
        # In a real implementation, we would calculate the expected output amount
        # based on the current price and slippage
        expected_token_amount = amount_sol * 1000  # This is just a placeholder
        
        return {
            "success": True,
            "transaction_signature": tx_signature,
            "amount_sol_spent": amount_sol,
            "expected_token_amount": expected_token_amount,
            "slippage_used": slippage
        }
    except Exception as e:
        logger.error(f"Error executing sniper buy: {str(e)}")
        return {
            "success": False,
            "error": str(e)
        }