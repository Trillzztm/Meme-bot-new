import os
import logging
from utils.ai_token_analyzer import analyze_token_social as token_social_analysis

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("ai_tools")

def analyze_token_social(token_address):
    """
    Get social sentiment analysis for a token.
    
    Args:
        token_address: The token's mint address
        
    Returns:
        String with social sentiment analysis
    """
    logger.info(f"Getting social analysis for {token_address}")
    
    try:
        analysis = token_social_analysis(token_address)
        return analysis
    except Exception as e:
        logger.error(f"Error analyzing token social sentiment: {e}")
        return "Could not analyze token social sentiment at this time."