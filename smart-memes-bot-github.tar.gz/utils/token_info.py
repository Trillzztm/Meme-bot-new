"""
Token information utilities for SMART MEMES BOT.

This module provides basic token information functions such as getting
token names, symbols, and other metadata.
"""

import logging
import re
import hashlib
from typing import Dict, Any, Optional

# Configure logger
logger = logging.getLogger(__name__)

# Try to import pricing module
try:
    from utils.pricing import get_token_price, get_token_liquidity
    HAS_PRICING = True
except ImportError:
    logger.warning("Pricing module not available for token info")
    HAS_PRICING = False


async def get_token_info(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Get basic token information (name, symbol, etc.) for a given token address.
    
    Args:
        token_address: The token address to look up
        network: Blockchain network (solana, ethereum, bsc, polygon)
        
    Returns:
        Dictionary with token info
    """
    # Initialize the result with defaults
    result = {
        "address": token_address,
        "network": network,
        "name": f"Token-{token_address[:8]}",
        "symbol": f"{token_address[:4].upper()}",
        "decimals": 9 if network == 'solana' else 18,
        "price": 0,
        "liquidity": 0,
        "volume_24h": 0,
        "market_cap": 0
    }
    
    # Special case handling for known tokens
    if await is_known_token(token_address, network):
        known_token = await get_known_token_data(token_address, network)
        if known_token:
            result.update(known_token)
    
    # Get price information if pricing module is available
    if HAS_PRICING:
        try:
            price = await get_token_price(token_address, network)
            if price:
                result["price"] = price
                
            liquidity = await get_token_liquidity(token_address, network)
            if liquidity:
                result["liquidity"] = liquidity
                
            # Estimate market cap (very rough)
            if price and "total_supply" in result:
                result["market_cap"] = price * result["total_supply"]
                
        except Exception as e:
            logger.error(f"Error getting price data for {token_address}: {e}")
    
    return result


async def is_known_token(token_address: str, network: str) -> bool:
    """
    Check if a token is in our known tokens database.
    
    Args:
        token_address: The token address to check
        network: Blockchain network
        
    Returns:
        True if token is known, False otherwise
    """
    # In a real implementation, this would check a database
    # For now, we'll hardcode a few known tokens for demo purposes
    known_tokens = {
        'solana': [
            "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
            "So11111111111111111111111111111111111111112",  # SOL (Wrapped)
            "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",  # BONK
            "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # RENDER
        ],
        'ethereum': [
            "0x6b175474e89094c44da98b954eedeac495271d0f",  # DAI
            "0xdac17f958d2ee523a2206206994597c13d831ec7",  # USDT
            "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",  # USDC
        ]
    }
    
    if network in known_tokens:
        return token_address in known_tokens[network]
    
    return False


async def get_known_token_data(token_address: str, network: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed data for a known token.
    
    Args:
        token_address: The token address to look up
        network: Blockchain network
        
    Returns:
        Dictionary with token data or None if not found
    """
    # Map of known tokens to their data
    known_token_data = {
        # Solana tokens
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v": {
            "name": "USD Coin",
            "symbol": "USDC",
            "decimals": 6,
            "total_supply": 5000000000,
            "is_stable": True
        },
        "So11111111111111111111111111111111111111112": {
            "name": "Wrapped SOL",
            "symbol": "wSOL",
            "decimals": 9,
            "total_supply": 500000000,
            "is_stable": False
        },
        "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263": {
            "name": "Bonk",
            "symbol": "BONK",
            "decimals": 5,
            "total_supply": 500000000000000,
            "is_stable": False
        },
        "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU": {
            "name": "Render Token",
            "symbol": "RNDR",
            "decimals": 8,
            "total_supply": 536000000,
            "is_stable": False
        },
        
        # Ethereum tokens
        "0x6b175474e89094c44da98b954eedeac495271d0f": {
            "name": "Dai Stablecoin",
            "symbol": "DAI",
            "decimals": 18,
            "total_supply": 8500000000,
            "is_stable": True
        },
        "0xdac17f958d2ee523a2206206994597c13d831ec7": {
            "name": "Tether USD",
            "symbol": "USDT",
            "decimals": 6,
            "total_supply": 73000000000,
            "is_stable": True
        },
        "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": {
            "name": "USD Coin",
            "symbol": "USDC",
            "decimals": 6,
            "total_supply": 45000000000,
            "is_stable": True
        }
    }
    
    return known_token_data.get(token_address)


def is_valid_token_address(token_address: str, network: str = 'solana') -> bool:
    """
    Validate if a string is a proper token address format.
    
    Args:
        token_address: Token address to validate
        network: Blockchain network
        
    Returns:
        True if valid format, False otherwise
    """
    if not token_address:
        return False
        
    # Validate based on network
    if network == 'solana':
        # Solana addresses are base58 encoded, typically 32-44 chars
        return bool(re.match(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$', token_address))
    elif network in ['ethereum', 'bsc', 'polygon']:
        # EVM addresses are hex, 0x followed by 40 hex chars
        return bool(re.match(r'^0x[a-fA-F0-9]{40}$', token_address))
    else:
        # Unknown network
        return False


def extract_token_name_from_address(token_address: str) -> str:
    """
    Create a human-readable token name from an address.
    Used when real token name is unavailable.
    
    Args:
        token_address: Token address
        
    Returns:
        Simplified token name
    """
    if not token_address:
        return "Unknown Token"
        
    # Use a hash for consistent naming
    token_hash = hashlib.md5(token_address.encode()).hexdigest()
    
    # Take first 6 characters
    return f"Token-{token_hash[:6].upper()}"