"""
Direct API utilities for token information.

This module provides direct API calls to blockchain explorers for rapid token lookups
without requiring the full token_analyzer module. It can be used as a fallback or
for lightweight implementations.
"""

import logging
import requests
from typing import Dict, Any, Optional, Union

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def get_solana_token_info(token_address: str) -> str:
    """
    Get basic Solana token information directly from Solscan API.
    
    Args:
        token_address: The token's contract address
        
    Returns:
        Formatted Markdown string with token information
    """
    try:
        url = f"https://public-api.solscan.io/token/meta?tokenAddress={token_address}"
        response = requests.get(url, headers={"accept": "application/json"})
        resp = response.json()
        
        if "symbol" not in resp:
            return "❌ Token not found or invalid address."
        
        # Format the response with more details and emojis
        return (
            f"🔍 *{resp.get('name','N/A')}* (`{resp.get('symbol','')}`)\n"
            f"📝 *Address:* `{token_address}`\n"
            f"🏦 *Supply:* {resp.get('totalSupply','?')}\n"
            f"👥 *Holders:* {resp.get('holders',0)}\n"
            f"🌐 *Website:* {resp.get('website','–')}"
        )
    except Exception as e:
        logger.error(f"Error fetching Solana token info: {str(e)}")
        return f"❌ *Error fetching token info:* {str(e)}"

def get_ethereum_token_info(token_address: str) -> str:
    """
    Get basic Ethereum token information directly from Etherscan API.
    
    Args:
        token_address: The token's contract address
        
    Returns:
        Formatted Markdown string with token information
    """
    try:
        # Note: In a production environment, you would need to provide an API key
        url = f"https://api.etherscan.io/api?module=token&action=tokeninfo&contractaddress={token_address}"
        response = requests.get(url)
        data = response.json()
        
        if data.get("status") != "1":
            return "❌ Token not found or invalid address."
        
        result = data.get("result", [])[0] if isinstance(data.get("result", []), list) else data.get("result", {})
        
        # Format the response
        return (
            f"🔍 *{result.get('name','N/A')}* (`{result.get('symbol','')}`)\n"
            f"📝 *Address:* `{token_address}`\n"
            f"🏦 *Supply:* {result.get('totalSupply','?')}\n"
            f"🔢 *Decimals:* {result.get('divisor','?')}\n"
            f"🌐 *Website:* {result.get('website','–')}"
        )
    except Exception as e:
        logger.error(f"Error fetching Ethereum token info: {str(e)}")
        return f"❌ *Error fetching token info:* {str(e)}"

def get_bsc_token_info(token_address: str) -> str:
    """
    Get basic BSC token information directly from BscScan API.
    
    Args:
        token_address: The token's contract address
        
    Returns:
        Formatted Markdown string with token information
    """
    try:
        # Note: In a production environment, you would need to provide an API key
        url = f"https://api.bscscan.com/api?module=token&action=tokeninfo&contractaddress={token_address}"
        response = requests.get(url)
        data = response.json()
        
        if data.get("status") != "1":
            return "❌ Token not found or invalid address."
        
        result = data.get("result", [])[0] if isinstance(data.get("result", []), list) else data.get("result", {})
        
        # Format the response
        return (
            f"🔍 *{result.get('name','N/A')}* (`{result.get('symbol','')}`)\n"
            f"📝 *Address:* `{token_address}`\n"
            f"🏦 *Supply:* {result.get('totalSupply','?')}\n"
            f"🔢 *Decimals:* {result.get('divisor','?')}\n"
            f"🌐 *Website:* {result.get('website','–')}"
        )
    except Exception as e:
        logger.error(f"Error fetching BSC token info: {str(e)}")
        return f"❌ *Error fetching token info:* {str(e)}"

def get_token_info(token_address: str, network: str = "solana") -> str:
    """
    Get token information for any supported network.
    This is a direct API implementation that can be used as a lightweight
    alternative to the more comprehensive token_analyzer.
    
    Args:
        token_address: The token's contract address
        network: Network to check (solana, ethereum, bsc, polygon)
        
    Returns:
        Formatted Markdown string with token information
    """
    # Auto-detect network from address format if not specified
    if network == "auto":
        if token_address.startswith("0x"):
            network = "ethereum"  # Could be any EVM chain, defaulting to Ethereum
        elif len(token_address) > 30 and not token_address.startswith("0x"):
            network = "solana"
        else:
            network = "ethereum"  # Default
    
    # Call the appropriate network-specific function
    network = network.lower()
    if network == "solana":
        return get_solana_token_info(token_address)
    elif network == "ethereum":
        return get_ethereum_token_info(token_address)
    elif network in ["bsc", "binance"]:
        return get_bsc_token_info(token_address)
    elif network == "polygon":
        # Polygon uses the same format as Ethereum, but with a different API URL
        # For this example, we'll return a placeholder
        return f"Polygon token info not implemented yet. Address: {token_address}"
    else:
        return f"Unsupported network: {network}"