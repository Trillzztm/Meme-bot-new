"""
Whale detection module for SMART MEMES BOT.

This module monitors blockchain transactions to detect significant whale movements
that could impact token prices, allowing for early position taking.
"""

import logging
import asyncio
import time
import json
from typing import Dict, Any, List, Tuple, Optional, Set
import aiohttp
import base58

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our utilities
from utils.token_analyzer import analyze_token
from database import session_scope, get_user_tracked_tokens, get_user_settings
from config import WHALE_THRESHOLD, WHALE_TRANSACTION_THRESHOLD

# Constants
SOLSCAN_API = "https://public-api.solscan.io/transaction/"
MAX_RETRIES = 3
POLL_INTERVAL = 30  # seconds between checks

# Internal cache to prevent duplicate alerts
_processed_transactions: Set[str] = set()
_whale_cache: Dict[str, Dict[str, Any]] = {}

class WhaleDetector:
    """Whale transaction detector and analyzer"""
    
    def __init__(self):
        """Initialize the whale detector"""
        self.running = False
        self.task = None
        self._reset_cache_timer = time.time()
    
    async def start(self):
        """Start the whale detector background task"""
        if self.running:
            logger.warning("Whale detector already running")
            return
            
        self.running = True
        self.task = asyncio.create_task(self._monitor_loop())
        logger.info("Whale detector started")
    
    async def stop(self):
        """Stop the whale detector background task"""
        if not self.running:
            return
            
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
                
        logger.info("Whale detector stopped")
    
    async def _monitor_loop(self):
        """Main monitoring loop for whale detection"""
        try:
            while self.running:
                try:
                    # Get tracked tokens from database
                    tracked_tokens = await self._get_tracked_tokens()
                    
                    # Process each token
                    for token in tracked_tokens:
                        await self._check_token_whale_activity(token)
                    
                    # Reset cache periodically (every 4 hours)
                    current_time = time.time()
                    if current_time - self._reset_cache_timer > 14400:  # 4 hours
                        _processed_transactions.clear()
                        _whale_cache.clear()
                        self._reset_cache_timer = current_time
                        logger.info("Whale detection cache cleared")
                        
                except Exception as e:
                    logger.error(f"Error in whale monitoring loop: {e}")
                    
                # Wait before next iteration
                await asyncio.sleep(POLL_INTERVAL)
                
        except asyncio.CancelledError:
            logger.info("Whale monitor task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in whale monitoring: {e}")
            self.running = False
    
    async def _get_tracked_tokens(self) -> List[Dict[str, Any]]:
        """Get tracked tokens from the database"""
        try:
            # This would typically query the database
            # For now, we'll return a simplified representation
            tokens = []
            
            with session_scope() as session:
                # Fetch all tracked tokens
                db_tokens = session.query("SELECT * FROM tracked_tokens WHERE active = true").all()
                
                # Convert to our format
                for token in db_tokens:
                    tokens.append({
                        "address": token.address,
                        "symbol": token.symbol,
                        "name": token.name,
                        "network": token.network,
                        "users": token.users  # User IDs tracking this token
                    })
                    
            return tokens
            
        except Exception as e:
            logger.error(f"Error fetching tracked tokens: {e}")
            return []
    
    async def _check_token_whale_activity(self, token: Dict[str, Any]):
        """Check for whale activity for a specific token"""
        token_address = token.get("address")
        if not token_address:
            return
            
        try:
            # Get recent transactions for this token
            # In a real implementation, this would query blockchain APIs
            transactions = await self._get_token_transactions(token_address)
            
            # Process transactions
            for tx in transactions:
                # Skip if already processed
                tx_hash = tx.get("txHash")
                if not tx_hash or tx_hash in _processed_transactions:
                    continue
                
                # Mark as processed
                _processed_transactions.add(tx_hash)
                
                # Check if this is a whale transaction
                amount = tx.get("amount", 0)
                usd_value = tx.get("usdValue", 0)
                
                if (amount >= WHALE_TRANSACTION_THRESHOLD or 
                    usd_value >= WHALE_THRESHOLD):
                    # This is a whale transaction!
                    await self._process_whale_transaction(token, tx)
                    
        except Exception as e:
            logger.error(f"Error checking whale activity for {token_address}: {e}")
    
    async def _get_token_transactions(self, token_address: str) -> List[Dict[str, Any]]:
        """Get recent transactions for a token"""
        # In a real implementation, this would query blockchain APIs
        # For now, we'll return a placeholder
        return []
    
    async def _process_whale_transaction(self, token: Dict[str, Any], transaction: Dict[str, Any]):
        """Process a detected whale transaction and notify users"""
        try:
            token_address = token.get("address")
            token_symbol = token.get("symbol", "Unknown")
            token_name = token.get("name", "Unknown Token")
            
            tx_hash = transaction.get("txHash", "Unknown")
            tx_type = transaction.get("type", "Unknown")
            amount = transaction.get("amount", 0)
            usd_value = transaction.get("usdValue", 0)
            wallet = transaction.get("wallet", "Unknown")
            
            # Build notification message
            message = (
                f"🐋 *WHALE ALERT!* 🐋\n\n"
                f"*Token:* `{token_name} ({token_symbol})`\n"
                f"*Amount:* {amount:,.0f} tokens (${usd_value:,.2f})\n"
                f"*Action:* {tx_type.capitalize()}\n"
                f"*Wallet:* `{wallet[:8]}...{wallet[-6:]}`\n"
                f"*Transaction:* [View on Explorer](https://solscan.io/tx/{tx_hash})\n\n"
                f"🚨 *Potential price impact detected* 🚨"
            )
            
            # Notify all users tracking this token
            for user_id in token.get("users", []):
                try:
                    # Check user notification preferences
                    with session_scope() as session:
                        user_settings = get_user_settings(user_id)
                        if not user_settings or user_settings.get("whale_alerts", True):
                            # Send notification to user
                            # Note: In a real implementation, this would use the bot instance
                            logger.info(f"Sending whale alert to user {user_id} for {token_symbol}")
                            
                            # If auto-buy on whale transactions is enabled
                            if user_settings and user_settings.get("auto_buy_whale", False):
                                # Execute a purchase
                                whale_buy_amount = user_settings.get("whale_buy_amount", 0.05)
                                logger.info(f"Auto-buying {whale_buy_amount} SOL of {token_symbol} for user {user_id}")
                                
                except Exception as user_error:
                    logger.error(f"Error notifying user {user_id} about whale activity: {user_error}")
            
        except Exception as e:
            logger.error(f"Error processing whale transaction: {e}")
            
# Create global instance
whale_detector = WhaleDetector()

# API functions
async def start_whale_detector():
    """Start the whale detector service"""
    await whale_detector.start()

async def stop_whale_detector():
    """Stop the whale detector service"""
    await whale_detector.stop()

async def is_whale_transaction(tx_hash: str) -> Tuple[bool, Dict[str, Any]]:
    """
    Check if a transaction is a whale transaction
    
    Args:
        tx_hash: Transaction hash to check
        
    Returns:
        Tuple containing (is_whale, transaction_details)
    """
    # Implementation would check transaction details
    # For now, this is a placeholder
    return False, {}