"""
Twitter Monitoring System for SMART MEMES BOT.

This module implements a Twitter monitoring system that:
1. Tracks influential crypto Twitter accounts
2. Extracts token addresses from tweets using pattern matching
3. Creates another source of trading opportunities
4. Enables cross-platform validation of token mentions

This expands intelligence gathering beyond Telegram to cover more discovery channels.
"""

import os
import re
import json
import logging
import time
import asyncio
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
import aiohttp

# Configure logger
logger = logging.getLogger(__name__)

# Twitter accounts to monitor
TWITTER_ACCOUNTS = [
    "CryptoWhale",
    "SolGems",
    "ElonCallz",
    "SolMemeSniper",
    "0xAlphaDrop",
    "CryptoDonAlt",
    "CryptoKaleo",
    "TheBlock",
    "SBF_FTX",
    "CoinMarketCap",
    "binance",
    "cz_binance"
]

# Additional focused token callers (more likely to post early-stage gems)
TOKEN_CALLERS = [
    "GemHunterSOL",
    "SOLGemsFinder",
    "MoonShot_Calls",
    "SOLPumpFinder",
    "SmallCapCalls",
    "EarlySOLCalls",
    "MemeTokenAlerts",
    "PumpFinderPro",
    "EarlyGemsCrypto",
    "WhaleMovements"
]

# Patterns to detect different types of token addresses
TOKEN_PATTERNS = {
    "solana": r'(?<![a-zA-Z0-9])[1-9A-HJ-NP-Za-km-z]{32,44}(?![a-zA-Z0-9])',
    "ethereum": r'(?<![a-zA-Z0-9])0x[a-fA-F0-9]{40}(?![a-zA-Z0-9])',
    "bsc": r'(?<![a-zA-Z0-9])0x[a-fA-F0-9]{40}(?![a-zA-Z0-9])'
}

# Keywords that suggest a token is being launched or promoted
LAUNCH_KEYWORDS = [
    "launch", "launching", "launched", "listing", "listed", 
    "presale", "stealth", "fair launch", "just launched", 
    "new gem", "moonshot", "contract", "address", "CA:", 
    "token address", "dexscreener", "dextools"
]

# Tweet cache to avoid reprocessing the same tweets
_processed_tweets = set()

# Token mentions cache for tracking interest
_token_mentions = {}


@dataclass
class TweetAnalysis:
    """Data class to hold tweet analysis results."""
    tweet_id: str
    account: str
    text: str
    tokens: List[Dict[str, str]]  # List of {token_address, network} dicts
    is_launch_tweet: bool
    relevance_score: float  # 0-10 scale
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert analysis to dictionary for storage."""
        return {
            "tweet_id": self.tweet_id,
            "account": self.account,
            "text": self.text,
            "tokens": self.tokens,
            "is_launch_tweet": self.is_launch_tweet,
            "relevance_score": self.relevance_score,
            "timestamp": self.timestamp
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TweetAnalysis':
        """Create analysis object from dictionary."""
        return cls(
            tweet_id=data["tweet_id"],
            account=data["account"],
            text=data["text"],
            tokens=data["tokens"],
            is_launch_tweet=data["is_launch_tweet"],
            relevance_score=data["relevance_score"],
            timestamp=data["timestamp"]
        )


@dataclass
class TokenMention:
    """Data class to track token mentions on Twitter."""
    token_address: str
    network: str
    first_seen: float
    last_seen: float
    mentions_count: int
    accounts: List[str]
    tweet_ids: List[str]
    relevance_scores: List[float]
    average_relevance: float
    is_trending: bool
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert mention tracking to dictionary for storage."""
        return {
            "token_address": self.token_address,
            "network": self.network,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "mentions_count": self.mentions_count,
            "accounts": self.accounts,
            "tweet_ids": self.tweet_ids,
            "relevance_scores": self.relevance_scores,
            "average_relevance": self.average_relevance,
            "is_trending": self.is_trending
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TokenMention':
        """Create mention tracking object from dictionary."""
        return cls(
            token_address=data["token_address"],
            network=data["network"],
            first_seen=data["first_seen"],
            last_seen=data["last_seen"],
            mentions_count=data["mentions_count"],
            accounts=data["accounts"],
            tweet_ids=data["tweet_ids"],
            relevance_scores=data["relevance_scores"],
            average_relevance=data["average_relevance"],
            is_trending=data["is_trending"]
        )


async def analyze_tweet(tweet_id: str, account: str, text: str) -> TweetAnalysis:
    """
    Analyze a tweet to find token addresses and assess relevance.
    
    Args:
        tweet_id: The tweet ID
        account: The Twitter account
        text: The tweet text
        
    Returns:
        TweetAnalysis object with detailed analysis
    """
    # Extract tokens from text
    tokens = []
    
    # Check each network pattern
    for network, pattern in TOKEN_PATTERNS.items():
        # Find all matches for this network's pattern
        matches = re.findall(pattern, text)
        for match in matches:
            tokens.append({
                "token_address": match,
                "network": network
            })
    
    # Check if this is a launch tweet
    is_launch_tweet = False
    for keyword in LAUNCH_KEYWORDS:
        if keyword.lower() in text.lower():
            is_launch_tweet = True
            break
    
    # Calculate relevance score (0-10)
    relevance_score = calculate_tweet_relevance(text, tokens, is_launch_tweet, account)
    
    # Create and return analysis
    return TweetAnalysis(
        tweet_id=tweet_id,
        account=account,
        text=text,
        tokens=tokens,
        is_launch_tweet=is_launch_tweet,
        relevance_score=relevance_score,
        timestamp=time.time()
    )


def calculate_tweet_relevance(
    text: str,
    tokens: List[Dict[str, str]],
    is_launch_tweet: bool,
    account: str
) -> float:
    """
    Calculate the relevance score for a tweet.
    
    Args:
        text: Tweet text
        tokens: List of extracted tokens
        is_launch_tweet: Whether this appears to be a launch tweet
        account: Twitter account
        
    Returns:
        Relevance score (0-10)
    """
    # Start with base score
    score = 0.0
    
    # Points for having tokens
    if tokens:
        score += min(len(tokens), 2) * 2.0  # Up to 4 points for having tokens
    else:
        return 0.0  # No tokens, no relevance
    
    # Points for being a launch tweet
    if is_launch_tweet:
        score += 3.0  # 3 points for launch tweets
    
    # Points for being a focused token caller
    if account in TOKEN_CALLERS:
        score += 2.0  # 2 points for trusted token callers
    elif account in TWITTER_ACCOUNTS:
        score += 1.0  # 1 point for general crypto accounts
    
    # Points for mentions of DEX links
    if re.search(r'dextools|dexscreener|birdeye|raydium', text, re.IGNORECASE):
        score += 1.0  # 1 point for DEX links
    
    # Cap and return
    return min(score, 10.0)


async def update_token_mentions(analysis: TweetAnalysis) -> None:
    """
    Update token mention tracking with a new tweet analysis.
    
    Args:
        analysis: TweetAnalysis object with extracted tokens
    """
    current_time = time.time()
    
    # Process each token in the tweet
    for token in analysis.tokens:
        token_address = token["token_address"]
        network = token["network"]
        
        # Create key for token
        token_key = f"{network}:{token_address}"
        
        # Initialize if not exists
        if token_key not in _token_mentions:
            _token_mentions[token_key] = TokenMention(
                token_address=token_address,
                network=network,
                first_seen=current_time,
                last_seen=current_time,
                mentions_count=0,
                accounts=[],
                tweet_ids=[],
                relevance_scores=[],
                average_relevance=0.0,
                is_trending=False
            )
        
        # Get token mention object
        mention = _token_mentions[token_key]
        
        # Update stats
        mention.last_seen = current_time
        mention.mentions_count += 1
        
        # Add account if not already there
        if analysis.account not in mention.accounts:
            mention.accounts.append(analysis.account)
        
        # Add tweet ID
        mention.tweet_ids.append(analysis.tweet_id)
        
        # Add relevance score
        mention.relevance_scores.append(analysis.relevance_score)
        
        # Recalculate average relevance
        mention.average_relevance = sum(mention.relevance_scores) / len(mention.relevance_scores)
        
        # Check trending status - at least 2 mentions within 24 hours and average score >= 5.0
        is_recent = current_time - mention.first_seen <= 86400  # 24 hours
        mention.is_trending = is_recent and mention.mentions_count >= 2 and mention.average_relevance >= 5.0


async def fetch_twitter_data() -> List[Dict[str, Any]]:
    """
    Fetch Twitter data from the Twitter API.
    
    Returns:
        List of tweet data objects
    """
    # In a real implementation, this would use the Twitter API
    # For now, we'll simulate some tweets
    
    logger.info("Fetching Twitter data")
    
    # List to hold simulated tweets
    tweets = []
    
    # Current time for timestamp
    current_time = time.time()
    
    # Simulate tweets for some accounts
    for i, account in enumerate(TWITTER_ACCOUNTS[:5] + TOKEN_CALLERS[:5]):
        # Create a unique tweet ID
        tweet_id = f"{account}_{int(current_time)}_{i}"
        
        # Skip if already processed
        if tweet_id in _processed_tweets:
            continue
        
        # Mark as processed
        _processed_tweets.add(tweet_id)
        
        # Determine if this is a Solana or Ethereum-focused account
        is_solana = "SOL" in account or "Sol" in account
        
        # Create a token address based on the account (for simulation)
        token_address = ""
        if is_solana:
            # Generate a random-looking Solana address
            token_address = "".join([
                "ABCDEFGHJKLMNPQRSTUVWXYZ123456789abcdefghijkmnopqrstuvwxyz"[
                    (ord(c) + i) % 58
                ] for c in account[:40]
            ])
            # Ensure length is typical for Solana
            token_address = token_address.ljust(44, "1")[:44]
        else:
            # Generate a random-looking Ethereum address
            token_address = "0x" + "".join([
                "0123456789abcdef"[(ord(c) + i) % 16] for c in account[:40]
            ])
            # Ensure length is typical for Ethereum
            token_address = token_address.ljust(42, "0")[:42]
        
        # Create tweet text based on account type
        if account in TOKEN_CALLERS:
            # Token caller: More direct, promotional tweet
            tweet_text = f"""
            🚀 NEW GEM ALERT 🚀
            
            Just found this amazing token - still early!
            
            Token: {token_address}
            
            ✅ Liquidity locked
            ✅ Contract verified
            ✅ Strong community
            
            Chart: https://dexscreener.com/{"solana" if is_solana else "ethereum"}/{token_address}
            
            NFA DYOR
            """
        else:
            # Regular crypto account: More casual mention
            tweet_text = f"""
            Interesting project I've been looking at lately.
            
            {"Solana" if is_solana else "Ethereum"} ecosystem continues to grow.
            
            {token_address}
            
            What do you all think?
            """
        
        # Add to tweets list
        tweets.append({
            "id": tweet_id,
            "account": account,
            "text": tweet_text,
            "created_at": current_time - (i * 60)  # Staggered times
        })
    
    return tweets


async def process_twitter_data() -> List[TweetAnalysis]:
    """
    Process Twitter data to find token mentions.
    
    Returns:
        List of TweetAnalysis objects with detailed analysis
    """
    # Fetch Twitter data
    tweets = await fetch_twitter_data()
    
    logger.info(f"Processing {len(tweets)} tweets")
    
    # Analyze each tweet
    analyses = []
    for tweet in tweets:
        try:
            analysis = await analyze_tweet(
                tweet_id=tweet["id"],
                account=tweet["account"],
                text=tweet["text"]
            )
            
            # Only include if tokens were found
            if analysis.tokens:
                analyses.append(analysis)
                
                # Update token mentions
                await update_token_mentions(analysis)
                
                logger.info(f"Found {len(analysis.tokens)} tokens in tweet from {analysis.account}")
        except Exception as e:
            logger.error(f"Error analyzing tweet {tweet['id']}: {e}")
    
    return analyses


async def get_trending_tokens() -> List[TokenMention]:
    """
    Get tokens that are trending on Twitter.
    
    Returns:
        List of trending TokenMention objects
    """
    # Filter for trending tokens
    trending = [
        mention for mention in _token_mentions.values()
        if mention.is_trending
    ]
    
    # Sort by average relevance (highest first)
    trending.sort(key=lambda m: m.average_relevance, reverse=True)
    
    return trending


async def check_twitter_for_tokens() -> List[Dict[str, Any]]:
    """
    Check Twitter for token mentions.
    
    Returns:
        List of dictionaries with token information
    """
    # Process Twitter data
    await process_twitter_data()
    
    # Get trending tokens
    trending = await get_trending_tokens()
    
    # Convert to simple dictionaries
    result = []
    for mention in trending:
        result.append({
            "token_address": mention.token_address,
            "network": mention.network,
            "mentions_count": mention.mentions_count,
            "accounts": mention.accounts,
            "average_relevance": mention.average_relevance,
            "is_trending": mention.is_trending
        })
    
    return result


async def extract_contracts_from_text(text: str) -> List[str]:
    """
    Extract contract addresses from text.
    
    Args:
        text: Text to extract from
        
    Returns:
        List of contract addresses
    """
    # Combine all patterns to extract tokens from any supported network
    all_tokens = []
    
    for network, pattern in TOKEN_PATTERNS.items():
        matches = re.findall(pattern, text)
        all_tokens.extend(matches)
    
    # Return unique tokens
    return list(set(all_tokens))


async def run_twitter_monitoring_cycle() -> List[Dict[str, Any]]:
    """
    Run a complete Twitter monitoring cycle.
    
    Returns:
        List of dictionaries with discovered tokens
    """
    logger.info("Running Twitter monitoring cycle")
    
    try:
        # Process Twitter data
        analyses = await process_twitter_data()
        
        # Get trending tokens
        trending = await get_trending_tokens()
        
        # Create results
        results = []
        for mention in trending:
            results.append({
                "token_address": mention.token_address,
                "network": mention.network,
                "mentions_count": mention.mentions_count,
                "accounts": mention.accounts,
                "average_relevance": mention.average_relevance,
                "first_seen": mention.first_seen,
                "last_seen": mention.last_seen
            })
        
        logger.info(f"Twitter monitoring cycle complete: {len(analyses)} tweets, {len(trending)} trending tokens")
        
        return results
    
    except Exception as e:
        logger.error(f"Error in Twitter monitoring cycle: {e}")
        return []


async def background_twitter_task():
    """
    Background task to continuously monitor Twitter.
    """
    while True:
        try:
            token_results = await check_twitter_for_tokens()
            logger.info(f"Twitter check complete: {len(token_results)} tokens found")
            
            # Here you would trigger auto-sniper
            for token in token_results:
                # This assumes there's a function like this in the auto-sniper
                # await try_snipe_token(token["token_address"], source="Twitter")
                logger.info(f"Found token on Twitter: {token['token_address']}")
        
        except Exception as e:
            logger.error(f"Error in Twitter background task: {e}")
        
        # Wait before next check
        await asyncio.sleep(60)  # Check every minute


# Test function
async def test_twitter_watcher():
    # Test the Twitter monitoring
    tokens = await check_twitter_for_tokens()
    
    print(f"Found {len(tokens)} tokens on Twitter")
    for token in tokens:
        print(f"Token: {token['token_address']}")
        print(f"Network: {token['network']}")
        print(f"Mentions: {token['mentions_count']}")
        print(f"Accounts: {', '.join(token['accounts'])}")
        print(f"Relevance: {token['average_relevance']:.1f}/10")
        print()
    
    # Test the monitoring cycle
    results = await run_twitter_monitoring_cycle()
    
    print(f"Monitoring cycle found {len(results)} trending tokens")


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_twitter_watcher())