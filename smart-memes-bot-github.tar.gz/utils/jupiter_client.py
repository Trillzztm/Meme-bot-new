import os
import base64
import aiohttp
import asyncio
import logging
import json

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("jupiter_client")

# Your Solana wallet public key (derived from private key)
WALLET_PUBKEY = os.getenv("SOLANA_WALLET_PUBKEY")

# Your Solana RPC endpoint
RPC_ENDPOINT = os.getenv("SOLANA_RPC", "https://api.mainnet-beta.solana.com")
JUPITER_API = "https://lite-api.jup.ag/v6"

async def get_quote(input_mint: str, output_mint: str, amount_lamports: int, slippage_bps: int = 50):
    """
    Fetches a swap quote from Jupiter lite API.
    - amount_lamports: amount in lamports to swap
    - slippage_bps: slippage in basis points (e.g. 50 = 0.50%)
    """
    logger.info(f"Getting quote for {amount_lamports} lamports from {input_mint} to {output_mint}")
    url = (
        f"{JUPITER_API}/quote?"
        f"inputMint={input_mint}&"
        f"outputMint={output_mint}&"
        f"amount={amount_lamports}&"
        f"slippageBps={slippage_bps}"
    )
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url) as res:
                if res.status != 200:
                    error_text = await res.text()
                    logger.error(f"Jupiter API error: {res.status} - {error_text}")
                    return None
                data = await res.json()
                # returns a dict with 'data': [ {..., 'swapTransaction': <base64 tx> , ...} ]
                result = data.get("data", [{}])[0]
                logger.info(f"Quote received: {result.get('outAmount')} out amount")
                return result
        except Exception as e:
            logger.error(f"Error fetching Jupiter quote: {e}")
            return None

async def execute_jupiter_swap(quote: dict):
    """
    In a real implementation, this would sign and send the swapTransaction.
    For simulation purposes, we'll just log and return a simulated transaction.
    """
    b64_tx = quote.get("swapTransaction")
    if not b64_tx:
        logger.error(f"No transaction found in quote: {quote}")
        return f"No transaction found in quote"

    # In real implementation, we would deserialize, sign and send the transaction
    # For simulation, we'll just generate a mock transaction ID
    import hashlib
    import time
    
    mock_tx_id = hashlib.sha256(f"{time.time()}_{b64_tx[:20]}".encode()).hexdigest()
    logger.info(f"Simulated transaction sent: {mock_tx_id}")
    
    return f"https://solscan.io/tx/{mock_tx_id}"

# Example helper to swap a given SOL amount to target token
async def swap_sol_to_token(token_mint: str, amount_sol: float, slippage_bps: int = 50):
    """
    Swap SOL to a target token.
    - token_mint: Target token mint address
    - amount_sol: Amount of SOL to swap
    - slippage_bps: Slippage in basis points (e.g. 50 = 0.50%)
    """
    lamports = int(amount_sol * 1_000_000_000)  # Convert SOL to lamports
    base_mint = "So11111111111111111111111111111111111111112"  # SOL wrapped mint
    
    logger.info(f"Swapping {amount_sol} SOL to token {token_mint}")
    quote = await get_quote(base_mint, token_mint, lamports, slippage_bps)
    if not quote:
        return "Quote fetch failed"
    
    return await execute_jupiter_swap(quote)

# Helper to swap a token back to SOL
async def swap_token_to_sol(token_mint: str, token_amount: int, slippage_bps: int = 50):
    """
    Swap a token back to SOL.
    - token_mint: Token mint address to swap from
    - token_amount: Amount of token in smallest units
    - slippage_bps: Slippage in basis points (e.g. 50 = 0.50%)
    """
    base_mint = "So11111111111111111111111111111111111111112"  # SOL wrapped mint
    
    logger.info(f"Swapping {token_amount} of token {token_mint} to SOL")
    quote = await get_quote(token_mint, base_mint, token_amount, slippage_bps)
    if not quote:
        return "Quote fetch failed"
    
    return await execute_jupiter_swap(quote)

# Helper to get token price in USDC
async def get_token_price_usdc(token_mint: str):
    """
    Get the price of a token in USDC.
    
    Args:
        token_mint: The token's mint address
        
    Returns:
        Price in USDC, or 0 if price cannot be determined
    """
    # USDC mint address
    usdc_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    
    try:
        # We'll use 1 unit of the token to get a quote
        quote = await get_quote(token_mint, usdc_mint, 1)
        
        if not quote or "outAmount" not in quote:
            return 0
        
        # The outAmount is how many USDC we get for 1 token unit
        usdc_amount = int(quote["outAmount"]) / 1_000_000  # USDC has 6 decimals
        return usdc_amount
    except Exception as e:
        logger.error(f"Error getting token price in USDC: {e}")
        return 0

# Helper to execute code asynchronously from synchronous code
def run_async(coroutine):
    """Run an async function from synchronous code."""
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coroutine)

# Test function to check if the module works
async def test_jupiter_api():
    """
    Test the Jupiter API functionality.
    """
    # USDC mint
    usdc_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    # Get quote for 0.01 SOL to USDC
    sol_amount = 0.01
    lamports = int(sol_amount * 1_000_000_000)
    sol_mint = "So11111111111111111111111111111111111111112"
    
    logger.info(f"Testing Jupiter API with {sol_amount} SOL to USDC quote")
    quote = await get_quote(sol_mint, usdc_mint, lamports)
    
    if quote:
        outAmount = int(quote.get("outAmount", 0))
        logger.info(f"Quote successful! Would receive {outAmount} USDC units (${outAmount/1000000:.2f})")
        return True
    else:
        logger.error("Failed to get Jupiter quote. API might be down or network issue.")
        return False