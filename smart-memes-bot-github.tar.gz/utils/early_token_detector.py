"""
Early Token Detection System for SMART MEMES BOT.

This module provides advanced early token detection capabilities to find
profitable tokens before they gain mainstream attention. It includes:

1. New token listing detection across multiple DEXs
2. Mempool monitoring for presales and stealth launches
3. Liquidity addition tracking for early entry
4. Social media monitoring for token announcements
5. Insider wallet tracking for early moves

Built for the sole purpose of finding million-dollar gems before they take off.
"""

import logging
import asyncio
import json
import os
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Set

# Try importing aiohttp, fall back gracefully if not available
try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    logging.warning("aiohttp not available, using fallback HTTP client")

# Always import requests as it's more commonly available
import requests

# Configure logger
logger = logging.getLogger(__name__)

# API keys for external services
BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY", "")
RUGCHECK_API_KEY = os.environ.get("RUGCHECK_API_KEY", "")

# Constants
MIN_LIQUIDITY_USD = 10000  # Minimum liquidity in USD to be considered
MAX_AGE_HOURS = 6         # Maximum age in hours for a token to be considered "early"
MIN_TRANSACTIONS = 10     # Minimum number of transactions to avoid false positives
MONITORING_INTERVAL = 60  # Seconds between monitoring runs

# Known DEXs on Solana
DEX_LIST = [
    "raydium",
    "orca",
    "jupiter",
    "serum",
    "aldrin"
]

# Set of previously detected tokens to avoid duplicates
detected_tokens: Set[str] = set()

# Known insider wallets (whales with good track records)
INSIDER_WALLETS = [
    # Add wallets of known profitable traders/investors
    "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1",  # Example wallet
    "FZLTRwrxsfMsXKE9WrPWRhKRhT5C8S4bJtmzuk8TtUHs",  # Example wallet
]

async def monitor_new_token_listings() -> List[Dict[str, Any]]:
    """
    Monitor for new token listings across multiple DEXs.
    
    Returns:
        List of newly detected token data
    """
    new_tokens = []
    
    try:
        # Check Birdeye API for recent listings
        if BIRDEYE_API_KEY:
            async with aiohttp.ClientSession() as session:
                url = "https://public-api.birdeye.so/public/recent_tokens?count=50"
                headers = {"X-API-KEY": BIRDEYE_API_KEY}
                
                async with session.get(url, headers=headers) as res:
                    if res.status == 200:
                        data = await res.json()
                        tokens = data.get('data', {}).get('tokens', [])
                        
                        for token in tokens:
                            token_address = token.get('address')
                            
                            # Skip if we've already detected this token
                            if token_address in detected_tokens:
                                continue
                                
                            # Check if it meets our criteria
                            age_hours = token.get('ageHours', 0)
                            liquidity = token.get('liquidity', 0)
                            
                            if age_hours <= MAX_AGE_HOURS and liquidity >= MIN_LIQUIDITY_USD:
                                # Get more detailed info
                                token_data = await get_detailed_token_info(token_address)
                                if token_data:
                                    new_tokens.append(token_data)
                                    detected_tokens.add(token_address)
                                    logger.info(f"Detected new early token: {token_address}")
        
        # Return the list of new tokens
        return new_tokens
                                
    except Exception as e:
        logger.error(f"Error monitoring new token listings: {str(e)}")
        return []

async def get_detailed_token_info(token_address: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed information about a token.
    
    Args:
        token_address: Token address to analyze
        
    Returns:
        Dictionary with detailed token information
    """
    try:
        if BIRDEYE_API_KEY:
            async with aiohttp.ClientSession() as session:
                # Get token metadata
                metadata_url = f"https://public-api.birdeye.so/public/token_metadata?address={token_address}"
                info_url = f"https://public-api.birdeye.so/public/tokeninfo?address={token_address}"
                headers = {"X-API-KEY": BIRDEYE_API_KEY}
                
                async with session.get(metadata_url, headers=headers) as res:
                    if res.status != 200:
                        return None
                    
                    metadata = await res.json()
                    
                    async with session.get(info_url, headers=headers) as res2:
                        if res2.status != 200:
                            return None
                        
                        info = await res2.json()
                        
                        # Combine data from both endpoints
                        token_data = {
                            "address": token_address,
                            "name": metadata.get('data', {}).get('name', 'Unknown Token'),
                            "symbol": metadata.get('data', {}).get('symbol', 'UNKNOWN'),
                            "liquidity_usd": info.get('data', {}).get('liquidity', 0),
                            "price_usd": info.get('data', {}).get('value', 0),
                            "volume_24h": info.get('data', {}).get('volume24h', 0),
                            "age_hours": info.get('data', {}).get('ageHours', 0),
                            "holders_count": info.get('data', {}).get('holdersCount', 0),
                            "transaction_count": info.get('data', {}).get('transactionCount', 0),
                            "detected_at": datetime.now().isoformat(),
                            "source": "birdeye_api",
                            "dex": info.get('data', {}).get('dex', 'unknown')
                        }
                        
                        # Check safety score if we have the API key
                        if RUGCHECK_API_KEY:
                            token_data["safety_data"] = await check_token_safety(token_address)
                        
                        return token_data
                        
        return None
    
    except Exception as e:
        logger.error(f"Error getting detailed token info: {str(e)}")
        return None

async def check_token_safety(token_address: str) -> Dict[str, Any]:
    """
    Check the safety of a token using RugCheck API.
    
    Args:
        token_address: Token address to check
        
    Returns:
        Dictionary with safety analysis results
    """
    if not RUGCHECK_API_KEY:
        return {"success": False, "reason": "RugCheck API key not configured"}
    
    try:
        async with aiohttp.ClientSession() as session:
            url = f"https://api.rugcheck.xyz/v1/tokens/{token_address}?apiKey={RUGCHECK_API_KEY}"
            
            async with session.get(url) as res:
                if res.status != 200:
                    return {"success": False, "reason": f"RugCheck API returned {res.status}"}
                
                data = await res.json()
                
                # Check if the token is a rug
                if data.get("is_rug", False):
                    return {
                        "success": True,
                        "safe": False,
                        "reason": "Token flagged as a rug pull"
                    }
                
                # Check for honeypot
                if data.get("honeypot", False):
                    return {
                        "success": True,
                        "safe": False,
                        "reason": "Token appears to be a honeypot"
                    }
                
                # Check other safety factors
                safety_score = data.get("score", 0)
                
                return {
                    "success": True,
                    "safe": safety_score >= 70,
                    "score": safety_score,
                    "details": {
                        "verified": data.get("verified", False),
                        "proxy": data.get("proxy", False),
                        "mint_enabled": data.get("mint_enabled", False),
                        "high_fee": data.get("high_fee", False)
                    }
                }
    
    except Exception as e:
        logger.error(f"Error checking token safety: {str(e)}")
        return {"success": False, "reason": str(e)}

async def monitor_insider_wallets() -> List[Dict[str, Any]]:
    """
    Monitor known insider wallets for new token acquisitions.
    
    Returns:
        List of newly detected tokens from insider activity
    """
    new_tokens = []
    
    try:
        # For each insider wallet, check recent transactions
        for wallet in INSIDER_WALLETS:
            # Use Solscan API to get recent transactions
            url = f"https://public-api.solscan.io/account/transactions?account={wallet}&limit=20"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as res:
                    if res.status != 200:
                        continue
                    
                    transactions = await res.json()
                    
                    for tx in transactions:
                        # Look for token purchases
                        if tx.get('type') == 'SWAP':
                            # Extract token address from the transaction
                            token_address = extract_token_from_swap(tx)
                            if token_address and token_address not in detected_tokens:
                                # Get token details
                                token_data = await get_detailed_token_info(token_address)
                                if token_data:
                                    token_data['source'] = 'insider_wallet'
                                    token_data['insider_wallet'] = wallet
                                    new_tokens.append(token_data)
                                    detected_tokens.add(token_address)
                                    logger.info(f"Detected insider activity on token: {token_address}")
    
    except Exception as e:
        logger.error(f"Error monitoring insider wallets: {str(e)}")
    
    return new_tokens

def extract_token_from_swap(transaction: Dict[str, Any]) -> Optional[str]:
    """
    Extract token address from a swap transaction.
    
    Args:
        transaction: Transaction data
        
    Returns:
        Token address or None if not found
    """
    # This is a simplified implementation
    # In a real scenario, you'd need to parse the transaction data more carefully
    try:
        tokens = transaction.get('tokenTransfers', [])
        for token in tokens:
            if token.get('mint'):
                return token.get('mint')
        return None
    except Exception:
        return None

async def continuous_monitoring():
    """
    Continuously monitor for new tokens and report findings.
    """
    while True:
        try:
            # Monitor for new token listings
            new_dex_tokens = await monitor_new_token_listings()
            
            # Monitor insider wallets
            new_insider_tokens = await monitor_insider_wallets()
            
            # Combine both sources
            all_new_tokens = new_dex_tokens + new_insider_tokens
            
            # Process and report new tokens
            if all_new_tokens:
                logger.info(f"Detected {len(all_new_tokens)} new early-stage tokens")
                for token in all_new_tokens:
                    # Here you would trigger your profit-making actions
                    # such as auto-sniping, alerts, or detailed analysis
                    logger.info(f"Early token opportunity: {token['symbol']} ({token['address']})")
                    logger.info(f"  Price: ${token['price_usd']:.8f}")
                    logger.info(f"  Liquidity: ${token['liquidity_usd']:,.2f}")
                    logger.info(f"  Age: {token['age_hours']} hours")
                    logger.info(f"  Source: {token['source']}")
            
            # Wait for the next monitoring interval
            await asyncio.sleep(MONITORING_INTERVAL)
            
        except Exception as e:
            logger.error(f"Error in continuous monitoring: {str(e)}")
            await asyncio.sleep(MONITORING_INTERVAL)

def _run_monitoring_loop():
    """
    Run the monitoring loop with proper async handling.
    """
    try:
        # Get or create an event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            # If no event loop exists in this thread, create one
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        # Run the monitoring coroutine
        loop.run_until_complete(continuous_monitoring())
    except Exception as e:
        logger.error(f"Error in monitoring loop: {str(e)}")

def start_monitoring():
    """
    Start the early token detection system.
    """
    logger.info("Starting Early Token Detection System")
    
    # Start in a separate thread if not already in one
    import threading
    monitor_thread = threading.Thread(target=_run_monitoring_loop)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    logger.info("Early Token Detection System is now running")

if __name__ == "__main__":
    # For testing
    asyncio.run(monitor_new_token_listings())