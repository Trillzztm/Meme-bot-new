"""
Trading utilities for SMART MEMES BOT.

This module provides trading-related functionality, including position sizing,
risk management, and trade execution logic.
"""

import logging
import os
import asyncio
from typing import Dict, Any, Optional, List, Tuple
import math
import random
from datetime import datetime, timedelta

# Configure logging
logger = logging.getLogger(__name__)

# Import the pricing module
try:
    from utils.pricing import get_token_price, get_token_price_history
    HAS_PRICING = True
    logger.info("Pricing module available for trading")
except ImportError:
    HAS_PRICING = False
    logger.warning("Pricing module not available for trading, using fallbacks")

# Import executor
try:
    from utils.solana_trade import execute_trade as _execute_trade
    HAS_EXECUTOR = True
    logger.info("Trade executor available")
except ImportError:
    HAS_EXECUTOR = False
    logger.warning("Trade executor not available, using simulation mode")

# Trading constants
BASE_INVESTMENT_SOL = 0.2
MAX_INVESTMENT_SOL = 3.0
MIN_INVESTMENT_SOL = 0.02
MAX_SLIPPAGE = 0.03  # 3% max slippage


def calculate_position_size(analysis: Dict[str, Any], base_investment: float = BASE_INVESTMENT_SOL) -> float:
    """
    Calculate position size based on token analysis.
    
    Args:
        analysis: The token analysis data
        base_investment: The base investment amount in SOL
        
    Returns:
        Position size in SOL
    """
    try:
        # Extract scores
        potential_score = analysis.get('score', 0)
        safety_score = analysis.get('safety_score', 0)
        
        # Calculate position size multiplier (0.1x to 3.0x)
        potential_factor = potential_score / 100.0  # 0.0 to 1.0
        safety_factor = safety_score / 100.0  # 0.0 to 1.0
        
        # Weighted combination
        combined_factor = (potential_factor * 0.7) + (safety_factor * 0.3)
        
        # Apply to position sizing
        position_multiplier = max(0.1, min(3.0, combined_factor * 3.0))
        
        # Calculate position size
        position_size = base_investment * position_multiplier
        
        # Enforce limits
        position_size = max(MIN_INVESTMENT_SOL, min(MAX_INVESTMENT_SOL, position_size))
        
        logger.info(f"Calculated position size: {position_size:.3f} SOL (multiplier: {position_multiplier:.2f}x)")
        return position_size
        
    except Exception as e:
        logger.error(f"Error calculating position size: {e}")
        return base_investment  # Default to base investment on error


def calculate_exit_strategy(entry_price: float, analysis: Dict[str, Any]) -> Dict[str, float]:
    """
    Calculate exit strategy based on entry price and analysis.
    
    Args:
        entry_price: The entry price
        analysis: The token analysis data
        
    Returns:
        Dictionary with exit strategy
    """
    try:
        # Extract risk level
        risk_level = analysis.get('risk_level', 'high')
        
        # Define stop loss percentages based on risk
        if risk_level == 'low':
            stop_loss_percent = 0.05  # 5% for low risk
        elif risk_level == 'medium':
            stop_loss_percent = 0.10  # 10% for medium risk
        else:
            stop_loss_percent = 0.15  # 15% for high risk
            
        # Calculate stop loss
        stop_loss = entry_price * (1 - stop_loss_percent)
        
        # Define take profit levels based on analysis
        potential_score = analysis.get('score', 50)
        
        # Higher potential score = higher take profit targets
        potential_factor = potential_score / 100.0  # 0.0 to 1.0
        
        # Calculate take profit levels
        tp1_percent = 0.20 + (potential_factor * 0.30)  # 20-50% for TP1
        tp2_percent = 0.40 + (potential_factor * 0.60)  # 40-100% for TP2
        tp3_percent = 0.80 + (potential_factor * 1.20)  # 80-200% for TP3
        
        # Calculate values
        take_profit_1 = entry_price * (1 + tp1_percent)
        take_profit_2 = entry_price * (1 + tp2_percent)
        take_profit_3 = entry_price * (1 + tp3_percent)
        
        logger.info(f"Exit strategy: SL: -{stop_loss_percent*100:.1f}%, TP1: +{tp1_percent*100:.1f}%, " +
                   f"TP2: +{tp2_percent*100:.1f}%, TP3: +{tp3_percent*100:.1f}%")
        
        return {
            'stop_loss': stop_loss,
            'take_profit_1': take_profit_1,
            'take_profit_2': take_profit_2,
            'take_profit_3': take_profit_3,
            'stop_loss_percent': stop_loss_percent,
            'tp1_percent': tp1_percent,
            'tp2_percent': tp2_percent,
            'tp3_percent': tp3_percent
        }
        
    except Exception as e:
        logger.error(f"Error calculating exit strategy: {e}")
        
        # Default exit strategy on error
        return {
            'stop_loss': entry_price * 0.9,  # 10% stop loss
            'take_profit_1': entry_price * 1.3,  # 30% profit
            'take_profit_2': entry_price * 1.6,  # 60% profit
            'take_profit_3': entry_price * 2.0,  # 100% profit
            'stop_loss_percent': 0.1,
            'tp1_percent': 0.3,
            'tp2_percent': 0.6,
            'tp3_percent': 1.0
        }


async def execute_trade(token_address: str, amount: float, is_buy: bool = True, 
                       slippage: float = 0.01) -> Dict[str, Any]:
    """
    Execute a trade with the given parameters.
    
    Args:
        token_address: The token address to trade
        amount: The amount in SOL to trade
        is_buy: Whether this is a buy (True) or sell (False)
        slippage: The allowed slippage percentage (0.01 = 1%)
        
    Returns:
        Dictionary with trade result
    """
    try:
        if not HAS_EXECUTOR:
            # Simulation mode
            logger.warning("Using simulated trade execution")
            return await simulate_trade(token_address, amount, is_buy, slippage)
            
        # Cap slippage to maximum allowed
        slippage = min(slippage, MAX_SLIPPAGE)
        
        # Execute the trade
        if is_buy:
            logger.info(f"Executing BUY trade for {token_address}: {amount:.3f} SOL (slippage: {slippage*100:.1f}%)")
        else:
            logger.info(f"Executing SELL trade for {token_address}: {amount:.3f} tokens (slippage: {slippage*100:.1f}%)")
            
        # Call the real executor
        result = await _execute_trade(
            token_address=token_address,
            amount=amount,
            is_buy=is_buy,
            slippage=slippage
        )
        
        return result
        
    except Exception as e:
        logger.error(f"Error executing trade: {e}")
        return {
            'success': False,
            'error': str(e)
        }


async def simulate_trade(token_address: str, amount: float, is_buy: bool = True, 
                        slippage: float = 0.01) -> Dict[str, Any]:
    """
    Simulate a trade for testing or when executor is unavailable.
    
    Args:
        token_address: The token address to trade
        amount: The amount in SOL to trade
        is_buy: Whether this is a buy (True) or sell (False)
        slippage: The allowed slippage percentage (0.01 = 1%)
        
    Returns:
        Dictionary with simulated trade result
    """
    # Add a small delay to simulate network latency
    await asyncio.sleep(1.5)
    
    # Get current price or generate a mock price
    if HAS_PRICING:
        price = await get_token_price(token_address)
    else:
        # Generate a mock price based on token address hash
        price = random.uniform(0.000001, 0.01)
    
    # Apply slippage to price (negative for buy, positive for sell)
    actual_slippage = random.uniform(0, slippage)
    if is_buy:
        execution_price = price * (1 + actual_slippage)
    else:
        execution_price = price * (1 - actual_slippage)
    
    # Calculate tokens received (for buy) or SOL received (for sell)
    if is_buy:
        tokens_received = amount / execution_price
        value_type = "tokens"
    else:
        tokens_received = amount * execution_price
        value_type = "SOL"
    
    # Generate a mock transaction hash
    # This format mimics a Solana transaction signature
    tx_hash = ''.join(random.choices('123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz', k=64))
    
    # Return simulated result
    return {
        'success': True,
        'transaction_hash': tx_hash,
        'entry_price': execution_price,
        'tokens_received': tokens_received,
        'actual_slippage': actual_slippage,
        'value_type': value_type,
        'simulated': True
    }


async def check_price_movement(token_address: str, 
                             time_periods: List[int] = [5*60, 15*60, 60*60]) -> Dict[str, float]:
    """
    Check price movement over different time periods.
    
    Args:
        token_address: The token address to check
        time_periods: List of time periods in seconds to check
        
    Returns:
        Dictionary with price changes as percentages (e.g., 0.05 = 5% increase)
    """
    try:
        if not HAS_PRICING:
            # Generate mock price movements
            return {
                f"{period//60}min": random.uniform(-0.1, 0.15) for period in time_periods
            }
            
        # Get current price
        current_price = await get_token_price(token_address, force_refresh=True)
        
        # Get price history
        price_history = await get_token_price_history(token_address)
        
        if not price_history:
            logger.warning(f"No price history available for {token_address}")
            return {f"{period//60}min": 0 for period in time_periods}
            
        # Current time
        now = datetime.now().timestamp()
        
        # Calculate price changes
        result = {}
        for period in time_periods:
            period_start = now - period
            
            # Find closest price point
            closest_point = None
            for point in price_history:
                point_time = point.get("recorded_at", 0)
                if abs(point_time - period_start) < 300:  # Within 5 minutes
                    closest_point = point
                    break
                    
            if closest_point:
                old_price = closest_point.get("price", current_price)
                if old_price > 0:
                    change = (current_price - old_price) / old_price
                    result[f"{period//60}min"] = change
                else:
                    result[f"{period//60}min"] = 0
            else:
                result[f"{period//60}min"] = 0
                
        return result
        
    except Exception as e:
        logger.error(f"Error checking price movement: {e}")
        return {f"{period//60}min": 0 for period in time_periods}


# Function to update trade stats
async def update_trade_stats(token_address: str, entry_price: float, current_price: float, 
                           amount: float, user_id: Optional[int] = None) -> Dict[str, Any]:
    """
    Update trade statistics.
    
    Args:
        token_address: The token address
        entry_price: The entry price
        current_price: The current price
        amount: The amount traded in SOL
        user_id: Optional user ID
        
    Returns:
        Dictionary with trade stats
    """
    try:
        # Calculate profit/loss percentage
        if entry_price > 0:
            pnl_percent = (current_price - entry_price) / entry_price
        else:
            pnl_percent = 0
            
        # Calculate profit/loss value
        pnl_value = amount * pnl_percent
        
        # Calculate ROI
        roi = pnl_percent * 100  # As percentage
        
        # Calculate annualized return if we have time information
        now = datetime.now()
        
        stats = {
            'token_address': token_address,
            'entry_price': entry_price,
            'current_price': current_price,
            'amount': amount,
            'pnl_percent': pnl_percent,
            'pnl_value': pnl_value,
            'roi': roi,
            'user_id': user_id
        }
        
        return stats
        
    except Exception as e:
        logger.error(f"Error updating trade stats: {e}")
        return {
            'token_address': token_address,
            'error': str(e)
        }