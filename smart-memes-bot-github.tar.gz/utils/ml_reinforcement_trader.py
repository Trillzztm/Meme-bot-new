"""
Machine Learning Reinforcement Trader for SMART MEMES BOT.

This advanced module uses reinforcement learning to automatically improve
trading strategies based on market conditions and past performance.
"""

import logging
import asyncio
import time
import json
from typing import Dict, Any, List, Tuple, Optional
import numpy as np
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our utilities
from utils.token_analyzer import analyze_token
from utils.market_ai_predictor import predict_token_movement
from utils.advanced_trading_core import execute_smart_trade
from database import session_scope, record_snipe_transaction, update_snipe_status
from config import (
    ML_TRADER_ENABLED,
    ML_TRADER_MAX_POSITION,
    ML_TRADER_LEARNING_RATE,
    ML_TRADER_EXPLORATION_RATE,
    ML_TRADER_MAX_POSITIONS,
    ML_TRADER_RISK_TOLERANCE
)

# Constants
STATE_FEATURES = 10  # Number of features in our state representation
ACTIONS = 3  # Buy, Sell, Hold
REWARD_SCALE = 10.0  # Scale factor for rewards to improve learning
MAX_MEMORY_SIZE = 10000  # Maximum size of the experience replay buffer
BATCH_SIZE = 32  # Batch size for training
UPDATE_FREQUENCY = 24 * 3600  # Update model once per day

class MLReinforcementTrader:
    """Machine Learning Reinforcement Trader with adaptive strategies"""
    
    def __init__(self):
        """Initialize the ML trader"""
        self.running = False
        self.task = None
        self.positions = {}  # Current positions {token_address: position_data}
        self.trade_history = []  # History of trades for learning
        self.last_model_update = 0
        self.q_table = {}  # Q-table for reinforcement learning
        self.position_count = 0
        self.total_profit = 0.0
        self.win_count = 0
        self.loss_count = 0
        
        # Performance metrics
        self.metrics = {
            "total_trades": 0,
            "profitable_trades": 0,
            "win_rate": 0.0,
            "avg_profit": 0.0,
            "avg_loss": 0.0,
            "max_drawdown": 0.0,
            "sharpe_ratio": 0.0
        }
        
        # Strategy parameters (initialized with default values)
        self.strategy_params = {
            "entry_threshold": 0.65,  # AI confidence threshold for entry
            "take_profit": 150,       # Take profit percentage (1.5x)
            "stop_loss": 25,          # Stop loss percentage
            "position_size": 0.2,     # Position size in SOL
            "max_hold_time": 72,      # Maximum hold time in hours
            "trend_follow_weight": 0.6,  # Weight for trend-following strategy
            "mean_reversion_weight": 0.4,  # Weight for mean-reversion strategy
            "volatility_adjustment": 0.5,  # Adjustment factor based on volatility
            "risk_factor": ML_TRADER_RISK_TOLERANCE  # Risk tolerance factor
        }
    
    async def start(self):
        """Start the ML trader"""
        if self.running:
            logger.warning("ML Reinforcement Trader already running")
            return
            
        # Check if ML trader is enabled in config
        if not ML_TRADER_ENABLED:
            logger.info("ML Reinforcement Trader disabled in config")
            return
            
        self.running = True
        
        # Initialize Q-table if not already done
        if not self.q_table:
            self._initialize_q_table()
            
        # Start the main trading loop
        self.task = asyncio.create_task(self._trading_loop())
        
        logger.info("ML Reinforcement Trader started")
    
    async def stop(self):
        """Stop the ML trader"""
        if not self.running:
            return
            
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
                
        logger.info("ML Reinforcement Trader stopped")
    
    def _initialize_q_table(self):
        """Initialize the Q-table with default values"""
        # In a real implementation, this would load a pretrained model or initialize a neural network
        # For this simplified version, we'll use a dictionary-based Q-table
        self.q_table = {}
    
    async def _trading_loop(self):
        """Main trading loop for ML Reinforcement Trader"""
        try:
            while self.running:
                try:
                    # 1. Get potential trading opportunities
                    opportunities = await self._find_trading_opportunities()
                    
                    # 2. Evaluate each opportunity
                    for opportunity in opportunities:
                        # Skip if we're at maximum positions
                        if self.position_count >= ML_TRADER_MAX_POSITIONS:
                            continue
                            
                        # Get current state
                        state = self._get_state(opportunity)
                        
                        # Choose action (buy, sell, hold) using ε-greedy policy
                        action = self._choose_action(state)
                        
                        # Execute action
                        if action == 0:  # Buy
                            await self._execute_buy(opportunity)
                        elif action == 1 and opportunity["token_address"] in self.positions:  # Sell
                            await self._execute_sell(opportunity)
                            
                        # Sleep briefly between opportunities
                        await asyncio.sleep(1)
                    
                    # 3. Check existing positions for auto-sell
                    for token_address, position in list(self.positions.items()):
                        await self._check_position(token_address, position)
                    
                    # 4. Update the model periodically
                    current_time = time.time()
                    if current_time - self.last_model_update > UPDATE_FREQUENCY:
                        self._update_model()
                        self.last_model_update = current_time
                    
                except Exception as e:
                    logger.error(f"Error in ML trading loop: {e}")
                    
                # Wait before next iteration
                await asyncio.sleep(300)  # Check every 5 minutes
                
        except asyncio.CancelledError:
            logger.info("ML trading task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in ML trading: {e}")
            self.running = False
    
    async def _find_trading_opportunities(self) -> List[Dict[str, Any]]:
        """
        Find potential trading opportunities
        
        Returns:
            List of trading opportunities
        """
        # In a real implementation, this would analyze market data and find opportunities
        # For now, we'll use a simplified approach
        
        try:
            # Get top tokens by volume or recent price action
            # This would typically come from an API or database
            tokens = await self._get_trending_tokens()
            
            opportunities = []
            
            # Analyze each token
            for token in tokens:
                token_address = token.get("address")
                if not token_address:
                    continue
                
                # Skip tokens we already have positions in
                if token_address in self.positions:
                    continue
                
                # Run AI prediction
                prediction = await predict_token_movement(token_address, "24h")
                
                if not prediction or not prediction.get("success"):
                    continue
                
                # Run token analysis
                safety_score, _, token_data = await analyze_token(token_address)
                
                # Create opportunity object
                opportunity = {
                    "token_address": token_address,
                    "token_name": token_data.get("name") or token_data.get("symbol") or "Unknown",
                    "current_price": token_data.get("market_data", {}).get("price", 0),
                    "prediction": {
                        "direction": prediction.get("direction", "neutral"),
                        "confidence": prediction.get("confidence", 0),
                        "change_percent": prediction.get("predicted_change_percent", 0)
                    },
                    "safety_score": safety_score,
                    "liquidity": token_data.get("market_data", {}).get("liquidity", 0),
                    "volume_24h": token_data.get("market_data", {}).get("volume_24h", 0),
                    "timestamp": time.time()
                }
                
                # Only consider opportunities that meet minimum criteria
                min_confidence = self.strategy_params["entry_threshold"]
                min_safety = 7.0
                
                direction = opportunity["prediction"]["direction"]
                confidence = opportunity["prediction"]["confidence"]
                
                # Apply our strategy weights
                if direction == "bullish" and confidence >= min_confidence and safety_score >= min_safety:
                    opportunities.append(opportunity)
            
            return opportunities
            
        except Exception as e:
            logger.error(f"Error finding trading opportunities: {e}")
            return []
    
    async def _get_trending_tokens(self) -> List[Dict[str, Any]]:
        """
        Get trending tokens based on volume, social mentions, etc.
        
        Returns:
            List of trending tokens
        """
        # In a real implementation, this would query APIs or databases
        # For now, we'll return placeholder data
        
        return [
            {"address": "Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu", "symbol": "TOKEN1"},
            {"address": "So11111111111111111111111111111111111111112", "symbol": "SOL"},
            {"address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "symbol": "USDC"}
        ]
    
    def _get_state(self, opportunity: Dict[str, Any]) -> Tuple:
        """
        Convert an opportunity into a state representation for the model
        
        Args:
            opportunity: The trading opportunity
            
        Returns:
            State representation as a tuple
        """
        # Extract features for the state
        direction = opportunity["prediction"]["direction"]
        direction_value = 1 if direction == "bullish" else (0 if direction == "neutral" else -1)
        
        confidence = opportunity["prediction"]["confidence"]
        change_percent = opportunity["prediction"]["change_percent"]
        safety_score = opportunity["safety_score"]
        price = opportunity["current_price"]
        
        # Additional features (would be more sophisticated in real implementation)
        # For simplicity, we'll use discretized values for the Q-table
        discretized_price = min(int(price * 10), 1000)  # Discretize price
        discretized_confidence = int(confidence * 10)  # 0-10
        discretized_safety = int(safety_score)  # 0-10
        discretized_direction = direction_value + 1  # 0-2
        discretized_change = int(min(max(change_percent + 10, 0), 20))  # 0-20
        
        # Create a state tuple (simplified for this implementation)
        state = (
            discretized_direction,
            discretized_confidence,
            discretized_safety,
            discretized_change
        )
        
        return state
    
    def _choose_action(self, state: Tuple) -> int:
        """
        Choose an action using epsilon-greedy policy
        
        Args:
            state: Current state
            
        Returns:
            Action index: 0 (buy), 1 (sell), 2 (hold)
        """
        # Exploration-exploitation trade-off
        if np.random.random() < ML_TRADER_EXPLORATION_RATE:
            # Random action (exploration)
            return np.random.choice(ACTIONS)
        else:
            # Get Q-values for this state
            if state not in self.q_table:
                # Initialize if not seen before
                self.q_table[state] = np.zeros(ACTIONS)
                
            # Choose best action (exploitation)
            return np.argmax(self.q_table[state])
    
    def _update_q_table(self, state: Tuple, action: int, reward: float, next_state: Tuple):
        """
        Update Q-table using Q-learning
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
        """
        # Initialize Q-values if not already present
        if state not in self.q_table:
            self.q_table[state] = np.zeros(ACTIONS)
        
        if next_state not in self.q_table:
            self.q_table[next_state] = np.zeros(ACTIONS)
        
        # Q-learning update rule
        # Q(s,a) = Q(s,a) + α * [r + γ * max(Q(s',a')) - Q(s,a)]
        
        # Current Q-value
        current_q = self.q_table[state][action]
        
        # Best next Q-value
        next_max_q = np.max(self.q_table[next_state])
        
        # Learning rate
        alpha = ML_TRADER_LEARNING_RATE
        
        # Discount factor
        gamma = 0.95
        
        # Update Q-value
        new_q = current_q + alpha * (reward + gamma * next_max_q - current_q)
        
        # Store updated Q-value
        self.q_table[state][action] = new_q
    
    def _update_model(self):
        """Update the model based on collected experience"""
        # In a real implementation, this would train a neural network on collected experiences
        # For this simplified version, we just update the Q-table directly
        
        # Calculate performance metrics
        self._calculate_performance_metrics()
        
        # Update strategy parameters based on performance
        self._adapt_strategy_parameters()
        
        logger.info(f"Updated ML model. New metrics: Win rate {self.metrics['win_rate']:.2f}%, "
                  f"Avg profit: {self.metrics['avg_profit']:.2f}%, "
                  f"Sharpe ratio: {self.metrics['sharpe_ratio']:.2f}")
    
    def _calculate_performance_metrics(self):
        """Calculate performance metrics based on trade history"""
        if not self.trade_history:
            return
            
        # Total trades
        self.metrics["total_trades"] = len(self.trade_history)
        
        # Profitable trades
        profitable_trades = [t for t in self.trade_history if t["profit_percent"] > 0]
        self.metrics["profitable_trades"] = len(profitable_trades)
        
        # Win rate
        if self.metrics["total_trades"] > 0:
            self.metrics["win_rate"] = (self.metrics["profitable_trades"] / self.metrics["total_trades"]) * 100
        
        # Average profit and loss
        if profitable_trades:
            self.metrics["avg_profit"] = sum(t["profit_percent"] for t in profitable_trades) / len(profitable_trades)
            
        losing_trades = [t for t in self.trade_history if t["profit_percent"] <= 0]
        if losing_trades:
            self.metrics["avg_loss"] = sum(t["profit_percent"] for t in losing_trades) / len(losing_trades)
        
        # More sophisticated metrics would be calculated in a real implementation
        # - Maximum drawdown
        # - Sharpe ratio
        # - Sortino ratio
        
        # Placeholder for now
        self.metrics["max_drawdown"] = 15.0
        self.metrics["sharpe_ratio"] = 1.2
    
    def _adapt_strategy_parameters(self):
        """Adapt strategy parameters based on performance metrics"""
        # Example of adaptive strategy:
        
        # 1. If win rate is too low, increase safety requirements
        if self.metrics["win_rate"] < 40:
            self.strategy_params["entry_threshold"] = min(0.85, self.strategy_params["entry_threshold"] + 0.05)
            self.strategy_params["risk_factor"] = max(0.3, self.strategy_params["risk_factor"] - 0.1)
        
        # 2. If average profit is too low compared to average loss, adjust take profit
        profit_loss_ratio = abs(self.metrics["avg_profit"] / self.metrics["avg_loss"]) if self.metrics["avg_loss"] != 0 else 1.0
        if profit_loss_ratio < 1.5:
            self.strategy_params["take_profit"] = min(300, self.strategy_params["take_profit"] + 20)
            self.strategy_params["stop_loss"] = min(35, self.strategy_params["stop_loss"] + 5)
        
        # 3. If Sharpe ratio is good, consider increasing position size
        if self.metrics["sharpe_ratio"] > 1.5:
            self.strategy_params["position_size"] = min(ML_TRADER_MAX_POSITION, self.strategy_params["position_size"] + 0.05)
        
        # Additional strategy adjustments would be implemented in a real system
        logger.info(f"Adapted strategy parameters: entry_threshold={self.strategy_params['entry_threshold']}, "
                  f"risk_factor={self.strategy_params['risk_factor']}, position_size={self.strategy_params['position_size']}")
    
    async def _execute_buy(self, opportunity: Dict[str, Any]) -> bool:
        """
        Execute a buy order
        
        Args:
            opportunity: Trading opportunity
            
        Returns:
            Success status
        """
        # Skip if we're already at max positions
        if self.position_count >= ML_TRADER_MAX_POSITIONS:
            return False
            
        token_address = opportunity["token_address"]
        token_name = opportunity["token_name"]
        
        # Calculate position size based on confidence and risk factor
        confidence = opportunity["prediction"]["confidence"]
        base_position = self.strategy_params["position_size"]
        risk_factor = self.strategy_params["risk_factor"]
        
        # Adjust position size based on confidence
        position_size = base_position * (0.5 + confidence * risk_factor)
        position_size = min(position_size, ML_TRADER_MAX_POSITION)
        
        # Set take profit and stop loss based on strategy
        take_profit = self.strategy_params["take_profit"]
        stop_loss = self.strategy_params["stop_loss"]
        
        logger.info(f"ML Trader executing buy: {token_name} ({token_address}), "
                  f"Amount: {position_size} SOL, TP: {take_profit}%, SL: {stop_loss}%")
        
        try:
            # Execute the trade using our smart trade system
            result = await execute_smart_trade(
                token_address=token_address,
                amount=position_size,
                user_id=0,  # System user
                slippage=0.5,
                auto_sell=take_profit,
                stop_loss=stop_loss,
                transaction_type="ml_trader"
            )
            
            # Check if the trade was successful
            if result.get("success"):
                # Store the position
                entry_price = result.get("entry_price", opportunity["current_price"])
                tokens_received = result.get("tokens_received", 0)
                transaction_id = result.get("transaction_id")
                
                # Create position object
                position = {
                    "token_address": token_address,
                    "token_name": token_name,
                    "entry_price": entry_price,
                    "amount_spent": position_size,
                    "tokens_received": tokens_received,
                    "entry_time": time.time(),
                    "take_profit": take_profit,
                    "stop_loss": stop_loss,
                    "transaction_id": transaction_id,
                    "state": self._get_state(opportunity),
                    "action": 0  # Buy action
                }
                
                # Store the position
                self.positions[token_address] = position
                self.position_count += 1
                
                return True
            else:
                # Trade failed
                logger.error(f"ML Trader buy failed: {result.get('error')}")
                return False
                
        except Exception as e:
            logger.error(f"Error executing ML Trader buy: {e}")
            return False
    
    async def _execute_sell(self, opportunity: Dict[str, Any]) -> bool:
        """
        Execute a sell order
        
        Args:
            opportunity: Trading opportunity
            
        Returns:
            Success status
        """
        token_address = opportunity["token_address"]
        
        # Check if we have a position for this token
        if token_address not in self.positions:
            return False
            
        position = self.positions[token_address]
        token_name = position["token_name"]
        
        logger.info(f"ML Trader executing sell: {token_name} ({token_address})")
        
        try:
            # In a real implementation, this would execute an actual sell
            # For now, we'll simulate a successful sell
            
            # Get current price from the opportunity
            current_price = opportunity["current_price"]
            
            # Calculate profit/loss
            entry_price = position["entry_price"]
            profit_percent = ((current_price / entry_price) - 1) * 100
            
            # Record the trade in history
            trade_record = {
                "token_address": token_address,
                "token_name": token_name,
                "entry_price": entry_price,
                "exit_price": current_price,
                "amount_spent": position["amount_spent"],
                "profit_percent": profit_percent,
                "hold_time_hours": (time.time() - position["entry_time"]) / 3600,
                "entry_time": position["entry_time"],
                "exit_time": time.time(),
                "state": position["state"],
                "next_state": self._get_state(opportunity),
                "action": 1,  # Sell action
                "reward": profit_percent / 100 * REWARD_SCALE  # Scale profit for reward
            }
            
            # Add to trade history
            self.trade_history.append(trade_record)
            
            # Update Q-table
            self._update_q_table(
                state=trade_record["state"],
                action=trade_record["action"],
                reward=trade_record["reward"],
                next_state=trade_record["next_state"]
            )
            
            # Update metrics
            self.total_profit += profit_percent
            if profit_percent > 0:
                self.win_count += 1
            else:
                self.loss_count += 1
                
            # Remove the position
            del self.positions[token_address]
            self.position_count -= 1
            
            logger.info(f"ML Trader sell completed: {token_name}, Profit: {profit_percent:.2f}%, "
                      f"Total positions: {self.position_count}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error executing ML Trader sell: {e}")
            return False
    
    async def _check_position(self, token_address: str, position: Dict[str, Any]) -> None:
        """
        Check an existing position for take profit, stop loss, or max hold time
        
        Args:
            token_address: Token address
            position: Position details
        """
        try:
            # Get current token data
            safety_score, _, token_data = await analyze_token(token_address)
            
            current_price = token_data.get("market_data", {}).get("price")
            if not current_price:
                return
                
            # Check if it's time to sell
            entry_price = position["entry_price"]
            take_profit = position["take_profit"]
            stop_loss = position["stop_loss"]
            max_hold_time = self.strategy_params["max_hold_time"]
            
            # Calculate current profit/loss
            profit_percent = ((current_price / entry_price) - 1) * 100
            
            # Calculate hold time in hours
            hold_time_hours = (time.time() - position["entry_time"]) / 3600
            
            # Check conditions for selling
            should_sell = False
            sell_reason = ""
            
            # Take profit reached
            if profit_percent >= take_profit:
                should_sell = True
                sell_reason = f"Take profit reached: {profit_percent:.2f}% > {take_profit}%"
                
            # Stop loss triggered
            elif profit_percent <= -stop_loss:
                should_sell = True
                sell_reason = f"Stop loss triggered: {profit_percent:.2f}% < -{stop_loss}%"
                
            # Maximum hold time exceeded
            elif hold_time_hours >= max_hold_time:
                should_sell = True
                sell_reason = f"Max hold time exceeded: {hold_time_hours:.1f}h > {max_hold_time}h"
                
            # Safety score significantly decreased
            elif safety_score < 5 and position.get("safety_score", 10) > 7:
                should_sell = True
                sell_reason = f"Safety score decreased: {safety_score} < 5"
                
            # Execute sell if needed
            if should_sell:
                logger.info(f"ML Trader position check triggering sell for {position['token_name']}: {sell_reason}")
                
                # Create a simple opportunity object for the sell function
                opportunity = {
                    "token_address": token_address,
                    "token_name": position["token_name"],
                    "current_price": current_price,
                    "prediction": {
                        "direction": "neutral",
                        "confidence": 0.5,
                        "change_percent": 0
                    },
                    "safety_score": safety_score,
                    "timestamp": time.time()
                }
                
                # Execute the sell
                await self._execute_sell(opportunity)
                
        except Exception as e:
            logger.error(f"Error checking position {token_address}: {e}")
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """
        Get performance statistics
        
        Returns:
            Dictionary with performance statistics
        """
        return {
            "total_trades": self.win_count + self.loss_count,
            "winning_trades": self.win_count,
            "losing_trades": self.loss_count,
            "win_rate": (self.win_count / (self.win_count + self.loss_count)) * 100 if (self.win_count + self.loss_count) > 0 else 0,
            "total_profit_percent": self.total_profit,
            "current_positions": self.position_count,
            "strategy_params": self.strategy_params,
            "detailed_metrics": self.metrics
        }

# Create global instance
ml_trader = MLReinforcementTrader()

# API functions
async def start_ml_trader():
    """Start the ML Reinforcement Trader"""
    await ml_trader.start()

async def stop_ml_trader():
    """Stop the ML Reinforcement Trader"""
    await ml_trader.stop()

async def get_ml_trader_stats() -> Dict[str, Any]:
    """Get ML trader performance statistics"""
    return ml_trader.get_performance_stats()