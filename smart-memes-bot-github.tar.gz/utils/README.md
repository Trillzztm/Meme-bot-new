# Smart Memes Bot - Utils Package

This package provides utility functions and standard handlers for the Smart Memes Bot.

## Overview

The utils package is designed to support multiple implementations of the Telegram bot:

1. The simplified custom implementation (`SimpleTelegramBot`)
2. The standard python-telegram-bot pattern using `Application` and `Update`/`Context`
3. The telebot library implementation (using `pyTelegramBotAPI`)

It also provides multiple approaches for retrieving token information:

1. The comprehensive token_analyzer approach (detailed analysis, but more resource-intensive)
2. The lightweight direct API approach (basic information, but much faster)

## Components

### token_info.py

This module provides synchronous wrapper functions for the asynchronous token analysis functions in `token_analyzer.py`.

- `get_token_info(token_address, network)`: Retrieve comprehensive token information
- `check_token_safety_info(token_address, network)`: Check token safety
- `analyze_token_info(token_address, network)`: Get AI-powered token analysis

These functions return formatted Markdown strings ready to be sent to users.

### direct_api.py

This module provides direct API calls to blockchain explorers for lightweight token lookups.

- `get_token_info(token_address, network)`: Quick token info via direct API calls
- `get_solana_token_info(token_address)`: Solana-specific token info
- `get_ethereum_token_info(token_address)`: Ethereum-specific token info
- `get_bsc_token_info(token_address)`: BSC-specific token info

These provide basic token information with minimal processing, ideal for quick responses.

### standard_handlers.py

This module provides standard python-telegram-bot handler functions that can be registered with an `Application` instance:

- `start_handler(update, context)`: Handle the /start command
- `help_handler(update, context)`: Handle the /help command
- `tokeninfo_handler(update, context)`: Handle the /tokeninfo command
- `check_handler(update, context)`: Handle the /check command
- `analyze_handler(update, context)`: Handle the /analyze command
- `snipe_handler(update, context)`: Handle the /snipe command

## Usage

### Using with Simplified Bot

```python
# In a SimpleTelegramBot method:
from utils.token_info import get_token_info

def handle_tokeninfo_command(self, chat_id, text):
    parts = text.split()
    token_address = parts[1]
    network = "ethereum"
    
    # Check if network is specified
    for part in parts[2:]:
        if part.startswith("network="):
            network = part.split("=")[1].lower()
    
    # Get formatted token info
    info_message = get_token_info(token_address, network)
    
    # Send to user
    self.send_message(chat_id, info_message, parse_mode="Markdown")
```

### Using Direct API for Quick Responses

```python
# In a bot handler method:
from utils.direct_api import get_token_info

def handle_quickinfo_command(self, chat_id, text):
    parts = text.split()
    token_address = parts[1]
    network = "solana"  # Default
    
    # Check if network is specified
    for part in parts[2:]:
        if part.startswith("network="):
            network = part.split("=")[1].lower()
    
    # Get quick token info via direct API
    info_message = get_token_info(token_address, network)
    
    # Send to user
    self.send_message(chat_id, info_message, parse_mode="Markdown")
```

### Using with Standard Bot (python-telegram-bot)

```python
# In your bot initialization:
from telegram.ext import ApplicationBuilder, CommandHandler
from utils.standard_handlers import tokeninfo_handler, register_handlers

# Create application
application = ApplicationBuilder().token(token).build()

# Register all handlers at once
register_handlers(application)

# Or register individual handlers
application.add_handler(CommandHandler("tokeninfo", tokeninfo_handler))

# Run the bot
application.run_polling()
```

### Using with Telebot

```python
# In your bot setup:
from telebot import TeleBot
from utils.token_info import get_token_info

bot = TeleBot(token)

@bot.message_handler(commands=['tokeninfo'])
def tokeninfo_handler(msg):
    args = msg.text.split()
    if len(args) < 2:
        return bot.reply_to(msg, "Usage: /tokeninfo <token_address>")
    
    token_address = args[1]
    network = "ethereum"  # Default
    
    # Check for network parameter
    for arg in args[2:]:
        if arg.startswith("network="):
            network = arg.split("=")[1].lower()
    
    # Use our shared token_info utility
    info = get_token_info(token_address, network)
    bot.reply_to(msg, info, parse_mode="Markdown")

# Start the bot
bot.polling()
```

## Multi-Library Hybrid Approach

The bot.py and crypto_bot.py files are set up to support multiple approaches:

1. If python-telegram-bot is available and `USE_SIMPLIFIED_BOT` is not set, the standard pattern is used
2. Otherwise, the simplified implementation is used
3. A telebot implementation can also be added as another option

This ensures maximum compatibility and resilience across different environments and library choices.

## Performance Trade-offs

The utils package offers two different approaches for token analysis:

1. **Comprehensive Analysis (`token_info.py`)**
   - More detailed information (price, liquidity, safety checks, AI analysis)
   - Uses comprehensive token_analyzer module
   - Slower response times (typically 1-3 seconds)
   - Higher resource usage

2. **Lightweight Analysis (`direct_api.py`)**
   - Basic token information (name, symbol, supply, holders)
   - Makes direct API calls to blockchain explorers
   - Much faster response times (typically <0.5 seconds)
   - Lower resource usage
   - Works with minimal dependencies

Choose the appropriate approach based on your use case:
- Quick responses: Use direct_api.py
- Detailed analysis: Use token_info.py
- Hybrid approach: Use direct_api for initial responses, then follow with detailed analysis

## Examples

- See `examples/hybrid_usage_example.py` for a complete example of the simplified and standard approaches
- See `examples/telebot_example.py` for an example using the telebot library
- See `examples/direct_api_example.py` for an example using direct API calls for token information