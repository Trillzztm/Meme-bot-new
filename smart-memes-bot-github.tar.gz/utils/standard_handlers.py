"""
Standard handlers for use with python-telegram-bot.

These handlers work with the standard python-telegram-bot pattern using 
Application, Update, and Context. They can be registered with an Application
instance to provide the bot's functionality.

All handlers use the shared token_info utilities to ensure consistency
across different implementations.
"""

import logging
import asyncio
from typing import Dict, Any, Optional, List, Union

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Import the shared token_info utilities
from utils.token_info import get_token_info, check_token_safety_info, analyze_token_info

# Try to import python-telegram-bot components
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import ContextTypes, Application, CommandHandler, CallbackQueryHandler, InlineQueryHandler
    PTB_AVAILABLE = True
except ImportError:
    logger.warning("python-telegram-bot not available, standard handlers will not work")
    PTB_AVAILABLE = False

# Try to import token_sniper for buy functionality
try:
    import token_sniper
    SNIPER_AVAILABLE = True
except ImportError:
    logger.warning("token_sniper not available, snipe commands will be limited")
    SNIPER_AVAILABLE = False

async def start_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /start command."""
    if not PTB_AVAILABLE:
        return
    
    welcome_text = (
        "🔮 *Welcome to Smart Memes Bot!* 🔮\n\n"
        "I can help you with cryptocurrency token analysis, safety checks, wallet monitoring, "
        "AI-powered trading, and even generate crypto memes!\n\n"
        "Commands:\n"
        "• /help - Show detailed command help\n"
        "• /tokeninfo <token_address> - Get token information\n"
        "• /check <token_address> - Check token safety\n"
        "• /analyze <token_address> - AI-powered token analysis\n"
        "• /aitrade <token_address> - AI-powered token trading\n"
        "• /snipe <token_address> <amount> - Snipe a token\n"
        "• /monitor <wallet_address> - Monitor a wallet\n"
        "• /meme - Generate a crypto meme\n\n"
        "Use /help for more detailed command information."
    )
    
    await update.message.reply_text(welcome_text, parse_mode="Markdown")

async def help_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /help command."""
    if not PTB_AVAILABLE:
        return
    
    help_text = (
        "🔮 *Smart Memes Bot Commands* 🔮\n\n"
        
        "*Token Information:*\n"
        "• `/tokeninfo <token_address> [network=solana]`\n"
        "   Get comprehensive token information including price, liquidity, and holders\n\n"
        
        "*Token Safety:*\n"
        "• `/check <token_address> [network=solana]`\n"
        "   Perform a security analysis to check for rugpull and honeypot risks\n\n"
        
        "*Token Analysis:*\n"
        "• `/analyze <token_address> [network=solana]`\n"
        "   Get AI-powered price predictions and investment recommendations\n\n"
        
        "*Token Sniping:*\n"
        "• `/snipe <token_address> <amount> [network=solana] [slippage=1]`\n"
        "   Buy a token automatically with specified parameters\n"
        "• `/manualsnipe <token_address> amount=<eth> slippage=<percent> gas=<level>`\n"
        "   Advanced manual token sniping with custom parameters\n"
        "• `/aitrade <token_address> [amount=0.02]`\n"
        "   AI-powered token analysis and automated trading with risk management\n\n"
        
        "*Wallet Monitoring:*\n"
        "• `/monitor <wallet_address> [alias=name]`\n"
        "   Track transactions and token movements for a wallet\n\n"
        
        "*Group Monitoring:*\n"
        "• `/watchgroup <group_link> [auto=yes/no] [min=3]`\n"
        "   Monitor a Telegram group for token mentions with optional auto-sniping\n\n"
        
        "*Meme Generation:*\n"
        "• `/meme [token=address] [theme=name]`\n"
        "   Generate a crypto-themed meme, optionally based on a token's performance\n\n"
        
        "*AI-Powered Features:*\n"
        "• `/aiadvice <prompt>`\n"
        "   Get AI-powered trading and crypto advice\n"
        "• `/ai <token_address> [amount=0.02]`\n"
        "   Shortcut for AI-powered trading\n\n"
        
        "*Parameters:*\n"
        "• `network` - Blockchain network (ethereum, bsc, polygon, solana)\n"
        "• `slippage` - Maximum price slippage percentage (default: 1%)\n"
        "• `gas` - Gas price level (low, medium, high, rapid)\n"
        "• `auto` - Enable auto-sniping for watched groups (yes/no)\n"
        "• `min` - Minimum mentions before auto-sniping (default: 3)\n"
        "• `theme` - Meme theme (moon_lambo, diamond_hands, etc.)\n\n"
        
        "Visit the web dashboard for advanced configuration and analytics: Your Replit URL"
    )
    
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def tokeninfo_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /tokeninfo command."""
    if not PTB_AVAILABLE:
        return
    
    # Check if a token address was provided
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address.\n"
            "Usage: `/tokeninfo <token_address> [network=solana]`", 
            parse_mode="Markdown"
        )
        return
    
    # Get the token address and network
    token_address = context.args[0]
    network = "ethereum"  # Default
    
    # Check for network parameter
    for arg in context.args[1:]:
        if arg.startswith("network="):
            network = arg.split("=")[1].lower()
    
    # Auto-detect Solana addresses
    if len(token_address) > 30 and not token_address.startswith("0x"):
        network = "solana"
    
    # Send a "processing" message
    processing_message = await update.message.reply_text(
        f"🔍 Retrieving information for token `{token_address}` on {network.upper()}...",
        parse_mode="Markdown"
    )
    
    # Get token information using the shared utility function
    info_message = get_token_info(token_address, network)
    
    # Edit the processing message with the result
    await processing_message.edit_text(
        info_message,
        parse_mode="Markdown"
    )

async def check_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /check command."""
    if not PTB_AVAILABLE:
        return
    
    # Check if a token address was provided
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address.\n"
            "Usage: `/check <token_address> [network=solana]`", 
            parse_mode="Markdown"
        )
        return
    
    # Get the token address and network
    token_address = context.args[0]
    network = "ethereum"  # Default
    
    # Check for network parameter
    for arg in context.args[1:]:
        if arg.startswith("network="):
            network = arg.split("=")[1].lower()
    
    # Auto-detect Solana addresses
    if len(token_address) > 30 and not token_address.startswith("0x"):
        network = "solana"
    
    # Send a "processing" message
    processing_message = await update.message.reply_text(
        f"🛡️ Performing safety check for token `{token_address}` on {network.upper()}...",
        parse_mode="Markdown"
    )
    
    # Get token safety information using the shared utility function
    safety_message = check_token_safety_info(token_address, network)
    
    # Edit the processing message with the result
    await processing_message.edit_text(
        safety_message,
        parse_mode="Markdown"
    )

async def analyze_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /analyze command."""
    if not PTB_AVAILABLE:
        return
    
    # Check if a token address was provided
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address.\n"
            "Usage: `/analyze <token_address> [network=solana]`", 
            parse_mode="Markdown"
        )
        return
    
    # Get the token address and network
    token_address = context.args[0]
    network = "ethereum"  # Default
    
    # Check for network parameter
    for arg in context.args[1:]:
        if arg.startswith("network="):
            network = arg.split("=")[1].lower()
    
    # Auto-detect Solana addresses
    if len(token_address) > 30 and not token_address.startswith("0x"):
        network = "solana"
    
    # Send a "processing" message
    processing_message = await update.message.reply_text(
        f"🧠 Analyzing token `{token_address}` on {network.upper()}...\n"
        f"This may take a moment as I gather and process data.",
        parse_mode="Markdown"
    )
    
    # Get token analysis using the shared utility function
    analysis_message = analyze_token_info(token_address, network)
    
    # Edit the processing message with the result
    await processing_message.edit_text(
        analysis_message,
        parse_mode="Markdown"
    )

async def snipe_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle the /snipe command."""
    if not PTB_AVAILABLE:
        return
    
    # Check if token_sniper is available
    if not SNIPER_AVAILABLE:
        await update.message.reply_text(
            "⚠️ Token sniping functionality is not available in this environment.",
            parse_mode="Markdown"
        )
        return
    
    # Check if parameters were provided
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "Please provide a token address and amount.\n"
            "Usage: `/snipe <token_address> <amount> [network=solana] [slippage=1]`", 
            parse_mode="Markdown"
        )
        return
    
    # Get the token address and amount
    token_address = context.args[0]
    
    # Parse amount
    try:
        amount = float(context.args[1])
    except ValueError:
        await update.message.reply_text(
            "Amount must be a number.",
            parse_mode="Markdown"
        )
        return
    
    # Parse optional parameters
    network = "ethereum"  # Default
    slippage = 1.0  # Default slippage of 1%
    gas_price = "medium"  # Default gas price
    
    for arg in context.args[2:]:
        if arg.startswith("network="):
            network = arg.split("=")[1].lower()
        elif arg.startswith("slippage="):
            try:
                slippage = float(arg.split("=")[1])
            except ValueError:
                await update.message.reply_text(
                    "Slippage must be a number.",
                    parse_mode="Markdown"
                )
                return
        elif arg.startswith("gas="):
            gas_price = arg.split("=")[1].lower()
    
    # Auto-detect Solana addresses
    if len(token_address) > 30 and not token_address.startswith("0x"):
        network = "solana"
    
    # Currency display based on network
    currency = "SOL" if network == "solana" else "ETH"
    
    # Send a "processing" message
    processing_message = await update.message.reply_text(
        f"🎯 Sniping {amount} {currency} to `{token_address}` on {network.upper()}...\n"
        f"Slippage: {slippage}%, Gas: {gas_price}",
        parse_mode="Markdown"
    )
    
    try:
        # Get user ID from update
        user_id = update.effective_user.id
        
        # Execute the snipe
        result = await token_sniper.manual_snipe(
            token_address,
            amount=amount,
            network=network,
            slippage=slippage,
            gas_price=gas_price,
            user_id=user_id
        )
        
        if result and result.get("success", False):
            # Format success message
            success_message = (
                f"✅ *Snipe Executed Successfully!*\n\n"
                f"• Token: `{token_address}`\n"
                f"• Transaction: `{result['transaction_hash']}`\n"
                f"• Amount Spent: {result['amount_spent']} {currency}\n"
                f"• Est. Tokens: {result['estimated_tokens']}\n"
                f"• Wallet: `{result['wallet_address']}`\n\n"
            )
            
            # Edit the processing message with the result
            await processing_message.edit_text(
                success_message,
                parse_mode="Markdown"
            )
            
            # Add buttons for token tracking and analysis
            keyboard = [
                [
                    InlineKeyboardButton("Track Token", callback_data=f"track:{token_address}:{network}"),
                    InlineKeyboardButton("Token Analysis", callback_data=f"analyze:{token_address}:{network}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                "What would you like to do next?",
                reply_markup=reply_markup
            )
        else:
            # Format error message
            error_message = (
                f"❌ *Snipe Failed*\n\n"
                f"• Token: `{token_address}`\n"
                f"• Error: {result.get('error', 'Unknown error')}\n\n"
            )
            
            # Edit the processing message with the result
            await processing_message.edit_text(
                error_message,
                parse_mode="Markdown"
            )
    except Exception as e:
        # Handle any exceptions during the snipe process
        await processing_message.edit_text(
            f"❌ *Error executing snipe:* {str(e)}",
            parse_mode="Markdown"
        )

async def button_callback_handler(update: 'Update', context: 'ContextTypes.DEFAULT_TYPE') -> None:
    """Handle button callbacks from inline keyboards."""
    if not PTB_AVAILABLE:
        return
    
    query = update.callback_query
    await query.answer()
    
    # Parse the callback data
    data = query.data.split(":")
    action = data[0]
    
    if action == "track" and len(data) >= 3:
        token_address = data[1]
        network = data[2]
        
        # Track the token (implementation depends on your system)
        await query.edit_message_text(
            f"🔍 Tracking token `{token_address}` on {network.upper()}...",
            parse_mode="Markdown"
        )
        
    elif action == "analyze" and len(data) >= 3:
        token_address = data[1]
        network = data[2]
        
        # Get token analysis
        analysis_message = analyze_token_info(token_address, network)
        
        # Send the analysis as a new message
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=analysis_message,
            parse_mode="Markdown"
        )

def register_handlers(application: 'Application') -> None:
    """Register all handlers with the application."""
    if not PTB_AVAILABLE:
        logger.warning("python-telegram-bot not available, handlers not registered")
        return
    
    # Register command handlers
    application.add_handler(CommandHandler("start", start_handler))
    application.add_handler(CommandHandler("help", help_handler))
    application.add_handler(CommandHandler("tokeninfo", tokeninfo_handler))
    application.add_handler(CommandHandler("check", check_handler))
    application.add_handler(CommandHandler("analyze", analyze_handler))
    application.add_handler(CommandHandler("snipe", snipe_handler))
    
    # Register AI trade handlers
    try:
        from handlers.ai_trade import get_handlers as get_ai_trade_handlers
        ai_handlers = get_ai_trade_handlers()
        for handler in ai_handlers:
            application.add_handler(handler)
        logger.info("AI trade handlers registered successfully")
    except ImportError:
        logger.warning("AI trade handlers not available")
    
    # Register callback query handler for buttons
    application.add_handler(CallbackQueryHandler(button_callback_handler))
    
    logger.info("Standard handlers registered successfully")