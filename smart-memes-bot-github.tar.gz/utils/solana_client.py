import os
import asyncio
import logging
from utils.jupiter_client import get_quote, execute_jupiter_swap, swap_sol_to_token, swap_token_to_sol, get_token_price_usdc

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("solana_client")

# SOL wrapped mint
SOL_MINT = "So11111111111111111111111111111111111111112"

async def get_token_price(token_address):
    """
    Get the current price of a token in SOL.
    
    Args:
        token_address: The token's mint address
        
    Returns:
        Price in SOL, or 0 if price cannot be determined
    """
    logger.info(f"Getting price for token {token_address}")
    
    try:
        # We'll use 1 SOL to get a quote
        lamports = 1_000_000_000  # 1 SOL in lamports
        
        # Get quote for 1 SOL to the token
        quote = await get_quote(SOL_MINT, token_address, lamports)
        
        if not quote or "outAmount" not in quote:
            logger.warning(f"Could not get quote for {token_address}")
            return 0
        
        # Calculate price in SOL (how much of the token we get for 1 SOL)
        token_amount = int(quote["outAmount"])
        
        if token_amount == 0:
            return 0
            
        # Price is 1/token_amount (price per token in SOL)
        return 1.0 / (token_amount)
    except Exception as e:
        logger.error(f"Error getting token price: {e}")
        return 0

async def buy_token(token_address, price=None, amount_sol=0.1):
    """
    Buy a token with SOL.
    
    Args:
        token_address: The token's mint address
        price: Optional price in SOL (for logging purposes only)
        amount_sol: Amount of SOL to spend
        
    Returns:
        Transaction URL or error message
    """
    logger.info(f"Buying {amount_sol} SOL worth of {token_address}")
    
    try:
        if price is None:
            price = await get_token_price(token_address)
            
        # Execute the swap
        tx_url = await swap_sol_to_token(token_address, amount_sol)
        
        # Log the purchase
        logger.info(f"Bought {token_address} with {amount_sol} SOL at price {price}")
        return tx_url
    except Exception as e:
        logger.error(f"Error buying token: {e}")
        return f"Error: {str(e)}"

async def sell_token(token_address, price=None, token_amount=None):
    """
    Sell a token for SOL.
    
    Args:
        token_address: The token's mint address
        price: Optional price in SOL (for logging purposes only)
        token_amount: Amount of token to sell (in smallest units)
        
    Returns:
        Transaction URL or error message
    """
    logger.info(f"Selling {token_amount} of {token_address}")
    
    try:
        if price is None:
            price = await get_token_price(token_address)
            
        # For simulation purposes, if token_amount is None, use a default value
        if token_amount is None:
            token_amount = 1000000
            
        # Execute the swap
        tx_url = await swap_token_to_sol(token_address, token_amount)
        
        # Log the sale
        logger.info(f"Sold {token_amount} of {token_address} at price {price}")
        return tx_url
    except Exception as e:
        logger.error(f"Error selling token: {e}")
        return f"Error: {str(e)}"

def run_async(coroutine):
    """Run an async function from synchronous code."""
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coroutine)

async def test_solana_client():
    """Test the Solana client with USDC."""
    # USDC mint
    usdc_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    
    logger.info(f"Testing Solana client with USDC ({usdc_mint})")
    
    # Get price
    price = await get_token_price(usdc_mint)
    logger.info(f"USDC price in SOL: {price}")
    
    return True