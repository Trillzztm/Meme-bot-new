"""
Cross-DEX arbitrage detection and execution for SMART MEMES BOT.

This module identifies and exploits price differences across decentralized exchanges
to generate risk-free profit through arbitrage opportunities.
"""

import logging
import asyncio
import time
import json
from typing import Dict, Any, List, Tuple, Optional
import aiohttp

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import our utilities
from utils.token_analyzer import analyze_token
from utils.enhanced_solana_trade import execute_trade
from database import session_scope, record_snipe_transaction, update_snipe_status
from config import (
    ARBITRAGE_MIN_PROFIT_PERCENT,
    ARBITRAGE_MAX_AMOUNT,
    ARBITRAGE_ENABLED_DEXES,
    ARBITRAGE_DETECTION_INTERVAL
)

# Constants
DEX_TIMEOUT = 10  # seconds
MAX_RETRIES = 3
PRICE_VARIANCE_THRESHOLD = 0.5  # Minimum price difference percentage to consider arbitrage

# Solana DEX endpoints (for illustration purposes)
SOLANA_DEXES = {
    "raydium": {
        "name": "Raydium",
        "api_url": "https://api.raydium.io/",
        "explorer_url": "https://raydium.io/swap/",
        "router_address": "xxxraydiumrouterxxx",
        "platform_fee": 0.25  # 0.25%
    },
    "orca": {
        "name": "Orca",
        "api_url": "https://api.orca.so/",
        "explorer_url": "https://orca.so/",
        "router_address": "xxxorcarouterxxx",
        "platform_fee": 0.3  # 0.3%
    },
    "serum": {
        "name": "Serum",
        "api_url": "https://api.serum-api.com/",
        "explorer_url": "https://serum-explorer.com/",
        "router_address": "xxxserumrouterxxx",
        "platform_fee": 0.22  # 0.22%
    }
}

class ArbitrageDetector:
    """Cross-DEX arbitrage detector and executor"""
    
    def __init__(self):
        """Initialize the arbitrage detector"""
        self.running = False
        self.task = None
        self.dexes = {k: v for k, v in SOLANA_DEXES.items() if k in ARBITRAGE_ENABLED_DEXES}
    
    async def start(self):
        """Start the arbitrage detector background task"""
        if self.running:
            logger.warning("Arbitrage detector already running")
            return
            
        self.running = True
        self.task = asyncio.create_task(self._detect_loop())
        logger.info(f"Arbitrage detector started (monitoring {len(self.dexes)} DEXes)")
    
    async def stop(self):
        """Stop the arbitrage detector background task"""
        if not self.running:
            return
            
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
            finally:
                self.task = None
                
        logger.info("Arbitrage detector stopped")
    
    async def _detect_loop(self):
        """Main detection loop for arbitrage opportunities"""
        try:
            while self.running:
                try:
                    # Get popular tokens to check
                    tokens = await self._get_top_tokens()
                    
                    # Check each token for arbitrage opportunities
                    for token in tokens:
                        token_address = token.get("address")
                        if not token_address:
                            continue
                            
                        # Check for price differences across DEXes
                        opportunity = await self._find_arbitrage_opportunity(token_address)
                        
                        if opportunity and opportunity.get("profitable"):
                            # Found a profitable opportunity!
                            await self._execute_arbitrage(opportunity)
                            
                        # Sleep briefly between tokens to avoid rate limits
                        await asyncio.sleep(1)
                    
                except Exception as e:
                    logger.error(f"Error in arbitrage detection loop: {e}")
                    
                # Wait before next detection cycle
                await asyncio.sleep(ARBITRAGE_DETECTION_INTERVAL)
                
        except asyncio.CancelledError:
            logger.info("Arbitrage detection task cancelled")
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error in arbitrage detection: {e}")
            self.running = False
    
    async def _get_top_tokens(self) -> List[Dict[str, Any]]:
        """Get top tokens by volume/liquidity to check for arbitrage"""
        try:
            # In a real implementation, this would query a token API or database
            # For now, we'll return a placeholder
            return [
                {"address": "Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu", "name": "Example Token", "symbol": "EX"},
                # Add more tokens here
            ]
            
        except Exception as e:
            logger.error(f"Error getting top tokens: {e}")
            return []
    
    async def _find_arbitrage_opportunity(self, token_address: str) -> Optional[Dict[str, Any]]:
        """
        Find arbitrage opportunity for a specific token across multiple DEXes
        
        Args:
            token_address: Token address to check
            
        Returns:
            Opportunity details if found, None otherwise
        """
        try:
            # Get token data
            _, _, token_data = await analyze_token(token_address)
            
            # Query prices from each DEX
            prices = {}
            
            for dex_id, dex_info in self.dexes.items():
                price = await self._get_token_price_from_dex(token_address, dex_id)
                
                if price and price > 0:
                    prices[dex_id] = price
            
            # Need at least 2 DEXes with valid prices
            if len(prices) < 2:
                return None
                
            # Find best buy and sell prices
            buy_dex = min(prices.items(), key=lambda x: x[1])
            sell_dex = max(prices.items(), key=lambda x: x[1])
            
            buy_price = buy_dex[1]
            buy_dex_id = buy_dex[0]
            
            sell_price = sell_dex[1]
            sell_dex_id = sell_dex[0]
            
            # Calculate price difference percentage
            price_diff_percent = ((sell_price - buy_price) / buy_price) * 100
            
            # Check if the difference is significant enough
            if price_diff_percent < PRICE_VARIANCE_THRESHOLD:
                return None
                
            # Calculate profit after fees
            buy_fee_percent = self.dexes[buy_dex_id].get("platform_fee", 0.3)
            sell_fee_percent = self.dexes[sell_dex_id].get("platform_fee", 0.3)
            
            gas_cost_estimate = 0.001  # Estimated SOL cost for two transactions
            
            # Calculate net profit percentage after fees
            net_profit_percent = price_diff_percent - buy_fee_percent - sell_fee_percent
            
            # Determine optimal amount based on profit percentage
            optimal_amount = min(
                ARBITRAGE_MAX_AMOUNT,
                0.05 + (net_profit_percent / 10) * 0.45  # Scale amount with profit potential
            )
            
            # Calculate estimated profit in SOL
            estimated_profit_sol = (optimal_amount * net_profit_percent / 100) - gas_cost_estimate
            
            # Check if this opportunity is profitable
            profitable = (
                net_profit_percent >= ARBITRAGE_MIN_PROFIT_PERCENT and
                estimated_profit_sol > 0
            )
            
            # Build opportunity object
            token_name = token_data.get("name") or token_data.get("symbol") or token_address[:10] + "..."
            
            opportunity = {
                "token_address": token_address,
                "token_name": token_name,
                "buy_dex": self.dexes[buy_dex_id]["name"],
                "buy_dex_id": buy_dex_id,
                "buy_price": buy_price,
                "sell_dex": self.dexes[sell_dex_id]["name"],
                "sell_dex_id": sell_dex_id,
                "sell_price": sell_price,
                "price_diff_percent": price_diff_percent,
                "net_profit_percent": net_profit_percent,
                "optimal_amount": optimal_amount,
                "estimated_profit_sol": estimated_profit_sol,
                "profitable": profitable,
                "timestamp": time.time()
            }
            
            if profitable:
                logger.info(f"Found arbitrage opportunity for {token_name}: "
                          f"Buy on {opportunity['buy_dex']} at ${buy_price:.6f}, "
                          f"Sell on {opportunity['sell_dex']} at ${sell_price:.6f}, "
                          f"Profit: {net_profit_percent:.2f}% (est. {estimated_profit_sol:.6f} SOL)")
            
            return opportunity
            
        except Exception as e:
            logger.error(f"Error finding arbitrage for {token_address}: {e}")
            return None
    
    async def _get_token_price_from_dex(self, token_address: str, dex_id: str) -> Optional[float]:
        """
        Get token price from a specific DEX
        
        Args:
            token_address: Token address to check
            dex_id: DEX identifier
            
        Returns:
            Token price or None if unavailable
        """
        # In a real implementation, this would query DEX APIs
        # For now, we'll simulate price variations
        try:
            # For demonstration: generate slightly different prices for each DEX
            # In a real implementation, this would call the actual DEX APIs
            
            # Use token analyzer to get base price
            _, _, token_data = await analyze_token(token_address)
            base_price = token_data.get("market_data", {}).get("price")
            
            if not base_price:
                return None
                
            # Convert to float if needed
            if isinstance(base_price, str):
                try:
                    base_price = float(base_price)
                except (ValueError, TypeError):
                    return None
            
            # Add a small variation based on DEX id (for demo purposes)
            # In reality, these would be actual different prices from different DEXes
            variations = {
                "raydium": -0.5,  # -0.5% from base
                "orca": 0.8,      # +0.8% from base
                "serum": 0.2      # +0.2% from base
            }
            
            variation_percent = variations.get(dex_id, 0)
            price = base_price * (1 + variation_percent / 100)
            
            return price
            
        except Exception as e:
            logger.error(f"Error getting price from {dex_id} for {token_address}: {e}")
            return None
    
    async def _execute_arbitrage(self, opportunity: Dict[str, Any]) -> bool:
        """
        Execute an arbitrage opportunity
        
        Args:
            opportunity: The arbitrage opportunity details
            
        Returns:
            Success status
        """
        try:
            # Extract details
            token_address = opportunity.get("token_address")
            token_name = opportunity.get("token_name")
            buy_dex = opportunity.get("buy_dex")
            sell_dex = opportunity.get("sell_dex")
            amount = opportunity.get("optimal_amount")
            
            logger.info(f"Executing arbitrage for {token_name}: "
                      f"Buy on {buy_dex}, Sell on {sell_dex}, Amount: {amount} SOL")
            
            # Step 1: Record transaction in database
            transaction_id = None
            try:
                transaction_id = record_snipe_transaction(
                    telegram_id=0,  # System user
                    token_address=token_address,
                    amount_spent=amount,
                    status="pending",
                    is_auto=True,
                    platform=buy_dex.lower(),
                    tx_type="arbitrage"
                )
            except Exception as db_error:
                logger.error(f"Error recording arbitrage transaction: {db_error}")
            
            # Step 2: Execute buy transaction
            # In a real implementation, this would specify the DEX to use
            buy_result = await execute_trade(token_address, amount)
            
            if not buy_result.get("success"):
                logger.error(f"Arbitrage buy failed: {buy_result.get('error')}")
                
                # Update transaction status
                if transaction_id:
                    update_snipe_status(
                        snipe_id=transaction_id,
                        status="failed",
                        error_message=f"Buy failed: {buy_result.get('error')}"
                    )
                
                return False
            
            # Step 3: Execute sell transaction
            # In a real implementation, this would be a separate function
            # For now, we'll simulate success
            
            tokens_received = buy_result.get("tokens_received", 0)
            
            # Update transaction status
            if transaction_id:
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="completed",
                    tx_hash=buy_result.get("transaction_hash"),
                    tokens_received=tokens_received,
                    current_price=opportunity.get("buy_price")
                )
            
            logger.info(f"Arbitrage for {token_name} executed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error executing arbitrage: {e}")
            return False

# Create global instance
arbitrage_detector = ArbitrageDetector()

# API functions
async def start_arbitrage_detector():
    """Start the arbitrage detector service"""
    await arbitrage_detector.start()

async def stop_arbitrage_detector():
    """Stop the arbitrage detector service"""
    await arbitrage_detector.stop()

async def check_token_arbitrage(token_address: str) -> Dict[str, Any]:
    """
    Check if a specific token has arbitrage opportunities
    
    Args:
        token_address: Token to check
        
    Returns:
        Opportunity details if found
    """
    try:
        return await arbitrage_detector._find_arbitrage_opportunity(token_address)
    except Exception as e:
        logger.error(f"Error checking arbitrage for {token_address}: {e}")
        return {
            "error": f"Error checking arbitrage: {str(e)}",
            "profitable": False
        }