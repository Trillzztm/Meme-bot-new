import os
import logging
import openai
import aiohttp
import json
import asyncio
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("ai_token_analyzer")

# OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")

# Solana API endpoints
SOLANA_RPC = os.getenv("SOLANA_RPC", "https://api.mainnet-beta.solana.com")
BIRDEYE_API_KEY = os.getenv("BIRDEYE_API_KEY")

# Cache for token data (to avoid unnecessary API calls)
token_cache = {}
cache_expiry = 5 * 60  # 5 minutes

async def get_token_metadata(token_address):
    """Get token metadata from Birdeye or Solana RPC."""
    # Check cache first
    if token_address in token_cache and token_cache[token_address]["expire_time"] > datetime.now():
        logger.info(f"Using cached metadata for {token_address}")
        return token_cache[token_address]["data"]
    
    logger.info(f"Fetching metadata for token {token_address}")
    
    # Try Birdeye API first if we have an API key
    if BIRDEYE_API_KEY:
        try:
            url = f"https://public-api.birdeye.so/public/tokeninfo?address={token_address}"
            headers = {"X-API-KEY": BIRDEYE_API_KEY}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("success"):
                            metadata = data.get("data", {})
                            # Cache the result
                            token_cache[token_address] = {
                                "data": metadata,
                                "expire_time": datetime.now() + timedelta(seconds=cache_expiry)
                            }
                            return metadata
        except Exception as e:
            logger.warning(f"Error fetching from Birdeye: {e}")
    
    # Fallback to Solana RPC getTokenAccountsByOwner
    try:
        url = SOLANA_RPC
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getAccountInfo",
            "params": [
                token_address,
                {"encoding": "jsonParsed"}
            ]
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    result = data.get("result", {}).get("value", {})
                    
                    # Basic metadata from RPC response
                    metadata = {
                        "address": token_address,
                        "name": "Unknown Token",
                        "symbol": "UNKNOWN",
                        "decimals": 0,
                        "supply": 0,
                    }
                    
                    # Extract more info if available
                    if "data" in result and "parsed" in result["data"]:
                        parsed = result["data"]["parsed"]
                        if "info" in parsed:
                            info = parsed["info"]
                            metadata["name"] = info.get("name", metadata["name"])
                            metadata["symbol"] = info.get("symbol", metadata["symbol"])
                            metadata["decimals"] = info.get("decimals", metadata["decimals"])
                            if "supply" in info:
                                metadata["supply"] = int(info["supply"])
                    
                    # Cache the result
                    token_cache[token_address] = {
                        "data": metadata,
                        "expire_time": datetime.now() + timedelta(seconds=cache_expiry)
                    }
                    return metadata
    except Exception as e:
        logger.error(f"Error fetching token metadata: {e}")
    
    # Return basic info if all else fails
    return {
        "address": token_address,
        "name": "Unknown Token",
        "symbol": "UNKNOWN",
        "decimals": 0,
        "supply": 0,
    }

async def get_token_price_and_liquidity(token_address):
    """Get token price and liquidity information."""
    logger.info(f"Fetching price and liquidity for {token_address}")
    
    # Try Birdeye API first if we have an API key
    if BIRDEYE_API_KEY:
        try:
            url = f"https://public-api.birdeye.so/public/price?address={token_address}"
            headers = {"X-API-KEY": BIRDEYE_API_KEY}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("success"):
                            price_data = data.get("data", {})
                            return {
                                "price": price_data.get("value", 0),
                                "price_change_24h": price_data.get("priceChange24h", 0),
                                "price_change_7d": price_data.get("priceChange7d", 0),
                                "volume_24h": price_data.get("volume24h", 0),
                                "liquidity": price_data.get("liquidity", 0),
                                "fdv": price_data.get("fdv", 0),
                            }
        except Exception as e:
            logger.warning(f"Error fetching price from Birdeye: {e}")
    
    # Fallback to a simpler response if we can't get real data
    return {
        "price": 0,
        "price_change_24h": 0,
        "price_change_7d": 0,
        "volume_24h": 0,
        "liquidity": 0,
        "fdv": 0,
    }

async def analyze_token_with_ai(token_address, metadata, price_data):
    """Analyze token using OpenAI GPT."""
    logger.info(f"Performing AI analysis for {token_address}")
    
    try:
        token_name = metadata.get("name", "Unknown Token")
        token_symbol = metadata.get("symbol", "UNKNOWN")
        token_supply = metadata.get("supply", 0)
        
        price = price_data.get("price", 0)
        price_change_24h = price_data.get("price_change_24h", 0)
        volume_24h = price_data.get("volume_24h", 0)
        liquidity = price_data.get("liquidity", 0)
        
        # Prepare prompt for GPT
        prompt = f"""
        Analyze this Solana token and provide a detailed risk assessment:
        
        Token Address: {token_address}
        Name: {token_name}
        Symbol: {token_symbol}
        Total Supply: {token_supply}
        
        Current Price: ${price}
        24h Price Change: {price_change_24h}%
        24h Volume: ${volume_24h}
        Liquidity: ${liquidity}
        
        Please provide:
        1. Risk assessment (low, medium, or high risk)
        2. Key concerns or red flags if any
        3. Trading recommendation
        4. Potential for short-term gains
        5. Interesting features or use case of this token
        
        Format your response as a structured analysis that a trader can easily understand.
        """
        
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a cryptocurrency token analyzer and risk assessment expert specializing in Solana tokens."},
                {"role": "user", "content": prompt}
            ]
        )
        
        analysis = response.choices[0].message.content
        
        # Second pass to add social sentiment analysis
        social_prompt = f"""
        Based on the token {token_name} ({token_symbol}) with address {token_address}:
        
        1. What is the likely social media sentiment around this token?
        2. Is this token trending or gaining attention?
        3. What kind of communities might be interested in this token?
        4. Is this a meme token or does it have a serious use case?
        
        Answer briefly and accurately based on your knowledge as a crypto expert.
        """
        
        social_response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a cryptocurrency social media analyst who understands token trends and community sentiment."},
                {"role": "user", "content": social_prompt}
            ]
        )
        
        social_analysis = social_response.choices[0].message.content
        
        return {
            "technical_analysis": analysis,
            "social_sentiment": social_analysis,
            "analysis_time": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error during AI analysis: {e}")
        return {
            "technical_analysis": "AI analysis failed. Please try again later.",
            "social_sentiment": "Unable to analyze social sentiment.",
            "analysis_time": datetime.now().isoformat(),
            "error": str(e)
        }

async def get_token_analysis(token_address):
    """Complete token analysis function that combines all data sources."""
    logger.info(f"Starting comprehensive analysis for {token_address}")
    
    # Get token metadata
    metadata = await get_token_metadata(token_address)
    
    # Get price and liquidity data
    price_data = await get_token_price_and_liquidity(token_address)
    
    # Perform AI analysis
    ai_analysis = await analyze_token_with_ai(token_address, metadata, price_data)
    
    # Combine all data
    analysis = {
        "token_address": token_address,
        "metadata": metadata,
        "market_data": price_data,
        "ai_analysis": ai_analysis,
        "timestamp": datetime.now().isoformat()
    }
    
    return analysis

# Helper to execute code asynchronously from synchronous code
def run_async(coroutine):
    """Run an async function from synchronous code."""
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coroutine)

# Synchronous wrapper for the main analysis function
def analyze_token(token_address):
    """Synchronous wrapper for token analysis."""
    return run_async(get_token_analysis(token_address))

# Function to analyze token social sentiment only (for use in Telegram bot)
def analyze_token_social(token_address):
    """Get just the social sentiment analysis for a token."""
    analysis = analyze_token(token_address)
    return analysis.get("ai_analysis", {}).get("social_sentiment", "No analysis available")

# Test function 
async def test_analyzer():
    """Test the token analyzer functionality."""
    # USDC on Solana
    usdc_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    
    logger.info(f"Testing token analyzer with USDC ({usdc_address})")
    analysis = await get_token_analysis(usdc_address)
    
    # Print a summary
    print("\n" + "="*50)
    print(f"Token: {analysis['metadata'].get('name')} ({analysis['metadata'].get('symbol')})")
    print(f"Price: ${analysis['market_data'].get('price')}")
    print(f"24h Change: {analysis['market_data'].get('price_change_24h')}%")
    print("-"*50)
    print("AI Analysis Summary:")
    print(analysis['ai_analysis'].get('technical_analysis')[:200] + "...")
    print("="*50 + "\n")
    
    return True