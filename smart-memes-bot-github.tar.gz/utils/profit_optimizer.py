"""
Advanced profit optimization module for SMART MEMES BOT.

This module implements sophisticated trading optimization algorithms including
Kelly Criterion, Sharpe Ratio, and drawdown analysis to maximize returns while
managing risk.
"""

import logging
import os
import json
import time
import math
from typing import Dict, List, Any, Optional, Tuple
import asyncio
from datetime import datetime, timedelta

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    logging.warning("NumPy not available. Advanced optimization functions will be limited.")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
DEFAULT_RISK_FREE_RATE = 0.02  # 2% annual risk-free rate
MIN_DATA_POINTS = 5  # Minimum number of data points for calculations
MAX_HISTORY_SIZE = 1000  # Maximum number of trades to store in history
HISTORY_FILE = "data/trade_history.json"

# Global state
_running = False
_task = None
_last_optimization_time = 0
_last_performance_calculation_time = 0
_optimization_interval = 86400  # 24 hours
_calculation_interval = 3600  # 1 hour

# Performance metrics
_performance_metrics = {
    "sharpe_ratio": 0.0,
    "max_drawdown": 0.0,
    "profit_factor": 1.0,
    "expectancy": 0.0,
    "kelly_criterion": 0.0,
    "win_rate": 0.0,
    "average_win": 0.0,
    "average_loss": 0.0,
    "risk_reward_ratio": 0.0,
    "daily_returns": [],
    "volatility": 0.0,
    "calmar_ratio": 0.0,
    "max_consecutive_losses": 0,
    "last_updated": 0
}

# Strategy optimized parameters
_optimized_parameters = {
    "strategy_weights": {},
    "max_position_size": 0.1,  # Default to 10% of capital per position
    "max_leverage": 1.0,  # Default to no leverage
    "stop_loss_percentage": 0.1,  # Default to 10% stop loss
    "take_profit_percentage": 0.3,  # Default to 30% take profit
    "risk_per_trade": 0.02,  # Default to 2% risk per trade
    "max_correlated_positions": 3,  # Maximum number of correlated positions
    "last_updated": 0
}

# Trade history
_trade_history = []

# Ensure data directory exists
os.makedirs("data", exist_ok=True)

# Load trade history from file if it exists
def _load_trade_history():
    global _trade_history
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                _trade_history = json.load(f)
                logger.info(f"Loaded {len(_trade_history)} trades from history file")
    except Exception as e:
        logger.error(f"Error loading trade history: {e}")
        _trade_history = []

# Save trade history to file
def _save_trade_history():
    try:
        # Ensure we don't exceed maximum history size
        global _trade_history
        if len(_trade_history) > MAX_HISTORY_SIZE:
            _trade_history = _trade_history[-MAX_HISTORY_SIZE:]
            
        with open(HISTORY_FILE, "w") as f:
            json.dump(_trade_history, f, indent=2)
            logger.info(f"Saved {len(_trade_history)} trades to history file")
    except Exception as e:
        logger.error(f"Error saving trade history: {e}")

# Record a new trade
def record_trade(trade_data: Dict[str, Any]) -> None:
    """
    Record a new trade in the history.
    
    Args:
        trade_data: Dictionary containing trade details
    """
    try:
        # Ensure required fields are present
        required_fields = ["timestamp", "profit_percentage", "direction", "token", "amount"]
        for field in required_fields:
            if field not in trade_data:
                logger.warning(f"Trade data missing required field: {field}")
                trade_data[field] = None
        
        # Add the trade to the history
        _trade_history.append(trade_data)
        
        # Save the updated history
        _save_trade_history()
        
        # If we're running, trigger an update of performance metrics
        if _running:
            _calculate_performance_metrics()
            
        logger.info(f"Recorded new trade: {trade_data['profit_percentage']}% profit")
        
    except Exception as e:
        logger.error(f"Error recording trade: {e}")

# Calculate Kelly Criterion
def _calculate_kelly_criterion(win_rate: float, avg_win: float, avg_loss: float) -> float:
    """
    Calculate the optimal position size using the Kelly Criterion.
    
    Args:
        win_rate: Probability of winning (0.0 to 1.0)
        avg_win: Average gain on winning trades (as a percentage)
        avg_loss: Average loss on losing trades (as a percentage)
        
    Returns:
        Recommended position size as a fraction of capital (0.0 to 1.0)
    """
    try:
        # Ensure we don't divide by zero
        if avg_loss == 0 or win_rate == 0:
            return 0.0
        
        # Convert percentage gains/losses to decimals
        win_decimal = avg_win / 100
        loss_decimal = abs(avg_loss) / 100
        
        # Kelly formula: f* = (p * b - q) / b
        # where p = probability of win, q = probability of loss (1-p),
        # b = net odds received on the wager
        
        b = win_decimal / loss_decimal
        kelly = (win_rate * b - (1 - win_rate)) / b
        
        # Limit to reasonable values and return
        return max(0.0, min(0.5, kelly))  # Cap at 50% to be conservative
        
    except Exception as e:
        logger.error(f"Error calculating Kelly Criterion: {e}")
        return 0.02  # Default to 2% if calculation fails

# Calculate Sharpe Ratio
def _calculate_sharpe_ratio(returns: List[float], risk_free_rate: float = DEFAULT_RISK_FREE_RATE) -> float:
    """
    Calculate the Sharpe Ratio for a series of returns.
    
    Args:
        returns: List of period returns (as percentages)
        risk_free_rate: Annual risk-free rate (as a decimal)
        
    Returns:
        Sharpe Ratio
    """
    try:
        if not returns or len(returns) < MIN_DATA_POINTS:
            logger.warning("Not enough data points to calculate Sharpe Ratio")
            return 0.0
            
        if NUMPY_AVAILABLE:
            returns_array = np.array(returns) / 100  # Convert percentage to decimal
            
            # Annualize based on daily returns
            excess_returns = returns_array - (risk_free_rate / 365)
            std_dev = np.std(returns_array)
            
            if std_dev == 0:
                return 0.0
                
            # Annualize Sharpe Ratio
            sharpe = (np.mean(excess_returns) / std_dev) * math.sqrt(365)
            return sharpe
        else:
            # Simplified calculation without NumPy
            returns_decimal = [r / 100 for r in returns]  # Convert percentage to decimal
            
            # Calculate mean and standard deviation
            mean_return = sum(returns_decimal) / len(returns_decimal)
            variance = sum((r - mean_return) ** 2 for r in returns_decimal) / len(returns_decimal)
            std_dev = math.sqrt(variance)
            
            if std_dev == 0:
                return 0.0
                
            # Calculate excess returns over risk-free rate
            excess_return = mean_return - (risk_free_rate / 365)
            
            # Annualize Sharpe Ratio
            sharpe = (excess_return / std_dev) * math.sqrt(365)
            return sharpe
                
    except Exception as e:
        logger.error(f"Error calculating Sharpe Ratio: {e}")
        return 0.0

# Calculate Maximum Drawdown
def _calculate_max_drawdown(returns: List[float]) -> float:
    """
    Calculate the maximum drawdown from a series of returns.
    
    Args:
        returns: List of period returns (as percentages)
        
    Returns:
        Maximum drawdown as a percentage
    """
    try:
        if not returns or len(returns) < MIN_DATA_POINTS:
            logger.warning("Not enough data points to calculate Maximum Drawdown")
            return 0.0
            
        # Convert returns to a cumulative equity curve
        equity_curve = [1.0]
        for r in returns:
            equity_curve.append(equity_curve[-1] * (1 + r / 100))
            
        # Calculate running maximum and drawdowns
        running_max = equity_curve[0]
        drawdowns = [0.0]
        
        for equity in equity_curve[1:]:
            running_max = max(running_max, equity)
            drawdown = (running_max - equity) / running_max * 100  # Convert to percentage
            drawdowns.append(drawdown)
            
        return max(drawdowns)
                
    except Exception as e:
        logger.error(f"Error calculating Maximum Drawdown: {e}")
        return 0.0

# Calculate Profit Factor
def _calculate_profit_factor(trades: List[Dict[str, Any]]) -> float:
    """
    Calculate the profit factor (gross profit / gross loss).
    
    Args:
        trades: List of trade dictionaries
        
    Returns:
        Profit factor
    """
    try:
        if not trades or len(trades) < MIN_DATA_POINTS:
            logger.warning("Not enough data points to calculate Profit Factor")
            return 1.0
            
        gross_profit = 0.0
        gross_loss = 0.0
        
        for trade in trades:
            profit = trade.get("profit_percentage", 0)
            if profit > 0:
                gross_profit += profit
            else:
                gross_loss += abs(profit)
                
        if gross_loss == 0:
            return 10.0  # Cap at 10.0 if no losses
            
        return gross_profit / gross_loss
                
    except Exception as e:
        logger.error(f"Error calculating Profit Factor: {e}")
        return 1.0

# Calculate Trade Expectancy
def _calculate_expectancy(win_rate: float, avg_win: float, avg_loss: float) -> float:
    """
    Calculate trade expectancy (expected value per trade).
    
    Args:
        win_rate: Probability of winning (0.0 to 1.0)
        avg_win: Average gain on winning trades (as a percentage)
        avg_loss: Average loss on losing trades (as a percentage)
        
    Returns:
        Expectancy as a percentage
    """
    try:
        # Formula: (Win Rate * Avg Win) - (Loss Rate * Avg Loss)
        loss_rate = 1.0 - win_rate
        expectancy = (win_rate * avg_win) - (loss_rate * abs(avg_loss))
        return expectancy
                
    except Exception as e:
        logger.error(f"Error calculating Expectancy: {e}")
        return 0.0

# Calculate performance metrics from trade history
def _calculate_performance_metrics() -> None:
    """Update all performance metrics based on current trade history."""
    global _performance_metrics, _last_performance_calculation_time
    
    try:
        # Skip if we don't have enough trades
        if len(_trade_history) < MIN_DATA_POINTS:
            logger.warning("Not enough trades to calculate performance metrics")
            return
            
        # Extract profits/losses
        profits = [trade.get("profit_percentage", 0) for trade in _trade_history]
        
        # Calculate win rate
        wins = [p for p in profits if p > 0]
        losses = [p for p in profits if p <= 0]
        win_rate = len(wins) / len(profits) if profits else 0
        
        # Calculate average win and loss
        avg_win = sum(wins) / len(wins) if wins else 0
        avg_loss = sum(losses) / len(losses) if losses else 0
        
        # Calculate daily returns (group by day)
        daily_returns = []
        
        if NUMPY_AVAILABLE:
            # Group trades by day and calculate daily returns
            trade_dates = {}
            for trade in _trade_history:
                date_str = datetime.fromtimestamp(trade.get("timestamp", 0)).strftime("%Y-%m-%d")
                if date_str not in trade_dates:
                    trade_dates[date_str] = []
                trade_dates[date_str].append(trade.get("profit_percentage", 0))
                
            # Calculate daily returns
            for date, day_profits in trade_dates.items():
                daily_return = sum(day_profits)
                daily_returns.append(daily_return)
        else:
            # Simplified approach without NumPy
            daily_returns = profits  # Use individual trade returns as proxy
        
        # Calculate maximum consecutive losses
        consecutive_losses = 0
        max_consecutive_losses = 0
        for profit in profits:
            if profit <= 0:
                consecutive_losses += 1
                max_consecutive_losses = max(max_consecutive_losses, consecutive_losses)
            else:
                consecutive_losses = 0
        
        # Calculate risk-reward ratio
        risk_reward_ratio = abs(avg_win / avg_loss) if avg_loss != 0 else 0
        
        # Calculate volatility
        volatility = math.sqrt(sum((r - sum(daily_returns)/len(daily_returns))**2 for r in daily_returns) / len(daily_returns)) if daily_returns else 0
        
        # Calculate Calmar ratio (annualized return / max drawdown)
        max_drawdown = _calculate_max_drawdown(daily_returns)
        avg_daily_return = sum(daily_returns) / len(daily_returns) if daily_returns else 0
        annualized_return = ((1 + avg_daily_return/100) ** 365 - 1) * 100  # Convert to percentage
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
        
        # Update metrics
        _performance_metrics = {
            "sharpe_ratio": _calculate_sharpe_ratio(daily_returns),
            "max_drawdown": max_drawdown,
            "profit_factor": _calculate_profit_factor(_trade_history),
            "expectancy": _calculate_expectancy(win_rate, avg_win, abs(avg_loss)),
            "kelly_criterion": _calculate_kelly_criterion(win_rate, avg_win, abs(avg_loss)),
            "win_rate": win_rate * 100,  # Convert to percentage
            "average_win": avg_win,
            "average_loss": abs(avg_loss),
            "risk_reward_ratio": risk_reward_ratio,
            "daily_returns": daily_returns[-30:],  # Keep only last 30 days
            "volatility": volatility,
            "calmar_ratio": calmar_ratio,
            "max_consecutive_losses": max_consecutive_losses,
            "last_updated": time.time()
        }
        
        _last_performance_calculation_time = time.time()
        
        logger.info(f"Performance metrics updated - Sharpe: {_performance_metrics['sharpe_ratio']:.2f}, "
                  f"Kelly: {_performance_metrics['kelly_criterion']:.2f}, "
                  f"Max DD: {_performance_metrics['max_drawdown']:.2f}%")
                
    except Exception as e:
        logger.error(f"Error calculating performance metrics: {e}")

# Optimize trading parameters based on performance metrics
def _optimize_parameters() -> None:
    """Update optimized parameters based on current performance metrics."""
    global _optimized_parameters, _last_optimization_time
    
    try:
        # Skip if we don't have updated performance metrics
        if _performance_metrics["last_updated"] == 0:
            logger.warning("No performance metrics available for optimization")
            return
            
        # Extract key metrics
        kelly = _performance_metrics["kelly_criterion"]
        sharpe = _performance_metrics["sharpe_ratio"]
        max_drawdown = _performance_metrics["max_drawdown"]
        profit_factor = _performance_metrics["profit_factor"]
        win_rate = _performance_metrics["win_rate"] / 100  # Convert to decimal
        
        # Optimize position size based on Kelly Criterion
        # Use a fraction of Kelly (half-Kelly) for safety
        half_kelly = kelly / 2
        max_position_size = max(0.01, min(0.25, half_kelly))  # Between 1% and 25%
        
        # Optimize stop loss based on average loss and drawdown
        avg_loss = _performance_metrics["average_loss"]
        
        # More robust stop loss if we have high drawdowns or poor win rate
        if max_drawdown > 20 or win_rate < 0.4:
            stop_loss_factor = 0.8  # Tighter stops
        else:
            stop_loss_factor = 1.0
            
        stop_loss_percentage = min(0.25, max(0.05, avg_loss * stop_loss_factor / 100))  # Between 5% and 25%
        
        # Optimize take profit based on risk-reward ratio
        risk_reward = _performance_metrics["risk_reward_ratio"]
        take_profit_percentage = max(0.1, min(0.5, stop_loss_percentage * max(1.5, risk_reward)))  # At least 1.5R
        
        # Optimize strategy weights based on performance
        # This would typically come from the Ultimate Trading Engine
        # Here we'll just use some dummy values
        strategy_weights = {
            "ml_trader": 0.3,
            "arbitrage": 0.25,
            "whale_following": 0.2,
            "flash_loan": 0.15,
            "market_prediction": 0.1
        }
        
        # Determine max leverage based on Sharpe ratio and profit factor
        # Higher Sharpe and profit factor allow for more leverage
        if sharpe > 2.0 and profit_factor > 2.0:
            max_leverage = 2.0
        elif sharpe > 1.0 and profit_factor > 1.5:
            max_leverage = 1.5
        else:
            max_leverage = 1.0
            
        # Calculate optimal risk per trade based on win rate and expectancy
        expectancy = _performance_metrics["expectancy"]
        
        if expectancy > 1.0 and win_rate > 0.5:
            risk_per_trade = max(0.01, min(0.03, half_kelly))  # Between 1% and 3%
        else:
            risk_per_trade = max(0.005, min(0.02, half_kelly / 2))  # Between 0.5% and 2%
            
        # Determine maximum number of correlated positions
        # If we're doing well, we can take on more correlated risk
        if profit_factor > 2.5 and max_drawdown < 15:
            max_correlated_positions = 5
        elif profit_factor > 1.5 and max_drawdown < 25:
            max_correlated_positions = 3
        else:
            max_correlated_positions = 2
            
        # Update optimized parameters
        _optimized_parameters = {
            "strategy_weights": strategy_weights,
            "max_position_size": max_position_size,
            "max_leverage": max_leverage,
            "stop_loss_percentage": stop_loss_percentage,
            "take_profit_percentage": take_profit_percentage,
            "risk_per_trade": risk_per_trade,
            "max_correlated_positions": max_correlated_positions,
            "last_updated": time.time()
        }
        
        _last_optimization_time = time.time()
        
        logger.info(f"Trading parameters optimized - Position size: {max_position_size:.2%}, "
                  f"SL: {stop_loss_percentage:.2%}, TP: {take_profit_percentage:.2%}, "
                  f"Risk/trade: {risk_per_trade:.2%}")
                
    except Exception as e:
        logger.error(f"Error optimizing parameters: {e}")

# Background task to periodically update metrics and parameters
async def _maintenance_task():
    """Background task to update metrics and parameters periodically."""
    try:
        while _running:
            current_time = time.time()
            
            # Update performance metrics if needed
            if current_time - _last_performance_calculation_time > _calculation_interval:
                _calculate_performance_metrics()
                
            # Optimize parameters if needed
            if current_time - _last_optimization_time > _optimization_interval:
                _optimize_parameters()
                
            # Sleep before next iteration
            await asyncio.sleep(60)  # Check every minute
            
    except asyncio.CancelledError:
        logger.info("Profit optimizer maintenance task cancelled")
        
    except Exception as e:
        logger.error(f"Error in profit optimizer maintenance task: {e}")
        global _running
        _running = False

# Get current performance metrics
def get_performance_metrics() -> Dict[str, Any]:
    """
    Get the current performance metrics.
    
    Returns:
        Dictionary of performance metrics
    """
    # Update metrics if they're stale
    if time.time() - _last_performance_calculation_time > _calculation_interval:
        _calculate_performance_metrics()
        
    return _performance_metrics

# Get optimized parameters
def get_optimized_parameters() -> Dict[str, Any]:
    """
    Get the current optimized parameters.
    
    Returns:
        Dictionary of optimized parameters
    """
    # Update parameters if they're stale
    if time.time() - _last_optimization_time > _optimization_interval:
        _optimize_parameters()
        
    return _optimized_parameters

# Start the profit optimizer
async def start_profit_optimizer():
    """Start the profit optimizer background task."""
    global _running, _task
    
    if _running:
        logger.warning("Profit optimizer is already running")
        return
        
    # Load trade history
    _load_trade_history()
    
    # Calculate initial metrics and parameters
    _calculate_performance_metrics()
    _optimize_parameters()
    
    # Start the background task
    _running = True
    _task = asyncio.create_task(_maintenance_task())
    
    logger.info("Profit optimizer started")

# Stop the profit optimizer
async def stop_profit_optimizer():
    """Stop the profit optimizer background task."""
    global _running, _task
    
    if not _running:
        logger.warning("Profit optimizer is not running")
        return
        
    # Stop the background task
    _running = False
    
    if _task:
        _task.cancel()
        try:
            await _task
        except asyncio.CancelledError:
            pass
        finally:
            _task = None
    
    # Save trade history
    _save_trade_history()
    
    logger.info("Profit optimizer stopped")