"""
Enhanced Wallet Tracker for SMART MEMES BOT.

This module provides advanced wallet tracking capabilities with enhanced 
sniping, filtering, and risk management based on wallet activity. It monitors
known successful wallets and their trading patterns to identify high-potential
tokens early.
"""

import os
import time
import asyncio
import logging
import json
from typing import Dict, List, Set, Optional, Union, Any
from datetime import datetime, timedelta

# Import our advanced systems
try:
    from utils.enhanced_token_safety import analyze_token_safety
    ENHANCED_SAFETY_AVAILABLE = True
except ImportError:
    ENHANCED_SAFETY_AVAILABLE = False
    logging.warning("Enhanced token safety not available for wallet tracker")

try:
    from utils.unified_trading_api import execute_trade, smart_trade
    UNIFIED_API_AVAILABLE = True
except ImportError:
    UNIFIED_API_AVAILABLE = False
    logging.warning("Unified trading API not available for wallet tracker")

try:
    from utils.enhanced_smart_sniper import smart_snipe
    ENHANCED_SNIPER_AVAILABLE = True
except ImportError:
    ENHANCED_SNIPER_AVAILABLE = False
    logging.warning("Enhanced smart sniper not available for wallet tracker")

# Legacy imports for fallback
try:
    from utils.token_info import check_token_safety
    LEGACY_SAFETY_AVAILABLE = True
except ImportError:
    LEGACY_SAFETY_AVAILABLE = False

try:
    from utils.trading import execute_buy
    LEGACY_TRADING_AVAILABLE = True
except ImportError:
    LEGACY_TRADING_AVAILABLE = False

try:
    from utils.profit_logger import log_sniped_token
    LEGACY_LOGGER_AVAILABLE = True
except ImportError:
    LEGACY_LOGGER_AVAILABLE = False

try:
    from utils.group_scoring import get_group_score
    LEGACY_SCORING_AVAILABLE = True
except ImportError:
    LEGACY_SCORING_AVAILABLE = False

# Configure logging
logger = logging.getLogger(__name__)

# Default settings
DEFAULT_SETTINGS = {
    "wallet_check_interval": 60,     # Seconds between wallet checks
    "min_wallet_score": 85,          # Minimum trusted wallet score (0-100)
    "min_token_safety": 80,          # Minimum token safety score (0-100)
    "max_daily_snipes": 10,          # Maximum daily snipes from wallets
    "position_size_multiplier": 1.0,  # Position size multiplier
    "risk_profile": "balanced",      # Risk profile
    "auto_trade": True,              # Auto-trade on wallet activity
    "trusted_wallets_only": True,    # Only snipe from trusted wallets
    "max_token_age": 48,             # Maximum token age in hours to consider
    "auto_discovery": True,          # Auto-discover new trusted wallets
    "preferred_chains": ["solana"]   # Preferred chains
}

# Default trusted wallets list
DEFAULT_TRUSTED_WALLETS = {
    "ExampleLegendWallet1": {
        "score": 90,
        "description": "Successful early trader",
        "success_ratio": 0.85,  # 85% successful trades
        "avg_profit_multiple": 8.5,  # 8.5x average profit
        "verified": True,
        "last_updated": time.time(),
        "chains": ["solana"],
        "preferred_tokens": ["meme", "defi", "gaming"],
        "position_sizes": {
            "min": 0.5,  # SOL
            "max": 5.0,  # SOL
            "avg": 1.5   # SOL
        },
        "stats": {
            "total_trades": 120,
            "successful_trades": 102,
            "total_profit": 850.5  # SOL
        }
    },
    "ExampleLegendWallet2": {
        "score": 88,
        "description": "Meme token specialist",
        "success_ratio": 0.78,  # 78% successful trades
        "avg_profit_multiple": 12.0,  # 12x average profit
        "verified": True,
        "last_updated": time.time(),
        "chains": ["solana"],
        "preferred_tokens": ["meme", "lowcap"],
        "position_sizes": {
            "min": 0.3,  # SOL
            "max": 3.0,  # SOL
            "avg": 1.2   # SOL
        },
        "stats": {
            "total_trades": 95,
            "successful_trades": 74,
            "total_profit": 720.0  # SOL
        }
    }
}

class EnhancedWalletTracker:
    """
    Enhanced Wallet Tracker with advanced sniping capabilities.
    """
    
    def __init__(self, settings: Optional[Dict[str, Any]] = None):
        """
        Initialize the Enhanced Wallet Tracker.
        
        Args:
            settings: Optional custom settings
        """
        self.settings = DEFAULT_SETTINGS.copy()
        if settings:
            self.settings.update(settings)
        
        # Load trusted wallets
        self.trusted_wallets = self._load_trusted_wallets()
        
        # Initialize tracking data
        self.recently_sniped = set()
        self.daily_snipes = 0
        self.last_reset_time = time.time()
        self.wallet_activity_history = {}
        self.running = False
        self.monitoring_task = None
        
        logger.info(f"Enhanced Wallet Tracker initialized with {len(self.trusted_wallets)} trusted wallets")
    
    def _load_trusted_wallets(self) -> Dict[str, Dict[str, Any]]:
        """
        Load trusted wallets from storage or defaults.
        
        Returns:
            Dictionary of trusted wallets
        """
        trusted_wallets_file = "data/config/trusted_wallets.json"
        
        try:
            if os.path.exists(trusted_wallets_file):
                with open(trusted_wallets_file, 'r') as f:
                    wallets = json.load(f)
                logger.info(f"Loaded {len(wallets)} trusted wallets from storage")
                return wallets
            else:
                # Use defaults and create file
                os.makedirs(os.path.dirname(trusted_wallets_file), exist_ok=True)
                with open(trusted_wallets_file, 'w') as f:
                    json.dump(DEFAULT_TRUSTED_WALLETS, f, indent=2)
                logger.info(f"Created default trusted wallets file with {len(DEFAULT_TRUSTED_WALLETS)} wallets")
                return DEFAULT_TRUSTED_WALLETS.copy()
        except Exception as e:
            logger.error(f"Error loading trusted wallets: {str(e)}")
            return DEFAULT_TRUSTED_WALLETS.copy()
    
    def _save_trusted_wallets(self):
        """Save trusted wallets to storage."""
        trusted_wallets_file = "data/config/trusted_wallets.json"
        
        try:
            os.makedirs(os.path.dirname(trusted_wallets_file), exist_ok=True)
            with open(trusted_wallets_file, 'w') as f:
                json.dump(self.trusted_wallets, f, indent=2)
            logger.info(f"Saved {len(self.trusted_wallets)} trusted wallets to storage")
        except Exception as e:
            logger.error(f"Error saving trusted wallets: {str(e)}")
    
    async def start_monitoring(self):
        """Start monitoring wallet activity."""
        if self.running:
            logger.warning("Wallet tracker already running")
            return
        
        self.running = True
        logger.info("Starting Enhanced Wallet Tracker")
        
        # Start the background monitoring task
        self.monitoring_task = asyncio.create_task(self._monitor_wallets())
    
    async def stop_monitoring(self):
        """Stop monitoring wallet activity."""
        if not self.running:
            logger.warning("Wallet tracker not running")
            return
        
        self.running = False
        logger.info("Stopping Enhanced Wallet Tracker")
        
        # Cancel the monitoring task
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
    
    async def _monitor_wallets(self):
        """Background task to monitor wallet activity."""
        try:
            while self.running:
                # Check if we need to reset daily snipes
                current_time = time.time()
                if current_time - self.last_reset_time > 86400:  # 24 hours
                    self.daily_snipes = 0
                    self.last_reset_time = current_time
                    logger.info("Reset daily wallet snipe counter")
                
                # In a real implementation, this would query blockchain APIs
                # For now, just simulate periodic checks
                logger.debug(f"Monitoring {len(self.trusted_wallets)} trusted wallets")
                
                # Wait before next check
                await asyncio.sleep(self.settings["wallet_check_interval"])
                
        except asyncio.CancelledError:
            logger.info("Wallet monitoring cancelled")
            raise
        
        except Exception as e:
            logger.error(f"Unexpected error in wallet monitoring: {str(e)}")
            raise
    
    async def handle_wallet_activity(self, wallet_address: str, token_address: str, 
                                   token_symbol: Optional[str] = None,
                                   transaction_type: str = "buy",
                                   amount: Optional[float] = None,
                                   group_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Handle detected wallet activity and decide whether to snipe.
        
        Args:
            wallet_address: Address of the wallet
            token_address: Address of the token
            token_symbol: Optional token symbol
            transaction_type: Type of transaction detected (buy, sell, etc.)
            amount: Optional amount of the transaction
            group_id: Optional group ID where activity was detected
            
        Returns:
            Result of handling the activity
        """
        logger.info(f"Processing wallet activity: {wallet_address} {transaction_type} {token_symbol or token_address}")
        
        # Skip if already sniped recently
        if token_address in self.recently_sniped:
            logger.info(f"Skipping {token_symbol or token_address}, already sniped recently")
            return {
                "success": False,
                "reason": "already_sniped",
                "token_address": token_address
            }
        
        # Skip if daily limit reached
        if self.daily_snipes >= self.settings["max_daily_snipes"]:
            logger.info(f"Skipping {token_symbol or token_address}, daily snipe limit reached")
            return {
                "success": False,
                "reason": "daily_limit_reached",
                "token_address": token_address
            }
        
        # Check if this is a trusted wallet
        wallet_data = self.trusted_wallets.get(wallet_address)
        if self.settings["trusted_wallets_only"] and not wallet_data:
            logger.info(f"Skipping {token_symbol or token_address}, wallet not trusted: {wallet_address}")
            return {
                "success": False,
                "reason": "untrusted_wallet",
                "token_address": token_address
            }
        
        # Get wallet score
        wallet_score = wallet_data["score"] if wallet_data else 0
        if wallet_score < self.settings["min_wallet_score"]:
            logger.info(f"Skipping {token_symbol or token_address}, wallet score too low: {wallet_score}")
            return {
                "success": False,
                "reason": "low_wallet_score",
                "token_address": token_address,
                "wallet_score": wallet_score
            }
        
        # Check token safety
        token_safe = False
        safety_score = 0
        safety_details = {}
        
        if ENHANCED_SAFETY_AVAILABLE:
            try:
                safety_score, safety_details = await analyze_token_safety(token_address)
                token_safe = safety_score >= self.settings["min_token_safety"] / 100  # Convert to 0-1 scale
            except Exception as e:
                logger.error(f"Error checking token safety: {str(e)}")
                # Fall back to legacy safety check
                token_safe = await self._legacy_safety_check(token_address)
        else:
            # Use legacy safety check
            token_safe = await self._legacy_safety_check(token_address)
        
        if not token_safe:
            logger.info(f"Skipping {token_symbol or token_address}, token safety check failed")
            return {
                "success": False,
                "reason": "failed_safety_check",
                "token_address": token_address,
                "safety_score": safety_score
            }
        
        # Get group score if available
        group_score = 0
        if group_id is not None:
            if LEGACY_SCORING_AVAILABLE:
                try:
                    group_score = await get_group_score(group_id)
                except Exception as e:
                    logger.error(f"Error getting group score: {str(e)}")
        
        # Calculate position size based on wallet's average position and our settings
        position_size = 1.0  # Default position size
        if wallet_data and "position_sizes" in wallet_data:
            position_size = wallet_data["position_sizes"].get("avg", 1.0)
        
        # Apply position size multiplier from settings
        position_size *= self.settings["position_size_multiplier"]
        
        # Execute the trade using the most advanced available system
        result = None
        
        if self.settings["auto_trade"]:
            if UNIFIED_API_AVAILABLE:
                try:
                    # Use smart trade for full analysis and execution
                    result = await smart_trade(
                        token_address=token_address,
                        token_symbol=token_symbol,
                        group_score=group_score,
                        wallet_score=wallet_score / 100,  # Convert to 0-1 scale
                        message_text=f"Token bought by trusted wallet {wallet_address}"
                    )
                except Exception as e:
                    logger.error(f"Error using smart trade: {str(e)}")
                    
                    # Fall back to direct trade execution
                    try:
                        result = await execute_trade(
                            token_address=token_address,
                            side="buy",
                            amount=position_size,
                            token_symbol=token_symbol
                        )
                    except Exception as e2:
                        logger.error(f"Error executing trade: {str(e2)}")
                
            elif ENHANCED_SNIPER_AVAILABLE:
                try:
                    # Use enhanced sniper
                    result = await smart_snipe(
                        token_address=token_address,
                        token_symbol=token_symbol,
                        group_score=group_score,
                        wallet_score=wallet_score / 100,  # Convert to 0-1 scale
                        message_text=f"Token bought by trusted wallet {wallet_address}",
                        risk_profile=self.settings["risk_profile"]
                    )
                except Exception as e:
                    logger.error(f"Error using enhanced sniper: {str(e)}")
            
            elif LEGACY_TRADING_AVAILABLE:
                try:
                    # Legacy execution
                    result = await execute_buy(token_address, position_size)
                except Exception as e:
                    logger.error(f"Error executing legacy buy: {str(e)}")
            
            else:
                logger.warning(f"No trading system available, simulation only")
                # Simulate successful trade for testing
                result = {
                    "success": True,
                    "token_address": token_address,
                    "token_symbol": token_symbol,
                    "amount": position_size,
                    "simulated": True
                }
        else:
            # Auto-trade disabled, just return evaluation
            result = {
                "success": True,
                "token_address": token_address,
                "token_symbol": token_symbol,
                "wallet_score": wallet_score,
                "safety_score": safety_score,
                "recommended_position": position_size,
                "auto_trade_disabled": True
            }
        
        # Log the snipe if successful
        if result and result.get("success", False):
            # Add to recently sniped
            self.recently_sniped.add(token_address)
            self.daily_snipes += 1
            
            # Log the snipe
            if LEGACY_LOGGER_AVAILABLE:
                try:
                    await log_sniped_token(token_address, "wallet", result)
                except Exception as e:
                    logger.error(f"Error logging sniped token: {str(e)}")
            
            logger.info(f"Successfully sniped {token_symbol or token_address} based on wallet activity")
        
        # Record wallet activity for potential auto-discovery
        self._record_wallet_activity(wallet_address, token_address, transaction_type, result)
        
        return {
            "success": result.get("success", False) if result else False,
            "token_address": token_address,
            "token_symbol": token_symbol,
            "wallet_address": wallet_address,
            "position_size": position_size if result and result.get("success", False) else 0,
            "result": result
        }
    
    async def _legacy_safety_check(self, token_address: str) -> bool:
        """
        Perform legacy token safety check.
        
        Args:
            token_address: Token address
            
        Returns:
            True if token is safe, False otherwise
        """
        if LEGACY_SAFETY_AVAILABLE:
            try:
                safety_score = await check_token_safety(token_address)
                return safety_score >= self.settings["min_token_safety"]
            except Exception as e:
                logger.error(f"Error in legacy safety check: {str(e)}")
                return False
        else:
            logger.warning("No safety check system available, assuming safe for testing")
            return True
    
    def _record_wallet_activity(self, wallet_address: str, token_address: str, 
                             transaction_type: str, result: Optional[Dict[str, Any]]):
        """
        Record wallet activity for analysis and potential auto-discovery.
        
        Args:
            wallet_address: Wallet address
            token_address: Token address
            transaction_type: Transaction type
            result: Transaction result
        """
        if wallet_address not in self.wallet_activity_history:
            self.wallet_activity_history[wallet_address] = []
        
        activity = {
            "token_address": token_address,
            "transaction_type": transaction_type,
            "timestamp": time.time(),
            "success": result.get("success", False) if result else False
        }
        
        self.wallet_activity_history[wallet_address].append(activity)
        
        # Keep only recent history
        self.wallet_activity_history[wallet_address] = self.wallet_activity_history[wallet_address][-100:]
        
        # Check if this wallet should be auto-discovered as trusted
        if self.settings["auto_discovery"] and wallet_address not in self.trusted_wallets:
            self._evaluate_wallet_for_trust(wallet_address)
    
    def _evaluate_wallet_for_trust(self, wallet_address: str):
        """
        Evaluate a wallet for potential inclusion in trusted wallets.
        
        Args:
            wallet_address: Wallet address to evaluate
        """
        if wallet_address not in self.wallet_activity_history:
            return
        
        activities = self.wallet_activity_history[wallet_address]
        
        # Need at least 5 activities to evaluate
        if len(activities) < 5:
            return
        
        # Calculate success ratio
        successful = sum(1 for a in activities if a.get("success", False))
        success_ratio = successful / len(activities)
        
        # If success ratio is high enough, add to trusted wallets
        if success_ratio >= 0.7:  # 70% success rate
            logger.info(f"Auto-discovering trusted wallet: {wallet_address} with {success_ratio:.2f} success ratio")
            
            self.trusted_wallets[wallet_address] = {
                "score": int(success_ratio * 100),
                "description": "Auto-discovered wallet",
                "success_ratio": success_ratio,
                "verified": False,
                "last_updated": time.time(),
                "auto_discovered": True,
                "stats": {
                    "total_activities": len(activities),
                    "successful_activities": successful
                }
            }
            
            # Save updated trusted wallets
            self._save_trusted_wallets()
    
    def add_trusted_wallet(self, wallet_address: str, data: Dict[str, Any]) -> bool:
        """
        Add or update a trusted wallet.
        
        Args:
            wallet_address: Wallet address
            data: Wallet data
            
        Returns:
            True if added/updated successfully, False otherwise
        """
        try:
            self.trusted_wallets[wallet_address] = data
            self._save_trusted_wallets()
            logger.info(f"Added/updated trusted wallet: {wallet_address}")
            return True
        except Exception as e:
            logger.error(f"Error adding trusted wallet: {str(e)}")
            return False
    
    def remove_trusted_wallet(self, wallet_address: str) -> bool:
        """
        Remove a trusted wallet.
        
        Args:
            wallet_address: Wallet address to remove
            
        Returns:
            True if removed successfully, False otherwise
        """
        if wallet_address in self.trusted_wallets:
            del self.trusted_wallets[wallet_address]
            self._save_trusted_wallets()
            logger.info(f"Removed trusted wallet: {wallet_address}")
            return True
        return False
    
    def get_trusted_wallets(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all trusted wallets.
        
        Returns:
            Dictionary of trusted wallets
        """
        return self.trusted_wallets
    
    def get_wallet_activity(self, wallet_address: str) -> List[Dict[str, Any]]:
        """
        Get activity history for a wallet.
        
        Args:
            wallet_address: Wallet address
            
        Returns:
            List of activity records
        """
        return self.wallet_activity_history.get(wallet_address, [])

# Singleton instance
_wallet_tracker = None

async def get_wallet_tracker(settings: Optional[Dict[str, Any]] = None) -> EnhancedWalletTracker:
    """
    Get the Enhanced Wallet Tracker instance.
    
    Args:
        settings: Optional custom settings
        
    Returns:
        EnhancedWalletTracker instance
    """
    global _wallet_tracker
    
    if _wallet_tracker is None:
        _wallet_tracker = EnhancedWalletTracker(settings)
        await _wallet_tracker.start_monitoring()
    elif settings:
        _wallet_tracker.settings.update(settings)
    
    return _wallet_tracker

# Legacy function for backwards compatibility
async def handle_wallet_activity(wallet_address, token_address, group_score=0):
    """
    Legacy handle_wallet_activity function for backwards compatibility.
    
    Args:
        wallet_address: Wallet address
        token_address: Token address
        group_score: Optional group score
        
    Returns:
        True if action taken, False otherwise
    """
    tracker = await get_wallet_tracker()
    
    result = await tracker.handle_wallet_activity(
        wallet_address=wallet_address,
        token_address=token_address,
        group_id=None
    )
    
    return result.get("success", False)

# Example usage
async def test_wallet_tracker():
    """
    Test the wallet tracker functionality.
    """
    logger.info("Testing Enhanced Wallet Tracker")
    
    # Initialize tracker
    tracker = await get_wallet_tracker()
    
    # Test with trusted wallet
    wallet_address = "ExampleLegendWallet1"
    token_address = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    token_symbol = "TESTTOKEN"
    
    result = await tracker.handle_wallet_activity(
        wallet_address=wallet_address,
        token_address=token_address,
        token_symbol=token_symbol,
        transaction_type="buy"
    )
    
    logger.info(f"Wallet activity result: {json.dumps(result, indent=2)}")
    
    # Test with untrusted wallet
    untrusted_wallet = "UnknownWallet123"
    
    result = await tracker.handle_wallet_activity(
        wallet_address=untrusted_wallet,
        token_address=token_address,
        token_symbol=token_symbol,
        transaction_type="buy"
    )
    
    logger.info(f"Untrusted wallet result: {json.dumps(result, indent=2)}")
    
    # Test auto-discovery
    logger.info("Testing wallet auto-discovery")
    
    # Simulate a series of successful activities
    for i in range(6):
        tracker._record_wallet_activity(
            wallet_address=untrusted_wallet,
            token_address=f"TOKEN{i}",
            transaction_type="buy",
            result={"success": True}
        )
    
    # Check if wallet was auto-discovered
    trusted_wallets = tracker.get_trusted_wallets()
    if untrusted_wallet in trusted_wallets:
        logger.info(f"Wallet auto-discovery successful: {json.dumps(trusted_wallets[untrusted_wallet], indent=2)}")
    else:
        logger.info("Wallet not auto-discovered yet")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Run the test function
    asyncio.run(test_wallet_tracker())