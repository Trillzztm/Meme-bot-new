"""
Simple Jupiter Client - No Dependencies Version

This module provides a simplified interface to Jupiter Exchange API that doesn't 
require the Solana SDK or other complex dependencies.

⚠️ REAL MONEY MODE ENABLED ⚠️
This module is set up to execute real money trades.
"""

import os
import json
import time
import base64
import logging
import requests
from typing import Dict, Any, Optional, List, Union

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - SimpleJupiter - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("jupiter_simple.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("SimpleJupiter")

# Constants
JUPITER_API_BASE = "https://quote-api.jup.ag/v6"
SOLANA_RPC_ENDPOINT = "https://api.mainnet-beta.solana.com"
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")

# Hardcode your wallet address here (for security, get it from a trusted source)
# If you don't want to hardcode it, set the WALLET_ADDRESS environment variable
WALLET_ADDRESS = os.environ.get("WALLET_ADDRESS", "GWrigDjL6HsYvK32y5b7ZzwTH8Vw1ZR2miN5jMLrM8f1")

# Token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"  # SOL mint address
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC mint address
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"  # BONK mint address
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"  # WIF mint address
JUP_MINT = "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN"  # JUP mint address

# Token symbol to mint address mapping
TOKEN_MAP = {
    "SOL": SOL_MINT,
    "USDC": USDC_MINT,
    "BONK": BONK_MINT,
    "WIF": WIF_MINT,
    "JUP": JUP_MINT,
}


def get_quote(
    input_mint: str, 
    output_mint: str, 
    amount: int, 
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Get a quote for a Jupiter swap
    
    Args:
        input_mint: Input token mint address (or symbol)
        output_mint: Output token mint address (or symbol)
        amount: Amount in lamports or smallest units of the token
        slippage_bps: Slippage tolerance in basis points (1 bp = 0.01%)
        
    Returns:
        Quote response from Jupiter API
    """
    # Convert symbols to mint addresses if needed
    input_mint = TOKEN_MAP.get(input_mint, input_mint)
    output_mint = TOKEN_MAP.get(output_mint, output_mint)
    
    try:
        logger.info(f"Getting Jupiter quote for {amount} units from {input_mint} to {output_mint}")
        
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": amount,
            "slippageBps": slippage_bps
        }
        
        response = requests.get(f"{JUPITER_API_BASE}/quote", params=params)
        if response.status_code != 200:
            logger.error(f"Jupiter API error ({response.status_code}): {response.text}")
            return {"error": f"Jupiter API error: {response.text}"}
        
        quote_data = response.json()
        logger.info(f"Got Jupiter quote with price impact: {quote_data.get('priceImpactPct')}%")
        return quote_data
    except Exception as e:
        logger.error(f"Error getting Jupiter quote: {e}")
        return {"error": str(e)}


def prepare_transaction(quote_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Prepare a transaction for a Jupiter swap
    
    Args:
        quote_data: Quote data from get_quote method
        
    Returns:
        Transaction data
    """
    if not WALLET_ADDRESS:
        return {"error": "No wallet address available"}
    
    try:
        logger.info("Preparing Jupiter swap transaction")
        
        swap_payload = {
            "quoteResponse": quote_data,
            "userPublicKey": WALLET_ADDRESS,
            "wrapAndUnwrapSol": True  # Auto-wrap SOL for the transaction
        }
        
        response = requests.post(f"{JUPITER_API_BASE}/swap", json=swap_payload)
        if response.status_code != 200:
            logger.error(f"Jupiter swap API error ({response.status_code}): {response.text}")
            return {"error": f"Jupiter swap API error: {response.text}"}
        
        swap_data = response.json()
        
        if "swapTransaction" not in swap_data:
            logger.error("No swapTransaction in response")
            return {"error": "No swapTransaction in response"}
        
        logger.info("Got Jupiter swap transaction data")
        return swap_data
    except Exception as e:
        logger.error(f"Error preparing Jupiter swap transaction: {e}")
        return {"error": str(e)}


def swap_sol_to_token(
    output_token: str, 
    amount_sol: float,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Swap SOL to a token in one function call
    
    Args:
        output_token: Output token mint address or symbol
        amount_sol: Amount of SOL to swap
        slippage_bps: Slippage tolerance in basis points
        
    Returns:
        Transaction result
    """
    # Convert to lamports
    amount_lamports = int(amount_sol * 10**9)
    
    # Convert symbol to mint address if needed
    if output_token in TOKEN_MAP:
        output_mint = TOKEN_MAP[output_token]
    else:
        output_mint = output_token
    
    try:
        # Get quote
        quote = get_quote(SOL_MINT, output_mint, amount_lamports, slippage_bps)
        if "error" in quote:
            return quote
        
        # Prepare transaction
        swap_data = prepare_transaction(quote)
        if "error" in swap_data:
            return swap_data
        
        # Transaction details
        return {
            "success": True,
            "input_token": "SOL",
            "input_amount": amount_sol,
            "output_token": output_token,
            "expected_output_amount": quote.get("outAmount"),
            "price_impact_pct": quote.get("priceImpactPct"),
            "quote": quote,
            "swap_data": swap_data
        }
    except Exception as e:
        logger.error(f"Error in swap_sol_to_token: {e}")
        return {"error": str(e)}


def check_wallet_balance() -> Dict[str, Any]:
    """Get the wallet balance"""
    if not WALLET_ADDRESS:
        return {"error": "No wallet address available"}
    
    try:
        logger.info(f"Getting balance for wallet: {WALLET_ADDRESS}")
        
        # Query Solana RPC
        response = requests.post(
            SOLANA_RPC_ENDPOINT,
            headers={"Content-Type": "application/json"},
            json={
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getBalance",
                "params": [WALLET_ADDRESS]
            }
        )
        
        if response.status_code != 200:
            logger.error(f"RPC error ({response.status_code}): {response.text}")
            return {"error": f"RPC error: {response.text}"}
        
        data = response.json()
        
        if "result" in data:
            balance_lamports = data["result"]["value"]
            balance_sol = balance_lamports / 10**9
            
            logger.info(f"Wallet balance: {balance_sol:.6f} SOL")
            
            return {
                "wallet_address": WALLET_ADDRESS,
                "balance_lamports": balance_lamports,
                "balance_sol": balance_sol,
                "balance_usd": balance_sol * 100  # Estimate SOL price at $100
            }
        else:
            logger.error(f"Failed to get balance: {data}")
            return {"error": f"Failed to get balance: {data}"}
    except Exception as e:
        logger.error(f"Error checking wallet balance: {e}")
        return {"error": str(e)}


# Example usage
if __name__ == "__main__":
    # Check if we have a wallet address
    if not WALLET_ADDRESS:
        print("No wallet address found. Set the WALLET_ADDRESS environment variable.")
        print("Example wallet address: GWrigDjL6HsYvK32y5b7ZzwTH8Vw1ZR2miN5jMLrM8f1")
        exit(1)
    
    # Get wallet balance
    balance = check_wallet_balance()
    print(f"Wallet balance: {json.dumps(balance, indent=2)}")
    
    # Get a quote
    quote = get_quote(SOL_MINT, BONK_MINT, 10000000)  # 0.01 SOL to BONK
    print(f"Quote: {json.dumps(quote, indent=2)}")
    
    # Prepare swap (uncomment to test)
    # swap = swap_sol_to_token("BONK", 0.01)
    # print(f"Swap: {json.dumps(swap, indent=2)}")