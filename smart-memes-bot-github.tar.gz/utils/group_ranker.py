"""
Group ranking module for SMART MEMES BOT.

This module analyzes the performance data of tracked Telegram groups
and provides a ranking system based on profitability and success rate.
"""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Mock database for demonstration
# In a real implementation, this would be replaced with actual database queries
_GROUPS_DB = {
    "group1": {
        "id": "group1",
        "name": "Crypto Moon Shots",
        "wins": 12,
        "losses": 3,
        "total_evals": 15,
        "success_rate": 0.8,
        "avg_profit": 1.75,  # Multiplier (1.0 = break even, 2.0 = 100% profit)
        "best_token": "Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu",
        "best_profit": 3.2,
        "token_history": [
            {"token": "Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu", "profit": 3.2, "timestamp": "2025-04-10T12:30:00"},
            {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "profit": 1.8, "timestamp": "2025-04-12T15:45:00"},
            {"token": "So11111111111111111111111111111111111111112", "profit": 0.7, "timestamp": "2025-04-15T09:20:00"}
        ]
    },
    "group2": {
        "id": "group2",
        "name": "SOLANA Gems Official",
        "wins": 8,
        "losses": 4,
        "total_evals": 12,
        "success_rate": 0.67,
        "avg_profit": 1.42,
        "best_token": "xH28mVPXWNeGxfvDJnWPuqGzaQsHdZs3Wv6ZtxhvG64",
        "best_profit": 2.7,
        "token_history": [
            {"token": "xH28mVPXWNeGxfvDJnWPuqGzaQsHdZs3Wv6ZtxhvG64", "profit": 2.7, "timestamp": "2025-04-08T14:10:00"},
            {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "profit": 1.5, "timestamp": "2025-04-11T13:30:00"},
            {"token": "So11111111111111111111111111111111111111112", "profit": 0.8, "timestamp": "2025-04-16T10:15:00"}
        ]
    },
    "group3": {
        "id": "group3",
        "name": "Alpha Calls",
        "wins": 15,
        "losses": 2,
        "total_evals": 17,
        "success_rate": 0.88,
        "avg_profit": 1.92,
        "best_token": "JRvMpN93ddTmyWzqQNJ3ghrn5WQnwqUWerZYJKW13pw",
        "best_profit": 4.1,
        "token_history": [
            {"token": "JRvMpN93ddTmyWzqQNJ3ghrn5WQnwqUWerZYJKW13pw", "profit": 4.1, "timestamp": "2025-04-09T11:20:00"},
            {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "profit": 2.2, "timestamp": "2025-04-13T16:40:00"},
            {"token": "FoXyMu5xwXre7zEoSvzViRk3nGawHUp9kUhfLPBYbAFb", "profit": 2.3, "timestamp": "2025-04-17T08:30:00"}
        ]
    },
    "group4": {
        "id": "group4",
        "name": "Sol Raiders",
        "wins": 6,
        "losses": 14,
        "total_evals": 20,
        "success_rate": 0.3,
        "avg_profit": 0.85,
        "best_token": "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TNZuJskuuV9",
        "best_profit": 1.8,
        "token_history": [
            {"token": "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TNZuJskuuV9", "profit": 1.8, "timestamp": "2025-04-07T10:00:00"},
            {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "profit": 0.9, "timestamp": "2025-04-14T17:20:00"},
            {"token": "FoXyMu5xwXre7zEoSvzViRk3nGawHUp9kUhfLPBYbAFb", "profit": 0.5, "timestamp": "2025-04-16T09:10:00"}
        ]
    },
    "group5": {
        "id": "group5",
        "name": "Degenerates United",
        "wins": 10,
        "losses": 5,
        "total_evals": 15,
        "success_rate": 0.67,
        "avg_profit": 1.35,
        "best_token": "FoXyMu5xwXre7zEoSvzViRk3nGawHUp9kUhfLPBYbAFb",
        "best_profit": 2.4,
        "token_history": [
            {"token": "FoXyMu5xwXre7zEoSvzViRk3nGawHUp9kUhfLPBYbAFb", "profit": 2.4, "timestamp": "2025-04-10T15:50:00"},
            {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "profit": 1.4, "timestamp": "2025-04-12T12:20:00"},
            {"token": "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TNZuJskuuV9", "profit": 1.1, "timestamp": "2025-04-15T14:40:00"}
        ]
    }
}

def get_ranked_groups(limit: int = 5) -> List[Dict[str, Any]]:
    """
    Get the top performing groups based on a weighted ranking algorithm.
    
    The ranking is calculated based on:
    1. Success rate (wins/total)
    2. Average profit
    3. Recent performance trend
    
    Args:
        limit: Maximum number of groups to return
        
    Returns:
        List of groups with their ranking metrics
    """
    try:
        # Get all groups from the database
        # In a real implementation, this would query the database
        groups = list(_GROUPS_DB.values())
        
        # Calculate the ranking score for each group
        for group in groups:
            # Base ranking on success rate and average profit
            success_rate = group.get("success_rate", 0)
            avg_profit = group.get("avg_profit", 1.0)
            
            # Calculate a weighted score
            # Higher weight on profit for groups with good success rate
            ranking_score = (success_rate * 0.6) + (min(avg_profit - 1, 1) * 0.4)
            
            # Add a bonus for groups with high win count
            wins = group.get("wins", 0)
            if wins > 10:
                ranking_score += 0.1
            
            # Add ranking score to the group data
            group["ranking_score"] = round(ranking_score, 3)
        
        # Sort groups by ranking score (descending)
        sorted_groups = sorted(groups, key=lambda x: x.get("ranking_score", 0), reverse=True)
        
        # Return the top groups up to the limit
        return sorted_groups[:limit]
    
    except Exception as e:
        logger.error(f"Error getting ranked groups: {str(e)}")
        return []

def get_group_stats(group_id: str) -> Dict[str, Any]:
    """
    Get detailed statistics for a specific group.
    
    Args:
        group_id: The group ID to get stats for
        
    Returns:
        Dictionary with group statistics
    """
    try:
        # Get the group data from the database
        # In a real implementation, this would query the database
        group_data = _GROUPS_DB.get(group_id)
        
        if not group_data:
            logger.warning(f"Group not found: {group_id}")
            return {}
        
        return group_data
    
    except Exception as e:
        logger.error(f"Error getting group stats for {group_id}: {str(e)}")
        return {}

def should_auto_snipe(group_id: str, config: Dict[str, Any]) -> Tuple[bool, float]:
    """
    Determine if a group should be auto-sniped and the optimal amount.
    
    Args:
        group_id: The group ID to check
        config: Auto-snipe configuration
        
    Returns:
        Tuple of (should_snipe, optimal_amount)
    """
    try:
        # Get the auto-snipe configuration
        enabled = config.get('enabled', False)
        min_success_rate = config.get('min_success_rate', 0.5)
        default_amount = config.get('amount', 0.01)
        max_amount = config.get('max_amount', 0.1)
        
        # If auto-sniping is disabled, return False
        if not enabled:
            return False, 0
        
        # Get the group stats
        group = get_group_stats(group_id)
        
        # If group not found or doesn't meet minimum success rate, don't auto-snipe
        if not group or group.get('success_rate', 0) < min_success_rate:
            return False, 0
        
        # Calculate the optimal amount based on group performance
        success_rate = group.get('success_rate', 0)
        avg_profit = group.get('avg_profit', 1.0)
        
        # Base amount on success rate and profit
        performance_factor = (success_rate * 0.7) + (min((avg_profit - 1) * 0.5, 0.5) * 0.3)
        
        # Scale the amount based on performance (0.01 to max_amount)
        optimal_amount = default_amount + (performance_factor * (max_amount - default_amount))
        
        # Round to 2 decimal places and ensure within limits
        optimal_amount = round(min(max(optimal_amount, default_amount), max_amount), 2)
        
        return True, optimal_amount
    
    except Exception as e:
        logger.error(f"Error determining auto-snipe for group {group_id}: {str(e)}")
        return False, 0

# Allow this module to be run directly for testing
if __name__ == "__main__":
    # Simple test
    ranked_groups = get_ranked_groups(limit=3)
    print(f"Top 3 ranked groups:")
    for i, group in enumerate(ranked_groups, 1):
        print(f"{i}. {group['name']} - Score: {group['ranking_score']}, Success Rate: {group['success_rate']:.1%}")