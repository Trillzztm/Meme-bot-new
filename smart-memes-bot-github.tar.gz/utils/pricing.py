"""
Token pricing utilities for SMART MEMES BOT.

This module handles token price fetching, historical price data,
and price-related calculations.
"""

import logging
import time
import random
import asyncio
from typing import Dict, Any, List, Optional, Tuple, Union

# Configure logger
logger = logging.getLogger(__name__)

# Cache for token prices
_price_cache = {}  # token_address -> {"price": float, "timestamp": int, "expires": int}
_liquidity_cache = {}  # token_address -> {"liquidity": float, "timestamp": int, "expires": int}
_price_history = {}  # token_address -> [{"price": float, "timestamp": int}]

# Cache expiration time (seconds)
PRICE_CACHE_EXPIRY = 60  # 1 minute
LIQUIDITY_CACHE_EXPIRY = 300  # 5 minutes

# API keys (would be loaded from environment variables in production)
try:
    import os
    BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY", "")
    if BIRDEYE_API_KEY:
        logger.info("BirdEye API key found")
    else:
        logger.warning("BirdEye API key not found, using simulated data")
except ImportError:
    logger.warning("Error loading environment variables")
    BIRDEYE_API_KEY = ""


async def get_token_price(token_address: str, network: str = 'solana') -> float:
    """
    Get the current price of a token.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        The token price in USD
    """
    # Check cache first
    cache_key = f"{network}:{token_address}"
    if cache_key in _price_cache:
        cached = _price_cache[cache_key]
        if cached["expires"] > time.time():
            return cached["price"]
    
    # Try to fetch from API
    price = await _fetch_token_price(token_address, network)
    
    # Store in cache with expiration
    _price_cache[cache_key] = {
        "price": price,
        "timestamp": int(time.time()),
        "expires": int(time.time() + PRICE_CACHE_EXPIRY)
    }
    
    # Store in price history
    if cache_key not in _price_history:
        _price_history[cache_key] = []
    
    _price_history[cache_key].append({
        "price": price,
        "timestamp": int(time.time())
    })
    
    # Keep only the last 1000 price points to avoid memory issues
    if len(_price_history[cache_key]) > 1000:
        _price_history[cache_key] = _price_history[cache_key][-1000:]
    
    return price


async def get_token_liquidity(token_address: str, network: str = 'solana') -> float:
    """
    Get the current liquidity of a token.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        The token liquidity in USD
    """
    # Check cache first
    cache_key = f"{network}:{token_address}"
    if cache_key in _liquidity_cache:
        cached = _liquidity_cache[cache_key]
        if cached["expires"] > time.time():
            return cached["liquidity"]
    
    # Try to fetch from API
    liquidity = await _fetch_token_liquidity(token_address, network)
    
    # Store in cache with expiration
    _liquidity_cache[cache_key] = {
        "liquidity": liquidity,
        "timestamp": int(time.time()),
        "expires": int(time.time() + LIQUIDITY_CACHE_EXPIRY)
    }
    
    return liquidity


async def get_token_price_history(token_address: str, network: str = 'solana', 
                                 timeframe: str = '1d') -> List[Dict[str, Any]]:
    """
    Get the price history for a token.
    
    Args:
        token_address: The token address
        network: Blockchain network
        timeframe: Time period ('1h', '24h', '7d', '30d')
        
    Returns:
        List of price data points
    """
    # First try to use our stored history if available
    cache_key = f"{network}:{token_address}"
    
    if cache_key in _price_history and _price_history[cache_key]:
        # Filter based on timeframe
        now = time.time()
        if timeframe == '1h':
            cutoff = now - 3600  # 1 hour
        elif timeframe == '24h':
            cutoff = now - 86400  # 24 hours
        elif timeframe == '7d':
            cutoff = now - 604800  # 7 days
        elif timeframe == '30d':
            cutoff = now - 2592000  # 30 days
        else:
            cutoff = now - 86400  # Default to 24 hours
        
        # Filter history by cutoff time
        filtered_history = [
            item for item in _price_history[cache_key] 
            if item["timestamp"] >= cutoff
        ]
        
        # If we have enough data points, return them
        if len(filtered_history) > 5:
            return filtered_history
    
    # If not enough cached data, fetch from API
    history = await _fetch_token_price_history(token_address, network, timeframe)
    return history


async def get_price_change(token_address: str, network: str = 'solana', 
                          period: str = '24h') -> Dict[str, float]:
    """
    Get the price change percentage for a specific period.
    
    Args:
        token_address: The token address
        network: Blockchain network
        period: Time period ('1h', '24h', '7d', '30d')
        
    Returns:
        Dictionary with change data
    """
    # Get price history
    history = await get_token_price_history(token_address, network, period)
    
    if not history or len(history) < 2:
        return {
            "change_pct": 0.0,
            "start_price": 0.0,
            "end_price": 0.0
        }
    
    # Sort by timestamp
    sorted_history = sorted(history, key=lambda x: x["timestamp"])
    
    start_price = sorted_history[0]["price"]
    end_price = sorted_history[-1]["price"]
    
    if start_price == 0:
        change_pct = 0.0
    else:
        change_pct = ((end_price - start_price) / start_price) * 100.0
    
    return {
        "change_pct": change_pct,
        "start_price": start_price,
        "end_price": end_price
    }


async def calculate_profit_potential(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Calculate the profit potential for a token based on various metrics.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        Dictionary with profit potential metrics
    """
    # Get current price and liquidity
    price = await get_token_price(token_address, network)
    liquidity = await get_token_liquidity(token_address, network)
    
    # Get price changes
    change_1h = await get_price_change(token_address, network, '1h')
    change_24h = await get_price_change(token_address, network, '24h')
    
    # Calculate metrics
    liquidity_score = min(100, max(0, liquidity / 10000))  # 0-100 based on liquidity
    momentum_score = min(100, max(0, ((change_1h["change_pct"] * 2) + change_24h["change_pct"]) / 3))
    volatility_score = min(100, max(0, abs(change_1h["change_pct"]) * 5))
    
    # Combine into a profit potential score (0-100)
    profit_potential = (
        (liquidity_score * 0.4) +  # 40% weight on liquidity
        (momentum_score * 0.4) +   # 40% weight on momentum
        (volatility_score * 0.2)   # 20% weight on volatility
    )
    
    return {
        "profit_potential": profit_potential,
        "liquidity_score": liquidity_score,
        "momentum_score": momentum_score,
        "volatility_score": volatility_score,
        "price": price,
        "liquidity": liquidity,
        "change_1h": change_1h["change_pct"],
        "change_24h": change_24h["change_pct"]
    }


async def _fetch_token_price(token_address: str, network: str = 'solana') -> float:
    """
    Fetch token price from external API.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        The token price in USD
    """
    # In a real implementation, this would call an external API
    # For this implementation, we'll simulate with realistic price data
    
    # For known tokens, use pre-set price ranges
    if token_address == "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v":  # USDC
        return 1.0 + (random.random() - 0.5) * 0.001  # $0.9995 - $1.0005
    
    elif token_address == "So11111111111111111111111111111111111111112":  # SOL
        base_price = 180.0
        variance = 10.0
        return base_price + (random.random() - 0.5) * variance
    
    elif token_address == "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263":  # BONK
        # Small priced token with 5 decimals
        return 0.00000214 * (1 + (random.random() - 0.5) * 0.2)
    
    elif token_address == "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU":  # RENDER
        base_price = 8.75
        variance = 0.5
        return base_price + (random.random() - 0.5) * variance
    
    # For unknown tokens, use a hash of the address to generate a consistent price
    # This ensures the same token always gets the same price in a demo
    else:
        # Create a hash of the address
        addr_hash = sum(ord(c) for c in token_address) % 10000
        
        # Tokens with different magnitudes of price
        if addr_hash % 100 < 50:  # 50% chance of micro price
            base = 0.00000001 * (addr_hash + 1)
            variance = base * 0.1
        elif addr_hash % 100 < 80:  # 30% chance of small price
            base = 0.001 * (addr_hash % 1000 + 1)
            variance = base * 0.1
        elif addr_hash % 100 < 95:  # 15% chance of medium price
            base = 0.1 * (addr_hash % 100 + 1)
            variance = base * 0.05
        else:  # 5% chance of large price
            base = 10.0 * (addr_hash % 10 + 1)
            variance = base * 0.02
        
        return base + (random.random() - 0.5) * variance


async def _fetch_token_liquidity(token_address: str, network: str = 'solana') -> float:
    """
    Fetch token liquidity from external API.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        The token liquidity in USD
    """
    # In a real implementation, this would call an external API
    
    # For known tokens, use pre-set liquidity values
    if token_address == "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v":  # USDC
        return 5000000000.0  # $5B liquidity
    
    elif token_address == "So11111111111111111111111111111111111111112":  # SOL
        return 1500000000.0  # $1.5B liquidity
    
    elif token_address == "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263":  # BONK
        return 25000000.0  # $25M liquidity
    
    elif token_address == "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU":  # RENDER
        return 75000000.0  # $75M liquidity
    
    # For unknown tokens, calculate based on address hash
    else:
        # Create a hash of the address
        addr_hash = sum(ord(c) for c in token_address) % 10000
        
        # Different liquidity tiers
        if addr_hash % 100 < 50:  # 50% chance of low liquidity
            return random.uniform(10000, 100000)  # $10K-$100K
        elif addr_hash % 100 < 80:  # 30% chance of medium liquidity
            return random.uniform(100000, 1000000)  # $100K-$1M
        elif addr_hash % 100 < 95:  # 15% chance of high liquidity
            return random.uniform(1000000, 10000000)  # $1M-$10M
        else:  # 5% chance of very high liquidity
            return random.uniform(10000000, 100000000)  # $10M-$100M


async def _fetch_token_price_history(token_address: str, network: str, timeframe: str) -> List[Dict[str, Any]]:
    """
    Fetch token price history from external API.
    
    Args:
        token_address: The token address
        network: Blockchain network
        timeframe: Time period ('1h', '24h', '7d', '30d')
        
    Returns:
        List of price data points
    """
    # In a real implementation, this would call an external API
    
    # Calculate number of data points based on timeframe
    if timeframe == '1h':
        points = 60  # 1 point per minute
        interval = 60  # 60 seconds
    elif timeframe == '24h':
        points = 24  # 1 point per hour
        interval = 3600  # 1 hour
    elif timeframe == '7d':
        points = 7 * 24  # 1 point per hour for 7 days
        interval = 3600  # 1 hour
    elif timeframe == '30d':
        points = 30  # 1 point per day
        interval = 86400  # 1 day
    else:
        points = 24  # Default to 24 hours
        interval = 3600  # 1 hour
    
    # Get current price as a base
    base_price = await get_token_price(token_address, network)
    
    # Generate historical data with realistic patterns
    history = []
    current_time = int(time.time())
    
    # Determine volatility based on token
    if token_address == "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v":  # USDC
        volatility = 0.001  # 0.1% max change between points
    elif token_address == "So11111111111111111111111111111111111111112":  # SOL
        volatility = 0.03  # 3% max change between points
    elif token_address == "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263":  # BONK
        volatility = 0.1  # 10% max change between points
    else:
        # Random token - generate based on address hash
        addr_hash = sum(ord(c) for c in token_address) % 100
        volatility = 0.02 + (addr_hash / 100) * 0.18  # 2-20% volatility
    
    # Generate random price movement direction
    # For most tokens (75% chance), generate an uptrend
    trend = random.random()
    if trend < 0.75:
        # Uptrend
        trend_direction = 0.6  # 60% chance of upward movement
    else:
        # Downtrend
        trend_direction = 0.4  # 40% chance of upward movement
    
    current_price = base_price
    
    # Generate points going backward in time
    for i in range(points):
        # Calculate time for this point
        point_time = current_time - (i * interval)
        
        # Add current price to history
        history.append({
            "price": current_price,
            "timestamp": point_time
        })
        
        # Determine next price movement direction
        if random.random() < trend_direction:
            # Price goes up
            change = -random.random() * volatility
        else:
            # Price goes down
            change = -random.random() * volatility * 1.2  # Losses tend to be bigger than gains
        
        # Update current price for next iteration
        # Moving backward in time, so we subtract the change
        current_price = current_price * (1 + change)
        
        # Ensure price doesn't go negative
        if current_price <= 0:
            current_price = base_price * 0.001  # Very small but positive price
    
    # Return reversed history so it's in chronological order
    return sorted(history, key=lambda x: x["timestamp"])


async def get_token_metrics(token_address: str, network: str = 'solana') -> Dict[str, Any]:
    """
    Get comprehensive metrics for a token.
    
    Args:
        token_address: The token address
        network: Blockchain network
        
    Returns:
        Dictionary with token metrics
    """
    # Fetch basic data
    price = await get_token_price(token_address, network)
    liquidity = await get_token_liquidity(token_address, network)
    
    # Fetch price changes
    change_1h = await get_price_change(token_address, network, '1h')
    change_24h = await get_price_change(token_address, network, '24h')
    change_7d = await get_price_change(token_address, network, '7d')
    
    # Calculate profit potential
    profit_potential = await calculate_profit_potential(token_address, network)
    
    # Combine all metrics
    metrics = {
        "price": price,
        "liquidity": liquidity,
        "price_change_1h": change_1h["change_pct"],
        "price_change_24h": change_24h["change_pct"],
        "price_change_7d": change_7d["change_pct"],
        "profit_potential": profit_potential["profit_potential"],
        "liquidity_score": profit_potential["liquidity_score"],
        "momentum_score": profit_potential["momentum_score"],
        "volatility_score": profit_potential["volatility_score"],
        "updated_at": int(time.time())
    }
    
    return metrics