"""
Start the minimal app version directly.
This script ensures the app will start using the minimal version
regardless of any issues with the main app.
"""

import os
import sys
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("RunMinimal")

def main():
    """Run the minimal app directly"""
    try:
        logger.info("Starting minimal app version for maximum reliability")
        
        # Check if the minimal app exists
        if not os.path.exists('app_minimal.py'):
            logger.error("Minimal app not found!")
            return 1
        
        # Import and run the minimal app
        from app_minimal import app
        
        # Get port from environment or use default
        port = int(os.environ.get('PORT', 5000))
        
        # Run with host 0.0.0.0 to be accessible from outside
        logger.info(f"Running minimal app on port {port}")
        app.run(host='0.0.0.0', port=port, debug=False)
        
        return 0
    except Exception as e:
        logger.error(f"Error starting minimal app: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())