#!/bin/bash

echo "==============================================="
echo "SMART MEMES BOT - WALLET SETUP"
echo "==============================================="
echo

# Check if private key is set
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
    echo "⚠️ SOLANA_PRIVATE_KEY environment variable not set!"
    
    read -p "Do you want to set it now? (y/n): " SET_KEY
    if [ "$SET_KEY" = "y" ] || [ "$SET_KEY" = "Y" ]; then
        read -p "Enter your Solana private key: " PRIVATE_KEY
        export SOLANA_PRIVATE_KEY="$PRIVATE_KEY"
        echo "export SOLANA_PRIVATE_KEY=\"$PRIVATE_KEY\"" >> ~/.bashrc
        echo "✅ Private key set successfully"
    else
        echo "❌ Private key not set. Bot will not function without it."
        echo "You can set it later with: export SOLANA_PRIVATE_KEY='your_key_here'"
        exit 1
    fi
else
    echo "✅ SOLANA_PRIVATE_KEY is already set"
fi

# Try to extract wallet address if possible
echo "📋 Checking wallet address..."
python -c "
import os
import sys
try:
    import base58
    from solana.keypair import Keypair
    print('✅ Required libraries installed')
except ImportError:
    print('⚠️ Installing required Solana libraries...')
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'solana', 'base58'])
    import base58
    from solana.keypair import Keypair

try:
    private_key = os.environ.get('SOLANA_PRIVATE_KEY')
    
    if private_key.startswith('['):
        # Array format
        import json
        private_key_bytes = bytes(json.loads(private_key))
    else:
        # Base58 format
        private_key_bytes = base58.b58decode(private_key)
    
    keypair = Keypair.from_secret_key(private_key_bytes)
    wallet_address = str(keypair.public_key)
    print(f'✅ Wallet address: {wallet_address}')
    print(f'ℹ️ Check balance: https://explorer.solana.com/address/{wallet_address}')
except Exception as e:
    print(f'❌ Error retrieving wallet address: {e}')
    print('Please check that your private key is valid')
"

echo
echo "📱 Checking Telegram configuration..."

# Check if Telegram bot token is set
if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
    echo "⚠️ TELEGRAM_BOT_TOKEN environment variable not set!"
    echo "Telegram notifications will not work without it."
    
    read -p "Do you want to set it now? (y/n): " SET_TOKEN
    if [ "$SET_TOKEN" = "y" ] || [ "$SET_TOKEN" = "Y" ]; then
        read -p "Enter your Telegram bot token: " BOT_TOKEN
        export TELEGRAM_BOT_TOKEN="$BOT_TOKEN"
        echo "export TELEGRAM_BOT_TOKEN=\"$BOT_TOKEN\"" >> ~/.bashrc
        echo "✅ Telegram bot token set successfully"
    else
        echo "ℹ️ Telegram bot token not set. Notifications will not work."
        echo "You can set it later with: export TELEGRAM_BOT_TOKEN='your_token_here'"
    fi
else
    echo "✅ TELEGRAM_BOT_TOKEN is already set"
fi

# Check if Telegram chat ID is set
if [ -z "$TELEGRAM_CHAT_ID" ]; then
    echo "⚠️ TELEGRAM_CHAT_ID environment variable not set!"
    echo "Using default chat ID: 6915721378"
    
    read -p "Do you want to set your own chat ID now? (y/n): " SET_CHAT_ID
    if [ "$SET_CHAT_ID" = "y" ] || [ "$SET_CHAT_ID" = "Y" ]; then
        read -p "Enter your Telegram chat ID: " CHAT_ID
        export TELEGRAM_CHAT_ID="$CHAT_ID"
        echo "export TELEGRAM_CHAT_ID=\"$CHAT_ID\"" >> ~/.bashrc
        echo "✅ Telegram chat ID set successfully"
    else
        echo "ℹ️ Using default chat ID. Notifications may not reach you."
        echo "You can set it later with: export TELEGRAM_CHAT_ID='your_chat_id'"
    fi
else
    echo "✅ TELEGRAM_CHAT_ID is already set"
fi

echo
echo "==============================================="
echo "✅ WALLET SETUP COMPLETE"
echo "==============================================="
echo
echo "You can now run the real trader with:"
echo "./start_24_7_trading.sh"
echo
echo "For 24/7 operation with auto-restart, use the watchdog:"
echo "./start_real_trader_watchdog.sh"
echo
echo "==============================================="