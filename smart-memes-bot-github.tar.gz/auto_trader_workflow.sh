#!/usr/bin/env bash
python auto_trader_simple.py
