#!/bin/bash
# Create utils directory if it doesn't exist
mkdir -p utils
touch utils/__init__.py
echo "Utils directory setup completed"