"""
API Rate Limiter for SMART MEMES BOT

This module provides rate limiting capabilities for API calls to prevent 
hitting rate limits (429 Too Many Requests errors) when interacting
with external APIs like Jupiter.
"""

import time
import random
import logging
import threading
from typing import Dict, Any, Callable
from functools import wraps

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ApiRateLimiter")

# Global rate limiting configurations
RATE_LIMITS = {
    "jupiter": {
        "max_calls": 40,           # Max calls allowed per time window (Jupiter limit is 60/min, but we're conservative)
        "time_window": 60,         # Time window in seconds (60 = 1 minute)
        "buffer_percentage": 25,   # Buffer percentage to stay under the limit
        "retry_delay": 2,          # Default retry delay in seconds
        "max_retries": 3,          # Maximum number of retry attempts
        "backoff_factor": 2        # Exponential backoff factor
    },
    "default": {
        "max_calls": 10,           # Default max calls per time window
        "time_window": 60,         # Default time window (1 minute)
        "buffer_percentage": 20,   # Default buffer percentage
        "retry_delay": 1,          # Default retry delay in seconds
        "max_retries": 3,          # Maximum number of retry attempts
        "backoff_factor": 1.5      # Exponential backoff factor
    }
}

# Call tracking
call_history = {}
call_locks = {}

def init_api(api_name: str) -> None:
    """Initialize tracking for an API"""
    if api_name not in call_history:
        call_history[api_name] = []
    
    if api_name not in call_locks:
        call_locks[api_name] = threading.Lock()

def get_rate_limit_config(api_name: str) -> Dict[str, Any]:
    """Get rate limit config for an API, falling back to default if not found"""
    return RATE_LIMITS.get(api_name, RATE_LIMITS["default"])

def cleanup_call_history(api_name: str) -> None:
    """Remove old calls from history based on time window"""
    config = get_rate_limit_config(api_name)
    time_window = config["time_window"]
    
    current_time = time.time()
    with call_locks[api_name]:
        call_history[api_name] = [
            timestamp for timestamp in call_history[api_name]
            if current_time - timestamp < time_window
        ]

def count_recent_calls(api_name: str) -> int:
    """Count calls within the time window"""
    cleanup_call_history(api_name)
    with call_locks[api_name]:
        return len(call_history[api_name])

def can_make_api_call(api_name: str) -> bool:
    """Check if we can make an API call without exceeding rate limits"""
    init_api(api_name)
    
    config = get_rate_limit_config(api_name)
    max_calls = config["max_calls"]
    buffer_percentage = config["buffer_percentage"]
    
    # Apply buffer to be conservative
    actual_max_calls = max_calls * (100 - buffer_percentage) // 100
    
    recent_calls = count_recent_calls(api_name)
    return recent_calls < actual_max_calls

def record_api_call(api_name: str) -> None:
    """Record an API call"""
    init_api(api_name)
    
    current_time = time.time()
    with call_locks[api_name]:
        call_history[api_name].append(current_time)

def wait_for_rate_limit(api_name: str) -> None:
    """Wait until we can make an API call"""
    init_api(api_name)
    
    config = get_rate_limit_config(api_name)
    time_window = config["time_window"]
    
    # Calculate smart backoff time
    recent_calls = count_recent_calls(api_name)
    config = get_rate_limit_config(api_name)
    max_calls = config["max_calls"] * (100 - config["buffer_percentage"]) // 100
    
    if recent_calls >= max_calls:
        # Calculate time needed to wait based on oldest call in window
        with call_locks[api_name]:
            if call_history[api_name]:  # Check if there are any calls in history
                oldest_call = min(call_history[api_name])
                wait_time = (oldest_call + time_window) - time.time()
                
                if wait_time > 0:
                    wait_time += 1  # Add 1 second buffer
                    logger.info(f"Rate limit reached for {api_name}, waiting {wait_time:.2f} seconds")
                    time.sleep(wait_time)

def retry_with_backoff(api_name: str, func, *args, **kwargs):
    """
    Retry a function with exponential backoff when rate limited
    
    Args:
        api_name: API name for rate limiting
        func: Function to retry
        *args: Arguments to pass to func
        **kwargs: Keyword arguments to pass to func
        
    Returns:
        Result of function call
    """
    init_api(api_name)
    config = get_rate_limit_config(api_name)
    max_retries = config.get("max_retries", 3)
    retry_delay = config.get("retry_delay", 2)
    backoff_factor = config.get("backoff_factor", 2)
    
    # Try to call the function with retries
    for attempt in range(max_retries + 1):
        try:
            # Wait for rate limiting if necessary
            wait_for_rate_limit(api_name)
            
            # Record the API call
            record_api_call(api_name)
            
            # Call the function
            result = func(*args, **kwargs)
            
            # Check for rate limit error in the response 
            if isinstance(result, dict) and result.get("statusCode") == 429:
                raise Exception(f"Rate limit exceeded: {result.get('message', 'Too Many Requests')}")
                
            # For HTTP response objects
            if hasattr(result, "status_code") and result.status_code == 429:
                raise Exception(f"Rate limit exceeded: {result.text}")
                
            # Success - return the result
            return result
            
        except Exception as e:
            # If this is a rate limit error
            if "Rate limit" in str(e) or "Too Many Requests" in str(e) or "429" in str(e):
                if attempt < max_retries:
                    # Calculate backoff time with jitter
                    backoff_time = retry_delay * (backoff_factor ** attempt)
                    # Add some random jitter (±20%)
                    jitter = backoff_time * 0.2 * (2 * random.random() - 1)
                    backoff_time = max(0.1, backoff_time + jitter)
                    
                    logger.warning(f"Rate limit hit, retrying in {backoff_time:.2f}s (attempt {attempt+1}/{max_retries})")
                    time.sleep(backoff_time)
                else:
                    logger.error(f"Rate limit exceeded after {max_retries} retries: {e}")
                    raise Exception(f"Rate limit exceeded after {max_retries} retries: {e}")
            else:
                # Not a rate limit error, re-raise
                raise
                
    # This should never happen, but just in case
    raise Exception(f"Retry logic failed after {max_retries} attempts")

def rate_limited(api_name: str):
    """
    Decorator for rate-limited API calls
    
    Example usage:
    
    @rate_limited("jupiter")
    def call_jupiter_api():
        # Make API call
        pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Initialize API tracking
            init_api(api_name)
            
            # Wait for rate limit if needed
            wait_for_rate_limit(api_name)
            
            # Record the API call
            record_api_call(api_name)
            
            # Call the original function
            return func(*args, **kwargs)
        return wrapper
    return decorator

# Example rate-limited function
@rate_limited("jupiter")
def call_jupiter_api():
    """Example function demonstrating rate limiting"""
    logger.info("Making Jupiter API call")
    # Actual API call would go here
    return {"success": True}

if __name__ == "__main__":
    # Test rate limiting
    for i in range(60):
        result = call_jupiter_api()
        logger.info(f"Call {i+1} result: {result}")