"""
Utility functions for the Telegram bot.
"""
import time
import re
from datetime import datetime

def get_current_timestamp():
    """
    Get the current Unix timestamp.
    
    Returns:
        int: Current Unix timestamp
    """
    return int(time.time())

def calculate_days_since(timestamp):
    """
    Calculate the number of days since a given timestamp.
    
    Args:
        timestamp (int): Unix timestamp
        
    Returns:
        int: Number of days
    """
    seconds_diff = get_current_timestamp() - timestamp
    return max(0, int(seconds_diff / 86400))  # 86400 seconds in a day

def is_cache_expired(timestamp, ttl=3600):
    """
    Check if a cache entry is expired.
    
    Args:
        timestamp (int): Timestamp of the cache entry
        ttl (int, optional): Time to live in seconds (default: 1 hour)
        
    Returns:
        bool: True if expired, False otherwise
    """
    return (get_current_timestamp() - timestamp) > ttl

def format_large_number(num):
    """
    Format a large number for display.
    
    Args:
        num (float): The number to format
        
    Returns:
        str: Formatted number
    """
    if num >= 1_000_000_000:
        return f"{num/1_000_000_000:.2f}B"
    elif num >= 1_000_000:
        return f"{num/1_000_000:.2f}M"
    elif num >= 1_000:
        return f"{num/1_000:.2f}K"
    else:
        return f"{num:.2f}"

def is_valid_eth_address(address):
    """
    Check if a string is a valid Ethereum address.
    
    Args:
        address (str): The address to check
        
    Returns:
        bool: True if valid, False otherwise
    """
    # Basic format check
    pattern = re.compile(r'^0x[a-fA-F0-9]{40}$')
    return bool(pattern.match(address))

def truncate_address(address, chars=6):
    """
    Truncate an address for display.
    
    Args:
        address (str): The address to truncate
        chars (int, optional): Number of characters to keep on each end
        
    Returns:
        str: Truncated address
    """
    if not address or len(address) <= chars * 2:
        return address
    
    return f"{address[:chars]}...{address[-chars:]}"

def format_timestamp(timestamp, format_str="%Y-%m-%d %H:%M:%S"):
    """
    Format a Unix timestamp to a readable date string.
    
    Args:
        timestamp (int): Unix timestamp
        format_str (str, optional): Format string
        
    Returns:
        str: Formatted date string
    """
    dt = datetime.fromtimestamp(timestamp)
    return dt.strftime(format_str)

def human_readable_time_since(timestamp):
    """
    Get a human-readable string representing time since a timestamp.
    
    Args:
        timestamp (int): Unix timestamp
        
    Returns:
        str: Human-readable time string
    """
    seconds_diff = get_current_timestamp() - timestamp
    
    if seconds_diff < 60:
        return f"{seconds_diff} seconds ago"
    elif seconds_diff < 3600:
        minutes = seconds_diff // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds_diff < 86400:
        hours = seconds_diff // 3600
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds_diff < 2592000:  # ~30 days
        days = seconds_diff // 86400
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif seconds_diff < 31536000:  # ~365 days
        months = seconds_diff // 2592000
        return f"{months} month{'s' if months != 1 else ''} ago"
    else:
        years = seconds_diff // 31536000
        return f"{years} year{'s' if years != 1 else ''} ago"

def sanitize_input(text):
    """
    Sanitize user input to prevent injection attacks.
    
    Args:
        text (str): User input
        
    Returns:
        str: Sanitized input
    """
    # Remove potentially dangerous characters
    sanitized = re.sub(r'[^\w\s\-\.,;:!?@#$%^&*()_+=\[\]{}|\\\'\"<>\/]', '', text)
    return sanitized.strip()
