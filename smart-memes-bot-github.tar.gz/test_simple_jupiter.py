#!/usr/bin/env python3
"""
Test Simple Jupiter - No Dependencies Version

This script tests if the simplified Jupiter client works correctly.
"""

import os
import sys
import json
from utils.simple_jupiter import check_wallet_balance, get_quote, SOL_MINT, BONK_MINT, WALLET_ADDRESS

# Print header
print("\n" + "="*60)
print("SMART MEMES BOT - SIMPLE JUPITER TEST")
print("="*60 + "\n")

# Check environment
print("Environment Setup:")
print(f"- WALLET_ADDRESS: {'✅ Set' if WALLET_ADDRESS else '❌ Not set'}")
print(f"- SOLANA_PRIVATE_KEY: {'✅ Set' if os.environ.get('SOLANA_PRIVATE_KEY') else '❌ Not set'}")

if not WALLET_ADDRESS:
    print("\n❌ ERROR: No wallet address found!")
    print("Please set your wallet address by doing one of the following:")
    print("1. Set the WALLET_ADDRESS environment variable")
    print("2. Edit utils/simple_jupiter.py and add your wallet address")
    print("\nExample wallet address: GWrigDjL6HsYvK32y5b7ZzwTH8Vw1ZR2miN5jMLrM8f1")
    sys.exit(1)

print(f"\nUsing wallet address: {WALLET_ADDRESS}")

# Check wallet balance
print("\nChecking wallet balance...")
balance = check_wallet_balance()
if "error" in balance:
    print(f"❌ Error getting wallet balance: {balance['error']}")
else:
    print(f"✅ Wallet balance: {balance.get('balance_sol', 0):.6f} SOL (${balance.get('balance_usd', 0):.2f})")

# Get a Jupiter quote
print("\nGetting Jupiter quote for 0.01 SOL to BONK...")
quote = get_quote(SOL_MINT, BONK_MINT, 10000000)  # 0.01 SOL to BONK

if "error" in quote:
    print(f"❌ Error getting Jupiter quote: {quote['error']}")
else:
    in_amount = int(quote.get("inAmount", 0))
    out_amount = int(quote.get("outAmount", 0))
    price_impact = quote.get("priceImpactPct", 0)
    
    print(f"✅ Jupiter quote received!")
    print(f"   Input: {in_amount / 10**9:.6f} SOL")
    print(f"   Output: {out_amount} BONK")
    print(f"   Price Impact: {price_impact}%")

# Print summary
print("\n" + "="*60)
print("TEST SUMMARY")
print("="*60)

wallet_ok = "error" not in balance
quote_ok = "error" not in quote

if wallet_ok:
    print("✅ Wallet Connection: CONNECTED")
else:
    print("❌ Wallet Connection: FAILED")

if quote_ok:
    print("✅ Jupiter API: WORKING")
else:
    print("❌ Jupiter API: FAILED")

if wallet_ok and quote_ok:
    print("\n🎉 ALL TESTS PASSED! Your system is ready to make real money trades!")
    print("\nTo start trading, run:")
    print("python auto_trader_simple.py")
else:
    print("\n⚠️ SOME TESTS FAILED. Please fix the issues above before trading.")

print("\n" + "="*60 + "\n")