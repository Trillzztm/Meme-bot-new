"""
Solana Transaction Signing for SMART MEMES BOT

This module provides utilities for securely signing and executing 
Solana transactions with proper keypair handling and safety checks.
"""

import os
import time
import json
import base58
import base64
import logging
from typing import Dict, Any, List, Optional, Union, Tuple

# Import Solana libraries for transaction signing
from solana.rpc.api import Client
from solana.transaction import Transaction, AccountMeta, TransactionInstruction
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.rpc.types import TxOpts
from solders.signature import Signature

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SolanaTransactionSigner")

# Constants
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"  # Use a reliable RPC endpoint
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")
TRANSACTION_HISTORY_FILE = "real_transactions.json"

# Initialize Solana client
client = Client(SOLANA_RPC_URL)

class TransactionSigner:
    """Class for handling Solana transaction signing and execution"""
    
    def __init__(self, private_key: Optional[str] = None):
        """
        Initialize transaction signer
        
        Args:
            private_key: Solana private key in base58 format
        """
        self.private_key = private_key or SOLANA_PRIVATE_KEY
        self.keypair = self._load_keypair()
        self.wallet_address = str(self.keypair.public_key) if self.keypair else None
    
    def _load_keypair(self) -> Optional[Keypair]:
        """
        Load Solana keypair from private key
        
        Returns:
            Keypair or None if key is not available
        """
        if not self.private_key:
            logger.error("No private key provided")
            return None
        
        try:
            # Convert base58 private key to bytes
            private_key_bytes = base58.b58decode(self.private_key)
            return Keypair.from_secret_key(private_key_bytes)
        except Exception as e:
            logger.error(f"Error loading keypair: {e}")
            return None
    
    def is_ready(self) -> bool:
        """Check if transaction signer is ready with a valid keypair"""
        return self.keypair is not None
    
    def sign_transaction(self, transaction: Transaction) -> Optional[Transaction]:
        """
        Sign a Solana transaction
        
        Args:
            transaction: Transaction to sign
            
        Returns:
            Signed transaction or None if signing fails
        """
        if not self.is_ready():
            logger.error("Transaction signer not ready (no keypair)")
            return None
        
        try:
            # Add the keypair as a signer
            transaction.sign(self.keypair)
            return transaction
        except Exception as e:
            logger.error(f"Error signing transaction: {e}")
            return None
    
    def sign_and_send_transaction(
        self, 
        transaction: Transaction, 
        skip_preflight: bool = False,
        commitment: str = "confirmed"
    ) -> Dict[str, Any]:
        """
        Sign and send a transaction to the Solana network
        
        Args:
            transaction: Transaction to sign and send
            skip_preflight: Whether to skip the preflight transaction check
            commitment: Desired commitment level
            
        Returns:
            Dictionary with transaction result
        """
        if not self.is_ready():
            return {"error": "Transaction signer not ready (no keypair)"}
        
        try:
            # Sign the transaction
            signed_tx = self.sign_transaction(transaction)
            if not signed_tx:
                return {"error": "Failed to sign transaction"}
            
            # Send the transaction
            opts = TxOpts(skip_preflight=skip_preflight, preflight_commitment=commitment)
            response = client.send_transaction(signed_tx, self.keypair, opts=opts)
            
            if "result" in response:
                tx_hash = response["result"]
                logger.info(f"Transaction sent: {tx_hash}")
                
                # Record the transaction
                self._record_transaction(tx_hash, "success", "Transaction sent")
                
                # Wait for confirmation if desired
                try:
                    time.sleep(1)  # Brief pause to allow transaction to propagate
                    confirmation = client.confirm_transaction(tx_hash)
                    if confirmation and confirmation.get("result", {}).get("value", {}).get("err") is None:
                        logger.info(f"Transaction confirmed: {tx_hash}")
                        return {
                            "success": True,
                            "tx_hash": tx_hash,
                            "confirmation": confirmation
                        }
                    else:
                        logger.warning(f"Transaction may have failed: {tx_hash}")
                        error_details = confirmation.get("result", {}).get("value", {}).get("err", "Unknown error")
                        
                        # Record the failure
                        self._record_transaction(tx_hash, "error", f"Transaction failed: {error_details}")
                        
                        return {
                            "success": False,
                            "tx_hash": tx_hash,
                            "error": error_details
                        }
                except Exception as e:
                    logger.warning(f"Error confirming transaction: {e}")
                    # Even if confirmation fails, the transaction might have succeeded
                    return {
                        "success": True,  # Assume success if we got a hash
                        "tx_hash": tx_hash,
                        "confirmation_error": str(e)
                    }
            else:
                error_msg = response.get("error", {}).get("message", "Unknown error")
                logger.error(f"Failed to send transaction: {error_msg}")
                
                # Record the failure
                self._record_transaction(None, "error", f"Failed to send: {error_msg}")
                
                return {
                    "success": False,
                    "error": error_msg
                }
        except Exception as e:
            logger.error(f"Error in sign_and_send_transaction: {e}")
            
            # Record the failure
            self._record_transaction(None, "error", f"Exception: {str(e)}")
            
            return {
                "success": False,
                "error": str(e)
            }
    
    def decode_transaction(self, encoded_tx: str) -> Optional[Transaction]:
        """
        Decode a base64-encoded transaction
        
        Args:
            encoded_tx: Base64-encoded transaction
            
        Returns:
            Decoded Transaction object or None if decoding fails
        """
        try:
            # Decode from base64
            tx_bytes = base64.b64decode(encoded_tx)
            
            # Deserialize into a Transaction object
            transaction = Transaction.deserialize(tx_bytes)
            return transaction
        except Exception as e:
            logger.error(f"Error decoding transaction: {e}")
            return None
    
    def _record_transaction(self, tx_hash: Optional[str], status: str, message: str) -> None:
        """
        Record a transaction in the history file
        
        Args:
            tx_hash: Transaction hash (signature)
            status: Transaction status (success/error)
            message: Additional message or details
        """
        try:
            # Load existing transactions
            history = self._load_transaction_history()
            
            # Add new transaction
            history.append({
                "timestamp": time.time(),
                "tx_hash": tx_hash,
                "wallet": self.wallet_address,
                "status": status,
                "message": message
            })
            
            # Save updated history
            with open(TRANSACTION_HISTORY_FILE, "w") as f:
                json.dump(history, f, indent=2)
        except Exception as e:
            logger.error(f"Error recording transaction: {e}")
    
    def _load_transaction_history(self) -> List[Dict[str, Any]]:
        """
        Load transaction history from file
        
        Returns:
            List of transaction records
        """
        if not os.path.exists(TRANSACTION_HISTORY_FILE):
            return []
        
        try:
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading transaction history: {e}")
            return []

def create_sol_transfer_instruction(
    from_pubkey: Union[str, PublicKey],
    to_pubkey: Union[str, PublicKey],
    lamports: int
) -> TransactionInstruction:
    """
    Create a SOL transfer instruction
    
    Args:
        from_pubkey: Sender public key
        to_pubkey: Recipient public key
        lamports: Amount in lamports to transfer
        
    Returns:
        TransactionInstruction for SOL transfer
    """
    # Convert string addresses to PublicKey if needed
    if isinstance(from_pubkey, str):
        from_pubkey = PublicKey(from_pubkey)
    if isinstance(to_pubkey, str):
        to_pubkey = PublicKey(to_pubkey)
    
    # System program ID for transfers
    system_program_id = PublicKey("11111111111111111111111111111111")
    
    # Create the instruction
    transfer_instruction = TransactionInstruction(
        keys=[
            AccountMeta(pubkey=from_pubkey, is_signer=True, is_writable=True),
            AccountMeta(pubkey=to_pubkey, is_signer=False, is_writable=True),
        ],
        program_id=system_program_id,
        data=bytes([2, 0, 0, 0]) + lamports.to_bytes(8, byteorder="little")  # Transfer instruction + amount
    )
    
    return transfer_instruction

def transfer_sol(
    to_address: str,
    amount_sol: float,
    signer: Optional[TransactionSigner] = None
) -> Dict[str, Any]:
    """
    Transfer SOL to another address
    
    Args:
        to_address: Recipient address
        amount_sol: Amount of SOL to transfer
        signer: Optional TransactionSigner instance
        
    Returns:
        Dict with transfer result
    """
    # Use provided signer or create a new one
    if signer is None:
        signer = TransactionSigner()
    
    if not signer.is_ready():
        return {"error": "No valid keypair available"}
    
    try:
        # Convert SOL to lamports
        lamports = int(amount_sol * 10**9)
        
        # Get a recent blockhash
        blockhash_resp = client.get_recent_blockhash()
        if "result" not in blockhash_resp:
            return {"error": "Failed to get recent blockhash"}
        
        blockhash = blockhash_resp["result"]["value"]["blockhash"]
        
        # Create a new transaction
        transaction = Transaction(recent_blockhash=blockhash)
        
        # Add the transfer instruction
        transfer_ix = create_sol_transfer_instruction(
            signer.wallet_address,
            to_address,
            lamports
        )
        transaction.add(transfer_ix)
        
        # Sign and send the transaction
        result = signer.sign_and_send_transaction(transaction)
        
        if result.get("success"):
            return {
                "success": True,
                "tx_hash": result["tx_hash"],
                "amount_sol": amount_sol,
                "to_address": to_address,
                "message": "SOL transfer successful"
            }
        else:
            return {
                "success": False,
                "error": result.get("error", "Unknown error"),
                "amount_sol": amount_sol,
                "to_address": to_address
            }
    except Exception as e:
        logger.error(f"Error in SOL transfer: {e}")
        return {
            "success": False,
            "error": str(e),
            "amount_sol": amount_sol,
            "to_address": to_address
        }

def test_transaction_signer():
    """Test the transaction signer"""
    signer = TransactionSigner()
    
    if not signer.is_ready():
        logger.error("Transaction signer not ready. Check SOLANA_PRIVATE_KEY.")
        return {
            "success": False,
            "error": "No valid keypair available"
        }
    
    # Get wallet balance
    try:
        response = client.get_balance(PublicKey(signer.wallet_address))
        balance_lamports = response["result"]["value"]
        balance_sol = balance_lamports / 10**9
        
        return {
            "success": True,
            "wallet_address": signer.wallet_address,
            "balance_lamports": balance_lamports,
            "balance_sol": balance_sol
        }
    except Exception as e:
        logger.error(f"Error testing transaction signer: {e}")
        return {
            "success": False,
            "error": str(e)
        }

if __name__ == "__main__":
    # Test the transaction signer
    print("Testing Solana Transaction Signer...")
    result = test_transaction_signer()
    
    for key, value in result.items():
        print(f"{key}: {value}")