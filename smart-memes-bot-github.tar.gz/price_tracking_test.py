"""
Test script for the enhanced price tracking system with API resilience features.

This script tests the improved price tracking functionality to ensure
it continues to function even when external APIs experience outages.
"""

import asyncio
import logging
import time
from typing import Dict, Any, List

from utils.price_tracker import schedule_price_check, get_price_tracking_status
from utils.group_scoring import (
    log_token_mention, 
    log_token_result,
    get_group_performance,
    get_top_groups
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Test tokens (known valid tokens)
TEST_TOKENS = [
    # USDC - very established token
    {
        "address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "name": "USDC",
        "type": "established"
    },
    
    # SOL - native token
    {
        "address": "So11111111111111111111111111111111111111112",
        "name": "SOL",
        "type": "native" 
    },
    
    # BONK - popular meme token
    {
        "address": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
        "name": "BONK",
        "type": "meme"
    }
]

# Test group IDs
TEST_GROUPS = [123456789, 987654321, 135792468]

async def test_group_scoring():
    """Test group scoring system with resilience features."""
    logger.info("Testing group scoring system...")
    
    for group_id in TEST_GROUPS:
        # Get initial group performance
        initial_performance = await get_group_performance(group_id)
        logger.info(f"Initial group {group_id} performance: {initial_performance}")
        
        # Log mentions for tokens in this group
        for token in TEST_TOKENS:
            await log_token_mention(group_id, token["address"])
            logger.info(f"Logged mention for {token['name']} in group {group_id}")
        
        # Get updated group performance after mentions
        updated_performance = await get_group_performance(group_id)
        logger.info(f"Updated group {group_id} performance after mentions: {updated_performance}")
        
        # Verify mentions increased
        assert updated_performance["mentions"] > initial_performance["mentions"], "Mentions should increase"
    
    # Log some token results
    for token in TEST_TOKENS:
        # Simulate different results for different token types
        if token["type"] == "established":
            result = "win"
        elif token["type"] == "meme":
            result = "win"  # Meme tokens are also winning in this test
        else:
            result = "neutral"
            
        # Log result for first group
        updated_groups = await log_token_result(token["address"], result, TEST_GROUPS[0])
        logger.info(f"Logged {result} result for {token['name']}")
        
        if updated_groups:
            updated_group = updated_groups.get(str(TEST_GROUPS[0]))
            if updated_group:
                logger.info(f"Group {TEST_GROUPS[0]} after {token['name']} {result}: {updated_group}")
    
    # Get top groups
    top_groups = await get_top_groups(limit=3)
    logger.info(f"Top groups: {top_groups}")
    
    logger.info("Group scoring test completed successfully!")

async def test_price_tracking():
    """Test price tracking system with resilience features."""
    logger.info("Testing price tracking system...")
    
    # Schedule price checks for test tokens
    for token in TEST_TOKENS:
        # Simulate a transaction ID
        tx_id = int(time.time()) % 10000 + TEST_TOKENS.index(token)
        
        # Simulate an entry price
        entry_price = 1.0 if token["type"] == "established" else 0.0001
        
        # Simulate tokens received
        tokens_received = 100 if token["type"] == "established" else 1000000
        
        # Schedule price check
        schedule_price_check(
            token_address=token["address"],
            transaction_id=tx_id,
            entry_price=entry_price,
            tokens_received=tokens_received
        )
        
        logger.info(f"Scheduled price tracking for {token['name']} (TX: {tx_id})")
    
    # Give some time for initial price checks
    logger.info("Waiting for initial price checks...")
    await asyncio.sleep(5)
    
    # Get price tracking status
    status = await get_price_tracking_status()
    logger.info(f"Price tracking status: {status}")
    
    if status["active_count"] > 0:
        logger.info(f"Active price tracking: {len(status['tokens'])} tokens")
        for token_data in status["tokens"]:
            logger.info(f"  {token_data['token_address']}: Entry ${token_data['entry_price']}, Current ${token_data['last_price']}")
    else:
        logger.warning("No active price tracking found!")
    
    logger.info("Price tracking test completed!")

async def test_resilience():
    """Test system resilience during API outages."""
    logger.info("Testing system resilience during API outages...")
    
    # This test would normally mock API outages, but for simplicity
    # we'll just check that the functions don't throw exceptions
    try:
        # Test price tracking during simulated API outage
        for token in TEST_TOKENS:
            # Schedule with invalid data to test error handling
            tx_id = int(time.time()) % 10000 + 1000 + TEST_TOKENS.index(token)
            schedule_price_check(
                token_address=token["address"],
                transaction_id=tx_id,
                entry_price=None,  # Invalid entry price
                tokens_received=None  # Invalid tokens received
            )
            logger.info(f"Scheduled price tracking with invalid data for {token['name']} (TX: {tx_id})")
        
        # Give some time for price checks
        logger.info("Waiting for price checks with invalid data...")
        await asyncio.sleep(5)
        
        # Should still be able to get status
        status = await get_price_tracking_status()
        logger.info(f"Price tracking status after simulated API outage: {status}")
        
        logger.info("Resilience test completed successfully!")
    except Exception as e:
        logger.error(f"Resilience test failed: {str(e)}")
        raise

async def main():
    """Run all tests."""
    logger.info("Starting price tracking and group scoring tests...")
    
    try:
        # Test group scoring system
        await test_group_scoring()
        
        print("\n" + "-"*50 + "\n")
        
        # Test price tracking system
        await test_price_tracking()
        
        print("\n" + "-"*50 + "\n")
        
        # Test resilience
        await test_resilience()
        
        logger.info("All tests completed successfully!")
    except Exception as e:
        logger.error(f"Tests failed: {str(e)}")
        raise

if __name__ == "__main__":
    # Run the test
    asyncio.run(main())