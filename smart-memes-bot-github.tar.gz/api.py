"""
High-Level API for SMART MEMES BOT.

This module provides a simplified high-level API for interacting with all the
bot's profit-making systems, including Flash Loan Arbitrage, MEV Optimization,
Enhanced Token Safety, Twitter Signal Enhancement, Cross-Chain Arbitrage,
AI-Enhanced Trading, Advanced Slippage Management, and Transaction Speed Enhancement.

It acts as a facade over the individual components, providing a unified
interface for bot users and maintainers.
"""

import logging
import asyncio
from typing import Dict, List, Tuple, Optional, Union, Any

# Import profit controller
try:
    from utils.advanced_profit_controller import get_profit_controller
    CONTROLLER_AVAILABLE = True
except ImportError:
    CONTROLLER_AVAILABLE = False
    logging.warning("Advanced profit controller not available")

# Import individual components for direct access when needed
try:
    from utils.flash_loan_arbitrage import (
        get_arbitrage_engine, start_arbitrage_monitoring,
        stop_arbitrage_monitoring, get_arbitrage_statistics
    )
    ARBITRAGE_AVAILABLE = True
except ImportError:
    ARBITRAGE_AVAILABLE = False

try:
    from utils.mev_optimizer import (
        get_mev_optimizer, protect_transaction,
        create_mev_bundle, get_mev_statistics
    )
    MEV_AVAILABLE = True
except ImportError:
    MEV_AVAILABLE = False

try:
    from utils.enhanced_token_safety import (
        analyze_token_safety, get_safety_recommendation
    )
    ENHANCED_SAFETY_AVAILABLE = True
except ImportError:
    ENHANCED_SAFETY_AVAILABLE = False

try:
    from utils.twitter_signal_enhancement import (
        start_twitter_monitoring, stop_twitter_monitoring,
        get_recent_signals, get_signal_for_token
    )
    TWITTER_ENHANCEMENT_AVAILABLE = True
except ImportError:
    TWITTER_ENHANCEMENT_AVAILABLE = False

try:
    from ai.trade_parameter_optimizer import (
        optimize_trade_parameters, record_transaction_result
    )
    TRADE_OPTIMIZER_AVAILABLE = True
except ImportError:
    TRADE_OPTIMIZER_AVAILABLE = False

try:
    from utils.cross_chain_arbitrage import (
        get_cross_chain_arbitrage, start_cc_arbitrage_monitoring,
        stop_cc_arbitrage_monitoring, get_cc_arbitrage_statistics
    )
    CROSS_CHAIN_ARBITRAGE_AVAILABLE = True
except ImportError:
    CROSS_CHAIN_ARBITRAGE_AVAILABLE = False

try:
    from utils.advanced_slippage_management import (
        get_slippage_manager, calculate_optimal_slippage,
        analyze_liquidity_depth, optimize_transaction_for_slippage
    )
    SLIPPAGE_MANAGEMENT_AVAILABLE = True
except ImportError:
    SLIPPAGE_MANAGEMENT_AVAILABLE = False

try:
    from utils.transaction_speed_enhancement import (
        get_transaction_enhancer, enhance_transaction_speed,
        execute_transaction_with_retries, get_recommended_priority_fee
    )
    TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE = True
except ImportError:
    TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE = False

try:
    from utils.ai_trade_fallback import (
        get_trade_fallback_system, execute_trade_with_fallback,
        get_system_status as get_fallback_status
    )
    AI_TRADE_FALLBACK_AVAILABLE = True
except ImportError:
    AI_TRADE_FALLBACK_AVAILABLE = False

# Configure logging
logger = logging.getLogger(__name__)

# ============================
# System Control Functions
# ============================

async def start_profit_systems() -> bool:
    """
    Start all profit systems.
    
    Returns:
        Success status
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot start profit systems: controller not available")
        return False
    
    controller = await get_profit_controller()
    return await controller.start()

async def stop_profit_systems() -> bool:
    """
    Stop all profit systems.
    
    Returns:
        Success status
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot stop profit systems: controller not available")
        return False
    
    controller = await get_profit_controller()
    return await controller.stop()

async def set_risk_profile(profile: str) -> bool:
    """
    Set the risk profile for all profit systems.
    
    Args:
        profile: Risk profile (conservative, balanced, aggressive)
        
    Returns:
        Success status
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot set risk profile: controller not available")
        return False
    
    controller = await get_profit_controller()
    return await controller.set_risk_profile(profile)

async def enable_strategy(strategy: str, enabled: bool) -> bool:
    """
    Enable or disable a profit strategy.
    
    Args:
        strategy: Strategy name (flash_loan_arbitrage, mev_optimization, etc.)
        enabled: Whether to enable or disable the strategy
        
    Returns:
        Success status
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot enable/disable strategy: controller not available")
        return False
    
    controller = await get_profit_controller()
    return await controller.enable_strategy(strategy, enabled)

async def get_profit_statistics(days: int = 30) -> Dict[str, Any]:
    """
    Get performance statistics for the profit systems.
    
    Args:
        days: Number of days to include in the statistics
        
    Returns:
        Dictionary of statistics
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot get statistics: controller not available")
        return {"error": "Controller not available"}
    
    controller = await get_profit_controller()
    return controller.get_stats(days)

# ============================
# Token Safety Functions
# ============================

async def check_token_safety(token_address: str) -> Tuple[int, Dict[str, Any]]:
    """
    Analyze token safety with enhanced methods.
    
    Args:
        token_address: Token address to analyze
        
    Returns:
        Tuple of (safety score, detailed analysis)
    """
    if not ENHANCED_SAFETY_AVAILABLE:
        logger.error("Cannot check token safety: enhanced safety not available")
        return 0, {"error": "Enhanced safety not available"}
    
    return await analyze_token_safety(token_address)

async def get_token_trade_recommendation(token_address: str) -> Dict[str, Any]:
    """
    Get trading recommendations based on token safety analysis.
    
    Args:
        token_address: Token address to analyze
        
    Returns:
        Dictionary with safety assessment and recommendations
    """
    if not ENHANCED_SAFETY_AVAILABLE:
        logger.error("Cannot get trade recommendation: enhanced safety not available")
        return {"error": "Enhanced safety not available"}
    
    return await get_safety_recommendation(token_address)

# ============================
# Trading Functions
# ============================

async def optimize_trade(trade_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Optimize a trade with AI-enhanced parameters and MEV protection.
    
    Args:
        trade_data: Trade information including token, amount, side
        
    Returns:
        Enhanced trade data
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot optimize trade: controller not available")
        return trade_data
    
    controller = await get_profit_controller()
    return await controller.process_trade(trade_data)

async def record_trade_result(token_address: str, result_data: Dict[str, Any]) -> bool:
    """
    Record the results of a trade for learning and statistics.
    
    Args:
        token_address: Token address
        result_data: Result information including success status, profit/loss
        
    Returns:
        Success status
    """
    if not CONTROLLER_AVAILABLE:
        logger.error("Cannot record trade result: controller not available")
        return False
    
    controller = await get_profit_controller()
    return await controller.record_trade_result(token_address, result_data)

# ============================
# Twitter Signal Functions
# ============================

async def get_token_signals(min_confidence: float = 0.6, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Get recent high-confidence token signals from Twitter.
    
    Args:
        min_confidence: Minimum confidence threshold
        limit: Maximum number of signals to return
        
    Returns:
        List of recent signals above the confidence threshold
    """
    if not TWITTER_ENHANCEMENT_AVAILABLE:
        logger.error("Cannot get token signals: Twitter enhancement not available")
        return []
    
    return await get_recent_signals(min_confidence, limit)

async def get_token_signal(token_address: str) -> Optional[Dict[str, Any]]:
    """
    Get the most recent Twitter signal for a specific token.
    
    Args:
        token_address: Token address
        
    Returns:
        Most recent signal for the token or None if not found
    """
    if not TWITTER_ENHANCEMENT_AVAILABLE:
        logger.error("Cannot get token signal: Twitter enhancement not available")
        return None
    
    return await get_signal_for_token(token_address)

# ============================
# Arbitrage Functions
# ============================

async def get_arbitrage_stats() -> Dict[str, Any]:
    """
    Get statistics from the flash loan arbitrage system.
    
    Returns:
        Dictionary of arbitrage statistics
    """
    if not ARBITRAGE_AVAILABLE:
        logger.error("Cannot get arbitrage stats: Flash loan arbitrage not available")
        return {}
    
    return await get_arbitrage_statistics()

# ============================
# MEV Functions
# ============================

async def get_mev_stats() -> Dict[str, Any]:
    """
    Get statistics from the MEV optimization system.
    
    Returns:
        Dictionary of MEV optimization statistics
    """
    if not MEV_AVAILABLE:
        logger.error("Cannot get MEV stats: MEV optimization not available")
        return {}
    
    return await get_mev_statistics()

async def protect_mev(transaction_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Apply MEV protection to a transaction.
    
    Args:
        transaction_data: Transaction details
        
    Returns:
        Protected transaction data
    """
    if not MEV_AVAILABLE:
        logger.error("Cannot protect transaction: MEV optimization not available")
        return transaction_data
    
    return await protect_transaction(transaction_data)

# ============================
# Cross-Chain Arbitrage Functions
# ============================

async def get_cross_chain_arbitrage_stats() -> Dict[str, Any]:
    """
    Get statistics from the cross-chain arbitrage system.
    
    Returns:
        Dictionary of cross-chain arbitrage statistics
    """
    if not CROSS_CHAIN_ARBITRAGE_AVAILABLE:
        logger.error("Cannot get cross-chain arbitrage stats: Cross-chain arbitrage not available")
        return {}
    
    return await get_cc_arbitrage_statistics()

async def start_cross_chain_arbitrage() -> bool:
    """
    Start cross-chain arbitrage monitoring.
    
    Returns:
        Success status
    """
    if not CROSS_CHAIN_ARBITRAGE_AVAILABLE:
        logger.error("Cannot start cross-chain arbitrage: Cross-chain arbitrage not available")
        return False
    
    await start_cc_arbitrage_monitoring()
    return True

async def stop_cross_chain_arbitrage() -> bool:
    """
    Stop cross-chain arbitrage monitoring.
    
    Returns:
        Success status
    """
    if not CROSS_CHAIN_ARBITRAGE_AVAILABLE:
        logger.error("Cannot stop cross-chain arbitrage: Cross-chain arbitrage not available")
        return False
    
    await stop_cc_arbitrage_monitoring()
    return True

# ============================
# Advanced Slippage Management Functions
# ============================

async def get_optimal_slippage(token_address: str, 
                             token_symbol: Optional[str] = None,
                             trade_size: Optional[float] = None,
                             side: str = "buy") -> float:
    """
    Calculate optimal slippage for a token trade.
    
    Args:
        token_address: Token address
        token_symbol: Optional token symbol
        trade_size: Optional trade size in USD
        side: Trade side ("buy" or "sell")
        
    Returns:
        Optimal slippage percentage
    """
    if not SLIPPAGE_MANAGEMENT_AVAILABLE:
        logger.warning("Cannot calculate optimal slippage: Slippage management not available")
        return 0.005  # Default 0.5% slippage
    
    return await calculate_optimal_slippage(token_address, token_symbol, trade_size, side)

async def get_liquidity_analysis(token_address: str, side: str = "buy") -> Dict[str, Any]:
    """
    Analyze liquidity depth for a token.
    
    Args:
        token_address: Token address
        side: Trade side ("buy" or "sell")
        
    Returns:
        Dictionary with liquidity analysis
    """
    if not SLIPPAGE_MANAGEMENT_AVAILABLE:
        logger.error("Cannot analyze liquidity: Slippage management not available")
        return {"error": "Slippage management not available"}
    
    return await analyze_liquidity_depth(token_address, side)

async def optimize_slippage(transaction_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Optimize a transaction's slippage settings.
    
    Args:
        transaction_data: Transaction details
        
    Returns:
        Optimized transaction data
    """
    if not SLIPPAGE_MANAGEMENT_AVAILABLE:
        logger.warning("Cannot optimize slippage: Slippage management not available")
        return transaction_data
    
    return await optimize_transaction_for_slippage(transaction_data)

# ============================
# Transaction Speed Enhancement Functions
# ============================

async def enhance_transaction(transaction_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Enhance a transaction for optimal speed and reliability.
    
    Args:
        transaction_data: Transaction details
        
    Returns:
        Enhanced transaction data
    """
    if not TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE:
        logger.warning("Cannot enhance transaction speed: Speed enhancement not available")
        return transaction_data
    
    return await enhance_transaction_speed(transaction_data)

async def execute_with_retries(transaction_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute a transaction with automatic retries and optimizations.
    
    Args:
        transaction_data: Transaction details
        
    Returns:
        Transaction result
    """
    if not TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE:
        logger.warning("Cannot execute with retries: Speed enhancement not available")
        return {"success": False, "error": "Speed enhancement not available"}
    
    return await execute_transaction_with_retries(transaction_data)

async def get_priority_fee(chain: str, priority_tier: str = "normal") -> int:
    """
    Get recommended priority fee for a transaction.
    
    Args:
        chain: Blockchain name
        priority_tier: Priority tier ("low", "normal", "high", "urgent")
        
    Returns:
        Recommended priority fee
    """
    if not TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE:
        logger.warning("Cannot get priority fee: Speed enhancement not available")
        return 0
    
    return await get_recommended_priority_fee(chain, priority_tier)

# ============================
# AI Trade Fallback Functions
# ============================

async def trade_with_fallback(trade_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute a trade with fallback mechanisms if primary methods fail.
    
    Args:
        trade_data: Trade information
        
    Returns:
        Trade result
    """
    if not AI_TRADE_FALLBACK_AVAILABLE:
        logger.warning("Cannot use trade fallback: AI trade fallback not available")
        return {"success": False, "error": "AI trade fallback not available"}
    
    return await execute_trade_with_fallback(trade_data)

def get_fallback_system_status() -> Dict[str, Any]:
    """
    Get the current status of the fallback trading system.
    
    Returns:
        System status information
    """
    if not AI_TRADE_FALLBACK_AVAILABLE:
        logger.warning("Cannot get fallback status: AI trade fallback not available")
        return {"error": "AI trade fallback not available"}
    
    return get_fallback_status()

# ============================
# End-to-End Functions
# ============================

async def analyze_and_trade(token_address: str, amount: float, side: str = "buy") -> Dict[str, Any]:
    """
    Perform comprehensive analysis and execute an optimized trade.
    
    Args:
        token_address: Token address to trade
        amount: Amount to trade
        side: Trade side ("buy" or "sell")
        
    Returns:
        Dictionary with trade results
    """
    try:
        # 1. Check token safety
        safety_score = 0
        if ENHANCED_SAFETY_AVAILABLE:
            safety_score, safety_details = await check_token_safety(token_address)
            
            # Skip unsafe tokens
            if safety_score < 50:
                return {
                    "success": False,
                    "error": "Token failed safety check",
                    "safety_score": safety_score,
                    "issues": safety_details.get("issues", [])
                }
        
        # 2. Check Twitter signals for additional confidence
        signal_data = None
        if TWITTER_ENHANCEMENT_AVAILABLE:
            signal_data = await get_token_signal(token_address)
        
        # 3. Calculate optimal slippage
        slippage = 0.005  # Default 0.5% slippage
        if SLIPPAGE_MANAGEMENT_AVAILABLE:
            slippage = await get_optimal_slippage(token_address, None, amount, side)
        
        # 4. Create trade data
        trade_data = {
            "token_address": token_address,
            "amount": amount,
            "side": side,
            "slippage_percentage": slippage,
            "safety_score": safety_score,
            "signal_data": signal_data,
            "chain": "solana",  # Default to Solana
            "priority_tier": "normal"  # Default priority tier
        }
        
        # 5. Enhance transaction speed
        if TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE:
            trade_data = await enhance_transaction(trade_data)
        
        # 6. Optimize trade parameters with controller
        if CONTROLLER_AVAILABLE:
            controller = await get_profit_controller()
            optimized_trade = await controller.process_trade(trade_data)
            trade_data.update(optimized_trade)
        
        # 7. Execute with fallback if available
        if AI_TRADE_FALLBACK_AVAILABLE:
            result = await trade_with_fallback(trade_data)
        else:
            # Simulate successful trade
            result = {
                "success": True,
                "token_address": token_address,
                "executed_price": 0.0,
                "executed_amount": 0.0,
                "transaction_hash": f"simulated_tx_{int(time.time()*1000)}",
                "message": "Trade would be executed in a real implementation"
            }
        
        # 8. Return comprehensive result
        return {
            "success": result.get("success", False),
            "token_address": token_address,
            "trade_data": trade_data,
            "result": result,
            "optimizations_applied": {
                "safety_check": ENHANCED_SAFETY_AVAILABLE,
                "signal_analysis": TWITTER_ENHANCEMENT_AVAILABLE and signal_data is not None,
                "slippage_optimization": SLIPPAGE_MANAGEMENT_AVAILABLE,
                "speed_enhancement": TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE,
                "ai_optimization": CONTROLLER_AVAILABLE,
                "fallback_protection": AI_TRADE_FALLBACK_AVAILABLE
            }
        }
        
    except Exception as e:
        logger.error(f"Error in analyze_and_trade: {str(e)}")
        return {
            "success": False,
            "error": str(e)
        }

# ============================
# Health/Status Functions
# ============================

async def get_system_status() -> Dict[str, Any]:
    """
    Get comprehensive status of all profit systems.
    
    Returns:
        Dictionary with status information
    """
    status = {
        "controller_available": CONTROLLER_AVAILABLE,
        "arbitrage_available": ARBITRAGE_AVAILABLE,
        "mev_available": MEV_AVAILABLE,
        "enhanced_safety_available": ENHANCED_SAFETY_AVAILABLE,
        "twitter_enhancement_available": TWITTER_ENHANCEMENT_AVAILABLE,
        "trade_optimizer_available": TRADE_OPTIMIZER_AVAILABLE,
        "cross_chain_arbitrage_available": CROSS_CHAIN_ARBITRAGE_AVAILABLE,
        "slippage_management_available": SLIPPAGE_MANAGEMENT_AVAILABLE,
        "transaction_speed_enhancement_available": TRANSACTION_SPEED_ENHANCEMENT_AVAILABLE,
        "ai_trade_fallback_available": AI_TRADE_FALLBACK_AVAILABLE,
        "systems_running": False,
        "active_strategies": [],
        "stats": {}
    }
    
    if CONTROLLER_AVAILABLE:
        controller = await get_profit_controller()
        status["systems_running"] = controller.running
        
        # Get active strategies
        for name, settings in controller.config.get("strategies", {}).items():
            if settings.get("enabled", False):
                status["active_strategies"].append(name)
        
        # Get recent stats
        status["stats"] = controller.get_stats(days=7)
    
    # Get fallback system status if available
    if AI_TRADE_FALLBACK_AVAILABLE:
        status["fallback_system"] = get_fallback_system_status()
    
    # Get cross-chain arbitrage stats if available
    if CROSS_CHAIN_ARBITRAGE_AVAILABLE:
        status["cross_chain_stats"] = await get_cross_chain_arbitrage_stats()
    
    return status