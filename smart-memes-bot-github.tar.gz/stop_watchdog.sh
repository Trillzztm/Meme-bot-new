#!/bin/bash
# Stop Watchdog Script - SMART MEMES BOT
# This script stops the watchdog and auto trader processes

echo "==============================================="
echo "SMART MEMES BOT - STOP WATCHDOG"
echo "==============================================="
echo

# Kill any existing auto trader processes
pkill -f "python auto_trader_simple.py" > /dev/null 2>&1
echo "✅ Stopped Auto Trader processes"

# Kill any existing watchdog processes
pkill -f "python watchdog.py" > /dev/null 2>&1
echo "✅ Stopped Watchdog process"

# Clean up PID files
if [ -f "auto_trader.pid" ]; then
  rm auto_trader.pid
  echo "✅ Removed Auto Trader PID file"
fi

if [ -f "watchdog.pid" ]; then
  rm watchdog.pid
  echo "✅ Removed Watchdog PID file"
fi

echo
echo "💰 Trading has been stopped. Your profits are safe!"
echo "Check auto_trader_profits.json to see your total profits."
echo

# Display current profits
if [ -f "auto_trader_profits.json" ]; then
  TOTAL_PROFIT=$(grep "total_profit_usd" auto_trader_profits.json | cut -d':' -f2 | cut -d',' -f1)
  echo "💵 Current total profit: $TOTAL_PROFIT"
  echo
fi

echo "To start trading again with enhanced reliability, run: ./start_watchdog.sh"
echo
echo "==============================================="