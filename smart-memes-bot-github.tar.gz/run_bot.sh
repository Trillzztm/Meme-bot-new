#!/bin/bash
cd /home/runner/workspace
python crypto_bot.py > crypto_bot.log 2>&1
