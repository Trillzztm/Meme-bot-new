"""
Test script for the Enhanced Smart Sniper.

This script demonstrates how the Enhanced Smart Sniper integrates with all our
profit-making systems to make intelligent sniping decisions.
"""

import asyncio
import logging
import json
from utils.enhanced_smart_sniper import smart_snipe, legacy_smart_sniper

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Test data for comparison
test_cases = [
    {
        "name": "High-quality launch with strong signals",
        "token_address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC on Solana for testing
        "token_symbol": "TEST1",
        "group_score": 0.95,
        "wallet_score": 0.92,
        "message_text": "🚀 Just launched! Our new token is live with locked liquidity for 6 months. Chart looking healthy, marketing starting now. Fair launch, no presale.",
        "liquidity": 150000,
        "market_cap": 300000,
        "expected_outcome": "snipe"
    },
    {
        "name": "Medium-quality launch with mixed signals",
        "token_address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "token_symbol": "TEST2",
        "group_score": 0.82,
        "wallet_score": 0.79,
        "message_text": "New token launching now. Chart live. Early stage gem with 100x potential.",
        "liquidity": 50000,
        "market_cap": 120000,
        "expected_outcome": "depends_on_risk_profile"
    },
    {
        "name": "Low-quality launch with red flags",
        "token_address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "token_symbol": "TEST3",
        "group_score": 0.71,
        "wallet_score": 0.65,
        "message_text": "🚨 LAUNCHING NOW! 1000x GEM! Claim fast before it's too late! Limited time opportunity, tax is only 20%!",
        "liquidity": 15000,
        "market_cap": 50000,
        "expected_outcome": "reject"
    },
    {
        "name": "Suspicious launch with scam indicators",
        "token_address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "token_symbol": "TEST4",
        "group_score": 0.60,
        "wallet_score": 0.55,
        "message_text": "NEW TOKEN LAUNCHED. Get in now! Dev from previous successful projects. Not a honeypot, not a scam! Trust us!",
        "liquidity": 5000,
        "market_cap": 25000,
        "expected_outcome": "reject"
    }
]

async def test_case(case, risk_profile):
    """Test a single case with a specific risk profile."""
    logger.info(f"Testing: {case['name']} with {risk_profile} risk profile")
    
    result = await smart_snipe(
        token_address=case["token_address"],
        token_symbol=case["token_symbol"],
        group_score=case["group_score"],
        wallet_score=case["wallet_score"],
        message_text=case["message_text"],
        liquidity=case.get("liquidity"),
        market_cap=case.get("market_cap"),
        risk_profile=risk_profile
    )
    
    # Log decision and confidence
    if result["snipe_scheduled"]:
        logger.info(f"✅ SNIPE SCHEDULED - Confidence: {result['confidence']:.2f}, Position: {result['position_size']:.4f} SOL")
        
        # Show which profit-making systems were applied
        optimizations = []
        if "evaluation" in result and "optimizations_applied" in result.get("evaluation", {}):
            for system, applied in result["evaluation"]["optimizations_applied"].items():
                if applied:
                    optimizations.append(system)
        if optimizations:
            logger.info(f"Systems applied: {', '.join(optimizations)}")
    else:
        logger.info(f"❌ SNIPE REJECTED - Reasons: {', '.join(result.get('reasons', ['Unknown']))}")
    
    return result

async def compare_with_legacy(case):
    """Compare the new sniper with the legacy implementation."""
    logger.info(f"Comparing new vs legacy sniper for: {case['name']}")
    
    # Convert to legacy format
    token_info = {
        "address": case["token_address"],
        "symbol": case["token_symbol"],
        "safety": case["group_score"],  # Approximate mapping
        "max_supply": 1000000
    }
    group_score = case["group_score"]
    wallet_score = case["wallet_score"]
    risk_class = "medium"  # Default risk class
    token_keywords = case["message_text"].split()
    
    # Run legacy sniper
    legacy_decision = legacy_smart_sniper(token_info, group_score, wallet_score, risk_class, token_keywords)
    logger.info(f"Legacy sniper decision: {'SNIPE' if legacy_decision else 'REJECT'}")
    
    # Run new sniper
    new_result = await smart_snipe(
        token_address=case["token_address"],
        token_symbol=case["token_symbol"],
        group_score=case["group_score"],
        wallet_score=case["wallet_score"],
        message_text=case["message_text"],
        risk_profile="balanced"
    )
    
    new_decision = new_result["snipe_scheduled"]
    logger.info(f"New sniper decision: {'SNIPE' if new_decision else 'REJECT'}")
    
    if legacy_decision != new_decision:
        logger.warning(f"Decision difference: Legacy={legacy_decision}, New={new_decision}")
        if new_decision:
            logger.info(f"New sniper confidence: {new_result['confidence']:.2f}")
            logger.info(f"Reasons for sniping: {new_result.get('evaluation', {}).get('reasons', ['Unknown'])}")
        else:
            logger.info(f"Reasons for rejection: {new_result.get('reasons', ['Unknown'])}")
    else:
        logger.info("Both systems made the same decision!")
    
    return {
        "case": case["name"],
        "legacy_decision": legacy_decision,
        "new_decision": new_decision,
        "new_confidence": new_result.get("confidence", 0),
        "new_reasons": new_result.get("reasons", [])
    }

async def main():
    """Run all tests."""
    logger.info("Starting Enhanced Smart Sniper tests")
    
    # Test all cases with all risk profiles
    risk_profiles = ["conservative", "balanced", "aggressive"]
    
    for case in test_cases:
        logger.info("=" * 80)
        logger.info(f"CASE: {case['name']}")
        
        results = {}
        for profile in risk_profiles:
            result = await test_case(case, profile)
            results[profile] = result["snipe_scheduled"]
        
        logger.info("-" * 40)
        logger.info(f"Decision summary for {case['name']}:")
        logger.info(f"Conservative: {'SNIPE' if results['conservative'] else 'REJECT'}")
        logger.info(f"Balanced: {'SNIPE' if results['balanced'] else 'REJECT'}")
        logger.info(f"Aggressive: {'SNIPE' if results['aggressive'] else 'REJECT'}")
        logger.info(f"Expected outcome: {case['expected_outcome'].upper()}")
        logger.info("-" * 40)
        
        # Compare with legacy implementation
        comparison = await compare_with_legacy(case)
    
    logger.info("=" * 80)
    logger.info("All tests completed")
    
    # Demonstrate how it integrates with our profit-making systems
    logger.info("\nDEMONSTRATING PROFIT SYSTEM INTEGRATION")
    logger.info("=" * 80)
    
    # Create a high-quality case to demonstrate all systems
    premium_case = {
        "name": "Premium token with all optimizations",
        "token_address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC on Solana
        "token_symbol": "PREMIUM",
        "group_score": 0.98,
        "wallet_score": 0.95,
        "message_text": "🔥 LAUNCHING NOW: Our premium token is live! Locked liquidity for 2 years, audited by 3 firms, incredible roadmap. Don't miss this rare opportunity!",
        "liquidity": 500000,
        "market_cap": 1000000
    }
    
    logger.info(f"Premium case: {premium_case['name']}")
    result = await smart_snipe(
        token_address=premium_case["token_address"],
        token_symbol=premium_case["token_symbol"],
        group_score=premium_case["group_score"],
        wallet_score=premium_case["wallet_score"],
        message_text=premium_case["message_text"],
        liquidity=premium_case["liquidity"],
        market_cap=premium_case["market_cap"],
        risk_profile="balanced"
    )
    
    if result["snipe_scheduled"]:
        logger.info(f"✅ PREMIUM SNIPE SCHEDULED - Confidence: {result['confidence']:.2f}, Position: {result['position_size']:.4f} SOL")
        
        # Show detailed evaluation
        if "evaluation" in result:
            eval_data = result["evaluation"]
            logger.info("\nDETAILED EVALUATION:")
            
            if "safety_score" in eval_data:
                logger.info(f"Token Safety Score: {eval_data['safety_score']:.2f}")
            
            if "twitter_signal" in eval_data:
                logger.info(f"Twitter Signal: {json.dumps(eval_data['twitter_signal'], indent=2)}")
            
            if "keyword_matches" in eval_data:
                logger.info(f"Keyword Matches: {', '.join(eval_data['keyword_matches'])}")
            
            if "exit_strategy" in eval_data:
                strategy = eval_data["exit_strategy"]
                logger.info(f"Exit Strategy: Take Profit at {strategy['take_profit']*100}%, Stop Loss at {strategy['stop_loss']*100}%, Trailing Stop {strategy['trailing_stop']*100}%")
    else:
        logger.info(f"❌ PREMIUM SNIPE REJECTED - Reasons: {', '.join(result.get('reasons', ['Unknown']))}")
    
    logger.info("=" * 80)
    logger.info("Test script completed")

if __name__ == "__main__":
    asyncio.run(main())