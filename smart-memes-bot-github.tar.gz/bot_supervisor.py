"""
Bot Supervisor - Ensures 24/7 operation without crashes.

This module monitors the bot and restarts it automatically if it crashes,
ensuring continuous profit generation without interruption.
"""

import os
import time
import signal
import logging
import threading
import subprocess
import json
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("BotSupervisor")

# Constants
MAX_RESTART_ATTEMPTS = 10
RESTART_COOLDOWN = 60  # seconds
HEALTH_CHECK_INTERVAL = 30  # seconds
HEALTH_FILE = "bot_health.txt"
LOG_FILE = "bot_supervisor.log"
KILL_TIMEOUT = 10  # seconds

# Global variables
running = True
bot_process = None
watchdog_thread = None


def write_health_status(status):
    """Write bot health status to file"""
    try:
        with open(HEALTH_FILE, "w") as f:
            health_data = {
                "timestamp": datetime.now().isoformat(),
                "status": status,
                "uptime": get_uptime()
            }
            f.write(json.dumps(health_data))
    except Exception as e:
        logger.error(f"Failed to write health status: {e}")


def get_uptime():
    """Get bot uptime in seconds"""
    if not hasattr(get_uptime, "start_time"):
        get_uptime.start_time = time.time()
    
    return int(time.time() - get_uptime.start_time)


def start_bot():
    """Start the trading bot process"""
    global bot_process
    
    try:
        logger.info("Starting the trading bot...")
        
        # Start the bot as a subprocess
        bot_process = subprocess.Popen(
            ["python3", "ultra_simple_app.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        
        logger.info(f"Bot started with PID: {bot_process.pid}")
        write_health_status("running")
        
        # Start a thread to read and log the bot's output
        threading.Thread(target=log_bot_output, daemon=True).start()
        
        return True
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
        return False


def log_bot_output():
    """Read and log the bot's output"""
    try:
        for line in bot_process.stdout:
            line = line.strip()
            if line:
                # Log critical errors and warnings for monitoring
                if "ERROR" in line or "CRITICAL" in line:
                    logger.error(f"Bot output: {line}")
                elif "WARNING" in line:
                    logger.warning(f"Bot output: {line}")
                else:
                    logger.debug(f"Bot output: {line}")
    except Exception as e:
        logger.error(f"Error reading bot output: {e}")


def stop_bot(force=False):
    """Stop the trading bot process"""
    global bot_process
    
    if bot_process is None:
        return True
    
    try:
        logger.info(f"Stopping bot (PID: {bot_process.pid})...")
        
        # Try to terminate gracefully first
        if bot_process.poll() is None:  # If the process is still running
            bot_process.terminate()
            
            # Wait for the process to terminate
            for _ in range(KILL_TIMEOUT):
                if bot_process.poll() is not None:
                    break
                time.sleep(1)
            
            # Force kill if still running and force flag is set
            if bot_process.poll() is None and force:
                logger.warning("Bot didn't terminate gracefully, force killing...")
                bot_process.kill()
        
        bot_process = None
        write_health_status("stopped")
        return True
    except Exception as e:
        logger.error(f"Error stopping bot: {e}")
        return False


def is_bot_running():
    """Check if the bot process is running"""
    return bot_process is not None and bot_process.poll() is None


def check_bot_health():
    """Check if the bot is healthy based on process status and logs"""
    if not is_bot_running():
        logger.warning("Bot process is not running")
        return False
    
    # Additional health checks could include:
    # - Checking if there's recent activity in logs
    # - Verifying the bot is making successful API calls
    # - Checking if profits are being recorded
    
    return True


def watchdog():
    """
    Watchdog thread that monitors and restarts the bot if needed.
    This ensures the bot is always running and making money.
    """
    global running
    restart_count = 0
    last_restart = 0
    
    logger.info("Watchdog thread started")
    
    while running:
        try:
            # Check if the bot is healthy
            if not check_bot_health():
                current_time = time.time()
                
                # Respect cooldown period between restarts
                if current_time - last_restart >= RESTART_COOLDOWN:
                    logger.warning("Bot appears to be unhealthy, attempting restart...")
                    
                    # Stop the bot if it's still running
                    stop_bot(force=True)
                    
                    # Start the bot
                    if start_bot():
                        logger.info("Bot restarted successfully")
                        restart_count += 1
                        last_restart = current_time
                    else:
                        logger.error("Failed to restart bot")
                    
                    # If we've restarted too many times, log a critical error
                    if restart_count >= MAX_RESTART_ATTEMPTS:
                        logger.critical(f"Bot has been restarted {restart_count} times, may need manual intervention")
            else:
                # Bot is healthy, update health status
                write_health_status("healthy")
            
            # Sleep before next check
            time.sleep(HEALTH_CHECK_INTERVAL)
        except Exception as e:
            logger.error(f"Error in watchdog: {e}")
            time.sleep(HEALTH_CHECK_INTERVAL)


def signal_handler(sig, frame):
    """Handle termination signals"""
    global running
    logger.info(f"Received signal {sig}, shutting down...")
    running = False
    stop_bot(force=True)


def run_supervisor():
    """Run the bot supervisor"""
    global watchdog_thread
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("Starting bot supervisor...")
    
    # Start the bot
    if not start_bot():
        logger.error("Failed to start bot initially")
        return False
    
    # Start the watchdog thread
    watchdog_thread = threading.Thread(target=watchdog, daemon=True)
    watchdog_thread.start()
    
    logger.info("Bot supervisor running, press Ctrl+C to stop")
    
    # Keep the main thread alive
    try:
        while running:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
    finally:
        # Clean up
        running = False
        stop_bot(force=True)
        
        # Wait for watchdog thread to complete
        if watchdog_thread is not None and watchdog_thread.is_alive():
            watchdog_thread.join(timeout=5)
        
        logger.info("Bot supervisor shutdown complete")


if __name__ == "__main__":
    run_supervisor()