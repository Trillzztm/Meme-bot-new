# SMART MEMES BOT - Complete Installation Guide

## Overview

The SMART MEMES BOT is an advanced AI-powered cryptocurrency trading platform for the Solana blockchain that combines:

- Real blockchain trading through Jupiter DEX
- 24/7 continuous operation
- Telegram bot interface
- Insider wallet tracking
- AI-enhanced token analysis
- Viral meme generation
- Automated sniping with risk management

## Installation Instructions

### Step 1: Extract the ZIP file

Extract the `smart_memes_bot_complete.zip` file to a directory of your choice.

### Step 2: Install Required Dependencies

```bash
pip install -r requirements.txt
```

### Step 3: Set Up Environment Variables

Create a `.env` file with the following variables:

```
# Required - Telegram Bot Config
TELEGRAM_BOT_TOKEN=your_telegram_bot_token

# Required - Solana Wallet Config
SOLANA_PRIVATE_KEY=your_solana_private_key

# Optional - OpenAI for AI features
OPENAI_API_KEY=your_openai_api_key

# Optional - Twitter API (if using Twitter signals)
TWITTER_BEARER_TOKEN=your_twitter_bearer_token

# Optional - Birdeye API (for enhanced token data)
BIRDEYE_API_KEY=your_birdeye_api_key
```

### Step 4: Run Setup Scripts

```bash
# Set up your wallet
./setup_wallet.sh

# Create the watchdog for 24/7 operation
./create_watchdog_for_real_trader.sh
```

## Running the Bot

### Option 1: Run the Telegram Bot

```bash
python bot.py
```

This will start the Telegram bot interface, allowing you to interact with the system through Telegram.

### Option 2: Run Real Trading (Command Line)

```bash
# Start real trading
./start_24_7_trading.sh

# For 24/7 operation with auto-restart
./start_real_trader_watchdog.sh
```

### Option 3: Run the Web Dashboard

```bash
python dashboard.py
```

This will start a web dashboard for monitoring the system.

## Key Features

### Real Trading Module

The real trading module executes actual blockchain transactions using your Solana wallet and Jupiter DEX. Key files:

- `real_trader_24_7.py` - Main trader script
- `jupiter_client.py` - Jupiter API client
- `real_trader_watchdog.py` - Auto-restart system

### Telegram Bot Module

The Telegram bot provides a user interface to interact with the system. Key files:

- `bot.py` - Main bot script
- `handlers/` - Command handlers

### Wallet Tracking Module

The wallet tracking module monitors insider wallets for signals. Key files:

- `wallet_tracker.py` - Wallet monitoring
- `wallet_intelligence_engine.py` - Signal processing

### AI and Analysis Module

The AI module provides token analysis and trading signals. Key files:

- `ai/` - AI components
- `utils/token_analyzer.py` - Token analysis
- `utils/risk_manager.py` - Risk management

### Meme Generation

The meme generation module creates viral marketing memes. Key files:

- `meme_generator.py` - Meme creation
- `assets/meme_templates/` - Meme templates

## Monitoring and Logging

All activities are logged to various log files:

- `real_trades.log` - Real trading logs
- `bot.log` - Telegram bot logs
- `watchdog.log` - Watchdog logs

## Stopping the System

```bash
# Stop real trading
./stop_24_7_trading.sh

# Stop the watchdog
./stop_real_trader_watchdog.sh
```

## Important Notes

1. The system requires a funded Solana wallet to execute real trades
2. Never share your private keys or API tokens
3. Start with small trading amounts until you're comfortable with the system
4. The watchdog will automatically restart the trader if it crashes

## Support

For issues or questions, please refer to the troubleshooting section in the documentation.