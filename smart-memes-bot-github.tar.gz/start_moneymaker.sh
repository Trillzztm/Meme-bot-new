#!/bin/bash

# Start the SMART MEMES BOT Money Maker
# This script ensures the money maker runs continuously
# and restarts it if it crashes

echo "==================================="
echo "Starting SMART MEMES BOT Money Maker"
echo "==================================="

# Make sure we have the right environment variables
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
  echo "WARNING: SOLANA_PRIVATE_KEY environment variable not set."
  echo "Real trading functionality will be limited."
  echo "You can set it by running: export SOLANA_PRIVATE_KEY=your_private_key"
fi

# Create log directory if it doesn't exist
mkdir -p logs

# Start the money maker
while true; do
  echo "Starting money maker at $(date)"
  python run_moneymaker.py
  echo "Money maker exited with code $? at $(date)"
  echo "Restarting in 5 seconds..."
  sleep 5
done