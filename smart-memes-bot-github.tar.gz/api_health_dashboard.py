"""
API Health Dashboard for SMART MEMES BOT.

This module provides a web interface for monitoring the health and status of all
integrated APIs and services. It includes detailed service status information,
response times, and endpoints status for each service.
"""

import os
import time
import json
import logging
import requests
import datetime
from typing import Dict, Any, List, Optional
from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import database and models
try:
    from database import db, init_app
    from models import User, ApiKey
    DATABASE_AVAILABLE = True
except ImportError:
    logger.warning("Database functionality not available")
    DATABASE_AVAILABLE = False

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key_for_testing")

# Initialize database if available
if DATABASE_AVAILABLE:
    init_app(app)

# Flask-Login is initialized in app.py

# API Services Configuration
API_SERVICES = [
    {
        "name": "Birdeye API",
        "base_url": "https://public-api.birdeye.so",
        "endpoints": [
            {"name": "/public/tokenlist", "method": "GET"},
            {"name": "/public/price", "method": "GET"},
        ],
        "api_key_env": "BIRDEYE_API_KEY",
        "api_key_header": "X-API-KEY"
    },
    {
        "name": "Solana RPC",
        "base_url": "https://api.mainnet-beta.solana.com",
        "endpoints": [
            {"name": "/", "method": "POST", "data": {"jsonrpc": "2.0", "id": 1, "method": "getHealth"}}
        ]
    },
    {
        "name": "OpenAI API",
        "base_url": "https://api.openai.com/v1",
        "endpoints": [
            {"name": "/models", "method": "GET"}
        ],
        "api_key_env": "OPENAI_API_KEY",
        "api_key_header": "Authorization",
        "api_key_prefix": "Bearer "
    },
    {
        "name": "Telegram Bot API",
        "base_url": "https://api.telegram.org",
        "endpoints": [
            {"name": "/bot{token}/getMe", "method": "GET"}
        ],
        "api_key_env": "TELEGRAM_BOT_TOKEN",
        "api_key_url": True
    }
]

# Status cache
API_STATUS_CACHE = []
LAST_CHECK_TIME = 0
CACHE_DURATION = 60  # seconds

def format_timestamp(timestamp):
    """Format timestamp for display."""
    if not timestamp:
        return "N/A"
    if isinstance(timestamp, (int, float)):
        dt = datetime.datetime.fromtimestamp(timestamp)
    else:
        dt = timestamp
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def check_api_service(service: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check the health of an API service.
    
    Args:
        service: Service configuration dictionary
        
    Returns:
        Service status dictionary
    """
    result = {
        "name": service["name"],
        "status": "down",
        "timestamp": time.time(),
        "endpoints": []
    }
    
    try:
        # Prepare base headers
        headers = {}
        
        # Add API key if needed
        if "api_key_env" in service:
            api_key = os.environ.get(service["api_key_env"])
            if not api_key:
                result["error_message"] = f"API key not found in environment: {service['api_key_env']}"
                return result
            
            if "api_key_header" in service:
                key_value = api_key
                if "api_key_prefix" in service:
                    key_value = f"{service['api_key_prefix']}{api_key}"
                headers[service["api_key_header"]] = key_value
        
        # Check all endpoints
        healthy_endpoints = 0
        total_response_time = 0
        
        for endpoint in service.get("endpoints", []):
            endpoint_result = {
                "name": endpoint["name"],
                "status": "down"
            }
            
            try:
                url = service["base_url"] + endpoint["name"]
                
                # Replace token in URL if needed
                if "api_key_url" in service and service["api_key_url"]:
                    token = os.environ.get(service["api_key_env"])
                    if token:
                        url = url.replace("{token}", token)
                
                # Make request
                method = endpoint.get("method", "GET")
                request_data = endpoint.get("data")
                
                start_time = time.time()
                if method == "GET":
                    response = requests.get(url, headers=headers, timeout=5)
                elif method == "POST":
                    response = requests.post(url, json=request_data, headers=headers, timeout=5)
                
                response_time = (time.time() - start_time) * 1000  # milliseconds
                total_response_time += response_time
                
                # Check response
                endpoint_result["response_time"] = round(response_time, 2)
                
                if response.status_code < 400:
                    endpoint_result["status"] = "healthy"
                    healthy_endpoints += 1
                else:
                    endpoint_result["status"] = "degraded"
                    endpoint_result["error"] = f"HTTP {response.status_code}: {response.text[:200]}"
            
            except Exception as e:
                endpoint_result["error"] = str(e)
            
            result["endpoints"].append(endpoint_result)
        
        # Calculate overall status
        total_endpoints = len(service.get("endpoints", []))
        
        if total_endpoints > 0:
            health_percentage = (healthy_endpoints / total_endpoints) * 100
            result["uptime_percentage"] = round(health_percentage, 1)
            
            if healthy_endpoints == total_endpoints:
                result["status"] = "healthy"
            elif healthy_endpoints > 0:
                result["status"] = "degraded"
            
            result["response_time"] = round(total_response_time / total_endpoints, 2)
    
    except Exception as e:
        result["error_message"] = str(e)
    
    return result

def check_all_api_services():
    """
    Check all API services with robust error handling.
    
    Returns:
        List of service status dictionaries
    """
    global API_STATUS_CACHE, LAST_CHECK_TIME
    
    # If there's any exception during the entire process, we'll at least return the cached results
    try:
        current_time = time.time()
        
        # Return cached results if available and not expired
        if API_STATUS_CACHE and (current_time - LAST_CHECK_TIME) < CACHE_DURATION:
            return API_STATUS_CACHE
        
        # Check all services
        results = []
        for service in API_SERVICES:
            try:
                # Wrap each service check in its own try-except to prevent one failure from affecting others
                service_result = check_api_service(service)
                results.append(service_result)
            except Exception as e:
                logger.error(f"Error checking service {service['name']}: {e}")
                # Add a fallback status entry for the failed service
                results.append({
                    "name": service["name"],
                    "status": "error",
                    "timestamp": time.time(),
                    "error_message": f"Service check failed: {str(e)}",
                    "endpoints": []
                })
        
        # Only update cache if we have results
        if results:
            API_STATUS_CACHE = results
            LAST_CHECK_TIME = current_time
            
        return results
    
    except Exception as e:
        logger.error(f"Critical error in check_all_api_services: {e}")
        # If we have cached results, return those instead of failing completely
        if API_STATUS_CACHE:
            return API_STATUS_CACHE
        
        # If all else fails, return a minimal error response
        return [{
            "name": "API Status Service",
            "status": "error",
            "timestamp": time.time(),
            "error_message": f"Failed to check API services: {str(e)}",
            "endpoints": []
        }]

@app.route('/')
def home():
    """Home page."""
    return render_template('index.html', now=datetime.datetime.now())

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = 'remember' in request.form
        
        if DATABASE_AVAILABLE:
            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                login_user(user, remember=remember)
                next_page = request.args.get('next')
                return redirect(next_page or url_for('dashboard'))
            else:
                flash('Invalid username or password', 'error')
        else:
            # For testing without database
            if username == 'admin' and password == 'admin':
                session['user'] = username
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout."""
    if current_user.is_authenticated:
        logout_user()
    elif 'user' in session:
        session.pop('user')
    
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard."""
    return redirect(url_for('api_health'))

@app.route('/api-health')
@login_required
def api_health():
    """API health dashboard."""
    api_health = check_all_api_services()
    return render_template('api_health.html', api_health=api_health, format_timestamp=format_timestamp)

@app.route('/api/health', methods=['GET'])
@login_required
def api_health_json():
    """API health data as JSON."""
    api_health = check_all_api_services()
    return jsonify(api_health)

@app.route('/api/health/<service_name>', methods=['GET'])
@login_required
def api_health_service_json(service_name):
    """API health data for a specific service as JSON."""
    api_health = check_all_api_services()
    service = next((s for s in api_health if s["name"] == service_name), None)
    
    if not service:
        return jsonify({"error": "Service not found"}), 404
    
    return jsonify(service)

@app.errorhandler(404)
def page_not_found(e):
    """404 error handler."""
    return render_template('error.html', error_code=404, error_message="Page Not Found"), 404

@app.errorhandler(500)
def server_error(e):
    """500 error handler."""
    return render_template('error.html', error_code=500, error_message="Server Error"), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)