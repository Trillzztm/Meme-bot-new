#!/usr/bin/env python3
"""
Dedicated Telegram bot daemon that runs independently of the Flask application.
This ensures the bot stays running even if the web application restarts.
"""
import logging
import os
import signal
import subprocess
import sys
import time
from threading import Thread
import atexit

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename='telegram_bot.log'
)

logger = logging.getLogger(__name__)

# Global variables
bot_process = None
keep_running = True

def start_bot_process():
    """Start the bot process and return it."""
    logger.info("Starting Telegram bot process...")
    env = os.environ.copy()
    
    # Ensure bot token is in environment
    if "TELEGRAM_BOT_TOKEN" not in env:
        logger.error("TELEGRAM_BOT_TOKEN not found in environment")
        return None
    
    # Start the bot as a separate process
    try:
        process = subprocess.Popen(
            ["python3", "simple_bot.py"],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        logger.info(f"Bot process started with PID: {process.pid}")
        return process
    except Exception as e:
        logger.error(f"Error starting bot process: {str(e)}")
        return None

def monitor_bot_process():
    """Monitor the bot process and restart it if it fails."""
    global bot_process, keep_running
    
    logger.info("Starting bot process monitor...")
    
    try:
        while keep_running:
            # Check if we need to start/restart the process
            if bot_process is None or bot_process.poll() is not None:
                # Process doesn't exist or has terminated
                if bot_process is not None:
                    exit_code = bot_process.poll()
                    logger.warning(f"Bot process terminated with exit code: {exit_code}")
                
                # Start new process
                bot_process = start_bot_process()
                if bot_process is None:
                    logger.error("Failed to start bot process, retrying in 60 seconds")
                    time.sleep(60)
                    continue
                
                # Start log reader thread
                log_thread = Thread(target=read_process_output, args=(bot_process,))
                log_thread.daemon = True
                log_thread.start()
            
            # Wait a bit before checking again
            time.sleep(5)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, stopping...")
        keep_running = False
    except Exception as e:
        logger.error(f"Error in monitor_bot_process: {str(e)}")
    finally:
        # Make sure to clean up
        stop_bot_process()

def read_process_output(process):
    """Read and log output from the bot process."""
    try:
        for line in process.stdout:
            line = line.strip()
            if line:
                logger.info(f"BOT: {line}")
    except Exception as e:
        logger.error(f"Error reading bot output: {str(e)}")

def stop_bot_process():
    """Stop the bot process if it's running."""
    global bot_process
    
    if bot_process is not None:
        logger.info(f"Stopping bot process (PID: {bot_process.pid})...")
        try:
            # Try to terminate gracefully
            bot_process.terminate()
            # Wait a bit
            time.sleep(2)
            # If still running, kill it
            if bot_process.poll() is None:
                bot_process.kill()
        except Exception as e:
            logger.error(f"Error stopping bot process: {str(e)}")
        finally:
            bot_process = None

def signal_handler(sig, frame):
    """Handle signals to gracefully stop the daemon."""
    global keep_running
    logger.info(f"Received signal {sig}, shutting down...")
    keep_running = False
    stop_bot_process()
    sys.exit(0)

def cleanup():
    """Cleanup function registered with atexit."""
    stop_bot_process()

def main():
    """Main function to run the daemon."""
    # Register the cleanup function
    atexit.register(cleanup)
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("Starting Telegram bot daemon...")
    
    # Start the bot process monitor in a separate thread
    monitor_thread = Thread(target=monitor_bot_process)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # Keep the main thread alive
    try:
        logger.info("Telegram bot daemon running. Press Ctrl+C to stop.")
        while keep_running:
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, stopping daemon...")
        keep_running = False
    finally:
        stop_bot_process()

if __name__ == "__main__":
    main()