"""
Main entry point for the Telegram bot.

This module sets up and runs the bot with all necessary handlers.
"""

import logging
import os
import sys
from typing import Any

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Import the bot token from config
from config import BOT_TOKEN


def main():
    """Main function to run the bot."""
    logger.info("Starting SMART MEMES BOT")
    
    # Get token from environment or config
    token = os.environ.get("TELEGRAM_BOT_TOKEN", BOT_TOKEN)
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN not set")
        sys.exit(1)
    
    try:
        # Set up the standard bot first
        bot = setup_standard_bot(token)
        
        # Run the standard bot
        logger.info("Running standard bot")
        bot.run_polling()
    except Exception as e:
        logger.error(f"Error running standard bot: {e}")
        logger.info("Falling back to simplified bot")
        
        try:
            # Fall back to the simplified bot
            bot = setup_simplified_bot(token)
            
            # Run the simplified bot
            logger.info("Running simplified bot")
            bot.start()
        except Exception as e2:
            logger.error(f"Error running simplified bot: {e2}")
            sys.exit(1)


def setup_standard_bot(token):
    """Set up the standard python-telegram-bot with all handlers."""
    try:
        from telegram.ext import ApplicationBuilder, CommandHandler
        
        # Import handlers
        from handlers.start import start
        from handlers.help import help
        from handlers.manualsnipe import manualsnipe
        from handlers.tokeninfo import tokeninfo
        from handlers.watchgroup import watchgroup
        
        # Create the Application
        app = ApplicationBuilder().token(token).build()
        
        # Add handlers
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("help", help))
        app.add_handler(CommandHandler("manualsnipe", manualsnipe))
        app.add_handler(CommandHandler("tokeninfo", tokeninfo))
        app.add_handler(CommandHandler("watchgroup", watchgroup))
        
        return app
    except Exception as e:
        logger.error(f"Failed to set up standard bot: {e}")
        raise


def setup_simplified_bot(token):
    """Set up the simplified bot implementation."""
    try:
        from simple_bot import SimpleTelegramBot
        
        # Create and return the bot
        return SimpleTelegramBot(token)
    except Exception as e:
        logger.error(f"Failed to set up simplified bot: {e}")
        raise


if __name__ == "__main__":
    main()