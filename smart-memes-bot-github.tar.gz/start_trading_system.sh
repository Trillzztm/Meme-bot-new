#!/bin/bash
# SMART MEMES BOT - Trading System Launcher
# This script launches all components of the real-time trading system

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Log directory
LOG_DIR="logs"
mkdir -p $LOG_DIR

# Print banner
echo -e "${CYAN}"
echo "  ███████╗███╗   ███╗ █████╗ ██████╗ ████████╗    ███╗   ███╗███████╗███╗   ███╗███████╗███████╗"
echo "  ██╔════╝████╗ ████║██╔══██╗██╔══██╗╚══██╔══╝    ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝"
echo "  ███████╗██╔████╔██║███████║██████╔╝   ██║       ██╔████╔██║█████╗  ██╔████╔██║█████╗  ███████╗"
echo "  ╚════██║██║╚██╔╝██║██╔══██║██╔══██╗   ██║       ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ╚════██║"
echo "  ███████║██║ ╚═╝ ██║██║  ██║██║  ██║   ██║       ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗███████║"
echo "  ╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝       ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝╚══════╝"
echo -e "${GREEN}                                REAL TIME TRADING SYSTEM                                ${NC}"
echo -e "${YELLOW}                        AUTOMATIC CRYPTO PROFIT GENERATION MACHINE                      ${NC}"
echo -e "${NC}"

# Check if private key is set
check_private_key() {
    if [ -z "$SOLANA_PRIVATE_KEY" ]; then
        echo -e "${YELLOW}Solana private key not set. Running setup...${NC}"
        python solana_private_key_setup.py
        
        # Check if setup was successful
        if [ -f "solana_key.txt" ]; then
            export SOLANA_PRIVATE_KEY=$(cat solana_key.txt)
            echo -e "${GREEN}Private key loaded.${NC}"
        else
            echo -e "${RED}Failed to set up private key. Trading system cannot start.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}Solana private key is already set.${NC}"
    fi
}

# Check for Birdeye API key
check_birdeye_api_key() {
    if [ -z "$BIRDEYE_API_KEY" ]; then
        echo -e "${YELLOW}Birdeye API key not set. Some features may be limited.${NC}"
    else
        echo -e "${GREEN}Birdeye API key is set.${NC}"
    fi
}

# Create required files
ensure_files() {
    # Create empty profit log if it doesn't exist
    if [ ! -f "profit_log.json" ]; then
        echo '{"total_profit_usd": 0, "trades": [], "daily_profit": {}}' > profit_log.json
        echo -e "${GREEN}Created profit log file.${NC}"
    fi
    
    # Create empty market data file if it doesn't exist
    if [ ! -f "token_market_data.json" ]; then
        echo '{}' > token_market_data.json
        echo -e "${GREEN}Created market data file.${NC}"
    fi
    
    # Create empty trading signals file if it doesn't exist
    if [ ! -f "trading_signals.json" ]; then
        echo '[]' > trading_signals.json
        echo -e "${GREEN}Created trading signals file.${NC}"
    fi
    
    # Create empty transaction history file if it doesn't exist
    if [ ! -f "jupiter_real_trades_history.json" ]; then
        echo '[]' > jupiter_real_trades_history.json
        echo -e "${GREEN}Created transaction history file.${NC}"
    fi
}

# Start market monitor
start_market_monitor() {
    echo -e "${BLUE}Starting market monitor...${NC}"
    nohup python market_monitor.py > $LOG_DIR/market_monitor.log 2>&1 &
    MARKET_MONITOR_PID=$!
    echo $MARKET_MONITOR_PID > $LOG_DIR/market_monitor.pid
    echo -e "${GREEN}Market monitor started with PID $MARKET_MONITOR_PID${NC}"
}

# Start trading engine
start_trading_engine() {
    echo -e "${BLUE}Starting trading engine...${NC}"
    nohup python realtime_trading_engine.py > $LOG_DIR/trading_engine.log 2>&1 &
    TRADING_ENGINE_PID=$!
    echo $TRADING_ENGINE_PID > $LOG_DIR/trading_engine.pid
    echo -e "${GREEN}Trading engine started with PID $TRADING_ENGINE_PID${NC}"
}

# Start trading dashboard
start_trading_dashboard() {
    echo -e "${BLUE}Starting trading dashboard...${NC}"
    nohup python trading_dashboard.py > $LOG_DIR/trading_dashboard.log 2>&1 &
    DASHBOARD_PID=$!
    echo $DASHBOARD_PID > $LOG_DIR/trading_dashboard.pid
    echo -e "${GREEN}Trading dashboard started with PID $DASHBOARD_PID${NC}"
}

# Stop all components
stop_all() {
    echo -e "${YELLOW}Stopping all components...${NC}"
    
    # Stop market monitor
    if [ -f "$LOG_DIR/market_monitor.pid" ]; then
        PID=$(cat $LOG_DIR/market_monitor.pid)
        if ps -p $PID > /dev/null; then
            kill $PID
            echo -e "${GREEN}Market monitor stopped.${NC}"
        else
            echo -e "${YELLOW}Market monitor was not running.${NC}"
        fi
        rm $LOG_DIR/market_monitor.pid
    fi
    
    # Stop trading engine
    if [ -f "$LOG_DIR/trading_engine.pid" ]; then
        PID=$(cat $LOG_DIR/trading_engine.pid)
        if ps -p $PID > /dev/null; then
            kill $PID
            echo -e "${GREEN}Trading engine stopped.${NC}"
        else
            echo -e "${YELLOW}Trading engine was not running.${NC}"
        fi
        rm $LOG_DIR/trading_engine.pid
    fi
    
    # Stop trading dashboard
    if [ -f "$LOG_DIR/trading_dashboard.pid" ]; then
        PID=$(cat $LOG_DIR/trading_dashboard.pid)
        if ps -p $PID > /dev/null; then
            kill $PID
            echo -e "${GREEN}Trading dashboard stopped.${NC}"
        else
            echo -e "${YELLOW}Trading dashboard was not running.${NC}"
        fi
        rm $LOG_DIR/trading_dashboard.pid
    fi
    
    echo -e "${GREEN}All components stopped.${NC}"
}

# Show status
show_status() {
    echo -e "${BLUE}Checking component status...${NC}"
    
    # Check market monitor
    if [ -f "$LOG_DIR/market_monitor.pid" ]; then
        PID=$(cat $LOG_DIR/market_monitor.pid)
        if ps -p $PID > /dev/null; then
            echo -e "${GREEN}Market monitor is running with PID $PID${NC}"
        else
            echo -e "${RED}Market monitor is not running (stale PID file)${NC}"
        fi
    else
        echo -e "${RED}Market monitor is not running${NC}"
    fi
    
    # Check trading engine
    if [ -f "$LOG_DIR/trading_engine.pid" ]; then
        PID=$(cat $LOG_DIR/trading_engine.pid)
        if ps -p $PID > /dev/null; then
            echo -e "${GREEN}Trading engine is running with PID $PID${NC}"
        else
            echo -e "${RED}Trading engine is not running (stale PID file)${NC}"
        fi
    else
        echo -e "${RED}Trading engine is not running${NC}"
    fi
    
    # Check trading dashboard
    if [ -f "$LOG_DIR/trading_dashboard.pid" ]; then
        PID=$(cat $LOG_DIR/trading_dashboard.pid)
        if ps -p $PID > /dev/null; then
            echo -e "${GREEN}Trading dashboard is running with PID $PID${NC}"
        else
            echo -e "${RED}Trading dashboard is not running (stale PID file)${NC}"
        fi
    else
        echo -e "${RED}Trading dashboard is not running${NC}"
    fi
    
    # Show profit information
    if [ -f "profit_log.json" ]; then
        TOTAL_PROFIT=$(grep -o '"total_profit_usd":[^,]*' profit_log.json | cut -d ':' -f2)
        echo -e "${CYAN}Total profit: $TOTAL_PROFIT USD${NC}"
    fi
}

# Show logs
show_logs() {
    component=$1
    lines=${2:-20}
    
    case $component in
        market)
            if [ -f "$LOG_DIR/market_monitor.log" ]; then
                echo -e "${BLUE}Last $lines lines of market monitor log:${NC}"
                tail -n $lines $LOG_DIR/market_monitor.log
            else
                echo -e "${RED}Market monitor log not found${NC}"
            fi
            ;;
        trading)
            if [ -f "$LOG_DIR/trading_engine.log" ]; then
                echo -e "${BLUE}Last $lines lines of trading engine log:${NC}"
                tail -n $lines $LOG_DIR/trading_engine.log
            else
                echo -e "${RED}Trading engine log not found${NC}"
            fi
            ;;
        dashboard)
            if [ -f "$LOG_DIR/trading_dashboard.log" ]; then
                echo -e "${BLUE}Last $lines lines of trading dashboard log:${NC}"
                tail -n $lines $LOG_DIR/trading_dashboard.log
            else
                echo -e "${RED}Trading dashboard log not found${NC}"
            fi
            ;;
        all)
            echo -e "${BLUE}=== Market Monitor Log ===${NC}"
            if [ -f "$LOG_DIR/market_monitor.log" ]; then
                tail -n $lines $LOG_DIR/market_monitor.log
            else
                echo -e "${RED}Market monitor log not found${NC}"
            fi
            
            echo -e "${BLUE}=== Trading Engine Log ===${NC}"
            if [ -f "$LOG_DIR/trading_engine.log" ]; then
                tail -n $lines $LOG_DIR/trading_engine.log
            else
                echo -e "${RED}Trading engine log not found${NC}"
            fi
            
            echo -e "${BLUE}=== Trading Dashboard Log ===${NC}"
            if [ -f "$LOG_DIR/trading_dashboard.log" ]; then
                tail -n $lines $LOG_DIR/trading_dashboard.log
            else
                echo -e "${RED}Trading dashboard log not found${NC}"
            fi
            ;;
        *)
            echo -e "${RED}Unknown component: $component${NC}"
            echo "Usage: $0 logs [market|trading|dashboard|all] [lines]"
            ;;
    esac
}

# Print usage
usage() {
    echo -e "${CYAN}SMART MEMES BOT - Trading System Launcher${NC}"
    echo "Usage: $0 [start|stop|status|logs|help]"
    echo ""
    echo "Commands:"
    echo "  start      Start all components"
    echo "  stop       Stop all components"
    echo "  status     Show status of all components"
    echo "  logs       Show logs (usage: $0 logs [market|trading|dashboard|all] [lines])"
    echo "  help       Show this help message"
    echo ""
}

# Main function
main() {
    command=$1
    
    case $command in
        start)
            check_private_key
            check_birdeye_api_key
            ensure_files
            start_market_monitor
            start_trading_engine
            start_trading_dashboard
            
            echo -e "${GREEN}All components started successfully!${NC}"
            echo -e "${CYAN}Trading dashboard: http://localhost:5001${NC}"
            ;;
        stop)
            stop_all
            ;;
        status)
            show_status
            ;;
        logs)
            component=${2:-all}
            lines=${3:-20}
            show_logs $component $lines
            ;;
        help|*)
            usage
            ;;
    esac
}

# Run main function with all arguments
main "$@"