#!/usr/bin/env python3
"""
Run Real Trade Script for SMART MEMES BOT

This script executes a real trade operation using the enhanced Jupiter trader.
It's designed to be run directly from the command line.

Usage:
  python run_real_trade.py <TOKEN> <AMOUNT_SOL>
  
Example:
  python run_real_trade.py BONK 0.01
"""

import sys
import logging
from enhanced_jupiter_trader import execute_real_trade

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("real_trades.log")
    ]
)
logger = logging.getLogger("RunRealTrade")

def main():
    # Check arguments
    if len(sys.argv) < 3:
        print("Usage: python run_real_trade.py <TOKEN> <AMOUNT_SOL>")
        print("Example: python run_real_trade.py BONK 0.01")
        return
    
    # Parse arguments
    token = sys.argv[1]
    try:
        amount = float(sys.argv[2])
    except ValueError:
        logger.error(f"Invalid amount: {sys.argv[2]}")
        print(f"Error: '{sys.argv[2]}' is not a valid amount. Please use a number like 0.01.")
        return
    
    # Execute the trade
    logger.info(f"⚠️ EXECUTING REAL TRADE: {amount} SOL to {token} ⚠️")
    
    # Confirm with user
    confirm = input(f"Are you sure you want to trade {amount} SOL for {token}? (yes/no): ")
    if confirm.lower() not in ["yes", "y"]:
        logger.info("Trade cancelled by user")
        print("Trade cancelled.")
        return
    
    # Execute the real trade
    result = execute_real_trade(token, amount_sol=amount)
    
    # Log the result
    if result.get("success"):
        logger.info(f"✅ TRADE SUCCESSFUL! Transaction hash: {result.get('tx_hash')}")
        print(f"Trade successful! Transaction hash: {result.get('tx_hash')}")
    else:
        logger.error(f"❌ TRADE FAILED: {result.get('error')}")
        print(f"Trade failed: {result.get('error')}")

if __name__ == "__main__":
    main()
