#!/bin/bash

echo "==============================================="
echo "SMART MEMES BOT - STOP REAL TRADER WATCHDOG"
echo "==============================================="
echo

if [ -f watchdog.pid ]; then
    PID=$(cat watchdog.pid)
    if ps -p $PID > /dev/null; then
        echo "Stopping Real Money Trader Watchdog (PID: $PID)"
        kill $PID
        echo "✅ Watchdog stopped successfully"
    else
        echo "Watchdog process not found. It may have already stopped."
    fi
    rm watchdog.pid
else
    echo "No watchdog.pid file found. Stopping any running instances..."
    pkill -f real_trader_watchdog.py
fi

echo "✅ Cleaned up all watchdog processes"

# Also stop the trading bot if it's running
if [ -f trader_24_7.pid ]; then
    PID=$(cat trader_24_7.pid)
    if ps -p $PID > /dev/null; then
        echo "Stopping Real Money Trader (PID: $PID)"
        kill $PID
        echo "✅ Real Money Trader stopped successfully"
    else
        echo "Real Money Trader process not found. It may have already stopped."
    fi
    rm trader_24_7.pid
else
    echo "No trader_24_7.pid file found. Stopping any running instances..."
    pkill -f real_trader_24_7.py
fi

echo "✅ Cleaned up all trading processes"
echo
echo "==============================================="