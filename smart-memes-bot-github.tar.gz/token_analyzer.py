"""
Token Analyzer for SMART MEMES BOT.

This module analyzes tokens for safety, tokenomics, and trading potential.
"""

import os
import time
import json
import logging
import datetime
import requests
from typing import Dict, Any, List, Optional, Tuple, Union
from decimal import Decimal

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Import OpenAI for advanced analysis if available
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
    logger.info("OpenAI functionality available for token analysis")
except ImportError:
    OPENAI_AVAILABLE = False
    logger.warning("OpenAI functionality not available for token analysis")

# Check for API keys
BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# Constants
ETHEREUM_CHAIN_ID = 1
SOLANA_CHAIN_ID = "solana"
BSC_CHAIN_ID = 56
POLYGON_CHAIN_ID = 137

class TokenAnalyzer:
    """Token analyzer class for multiple blockchains."""
    
    def __init__(self):
        """Initialize the token analyzer."""
        self.cache = {}
        self.cache_ttl = 300  # 5 minutes cache
        
        # Initialize OpenAI if available
        if OPENAI_AVAILABLE and OPENAI_API_KEY:
            self.openai_client = OpenAI(api_key=OPENAI_API_KEY)
            logger.info("OpenAI client initialized")
        else:
            self.openai_client = None
            if OPENAI_AVAILABLE:
                logger.warning("OpenAI API key not set")
    
    def _make_api_request(self, url: str, params: Dict = None, headers: Dict = None, 
                         timeout: int = 10, retries: int = 3) -> Dict:
        """
        Make a resilient API request with retries.
        
        Args:
            url: API endpoint URL
            params: Query parameters
            headers: Request headers
            timeout: Request timeout in seconds
            retries: Number of retry attempts
            
        Returns:
            API response as dictionary
        """
        for attempt in range(retries):
            try:
                response = requests.get(url, params=params, headers=headers, timeout=timeout)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"API request failed (attempt {attempt+1}/{retries}): {e}")
                if attempt == retries - 1:
                    raise
                time.sleep(1)
    
    def _get_token_info_solana(self, token_address: str) -> Dict[str, Any]:
        """
        Get basic token information for a Solana token.
        
        Args:
            token_address: Token mint address
            
        Returns:
            Token information
        """
        cache_key = f"token_info_solana_{token_address}"
        if cache_key in self.cache and time.time() - self.cache[cache_key]['timestamp'] < self.cache_ttl:
            return self.cache[cache_key]['data']
        
        if not BIRDEYE_API_KEY:
            logger.error("BirdEye API key not set")
            raise ValueError("BirdEye API key not set")
        
        url = f"https://public-api.birdeye.so/public/tokenlist/solana"
        headers = {
            "X-API-KEY": BIRDEYE_API_KEY
        }
        
        try:
            response = self._make_api_request(url, headers=headers)
            
            # Find token in the response
            token_data = None
            for token in response.get('data', []):
                if token.get('address') == token_address:
                    token_data = token
                    break
            
            if not token_data:
                # Try to get token directly
                url = f"https://public-api.birdeye.so/public/token_info/solana?address={token_address}"
                token_response = self._make_api_request(url, headers=headers)
                token_data = token_response.get('data', {})
            
            result = {
                'address': token_address,
                'name': token_data.get('name', 'Unknown'),
                'symbol': token_data.get('symbol', 'Unknown'),
                'decimals': token_data.get('decimals', 9),
                'total_supply': token_data.get('totalSupply', 0),
                'price_usd': token_data.get('priceUsd', 0),
                'market_cap': token_data.get('marketCap', 0),
                'volume_24h': token_data.get('volume24h', 0),
                'price_change_24h': token_data.get('priceChange24h', 0),
                'chain': 'solana'
            }
            
            # Cache the result
            self.cache[cache_key] = {
                'data': result,
                'timestamp': time.time()
            }
            
            return result
        
        except Exception as e:
            logger.error(f"Error getting Solana token info: {e}")
            return {
                'address': token_address,
                'name': 'Unknown',
                'symbol': 'Unknown',
                'decimals': 9,
                'chain': 'solana'
            }
    
    def _get_token_info_ethereum(self, token_address: str) -> Dict[str, Any]:
        """
        Get basic token information for an Ethereum token.
        
        Args:
            token_address: Token contract address
            
        Returns:
            Token information
        """
        cache_key = f"token_info_ethereum_{token_address}"
        if cache_key in self.cache and time.time() - self.cache[cache_key]['timestamp'] < self.cache_ttl:
            return self.cache[cache_key]['data']
        
        # Use CoinGecko API (free tier)
        url = f"https://api.coingecko.com/api/v3/coins/ethereum/contract/{token_address}"
        
        try:
            response = self._make_api_request(url)
            
            result = {
                'address': token_address,
                'name': response.get('name', 'Unknown'),
                'symbol': response.get('symbol', 'Unknown').upper(),
                'decimals': 18,  # Default for Ethereum
                'total_supply': response.get('market_data', {}).get('total_supply', 0),
                'price_usd': response.get('market_data', {}).get('current_price', {}).get('usd', 0),
                'market_cap': response.get('market_data', {}).get('market_cap', {}).get('usd', 0),
                'volume_24h': response.get('market_data', {}).get('total_volume', {}).get('usd', 0),
                'price_change_24h': response.get('market_data', {}).get('price_change_percentage_24h', 0),
                'chain': 'ethereum'
            }
            
            # Cache the result
            self.cache[cache_key] = {
                'data': result,
                'timestamp': time.time()
            }
            
            return result
        
        except Exception as e:
            logger.error(f"Error getting Ethereum token info: {e}")
            return {
                'address': token_address,
                'name': 'Unknown',
                'symbol': 'Unknown',
                'decimals': 18,
                'chain': 'ethereum'
            }
    
    def get_token_info(self, token_address: str, chain: str = 'auto') -> Dict[str, Any]:
        """
        Get basic token information.
        
        Args:
            token_address: Token address
            chain: Blockchain (auto, ethereum, solana, bsc, polygon)
            
        Returns:
            Token information
        """
        # Auto-detect chain based on address format
        if chain == 'auto':
            if len(token_address) <= 44 and token_address.isalnum():
                chain = 'solana'
            else:
                chain = 'ethereum'
        
        if chain == 'solana':
            return self._get_token_info_solana(token_address)
        else:
            return self._get_token_info_ethereum(token_address)
    
    def analyze_token_safety(self, token_address: str, chain: str = 'auto') -> Dict[str, Any]:
        """
        Analyze token safety.
        
        Args:
            token_address: Token address
            chain: Blockchain (auto, ethereum, solana, bsc, polygon)
            
        Returns:
            Safety analysis
        """
        # Auto-detect chain based on address format
        if chain == 'auto':
            if len(token_address) <= 44 and token_address.isalnum():
                chain = 'solana'
            else:
                chain = 'ethereum'
        
        cache_key = f"token_safety_{chain}_{token_address}"
        if cache_key in self.cache and time.time() - self.cache[cache_key]['timestamp'] < self.cache_ttl:
            return self.cache[cache_key]['data']
        
        # Get token info first
        token_info = self.get_token_info(token_address, chain)
        
        try:
            # Default safety scores
            safety_scores = {
                'contract_score': 0,
                'liquidity_score': 0,
                'holder_score': 0,
                'social_score': 0,
                'overall_score': 0,
                'is_honeypot': False,
                'is_mintable': False,
                'has_high_fees': False,
                'has_blacklist': False,
                'has_whitelist': False,
                'has_proxy': False,
                'has_fee_change_function': False,
                'has_owner_control': False,
                'risk_factors': []
            }
            
            if chain == 'solana':
                # Use BirdEye API for Solana
                if BIRDEYE_API_KEY:
                    url = f"https://public-api.birdeye.so/defi/token_risk_check?token_address={token_address}"
                    headers = {
                        "X-API-KEY": BIRDEYE_API_KEY
                    }
                    
                    try:
                        risk_response = self._make_api_request(url, headers=headers)
                        risk_data = risk_response.get('data', {})
                        
                        # Map risk data to safety scores
                        contract_risk = risk_data.get('contractRiskLevel', 'medium')
                        liquidity_risk = risk_data.get('liquidityRiskLevel', 'medium')
                        holder_risk = risk_data.get('holderRiskLevel', 'medium')
                        
                        # Convert risk levels to scores (0-100)
                        risk_to_score = {
                            'low': 80,
                            'medium': 50,
                            'high': 20
                        }
                        
                        safety_scores['contract_score'] = risk_to_score.get(contract_risk, 50)
                        safety_scores['liquidity_score'] = risk_to_score.get(liquidity_risk, 50)
                        safety_scores['holder_score'] = risk_to_score.get(holder_risk, 50)
                        safety_scores['social_score'] = 50  # Default social score
                        
                        # Calculate overall score
                        safety_scores['overall_score'] = int(
                            safety_scores['contract_score'] * 0.4 +
                            safety_scores['liquidity_score'] * 0.3 +
                            safety_scores['holder_score'] * 0.2 +
                            safety_scores['social_score'] * 0.1
                        )
                        
                        # Set risk flags
                        safety_scores['is_honeypot'] = risk_data.get('isHoneypot', False)
                        safety_scores['is_mintable'] = risk_data.get('isMintable', False)
                        
                        # Add risk factors
                        risk_factors = []
                        if safety_scores['is_honeypot']:
                            risk_factors.append("Potential honeypot - selling may be restricted")
                        if safety_scores['is_mintable']:
                            risk_factors.append("Token is mintable - supply can be increased")
                        if safety_scores['contract_score'] < 40:
                            risk_factors.append("High contract risk - potential malicious code")
                        if safety_scores['liquidity_score'] < 40:
                            risk_factors.append("Low liquidity - potential for high slippage or rug pulls")
                        if safety_scores['holder_score'] < 40:
                            risk_factors.append("Concentrated holder distribution - whales may control price")
                        
                        safety_scores['risk_factors'] = risk_factors
                    
                    except Exception as e:
                        logger.error(f"Error getting Solana token risk data: {e}")
            
            else:
                # For Ethereum and other EVM chains, use a simple algorithm for now
                # In a real implementation, we would use services like GoPlus, Etherscan, etc.
                
                # Sample holder distribution check
                holders_url = f"https://api.ethplorer.io/getTopTokenHolders/{token_address}?apiKey=freekey"
                
                try:
                    holders_response = self._make_api_request(holders_url)
                    holders = holders_response.get('holders', [])
                    
                    # Calculate concentration of top holders
                    top_holders_percentage = sum(float(holder.get('share', 0)) for holder in holders[:5])
                    
                    # Score based on concentration (lower is better)
                    if top_holders_percentage > 80:
                        safety_scores['holder_score'] = 20
                    elif top_holders_percentage > 60:
                        safety_scores['holder_score'] = 40
                    elif top_holders_percentage > 40:
                        safety_scores['holder_score'] = 60
                    elif top_holders_percentage > 20:
                        safety_scores['holder_score'] = 80
                    else:
                        safety_scores['holder_score'] = 100
                    
                    # Add risk factor if top holders own too much
                    if top_holders_percentage > 60:
                        safety_scores['risk_factors'].append(
                            f"Top 5 holders own {top_holders_percentage:.1f}% of supply - high concentration risk"
                        )
                
                except Exception as e:
                    logger.error(f"Error getting holder data: {e}")
                    safety_scores['holder_score'] = 50  # Default if can't get data
                
                # Default scores for other factors
                safety_scores['contract_score'] = 70
                safety_scores['liquidity_score'] = 60
                safety_scores['social_score'] = 50
                
                # Calculate overall score
                safety_scores['overall_score'] = int(
                    safety_scores['contract_score'] * 0.4 +
                    safety_scores['liquidity_score'] * 0.3 +
                    safety_scores['holder_score'] * 0.2 +
                    safety_scores['social_score'] * 0.1
                )
            
            # Enhance with OpenAI if available
            if self.openai_client and OPENAI_API_KEY:
                try:
                    additional_context = self._get_ai_analysis(token_info, safety_scores)
                    
                    # Add additional risk factors from AI
                    if 'additional_risk_factors' in additional_context:
                        for risk in additional_context['additional_risk_factors']:
                            if risk not in safety_scores['risk_factors']:
                                safety_scores['risk_factors'].append(risk)
                    
                    # Add AI context
                    safety_scores['ai_analysis'] = additional_context.get('analysis_summary', '')
                
                except Exception as e:
                    logger.error(f"Error getting AI analysis: {e}")
            
            # Cache the result
            self.cache[cache_key] = {
                'data': safety_scores,
                'timestamp': time.time()
            }
            
            return safety_scores
        
        except Exception as e:
            logger.error(f"Error analyzing token safety: {e}")
            return {
                'contract_score': 0,
                'liquidity_score': 0,
                'holder_score': 0,
                'social_score': 0,
                'overall_score': 0,
                'is_honeypot': False,
                'risk_factors': ["Unable to analyze token safety"]
            }
    
    def _get_ai_analysis(self, token_info: Dict[str, Any], safety_scores: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get AI-powered analysis for a token.
        
        Args:
            token_info: Token information
            safety_scores: Safety analysis
            
        Returns:
            AI analysis
        """
        if not self.openai_client:
            return {}
        
        try:
            # Prepare prompt for OpenAI
            prompt = f"""
            Analyze this cryptocurrency token for potential risks and opportunities:
            
            Token Information:
            - Name: {token_info.get('name', 'Unknown')}
            - Symbol: {token_info.get('symbol', 'Unknown')}
            - Chain: {token_info.get('chain', 'Unknown')}
            - Market Cap: ${token_info.get('market_cap', 0):,.2f}
            - 24h Volume: ${token_info.get('volume_24h', 0):,.2f}
            - Price Change 24h: {token_info.get('price_change_24h', 0):.2f}%
            
            Safety Analysis:
            - Contract Score: {safety_scores.get('contract_score', 0)}/100
            - Liquidity Score: {safety_scores.get('liquidity_score', 0)}/100
            - Holder Distribution Score: {safety_scores.get('holder_score', 0)}/100
            - Social Presence Score: {safety_scores.get('social_score', 0)}/100
            - Overall Safety Score: {safety_scores.get('overall_score', 0)}/100
            - Is Honeypot: {safety_scores.get('is_honeypot', False)}
            - Is Mintable: {safety_scores.get('is_mintable', False)}
            
            Provide a brief analysis of the token's investment risk, potential red flags, and opportunities.
            Return your analysis as a JSON with the following fields:
            - analysis_summary: A concise summary of the token analysis (max 150 words)
            - risk_level: A string representing risk level (low, medium, high, extreme)
            - additional_risk_factors: An array of strings identifying specific risks not already mentioned
            - investment_outlook: Short-term and long-term investment potential assessment
            - recommendations: Brief trading recommendations based on the analysis
            """
            
            # Get response from OpenAI
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # The newest OpenAI model is "gpt-4o" which was released May 13, 2024
                messages=[
                    {"role": "system", "content": "You are a crypto token analysis expert."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=1000
            )
            
            # Parse the response
            if response.choices and len(response.choices) > 0:
                try:
                    result = json.loads(response.choices[0].message.content)
                    return result
                except json.JSONDecodeError:
                    logger.error("Failed to parse JSON from OpenAI response")
                    return {}
            
            return {}
        
        except Exception as e:
            logger.error(f"Error getting AI analysis: {e}")
            return {}
    
    def analyze_token(self, token_address: str, chain: str = 'auto') -> Dict[str, Any]:
        """
        Perform comprehensive token analysis.
        
        Args:
            token_address: Token address
            chain: Blockchain (auto, ethereum, solana, bsc, polygon)
            
        Returns:
            Comprehensive token analysis
        """
        # Auto-detect chain based on address format
        if chain == 'auto':
            if len(token_address) <= 44 and token_address.isalnum():
                chain = 'solana'
            else:
                chain = 'ethereum'
        
        cache_key = f"token_analysis_{chain}_{token_address}"
        if cache_key in self.cache and time.time() - self.cache[cache_key]['timestamp'] < self.cache_ttl:
            return self.cache[cache_key]['data']
        
        # Get token info
        token_info = self.get_token_info(token_address, chain)
        
        # Get safety analysis
        safety_analysis = self.analyze_token_safety(token_address, chain)
        
        # Combine into comprehensive analysis
        analysis = {
            'token_info': token_info,
            'safety_analysis': safety_analysis,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        # Add trading recommendation
        overall_score = safety_analysis.get('overall_score', 0)
        if overall_score >= 80:
            risk_level = "Low"
            recommendation = "Consider for investment with normal position sizing"
        elif overall_score >= 60:
            risk_level = "Medium"
            recommendation = "Consider for investment with reduced position sizing"
        elif overall_score >= 40:
            risk_level = "High"
            recommendation = "Only invest what you can afford to lose"
        else:
            risk_level = "Extreme"
            recommendation = "Avoid investment - high risk of loss"
        
        analysis['risk_level'] = risk_level
        analysis['recommendation'] = recommendation
        
        # Add trading parameters
        analysis['trading_parameters'] = {
            'position_size_factor': max(0.1, min(1.0, overall_score / 100)),  # 0.1 to 1.0
            'take_profit_percentage': 20 + (80 - overall_score) / 2,  # Higher for riskier tokens
            'stop_loss_percentage': 10 + (80 - overall_score) / 4,   # Higher for riskier tokens
            'max_slippage': 1 + (100 - overall_score) / 10  # 1% to 11%
        }
        
        # Cache the result
        self.cache[cache_key] = {
            'data': analysis,
            'timestamp': time.time()
        }
        
        return analysis

# Create a global instance
token_analyzer = TokenAnalyzer()

def analyze_token(token_address: str, chain: str = 'auto') -> Dict[str, Any]:
    """
    Perform comprehensive token analysis using the global analyzer instance.
    
    Args:
        token_address: Token address
        chain: Blockchain (auto, ethereum, solana, bsc, polygon)
        
    Returns:
        Comprehensive token analysis
    """
    return token_analyzer.analyze_token(token_address, chain)

if __name__ == "__main__":
    # Test the token analyzer
    # Solana example: BONK
    bonk_analysis = token_analyzer.analyze_token("DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263")
    print(f"BONK Analysis: {json.dumps(bonk_analysis, indent=2)}")
    
    # Ethereum example: PEPE
    pepe_analysis = token_analyzer.analyze_token("0x6982508145454ce325ddbe47a25d4ec3d2311933")
    print(f"PEPE Analysis: {json.dumps(pepe_analysis, indent=2)}")