#!/bin/bash

# This script starts the Telegram bot and ensures it keeps running

# Kill any existing direct_bot.py processes
pkill -f "python direct_bot.py" || true

# Start the bot in the background
nohup python direct_bot.py > direct_bot.log 2>&1 &

echo "Telegram bot started! PID: $!"
echo "Log file: direct_bot.log"