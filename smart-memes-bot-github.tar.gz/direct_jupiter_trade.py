"""
Direct Jupiter Trade Implementation

This script provides a direct integration with Jupiter API for executing 
real trades with your Solana wallet.
"""

import os
import json
import time
import base58
import base64
import logging
import requests
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
from datetime import datetime
import argparse

# Import Solana libraries
from solana.rpc.api import Client
from solana.transaction import Transaction
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.rpc.types import TxOpts

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("DirectJupiterTrade")

# Constants
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
JUPITER_QUOTE_API_URL = "https://quote-api.jup.ag/v6/quote"
JUPITER_SWAP_API_URL = "https://quote-api.jup.ag/v6/swap"
TRANSACTION_HISTORY_FILE = "jupiter_real_trades.json"

# Token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
JTO_MINT = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"

# Token symbol to address mapping
TOKEN_MAP = {
    "SOL": SOL_MINT,
    "USDC": USDC_MINT,
    "BONK": BONK_MINT,
    "WIF": WIF_MINT,
    "JTO": JTO_MINT
}

# Environment variables
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")

# Initialize Solana client
client = Client(SOLANA_RPC_URL)

def load_keypair() -> Optional[Keypair]:
    """
    Load Solana keypair from private key
    
    Returns:
        Keypair or None if not available
    """
    if not SOLANA_PRIVATE_KEY:
        logger.error("SOLANA_PRIVATE_KEY environment variable not set")
        return None
    
    try:
        # Convert from base58
        private_key_bytes = base58.b58decode(SOLANA_PRIVATE_KEY)
        return Keypair.from_secret_key(private_key_bytes)
    except Exception as e:
        logger.error(f"Error loading keypair: {e}")
        return None

def get_wallet_address() -> Optional[str]:
    """
    Get wallet address from private key
    
    Returns:
        Wallet address or None if private key not available
    """
    keypair = load_keypair()
    if not keypair:
        return None
    
    return str(keypair.public_key)

def get_sol_balance() -> Dict[str, Any]:
    """
    Get SOL balance for the wallet
    
    Returns:
        Dict with balance information
    """
    wallet_address = get_wallet_address()
    if not wallet_address:
        return {"error": "No wallet address available"}
    
    try:
        response = client.get_balance(PublicKey(wallet_address))
        if "result" in response and "value" in response["result"]:
            balance_lamports = response["result"]["value"]
            balance_sol = balance_lamports / 10**9
            
            # For simplicity, assume $100 per SOL
            # In a real implementation, get the price from an API
            sol_price_usd = 100.0
            
            return {
                "address": wallet_address,
                "balance_lamports": balance_lamports,
                "balance_sol": balance_sol,
                "balance_usd": balance_sol * sol_price_usd
            }
        else:
            return {"error": f"Failed to get balance: {response}"}
    except Exception as e:
        logger.error(f"Error getting SOL balance: {e}")
        return {"error": str(e)}

def get_quote(
    input_mint: str, 
    output_mint: str, 
    amount: int, 
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Get a swap quote from Jupiter
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Maximum slippage in basis points (1 bps = 0.01%)
        
    Returns:
        Dict with quote information or error
    """
    try:
        url = JUPITER_QUOTE_API_URL
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": str(amount),
            "slippageBps": slippage_bps,
            "onlyDirectRoutes": False,
            "asLegacyTransaction": False
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            return response.json()
        else:
            error_msg = f"Error getting quote: {response.status_code} - {response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error getting quote: {e}")
        return {"error": str(e)}

def execute_swap(
    input_mint: str, 
    output_mint: str, 
    amount: int,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Execute a token swap using Jupiter
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Maximum slippage in basis points
        
    Returns:
        Dict with transaction result or error
    """
    # Get wallet information
    wallet_address = get_wallet_address()
    keypair = load_keypair()
    
    if not wallet_address or not keypair:
        return {"error": "No wallet available for trading"}
    
    try:
        # 1. Get a quote
        logger.info(f"Getting quote for {amount} of {input_mint} to {output_mint}")
        quote = get_quote(input_mint, output_mint, amount, slippage_bps)
        
        if "error" in quote:
            return quote
        
        # 2. Prepare swap transaction
        swap_data = {
            "quoteResponse": quote,
            "userPublicKey": wallet_address,
            "wrapAndUnwrapSol": True
        }
        
        logger.info("Requesting swap transaction...")
        swap_response = requests.post(JUPITER_SWAP_API_URL, json=swap_data)
        
        if swap_response.status_code != 200:
            error_msg = f"Error getting swap transaction: {swap_response.status_code} - {swap_response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
        
        swap_transaction = swap_response.json()
        
        # 3. Decode and sign the transaction
        if "swapTransaction" not in swap_transaction:
            return {"error": "No swap transaction in response"}
        
        logger.info("Decoding transaction...")
        tx_data = base64.b64decode(swap_transaction["swapTransaction"])
        transaction = Transaction.deserialize(tx_data)
        
        # 4. Sign and send the transaction
        logger.info("Signing and sending transaction...")
        opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
        
        result = client.send_transaction(transaction, keypair, opts=opts)
        
        if "result" in result:
            tx_hash = result["result"]
            logger.info(f"Transaction submitted: {tx_hash}")
            
            # 5. Record the transaction
            record_transaction(input_mint, output_mint, amount, quote, tx_hash)
            
            # 6. Wait for confirmation
            logger.info("Waiting for confirmation...")
            time.sleep(5)
            
            # 7. Check transaction status
            status = client.confirm_transaction(tx_hash)
            
            if status and status.get("result", {}).get("value", {}).get("err") is None:
                logger.info(f"Transaction confirmed: {tx_hash}")
                return {
                    "success": True,
                    "tx_hash": tx_hash,
                    "input_mint": input_mint,
                    "output_mint": output_mint,
                    "amount": amount,
                    "confirmed": True
                }
            else:
                logger.warning(f"Transaction may have failed: {tx_hash}")
                return {
                    "success": True,  # We got a transaction hash
                    "tx_hash": tx_hash,
                    "input_mint": input_mint,
                    "output_mint": output_mint,
                    "amount": amount,
                    "confirmed": False,
                    "error": "Transaction may have failed"
                }
        else:
            error_msg = f"Error sending transaction: {result}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error executing swap: {e}")
        return {"error": str(e)}

def record_transaction(
    input_mint: str,
    output_mint: str,
    amount: int,
    quote: Dict[str, Any],
    tx_hash: str
) -> None:
    """
    Record a transaction in the history file
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        quote: Quote data
        tx_hash: Transaction hash
    """
    # Load existing transactions
    transactions = []
    if os.path.exists(TRANSACTION_HISTORY_FILE):
        try:
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                transactions = json.load(f)
        except Exception as e:
            logger.error(f"Error loading transaction history: {e}")
    
    # Create transaction record
    transaction = {
        "timestamp": datetime.now().isoformat(),
        "input_mint": input_mint,
        "output_mint": output_mint,
        "input_amount": amount,
        "output_amount": quote.get("outAmount", 0),
        "price_impact_pct": quote.get("priceImpactPct", 0),
        "tx_hash": tx_hash,
        "real_transaction": True
    }
    
    # Add to list
    transactions.append(transaction)
    
    # Save updated list
    try:
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(transactions, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving transaction history: {e}")

def buy_token_with_sol(token_mint: str, sol_amount: float, slippage_bps: int = 50) -> Dict[str, Any]:
    """
    Buy a token using SOL
    
    Args:
        token_mint: Token mint address to buy
        sol_amount: Amount of SOL to spend (in SOL, not lamports)
        slippage_bps: Maximum slippage in basis points
        
    Returns:
        Dict with transaction result or error
    """
    # Convert SOL to lamports
    lamports = int(sol_amount * 10**9)
    
    return execute_swap(
        input_mint=SOL_MINT,
        output_mint=token_mint,
        amount=lamports,
        slippage_bps=slippage_bps
    )

def sell_token_for_sol(token_mint: str, token_amount: int, slippage_bps: int = 50) -> Dict[str, Any]:
    """
    Sell a token for SOL
    
    Args:
        token_mint: Token mint address to sell
        token_amount: Amount of token to sell (in smallest units)
        slippage_bps: Maximum slippage in basis points
        
    Returns:
        Dict with transaction result or error
    """
    return execute_swap(
        input_mint=token_mint,
        output_mint=SOL_MINT,
        amount=token_amount,
        slippage_bps=slippage_bps
    )

def check_system_ready() -> Dict[str, bool]:
    """
    Check if the trading system is ready
    
    Returns:
        Dict with system status
    """
    status = {
        "private_key_available": SOLANA_PRIVATE_KEY is not None,
        "keypair_valid": load_keypair() is not None,
        "wallet_address": get_wallet_address()
    }
    
    # Check for SOL balance
    if status["wallet_address"]:
        balance = get_sol_balance()
        if "error" not in balance:
            status["sol_balance"] = balance["balance_sol"]
            status["has_funds"] = balance["balance_sol"] > 0
        else:
            status["has_funds"] = False
    else:
        status["has_funds"] = False
    
    # System is ready if we have a valid keypair and funds
    status["ready"] = status["keypair_valid"] and status["has_funds"]
    
    return status

def run_direct_swap(args):
    """
    Run a direct swap based on command-line arguments
    
    Args:
        args: Command-line arguments
    """
    # Check if the system is ready
    status = check_system_ready()
    
    if not status["ready"]:
        if not status["private_key_available"]:
            print("Error: SOLANA_PRIVATE_KEY environment variable not set")
        elif not status["keypair_valid"]:
            print("Error: Invalid private key")
        elif not status["has_funds"]:
            print(f"Error: No SOL balance in wallet {status['wallet_address']}")
        return
    
    # Determine input and output token addresses
    input_token = args.input_token.upper()
    output_token = args.output_token.upper()
    
    input_mint = TOKEN_MAP.get(input_token, input_token)
    output_mint = TOKEN_MAP.get(output_token, output_token)
    
    # Determine amount
    amount = args.amount
    
    # For SOL, convert to lamports
    if input_token == "SOL" or input_mint == SOL_MINT:
        amount_units = int(amount * 10**9)
        print(f"Trading {amount} SOL ({amount_units} lamports) for {output_token}")
    else:
        # Assume 9 decimals for other tokens
        # In a real implementation, we would look up the token's decimals
        decimals = 9
        amount_units = int(amount * 10**decimals)
        print(f"Trading {amount} {input_token} ({amount_units} units) for {output_token}")
    
    # Get a quote
    quote = get_quote(input_mint, output_mint, amount_units, args.slippage)
    
    if "error" in quote:
        print(f"Error getting quote: {quote['error']}")
        return
    
    # Show the quote
    if "outAmount" in quote:
        out_amount = int(quote["outAmount"])
        out_decimals = 9 if output_token != "USDC" else 6
        out_amount_readable = out_amount / 10**out_decimals
        price_impact = quote.get("priceImpactPct", 0) * 100
        
        print(f"Quote: {amount} {input_token} -> {out_amount_readable} {output_token}")
        print(f"Price impact: {price_impact:.2f}%")
        print(f"Slippage protection: {args.slippage / 100:.2f}%")
    
    # Confirm with user
    if not args.yes:
        confirm = input("Execute this trade? (y/n): ")
        if confirm.lower() != "y":
            print("Trade cancelled")
            return
    
    # Execute the swap
    print("Executing swap...")
    result = execute_swap(input_mint, output_mint, amount_units, args.slippage)
    
    if "error" in result:
        print(f"Error executing swap: {result['error']}")
    elif result.get("success"):
        print(f"Swap submitted successfully!")
        print(f"Transaction hash: {result['tx_hash']}")
        print(f"Status: {'Confirmed' if result.get('confirmed') else 'Pending confirmation'}")
    else:
        print(f"Swap failed: {result}")

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Direct Jupiter Trade")
    parser.add_argument("input_token", help="Input token symbol or address")
    parser.add_argument("output_token", help="Output token symbol or address")
    parser.add_argument("amount", type=float, help="Amount in input token's native units")
    parser.add_argument("--slippage", type=int, default=50, help="Slippage in basis points (default: 50 = 0.5%%)")
    parser.add_argument("--yes", "-y", action="store_true", help="Execute without confirmation")
    
    args = parser.parse_args()
    
    # Run the direct swap
    run_direct_swap(args)

if __name__ == "__main__":
    main()