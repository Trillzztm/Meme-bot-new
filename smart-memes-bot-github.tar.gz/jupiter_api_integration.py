"""
Jupiter DEX API Integration for SMART MEMES BOT

This module provides direct integration with Jupiter's API for Solana trading.
It enables real transactions using the user's private key.
"""

import os
import json
import time
import base64
import logging
import requests
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
from datetime import datetime

# Import required Solana libraries
from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solana.rpc.api import Client
from solana.transaction import Transaction
from solana.rpc.types import TxOpts

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("JupiterAPI")

# Constants
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")
TRANSACTION_HISTORY_FILE = "jupiter_real_transactions.json"

# Solana network configuration
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
SOLANA_WEBSOCKET_URL = "wss://api.mainnet-beta.solana.com"

# Common token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"

# Jupiter API endpoints
JUPITER_API_BASE = "https://quote-api.jup.ag/v6"
QUOTE_ENDPOINT = f"{JUPITER_API_BASE}/quote"
SWAP_ENDPOINT = f"{JUPITER_API_BASE}/swap"


@dataclass
class SwapParams:
    """Parameters for a token swap"""
    input_mint: str  # Input token mint address
    output_mint: str  # Output token mint address
    amount: int  # Amount in input token's smallest units
    slippage_bps: int = 50  # Slippage in basis points (default 0.5%)
    max_accounts: int = 10  # Maximum number of accounts to include
    as_legacy_transaction: bool = False  # Whether to use legacy transaction format


def check_valid_private_key() -> bool:
    """Check if a valid private key is available"""
    if not SOLANA_PRIVATE_KEY:
        logger.error("No Solana private key found in environment")
        return False
    
    try:
        # Try to decode the private key
        if len(SOLANA_PRIVATE_KEY) == 88 and SOLANA_PRIVATE_KEY[:3] == "[" and SOLANA_PRIVATE_KEY[-1] == "]":
            # Format is likely a string representation of a byte array
            # Convert it to proper format for Keypair
            return True
        elif len(SOLANA_PRIVATE_KEY) in (64, 128):
            # Hex encoded or base58 encoded private key
            return True
        else:
            logger.error("Invalid private key format")
            return False
    except Exception as e:
        logger.error(f"Error validating private key: {e}")
        return False


def get_keypair() -> Optional[Keypair]:
    """Get Solana keypair from private key"""
    if not SOLANA_PRIVATE_KEY:
        logger.error("No private key available")
        return None
    
    try:
        # Try different formats of private key
        if len(SOLANA_PRIVATE_KEY) == 88 and SOLANA_PRIVATE_KEY[:3] == "[" and SOLANA_PRIVATE_KEY[-1] == "]":
            # Convert string representation of array to bytes
            byte_array = json.loads(SOLANA_PRIVATE_KEY)
            return Keypair.from_bytes(bytes(byte_array))
        elif len(SOLANA_PRIVATE_KEY) == 64:
            # Hex encoded private key
            binary_data = bytes.fromhex(SOLANA_PRIVATE_KEY)
            return Keypair.from_bytes(binary_data)
        else:
            # Assume base58 encoded
            return Keypair.from_base58_string(SOLANA_PRIVATE_KEY)
    except Exception as e:
        logger.error(f"Error creating keypair: {e}")
        return None


def get_wallet_address() -> Optional[str]:
    """Get wallet address from keypair"""
    keypair = get_keypair()
    if not keypair:
        return None
    
    return str(keypair.pubkey())


def connect_solana_client() -> Client:
    """Connect to Solana RPC"""
    return Client(SOLANA_RPC_URL)


def get_quote(
    input_mint: str, 
    output_mint: str, 
    amount: int, 
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Get a swap quote from Jupiter
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Quote information or error
    """
    try:
        url = QUOTE_ENDPOINT
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": amount,
            "slippageBps": slippage_bps,
            "onlyDirectRoutes": False,
            "asLegacyTransaction": False
        }
        
        logger.info(f"Getting quote for {amount} of {input_mint} to {output_mint}")
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            return response.json()
        else:
            error_msg = f"Error getting quote: {response.status_code} - {response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error getting quote: {e}")
        return {"error": f"Error: {str(e)}"}


def get_swap_instructions(
    wallet_address: str,
    quote_response: Dict[str, Any],
    as_legacy_transaction: bool = False
) -> Dict[str, Any]:
    """
    Get swap instructions from Jupiter
    
    Args:
        wallet_address: User's wallet address
        quote_response: Quote response from get_quote
        as_legacy_transaction: Whether to use legacy transaction format
        
    Returns:
        dict: Swap instructions or error
    """
    try:
        url = SWAP_ENDPOINT
        payload = {
            "quoteResponse": quote_response,
            "userPublicKey": wallet_address,
            "wrapAndUnwrapSol": True,
            "asLegacyTransaction": as_legacy_transaction
        }
        
        logger.info(f"Getting swap instructions for wallet {wallet_address}")
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            return response.json()
        else:
            error_msg = f"Error getting swap instructions: {response.status_code} - {response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error getting swap instructions: {e}")
        return {"error": f"Error: {str(e)}"}


def execute_swap_transaction(
    swap_instructions: Dict[str, Any],
    keypair: Keypair
) -> Dict[str, Any]:
    """
    Execute a swap transaction
    
    Args:
        swap_instructions: Swap instructions from get_swap_instructions
        keypair: Solana keypair
        
    Returns:
        dict: Transaction result or error
    """
    try:
        client = connect_solana_client()
        
        # Extracting transaction data
        if "swapTransaction" not in swap_instructions:
            return {"error": "No swap transaction in instructions"}
        
        # Decode the transaction data
        tx_data = swap_instructions["swapTransaction"]
        tx_buffer = base64.b64decode(tx_data)
        
        # Create a transaction from the serialized data
        transaction = Transaction.from_bytes(tx_buffer)
        
        # Sign and send the transaction
        logger.info(f"Sending transaction to Solana network")
        opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
        result = client.send_transaction(transaction, keypair, opts=opts)
        
        if "result" in result:
            tx_hash = result["result"]
            logger.info(f"Transaction submitted: {tx_hash}")
            
            # Wait for confirmation
            logger.info("Waiting for transaction confirmation...")
            time.sleep(5)  # Wait for confirmation
            
            # Get transaction status
            status = client.get_transaction(tx_hash)
            
            if status and "result" in status and status["result"]:
                logger.info("Transaction confirmed!")
                save_transaction(swap_instructions, tx_hash, True)
                
                return {
                    "success": True,
                    "tx_hash": tx_hash,
                    "status": "confirmed",
                    "input_mint": swap_instructions.get("inputMint"),
                    "output_mint": swap_instructions.get("outputMint"),
                    "input_amount": swap_instructions.get("inputAmount"),
                    "output_amount": swap_instructions.get("outputAmount")
                }
            else:
                logger.warning(f"Transaction not confirmed yet: {tx_hash}")
                save_transaction(swap_instructions, tx_hash, None)
                
                return {
                    "success": True,
                    "tx_hash": tx_hash,
                    "status": "pending",
                    "message": "Transaction submitted but not confirmed yet"
                }
        else:
            error_msg = f"Error sending transaction: {result}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error executing swap: {e}")
        return {"error": f"Error: {str(e)}"}


def execute_swap(
    input_mint: str,
    output_mint: str,
    amount: int,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    High-level function to execute a token swap using Jupiter
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Transaction result or error
    """
    # Check if we have a private key
    if not check_valid_private_key():
        return {"error": "No valid private key available"}
    
    # Get keypair
    keypair = get_keypair()
    if not keypair:
        return {"error": "Failed to create keypair"}
    
    # Get wallet address
    wallet_address = str(keypair.pubkey())
    logger.info(f"Using wallet address: {wallet_address}")
    
    # 1. Get a quote
    quote = get_quote(input_mint, output_mint, amount, slippage_bps)
    if "error" in quote:
        return quote
    
    # 2. Get swap instructions
    swap_instructions = get_swap_instructions(wallet_address, quote)
    if "error" in swap_instructions:
        return swap_instructions
    
    # 3. Execute the swap transaction
    return execute_swap_transaction(swap_instructions, keypair)


def save_transaction(swap_data: Dict[str, Any], tx_hash: str, confirmed: Optional[bool]) -> None:
    """
    Save transaction record to history file
    
    Args:
        swap_data: Swap transaction data
        tx_hash: Transaction hash
        confirmed: Whether the transaction is confirmed (None if unknown)
    """
    try:
        # Load existing transactions
        transactions = []
        if os.path.exists(TRANSACTION_HISTORY_FILE):
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                transactions = json.load(f)
        
        # Create transaction record
        transaction = {
            "timestamp": datetime.now().isoformat(),
            "tx_hash": tx_hash,
            "input_mint": swap_data.get("inputMint", "unknown"),
            "output_mint": swap_data.get("outputMint", "unknown"),
            "input_amount": swap_data.get("inputAmount", 0),
            "output_amount": swap_data.get("outputAmount", 0),
            "confirmed": confirmed,
            "real_transaction": True
        }
        
        # Add to list
        transactions.append(transaction)
        
        # Save updated list
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(transactions, f, indent=2)
            
        logger.info(f"Saved transaction {tx_hash} to history")
    except Exception as e:
        logger.error(f"Error saving transaction history: {e}")


def get_transaction_history() -> List[Dict[str, Any]]:
    """
    Get transaction history
    
    Returns:
        list: Transaction history
    """
    if not os.path.exists(TRANSACTION_HISTORY_FILE):
        return []
    
    try:
        with open(TRANSACTION_HISTORY_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading transaction history: {e}")
        return []


def check_transaction_status(tx_hash: str) -> Dict[str, Any]:
    """
    Check the status of a transaction
    
    Args:
        tx_hash: Transaction hash
        
    Returns:
        dict: Transaction status
    """
    try:
        client = connect_solana_client()
        status = client.get_transaction(tx_hash)
        
        if status and "result" in status and status["result"]:
            # Update transaction status in history
            update_transaction_status(tx_hash, True)
            
            return {
                "success": True,
                "tx_hash": tx_hash,
                "status": "confirmed",
                "confirmation_time": status["result"].get("blockTime", None)
            }
        else:
            return {
                "success": False,
                "tx_hash": tx_hash,
                "status": "pending or not found"
            }
    except Exception as e:
        logger.error(f"Error checking transaction status: {e}")
        return {"error": f"Error: {str(e)}"}


def update_transaction_status(tx_hash: str, confirmed: bool) -> None:
    """
    Update transaction status in history file
    
    Args:
        tx_hash: Transaction hash
        confirmed: Whether the transaction is confirmed
    """
    try:
        # Load existing transactions
        transactions = get_transaction_history()
        
        # Find and update transaction
        for tx in transactions:
            if tx.get("tx_hash") == tx_hash:
                tx["confirmed"] = confirmed
                break
        
        # Save updated list
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(transactions, f, indent=2)
            
        logger.info(f"Updated status for transaction {tx_hash}: confirmed={confirmed}")
    except Exception as e:
        logger.error(f"Error updating transaction status: {e}")


def buy_token_with_sol(token_mint: str, sol_amount: float, slippage_bps: int = 50) -> Dict[str, Any]:
    """
    Buy a token using SOL
    
    Args:
        token_mint: Token mint address to buy
        sol_amount: Amount of SOL to spend (in SOL, not lamports)
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Transaction result or error
    """
    # Convert SOL to lamports
    lamports = int(sol_amount * 10**9)
    
    return execute_swap(
        input_mint=SOL_MINT,
        output_mint=token_mint,
        amount=lamports,
        slippage_bps=slippage_bps
    )


def sell_token_for_sol(token_mint: str, token_amount: int, slippage_bps: int = 50) -> Dict[str, Any]:
    """
    Sell a token for SOL
    
    Args:
        token_mint: Token mint address to sell
        token_amount: Amount of token to sell (in token's smallest units)
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Transaction result or error
    """
    return execute_swap(
        input_mint=token_mint,
        output_mint=SOL_MINT,
        amount=token_amount,
        slippage_bps=slippage_bps
    )


def get_sol_balance() -> Dict[str, Any]:
    """
    Get SOL balance for the current wallet
    
    Returns:
        dict: Balance information
    """
    wallet_address = get_wallet_address()
    if not wallet_address:
        return {"error": "No wallet address available"}
    
    try:
        client = connect_solana_client()
        response = client.get_balance(wallet_address)
        
        if "result" in response and "value" in response["result"]:
            lamports = response["result"]["value"]
            sol = lamports / 10**9
            
            return {
                "address": wallet_address,
                "balance_lamports": lamports,
                "balance_sol": sol,
                "balance_usd": sol * get_sol_price_usd()
            }
        else:
            return {"error": f"Error getting balance: {response}"}
    except Exception as e:
        logger.error(f"Error getting SOL balance: {e}")
        return {"error": f"Error: {str(e)}"}


def get_token_balance(token_mint: str) -> Dict[str, Any]:
    """
    Get balance of a specific token
    
    Args:
        token_mint: Token mint address
        
    Returns:
        dict: Token balance information
    """
    wallet_address = get_wallet_address()
    if not wallet_address:
        return {"error": "No wallet address available"}
    
    try:
        client = connect_solana_client()
        
        # This is a simplification - in a real implementation,
        # you would need to find the associated token account and query its balance
        # For now, we'll return a placeholder
        
        return {
            "address": wallet_address,
            "token_mint": token_mint,
            "balance": 0,
            "decimals": 9
        }
    except Exception as e:
        logger.error(f"Error getting token balance: {e}")
        return {"error": f"Error: {str(e)}"}


def get_sol_price_usd() -> float:
    """
    Get current SOL price in USD
    
    Returns:
        float: SOL price in USD
    """
    try:
        # In a real implementation, you would query a price API
        # For simplicity, we'll use a hardcoded price
        return 100.0
    except Exception as e:
        logger.error(f"Error getting SOL price: {e}")
        return 100.0  # Default fallback price


def test_jupiter_integration() -> None:
    """Test Jupiter integration"""
    logger.info("Testing Jupiter API integration")
    
    # Check if private key is valid
    valid_key = check_valid_private_key()
    logger.info(f"Valid private key: {valid_key}")
    
    if not valid_key:
        logger.warning("No valid private key found, cannot execute transactions")
        return
    
    # Get wallet address
    wallet_address = get_wallet_address()
    logger.info(f"Wallet address: {wallet_address}")
    
    # Get SOL balance
    balance = get_sol_balance()
    logger.info(f"SOL balance: {balance}")
    
    # Test get_quote
    logger.info("Testing get_quote...")
    quote = get_quote(SOL_MINT, USDC_MINT, 10000000)  # 0.01 SOL
    logger.info(f"Quote result: {'Success' if 'error' not in quote else quote['error']}")
    
    if "error" not in quote:
        # In a real scenario, you might want to execute the swap
        # But for testing, we'll just log the details
        logger.info(f"Quote details: {json.dumps(quote, indent=2)}")


if __name__ == "__main__":
    test_jupiter_integration()