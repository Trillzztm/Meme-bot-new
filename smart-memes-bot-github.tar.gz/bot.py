import os
import logging
import asyncio
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# Import utility modules
from utils.solana_client import run_async, get_token_price, buy_token, sell_token
from utils.ai_tools import analyze_token_social

# ─── Configuration ────────────────────────────────────────────────────────
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not TELEGRAM_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN is not set in environment variables")

# ─── Logging Setup ─────────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ─── Command Handlers ──────────────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome message and basic health check."""
    await update.message.reply_text(
        "🤖 SMART MEMES BOT is online!\n"
        "Use /help to see available commands."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List out all your commands."""
    cmds = [
        "/start - Start the bot",
        "/help - Show this help message",
        "/manualsnipe <address> <amount_sol> - Buy a token with specified SOL amount",
        "/tokeninfo <address> - Get AI-powered analysis of a token",
        "/aiadvice <address> <market_address> - Get AI trading advice for a token",
        "/status - Check bot status and wallet balance",
    ]
    await update.message.reply_text("Available commands:\n" + "\n".join(cmds))

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get bot status and wallet balance."""
    await update.message.reply_text(
        "🤖 SMART MEMES BOT Status\n"
        "✅ Bot is running\n"
        "✅ Trading system is operational\n"
        "✅ AI analysis system is online\n\n"
        "Detailed statistics will be shown here."
    )

# ─── Trading Handlers ──────────────────────────────────────────────────────
async def watchgroup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Auto‑snipes every SOL token address mentioned in this group."""
    msg = update.message.text
    # Extract anything that looks like a 44‑char base58 Solana pubkey
    import re
    addrs = re.findall(r"[1-9A-HJ-NP-Za-km-z]{32,45}", msg)
    
    if not addrs:
        return
        
    for addr in set(addrs):
        try:
            # Get token price
            price = run_async(get_token_price(addr))
            if price <= 0:
                logger.warning(f"Invalid price {price} for token {addr}")
                continue
                
            # Buy 0.1 SOL worth by default
            sol_size = 0.1
            
            # Execute the trade
            resp = run_async(buy_token(addr, price, sol_size))
            
            await update.message.reply_text(
                f"🚀 Auto-sniped token {addr}\n"
                f"💰 Amount: {sol_size} SOL\n"
                f"💲 Price: {price:.8f} SOL\n"
                f"🔗 Transaction: {resp}"
            )
            
            # Log the trade to database
            from models import ProfitLog, db
            
            profit_log = ProfitLog(
                token_address=addr,
                market_address=addr,
                buy_price=price,
                buy_amount_sol=sol_size,
                size=sol_size / price if price > 0 else 0,
                buy_tx=resp if "solscan.io" in str(resp) else None,
                source="telegram_group",
            )
            profit_log.save()
            
        except Exception as e:
            logger.error(f"Error auto-sniping token {addr}: {e}")
            await update.message.reply_text(f"❌ Error sniping token {addr}: {str(e)}")

async def manualsnipe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manually snipe a token with a specified amount of SOL."""
    # Check arguments
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /manualsnipe <token_address> <amount_sol>")
        return
        
    try:
        addr = context.args[0]
        amount_sol = float(context.args[1])
        
        # Validate SOL amount
        if amount_sol <= 0 or amount_sol > 10:
            await update.message.reply_text("❌ Invalid SOL amount. Must be between 0 and 10 SOL.")
            return
            
        # Get token price
        price = run_async(get_token_price(addr))
        if price <= 0:
            await update.message.reply_text("❌ Could not get token price. Invalid token or liquidity too low.")
            return
            
        # Execute the trade
        resp = run_async(buy_token(addr, price, amount_sol))
        
        await update.message.reply_text(
            f"🚀 Manually sniped token {addr}\n"
            f"💰 Amount: {amount_sol} SOL\n"
            f"💲 Price: {price:.8f} SOL\n"
            f"🔗 Transaction: {resp}"
        )
        
        # Log the trade to database
        from models import ProfitLog, db
        
        profit_log = ProfitLog(
            token_address=addr,
            market_address=addr,
            buy_price=price,
            buy_amount_sol=amount_sol,
            size=amount_sol / price if price > 0 else 0,
            buy_tx=resp if "solscan.io" in str(resp) else None,
            source="manual",
        )
        profit_log.save()
        
    except ValueError:
        await update.message.reply_text("❌ Invalid SOL amount. Please provide a number.")
    except Exception as e:
        logger.error(f"Error in manual snipe: {e}")
        await update.message.reply_text(f"❌ Error sniping token: {str(e)}")

async def tokeninfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get AI token analysis."""
    # Check arguments
    if len(context.args) < 1:
        await update.message.reply_text("Usage: /tokeninfo <token_address>")
        return
        
    addr = context.args[0]
    
    try:
        # First, send a message that we're analyzing
        await update.message.reply_text(f"🔍 Analyzing token {addr}...\nThis may take a moment.")
        
        # Get the social sentiment analysis
        social = analyze_token_social(addr)
        
        # Get the token price
        price = run_async(get_token_price(addr))
        
        await update.message.reply_text(
            f"🧠 AI Analysis for Token {addr}\n"
            f"💲 Current Price: {price:.8f} SOL\n\n"
            f"📊 Social Sentiment Analysis:\n\n{social}"
        )
        
    except Exception as e:
        logger.error(f"Error analyzing token {addr}: {e}")
        await update.message.reply_text(f"❌ Error analyzing token: {str(e)}")

async def aiadvice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Get AI trading advice for a token on a specific market."""
    # Check arguments
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /aiadvice <token_address> <market_address>")
        return
        
    addr = context.args[0]
    market = context.args[1]
    
    try:
        # First, send a message that we're analyzing
        await update.message.reply_text(f"🔍 Getting AI trading advice for {addr} on market {market}...\nThis may take a moment.")
        
        # Get the token price
        price = run_async(get_token_price(market))
        
        # Get the social sentiment analysis
        advice = analyze_token_social(addr)
        
        await update.message.reply_text(
            f"🤖 AI Trading Advice for {addr}\n"
            f"🏦 Market: {market}\n"
            f"💲 Current Price: {price:.8f} SOL\n\n"
            f"📈 Trading Recommendation:\n\n{advice}"
        )
        
    except Exception as e:
        logger.error(f"Error getting AI advice for {addr}: {e}")
        await update.message.reply_text(f"❌ Error getting AI advice: {str(e)}")

# ─── Global Error Handler ─────────────────────────────────────────────────
async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Log the error and keep the bot alive."""
    logger.error("Exception while handling an update:", exc_info=context.error)
    
    # If update is available, send error message to user
    if update and hasattr(update, 'effective_message') and update.effective_message:
        await update.effective_message.reply_text("Sorry, something went wrong. Please try again later.")

# ─── Bot Runner ───────────────────────────────────────────────────────────
def main():
    """Builds the application, registers handlers, and starts polling."""
    app = (
        ApplicationBuilder()
        .token(TELEGRAM_TOKEN)
        .concurrent_updates(True)
        .build()
    )

    # Register built‑in commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("status", status_command))

    # Register trading commands
    app.add_handler(CommandHandler("manualsnipe", manualsnipe))
    app.add_handler(CommandHandler("tokeninfo", tokeninfo))
    app.add_handler(CommandHandler("aiadvice", aiadvice))

    # Group sniping logic (non‑command messages in groups)
    app.add_handler(
        MessageHandler(
            filters.ChatType.GROUPS & filters.TEXT & ~filters.COMMAND,
            watchgroup,
        )
    )

    # Catch‑all error handler so one crash won't kill your bot
    app.add_error_handler(error_handler)

    # Start polling with automatic recovery, dropping any backed‑up updates
    logger.info("🔄 Starting SMART MEMES BOT polling…")
    app.run_polling(
        poll_interval=1.0,
        timeout=20,
        read_timeout=10,
        drop_pending_updates=True,
    )

if __name__ == "__main__":
    main()