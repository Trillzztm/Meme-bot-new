"""
Gamified Learning Progress Tracker for Crypto Trading

This module implements a gamified learning system to track user progress
and enhance engagement with crypto trading concepts and skills.
"""

import os
import json
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("LearningTracker")

# Constants
LEARNING_DATA_FILE = "learning_progress.json"
ACHIEVEMENTS_FILE = "achievements.json"

# Learning Path Stages
LEARNING_PATHS = {
    "basics": {
        "name": "Crypto Basics",
        "description": "Learn the fundamentals of cryptocurrency and blockchain",
        "stages": [
            {
                "id": "crypto_101",
                "name": "Crypto 101",
                "description": "Introduction to cryptocurrencies",
                "xp": 100,
                "requirements": []
            },
            {
                "id": "blockchain_basics",
                "name": "Blockchain Basics",
                "description": "Understanding how blockchain works",
                "xp": 150,
                "requirements": ["crypto_101"]
            },
            {
                "id": "wallet_setup",
                "name": "Wallet Setup Master",
                "description": "Setting up and securing crypto wallets",
                "xp": 200,
                "requirements": ["crypto_101"]
            },
            {
                "id": "crypto_exchanges",
                "name": "Exchange Explorer",
                "description": "Navigating cryptocurrency exchanges",
                "xp": 250,
                "requirements": ["crypto_101", "wallet_setup"]
            }
        ]
    },
    "trading": {
        "name": "Trading Skills",
        "description": "Develop your crypto trading strategies and skills",
        "stages": [
            {
                "id": "chart_reading",
                "name": "Chart Reader",
                "description": "Learn to read and analyze price charts",
                "xp": 300,
                "requirements": ["crypto_exchanges"]
            },
            {
                "id": "technical_analysis",
                "name": "Technical Analyst",
                "description": "Using technical indicators for trading decisions",
                "xp": 400,
                "requirements": ["chart_reading"]
            },
            {
                "id": "trading_strategies",
                "name": "Strategy Master",
                "description": "Developing effective trading strategies",
                "xp": 500,
                "requirements": ["technical_analysis"]
            },
            {
                "id": "risk_management",
                "name": "Risk Manager",
                "description": "Managing risk and portfolio allocation",
                "xp": 450,
                "requirements": ["trading_strategies"]
            }
        ]
    },
    "advanced": {
        "name": "Advanced Techniques",
        "description": "Master advanced trading techniques and strategies",
        "stages": [
            {
                "id": "defi_mastery",
                "name": "DeFi Explorer",
                "description": "Navigate and use decentralized finance protocols",
                "xp": 600,
                "requirements": ["risk_management"]
            },
            {
                "id": "market_psychology",
                "name": "Market Psychologist",
                "description": "Understanding market sentiment and investor psychology",
                "xp": 550,
                "requirements": ["risk_management"]
            },
            {
                "id": "automated_trading",
                "name": "Bot Commander",
                "description": "Setting up and optimizing trading bots",
                "xp": 700,
                "requirements": ["defi_mastery", "market_psychology"]
            },
            {
                "id": "trading_master",
                "name": "Trading Master",
                "description": "Combining all skills into a complete trading system",
                "xp": 1000,
                "requirements": ["automated_trading"]
            }
        ]
    }
}

# Achievement Types
ACHIEVEMENTS = [
    {
        "id": "first_trade",
        "name": "First Steps",
        "description": "Complete your first trade",
        "icon": "🚀",
        "xp": 50,
        "secret": False
    },
    {
        "id": "profitable_trader",
        "name": "Profitable Trader",
        "description": "Achieve 3 profitable trades in a row",
        "icon": "💰",
        "xp": 100,
        "secret": False
    },
    {
        "id": "portfolio_diversifier",
        "name": "Portfolio Diversifier",
        "description": "Own at least 5 different cryptocurrencies",
        "icon": "🔄",
        "xp": 150,
        "secret": False
    },
    {
        "id": "diamond_hands",
        "name": "Diamond Hands",
        "description": "Hold a position during a 20% market dip",
        "icon": "💎",
        "xp": 200,
        "secret": False
    },
    {
        "id": "quick_learner",
        "name": "Quick Learner",
        "description": "Complete 3 learning modules in a single day",
        "icon": "📚",
        "xp": 120,
        "secret": False
    },
    {
        "id": "night_owl",
        "name": "Night Owl",
        "description": "Trade at 3 AM",
        "icon": "🦉",
        "xp": 75,
        "secret": True
    },
    {
        "id": "dip_buyer",
        "name": "Dip Buyer",
        "description": "Buy a token that dropped more than 15% in 24 hours",
        "icon": "📉",
        "xp": 100,
        "secret": False
    },
    {
        "id": "profit_taker",
        "name": "Profit Taker",
        "description": "Take profit with at least 25% gain",
        "icon": "💸",
        "xp": 150,
        "secret": False
    },
    {
        "id": "trading_streak",
        "name": "Trading Streak",
        "description": "Log in and trade for 7 consecutive days",
        "icon": "🔥",
        "xp": 250,
        "secret": False
    },
    {
        "id": "crypto_millionaire",
        "name": "Crypto Millionaire",
        "description": "Reach a portfolio value of $1,000,000",
        "icon": "🏆",
        "xp": 1000,
        "secret": True
    }
]

# User Levels
LEVELS = [
    {"level": 1, "name": "Crypto Newbie", "xp_required": 0},
    {"level": 2, "name": "Blockchain Explorer", "xp_required": 500},
    {"level": 3, "name": "Trading Apprentice", "xp_required": 1000},
    {"level": 4, "name": "Market Analyst", "xp_required": 2000},
    {"level": 5, "name": "Chart Master", "xp_required": 3500},
    {"level": 6, "name": "Strategy Developer", "xp_required": 5000},
    {"level": 7, "name": "Risk Manager", "xp_required": 7000},
    {"level": 8, "name": "Portfolio Expert", "xp_required": 10000},
    {"level": 9, "name": "Trading Guru", "xp_required": 15000},
    {"level": 10, "name": "Crypto Wizard", "xp_required": 25000}
]


def initialize_user_progress(user_id):
    """
    Initialize a new user's learning progress tracking
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: Initial progress data
    """
    # Default structure for a new user
    default_progress = {
        "user_id": user_id,
        "xp": 0,
        "level": 1,
        "completed_stages": [],
        "achievements": [],
        "daily_streak": 0,
        "last_activity": datetime.now().isoformat(),
        "last_login": datetime.now().isoformat(),
        "trade_stats": {
            "total_trades": 0,
            "profitable_trades": 0,
            "losses": 0,
            "biggest_win": 0,
            "biggest_loss": 0,
            "win_streak": 0,
            "current_streak": 0
        }
    }
    
    save_user_progress(user_id, default_progress)
    return default_progress


def get_user_progress(user_id):
    """
    Get a user's current learning progress
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: User's progress data
    """
    # Create progress data file if it doesn't exist
    if not os.path.exists(LEARNING_DATA_FILE):
        with open(LEARNING_DATA_FILE, "w") as f:
            json.dump({}, f)
    
    # Load the learning progress data
    with open(LEARNING_DATA_FILE, "r") as f:
        all_progress = json.load(f)
    
    # If user not found, initialize their progress
    if str(user_id) not in all_progress:
        return initialize_user_progress(user_id)
    
    return all_progress[str(user_id)]


def save_user_progress(user_id, progress_data):
    """
    Save a user's learning progress
    
    Args:
        user_id: User identifier
        progress_data: Progress data to save
        
    Returns:
        bool: Success status
    """
    try:
        # Create file if it doesn't exist
        if not os.path.exists(LEARNING_DATA_FILE):
            with open(LEARNING_DATA_FILE, "w") as f:
                json.dump({}, f)
        
        # Load existing data
        with open(LEARNING_DATA_FILE, "r") as f:
            all_progress = json.load(f)
        
        # Update the user's progress
        all_progress[str(user_id)] = progress_data
        
        # Save back to file
        with open(LEARNING_DATA_FILE, "w") as f:
            json.dump(all_progress, f, indent=2)
        
        return True
    except Exception as e:
        logger.error(f"Error saving user progress: {e}")
        return False


def complete_learning_stage(user_id, stage_id):
    """
    Mark a learning stage as completed and award XP
    
    Args:
        user_id: User identifier
        stage_id: ID of the completed stage
        
    Returns:
        dict: Updated user progress
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Skip if already completed
    if stage_id in progress["completed_stages"]:
        return progress
    
    # Find the stage in learning paths
    stage_info = None
    for path_key, path_data in LEARNING_PATHS.items():
        for stage in path_data["stages"]:
            if stage["id"] == stage_id:
                stage_info = stage
                break
        if stage_info:
            break
    
    if not stage_info:
        logger.error(f"Stage {stage_id} not found in learning paths")
        return progress
    
    # Check if requirements are met
    for req in stage_info["requirements"]:
        if req not in progress["completed_stages"]:
            logger.warning(f"Requirements not met for stage {stage_id}")
            return progress
    
    # Update progress
    progress["completed_stages"].append(stage_id)
    progress["xp"] += stage_info["xp"]
    progress["last_activity"] = datetime.now().isoformat()
    
    # Check for level up
    current_level = progress["level"]
    for level_info in LEVELS:
        if level_info["level"] > current_level and progress["xp"] >= level_info["xp_required"]:
            progress["level"] = level_info["level"]
            logger.info(f"User {user_id} leveled up to {level_info['level']}: {level_info['name']}")
    
    # Save the updated progress
    save_user_progress(user_id, progress)
    
    return progress


def unlock_achievement(user_id, achievement_id):
    """
    Unlock an achievement and award XP
    
    Args:
        user_id: User identifier
        achievement_id: ID of the achievement
        
    Returns:
        dict: Updated user progress and achievement details
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Skip if already unlocked
    if achievement_id in [a["id"] for a in progress["achievements"]]:
        return {"progress": progress, "achievement": None, "new": False}
    
    # Find the achievement
    achievement = None
    for a in ACHIEVEMENTS:
        if a["id"] == achievement_id:
            achievement = a
            break
    
    if not achievement:
        logger.error(f"Achievement {achievement_id} not found")
        return {"progress": progress, "achievement": None, "new": False}
    
    # Add achievement details with timestamp
    achievement_entry = {
        "id": achievement["id"],
        "name": achievement["name"],
        "description": achievement["description"],
        "icon": achievement["icon"],
        "xp": achievement["xp"],
        "unlocked_at": datetime.now().isoformat()
    }
    
    # Update progress
    progress["achievements"].append(achievement_entry)
    progress["xp"] += achievement["xp"]
    progress["last_activity"] = datetime.now().isoformat()
    
    # Check for level up
    current_level = progress["level"]
    for level_info in LEVELS:
        if level_info["level"] > current_level and progress["xp"] >= level_info["xp_required"]:
            progress["level"] = level_info["level"]
            logger.info(f"User {user_id} leveled up to {level_info['level']}: {level_info['name']}")
    
    # Save the updated progress
    save_user_progress(user_id, progress)
    
    return {"progress": progress, "achievement": achievement, "new": True}


def record_trade(user_id, trade_data):
    """
    Record a trade and update stats, check for achievements
    
    Args:
        user_id: User identifier
        trade_data: Trade information
        
    Returns:
        dict: Updated user progress and any unlocked achievements
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Update trade stats
    stats = progress["trade_stats"]
    stats["total_trades"] += 1
    
    # Calculate profit/loss
    profit = trade_data.get("profit", 0)
    if profit > 0:
        stats["profitable_trades"] += 1
        stats["current_streak"] = stats["current_streak"] + 1 if stats["current_streak"] >= 0 else 1
        if stats["current_streak"] > stats["win_streak"]:
            stats["win_streak"] = stats["current_streak"]
        if profit > stats["biggest_win"]:
            stats["biggest_win"] = profit
    elif profit < 0:
        stats["losses"] += 1
        stats["current_streak"] = stats["current_streak"] - 1 if stats["current_streak"] <= 0 else -1
        if abs(profit) > abs(stats["biggest_loss"]):
            stats["biggest_loss"] = profit  # This will be negative
    
    # Update progress
    progress["trade_stats"] = stats
    progress["last_activity"] = datetime.now().isoformat()
    
    # Check for achievements
    unlocked_achievements = []
    
    # First trade achievement
    if stats["total_trades"] == 1:
        result = unlock_achievement(user_id, "first_trade")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Profitable trader achievement
    if stats["current_streak"] >= 3:
        result = unlock_achievement(user_id, "profitable_trader")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Profit taker achievement
    if trade_data.get("profit_percentage", 0) >= 25:
        result = unlock_achievement(user_id, "profit_taker")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Dip buyer achievement
    if trade_data.get("bought_dip", False) and trade_data.get("dip_percentage", 0) >= 15:
        result = unlock_achievement(user_id, "dip_buyer")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Night owl achievement
    current_hour = datetime.now().hour
    if current_hour >= 3 and current_hour < 4:
        result = unlock_achievement(user_id, "night_owl")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Save the updated progress
    save_user_progress(user_id, progress)
    
    return {"progress": progress, "achievements": unlocked_achievements}


def update_login_streak(user_id):
    """
    Update user's daily login streak and check for achievements
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: Updated user progress and any unlocked achievements
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Get last login date (just the date part, not time)
    last_login = datetime.fromisoformat(progress["last_login"]).date()
    today = datetime.now().date()
    yesterday = datetime.now().date().replace(day=today.day-1)
    
    # Update streak if logged in on consecutive days
    if last_login == yesterday:
        progress["daily_streak"] += 1
    elif last_login < yesterday:
        # Reset streak if missed a day
        progress["daily_streak"] = 1
    # If logged in already today, don't update the streak
    
    # Update last login to today
    if last_login != today:
        progress["last_login"] = datetime.now().isoformat()
    
    # Check for trading streak achievement
    unlocked_achievements = []
    if progress["daily_streak"] >= 7:
        result = unlock_achievement(user_id, "trading_streak")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Save the updated progress
    save_user_progress(user_id, progress)
    
    return {"progress": progress, "achievements": unlocked_achievements}


def check_portfolio_achievements(user_id, portfolio_data):
    """
    Check for portfolio-related achievements
    
    Args:
        user_id: User identifier
        portfolio_data: Portfolio information
        
    Returns:
        dict: Updated user progress and any unlocked achievements
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Check for achievements
    unlocked_achievements = []
    
    # Portfolio diversifier achievement
    unique_tokens = portfolio_data.get("unique_tokens", 0)
    if unique_tokens >= 5:
        result = unlock_achievement(user_id, "portfolio_diversifier")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Crypto millionaire achievement
    portfolio_value = portfolio_data.get("total_value", 0)
    if portfolio_value >= 1000000:
        result = unlock_achievement(user_id, "crypto_millionaire")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Diamond hands achievement
    if portfolio_data.get("held_through_dip", False) and portfolio_data.get("dip_percentage", 0) >= 20:
        result = unlock_achievement(user_id, "diamond_hands")
        if result["new"]:
            unlocked_achievements.append(result["achievement"])
    
    # Save the updated progress
    save_user_progress(user_id, progress)
    
    return {"progress": progress, "achievements": unlocked_achievements}


def get_available_learning_stages(user_id):
    """
    Get all learning stages with their availability status
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: Learning paths with availability status for each stage
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    completed_stages = progress["completed_stages"]
    
    # Copy learning paths structure to avoid modifying the original
    available_paths = {}
    
    for path_key, path_data in LEARNING_PATHS.items():
        available_paths[path_key] = {
            "name": path_data["name"],
            "description": path_data["description"],
            "stages": []
        }
        
        for stage in path_data["stages"]:
            # Check if requirements are met
            requirements_met = True
            for req in stage["requirements"]:
                if req not in completed_stages:
                    requirements_met = False
                    break
            
            # Add availability info to the stage
            stage_info = {
                "id": stage["id"],
                "name": stage["name"],
                "description": stage["description"],
                "xp": stage["xp"],
                "completed": stage["id"] in completed_stages,
                "available": requirements_met,
                "requirements": stage["requirements"]
            }
            
            available_paths[path_key]["stages"].append(stage_info)
    
    return available_paths


def get_user_level_info(user_id):
    """
    Get detailed level information for a user
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: Level information including progress to next level
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    current_level = progress["level"]
    current_xp = progress["xp"]
    
    # Find current and next level info
    current_level_info = None
    next_level_info = None
    
    for i, level_info in enumerate(LEVELS):
        if level_info["level"] == current_level:
            current_level_info = level_info
            if i < len(LEVELS) - 1:
                next_level_info = LEVELS[i + 1]
            break
    
    if not current_level_info:
        logger.error(f"Could not find level info for level {current_level}")
        return None
    
    # Calculate progress to next level
    if next_level_info:
        xp_for_current_level = current_level_info["xp_required"]
        xp_for_next_level = next_level_info["xp_required"]
        xp_needed = xp_for_next_level - xp_for_current_level
        xp_progress = current_xp - xp_for_current_level
        percentage = min(100, int((xp_progress / xp_needed) * 100))
        
        level_info = {
            "current_level": current_level,
            "current_level_name": current_level_info["name"],
            "next_level": next_level_info["level"],
            "next_level_name": next_level_info["name"],
            "current_xp": current_xp,
            "xp_for_next_level": xp_for_next_level,
            "xp_needed": xp_needed,
            "xp_progress": xp_progress,
            "percentage": percentage,
            "max_level": False
        }
    else:
        # Max level reached
        level_info = {
            "current_level": current_level,
            "current_level_name": current_level_info["name"],
            "current_xp": current_xp,
            "xp_for_current_level": current_level_info["xp_required"],
            "max_level": True
        }
    
    return level_info


def get_leaderboard(limit=10):
    """
    Get the XP leaderboard
    
    Args:
        limit: Maximum number of users to include
        
    Returns:
        list: Top users by XP
    """
    # Load all user progress
    if not os.path.exists(LEARNING_DATA_FILE):
        return []
    
    with open(LEARNING_DATA_FILE, "r") as f:
        all_progress = json.load(f)
    
    # Convert to list and sort by XP
    users = []
    for user_id, progress in all_progress.items():
        users.append({
            "user_id": user_id,
            "xp": progress["xp"],
            "level": progress["level"],
            "level_name": next((l["name"] for l in LEVELS if l["level"] == progress["level"]), "Unknown")
        })
    
    # Sort and limit
    users.sort(key=lambda x: x["xp"], reverse=True)
    return users[:limit]


def get_user_stats_summary(user_id):
    """
    Get a summary of user's stats and achievements
    
    Args:
        user_id: User identifier
        
    Returns:
        dict: Summary of user's progress
    """
    # Get user's current progress
    progress = get_user_progress(user_id)
    
    # Get level info
    level_info = get_user_level_info(user_id)
    
    # Count completed stages per path
    completed_by_path = {}
    total_by_path = {}
    
    for path_key, path_data in LEARNING_PATHS.items():
        completed_count = 0
        total_count = len(path_data["stages"])
        
        for stage in path_data["stages"]:
            if stage["id"] in progress["completed_stages"]:
                completed_count += 1
        
        completed_by_path[path_key] = completed_count
        total_by_path[path_key] = total_count
    
    # Calculate overall completion percentage
    total_stages = sum(total_by_path.values())
    completed_stages = sum(completed_by_path.values())
    completion_percentage = int((completed_stages / total_stages) * 100) if total_stages > 0 else 0
    
    # Prepare summary
    summary = {
        "user_id": user_id,
        "xp": progress["xp"],
        "level": level_info,
        "daily_streak": progress["daily_streak"],
        "achievements": {
            "total": len(ACHIEVEMENTS),
            "unlocked": len(progress["achievements"]),
            "percentage": int((len(progress["achievements"]) / len(ACHIEVEMENTS)) * 100)
        },
        "learning_paths": {
            "total_stages": total_stages,
            "completed_stages": completed_stages,
            "completion_percentage": completion_percentage,
            "by_path": {
                path_key: {
                    "name": LEARNING_PATHS[path_key]["name"],
                    "completed": completed_by_path[path_key],
                    "total": total_by_path[path_key],
                    "percentage": int((completed_by_path[path_key] / total_by_path[path_key]) * 100)
                } for path_key in LEARNING_PATHS
            }
        },
        "trade_stats": progress["trade_stats"],
        "last_activity": progress["last_activity"]
    }
    
    return summary