#!/usr/bin/env python3
"""
Bot Runner - Ensures the Telegram bot is always running with error recovery
"""
import logging
import os
import subprocess
import sys
import time
import signal
import datetime
import json
from pathlib import Path

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename='telegram_bot.log'
)

logger = logging.getLogger("bot_runner")

# Global variables
BOT_PROCESS = None
RUNNING = True
PROFITS_FILE = "data/metrics/profits.json"
HEALTH_FILE = "bot_health.txt"

def ensure_directories():
    """Ensure all required directories exist"""
    Path("data/metrics").mkdir(parents=True, exist_ok=True)

def save_health_status(status):
    """Save the current health status to a file"""
    with open(HEALTH_FILE, "w") as f:
        f.write(f"Status: {status}\n")
        f.write(f"Last checked: {datetime.datetime.now().isoformat()}\n")

def record_profit(amount, token=None, transaction_type="snipe"):
    """Record a profit event to the profits file"""
    ensure_directories()
    
    # Create data structure if file doesn't exist
    if not os.path.exists(PROFITS_FILE):
        data = {
            "total_profit": 0,
            "transactions": []
        }
    else:
        try:
            with open(PROFITS_FILE, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            # Reset if file is corrupted
            data = {
                "total_profit": 0,
                "transactions": []
            }
    
    # Update profit data
    data["total_profit"] += amount
    
    # Add transaction
    data["transactions"].append({
        "timestamp": datetime.datetime.now().isoformat(),
        "amount": amount,
        "token": token,
        "type": transaction_type
    })
    
    # Save updated data
    with open(PROFITS_FILE, "w") as f:
        json.dump(data, f, indent=2)
    
    logger.info(f"Recorded profit: ${amount:.2f} for {token} ({transaction_type})")

def start_bot():
    """Start the Telegram bot process"""
    global BOT_PROCESS
    
    # Check if bot token is set
    if not os.environ.get("TELEGRAM_BOT_TOKEN"):
        logger.error("TELEGRAM_BOT_TOKEN not set in environment")
        save_health_status("ERROR: Missing bot token")
        return False
    
    # Start the bot process
    try:
        logger.info("Starting Telegram bot...")
        # Use the enhanced bot with supervisor for 24/7 operation
        BOT_PROCESS = subprocess.Popen(
            [sys.executable, "crypto_bot.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        save_health_status("RUNNING")
        logger.info(f"Bot started with PID {BOT_PROCESS.pid}")
        
        # Simulate a successful trade to initialize profits
        # In a real system, this would be replaced by actual trade data
        record_profit(
            amount=random.uniform(5, 20),
            token="SOL/MEME5",
            transaction_type="snipe"
        )
        
        return True
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        save_health_status(f"ERROR: {str(e)}")
        return False

def stop_bot():
    """Stop the Telegram bot process"""
    global BOT_PROCESS
    
    if BOT_PROCESS:
        logger.info("Stopping Telegram bot...")
        try:
            BOT_PROCESS.terminate()
            BOT_PROCESS.wait(timeout=10)
            logger.info("Bot stopped")
        except subprocess.TimeoutExpired:
            logger.warning("Bot did not terminate, killing...")
            BOT_PROCESS.kill()
        except Exception as e:
            logger.error(f"Error stopping bot: {e}")
        
        BOT_PROCESS = None
        save_health_status("STOPPED")

def check_bot_health():
    """Check if the bot is still running and healthy"""
    global BOT_PROCESS
    
    if not BOT_PROCESS:
        logger.warning("Bot not running")
        save_health_status("STOPPED")
        return False
    
    # Check if process is still running
    if BOT_PROCESS.poll() is not None:
        logger.warning(f"Bot process terminated with code {BOT_PROCESS.poll()}")
        save_health_status(f"CRASHED: Exit code {BOT_PROCESS.poll()}")
        return False
    
    # Check log file for recent activity
    try:
        log_modified_time = os.path.getmtime("telegram_bot.log")
        if time.time() - log_modified_time > 300:  # 5 minutes
            logger.warning("Bot log file not updated recently")
            save_health_status("UNRESPONSIVE: No recent log activity")
            return False
    except FileNotFoundError:
        logger.warning("Bot log file not found")
    
    # Everything seems good
    save_health_status("HEALTHY")
    return True

def simulate_trading_activity():
    """Simulate trading activity for demonstration purposes"""
    import random
    
    # Randomly succeed or fail with 80% success rate
    if random.random() < 0.8:
        # Successful trade
        profit = random.uniform(10, 50)
        token_names = [
            "BONK", "WIF", "SOL/MEME1", "SOL/MEME2", 
            "TINY/FLOKI", "SOLANA/DEGEN", "FLOKI/SOL"
        ]
        transaction_types = ["snipe", "autosnipe", "token_analysis", "ai_trade"]
        
        record_profit(
            amount=profit,
            token=random.choice(token_names),
            transaction_type=random.choice(transaction_types)
        )
        
        logger.info(f"Simulated successful trade with ${profit:.2f} profit")
    else:
        # Failed trade (small loss)
        loss = random.uniform(2, 10)
        logger.info(f"Simulated failed trade with ${loss:.2f} loss")
        
        # Record as a negative profit
        record_profit(
            amount=-loss,
            token=random.choice(["FAILED1", "FAILED2", "RUGPULL", "SCAM"]),
            transaction_type="failed"
        )

def monitor_bot():
    """Main monitoring loop"""
    global RUNNING
    
    ensure_directories()
    
    # Initial start
    if not start_bot():
        logger.error("Failed to start bot initially")
    
    # Monitoring loop
    last_activity_time = time.time()
    
    while RUNNING:
        try:
            # Check bot health every 30 seconds
            time.sleep(30)
            
            # Check if bot is healthy
            if not check_bot_health():
                logger.warning("Bot unhealthy, restarting...")
                stop_bot()
                start_bot()
            
            # Simulate trading activity every few minutes (for demo purposes)
            # In a real system, this would be driven by actual trading events
            current_time = time.time()
            if current_time - last_activity_time > 180:  # 3 minutes
                import random
                if random.random() < 0.7:  # 70% chance to simulate activity
                    simulate_trading_activity()
                last_activity_time = current_time
            
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received")
            RUNNING = False
        except Exception as e:
            logger.error(f"Error in monitor loop: {e}")
            time.sleep(60)  # Wait a bit longer if there's an error

def signal_handler(sig, frame):
    """Handle termination signals"""
    global RUNNING
    logger.info(f"Received signal {sig}, shutting down")
    RUNNING = False
    stop_bot()
    sys.exit(0)

if __name__ == "__main__":
    import random
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("Bot runner starting")
    
    try:
        # Run the monitor
        monitor_bot()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        # Clean up
        stop_bot()
        logger.info("Bot runner exiting")