"""
This is a minimal replacement for main.py
that just imports app_minimal and makes it available as 'app'
for Gunicorn to use.
"""

import logging
import os
from app_minimal import app

# Set up logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("MainMinimal")

# Check environment
logger.info(f"Starting with minimal stable app")
logger.info(f"PORT environment variable: {os.environ.get('PORT', '5000')}")

# This is not needed for gunicorn, but useful for direct execution
if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"Starting app on port {port}")
    app.run(host='0.0.0.0', port=port)