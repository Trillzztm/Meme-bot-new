#!/usr/bin/env python3
"""
SMART MEMES BOT - Real-Time Trading System Launcher

This script launches the complete real-time trading system with market monitoring
and automated trade execution. It provides a simple interface to manage all
components of the trading system.
"""

import os
import sys
import json
import time
import signal
import logging
import argparse
import threading
import subprocess
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trading_system.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("TradingSystem")

# Constants
CONFIG_FILE = "trading_system_config.json"
PROFIT_LOG_FILE = "profit_log.json"

# Global variables
processes = {}
stop_all = False

# Default configuration
DEFAULT_CONFIG = {
    "market_monitor_enabled": True,
    "trading_engine_enabled": True,
    "notification_enabled": True,
    "auto_trade_enabled": True,
    "max_sol_per_trade": 0.05,
    "risk_level": "medium",  # low, medium, high
    "trading_pairs": ["BONK", "WIF", "JTO"],
    "report_interval_min": 15
}

def load_config() -> Dict[str, Any]:
    """
    Load configuration from file
    
    Returns:
        Dict with configuration
    """
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
    
    # Use default config
    return DEFAULT_CONFIG

def save_config(config_data: Dict[str, Any]) -> None:
    """
    Save configuration to file
    
    Args:
        config_data: Configuration to save
    """
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config_data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving configuration: {e}")

def load_profit_log() -> Dict[str, Any]:
    """
    Load profit log from file
    
    Returns:
        Dict with profit log
    """
    if os.path.exists(PROFIT_LOG_FILE):
        try:
            with open(PROFIT_LOG_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading profit log: {e}")
    
    return {"total_profit_usd": 0, "trades": [], "daily_profit": {}}

def save_profit_log(profit_data: Dict[str, Any]) -> None:
    """
    Save profit log to file
    
    Args:
        profit_data: Profit data to save
    """
    try:
        with open(PROFIT_LOG_FILE, "w") as f:
            json.dump(profit_data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving profit log: {e}")

def record_profit(amount_usd: float, token: str, tx_hash: str = None) -> None:
    """
    Record a profit in the log
    
    Args:
        amount_usd: Profit amount in USD
        token: Token involved
        tx_hash: Transaction hash
    """
    profit_log = load_profit_log()
    
    # Add to total profit
    profit_log["total_profit_usd"] += amount_usd
    
    # Add trade record
    trade = {
        "timestamp": time.time(),
        "amount_usd": amount_usd,
        "token": token,
        "tx_hash": tx_hash
    }
    
    profit_log["trades"].append(trade)
    
    # Update daily profit
    import datetime
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    
    if today not in profit_log["daily_profit"]:
        profit_log["daily_profit"][today] = 0
    
    profit_log["daily_profit"][today] += amount_usd
    
    # Save profit log
    save_profit_log(profit_log)
    
    logger.info(f"Recorded profit: ${amount_usd:.2f} from {token}")

def check_solana_private_key() -> bool:
    """
    Check if Solana private key is set in environment
    
    Returns:
        bool: True if private key is set
    """
    if not os.environ.get("SOLANA_PRIVATE_KEY"):
        logger.warning("SOLANA_PRIVATE_KEY environment variable not set")
        
        # Check if we can set it up
        if os.path.exists("solana_private_key_setup.py"):
            logger.info("Running private key setup...")
            os.system("python solana_private_key_setup.py")
            
            # Check again
            if not os.environ.get("SOLANA_PRIVATE_KEY"):
                logger.error("Failed to set up private key")
                return False
            else:
                logger.info("Private key set up successfully")
                return True
        else:
            logger.error("Private key setup script not found")
            return False
    
    return True

def check_birdeye_api_key() -> bool:
    """
    Check if Birdeye API key is set in environment
    
    Returns:
        bool: True if API key is set
    """
    if not os.environ.get("BIRDEYE_API_KEY"):
        logger.warning("BIRDEYE_API_KEY environment variable not set")
        
        # Ask user for key
        print("\nBirdeye API key is required for market monitoring.")
        print("You can get a free API key at https://docs.birdeye.so/docs/public-api")
        
        api_key = input("Enter your Birdeye API key: ")
        
        if api_key:
            os.environ["BIRDEYE_API_KEY"] = api_key
            logger.info("Birdeye API key set")
            return True
        else:
            logger.error("No Birdeye API key provided")
            return False
    
    return True

def start_market_monitor() -> Optional[subprocess.Popen]:
    """
    Start the market monitor
    
    Returns:
        Popen object or None if failed
    """
    # Check if script exists
    if not os.path.exists("market_monitor.py"):
        logger.error("market_monitor.py not found")
        return None
    
    try:
        # Start process
        process = subprocess.Popen(
            ["python", "market_monitor.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        
        logger.info("Market monitor started")
        return process
    
    except Exception as e:
        logger.error(f"Error starting market monitor: {e}")
        return None

def start_trading_engine() -> Optional[subprocess.Popen]:
    """
    Start the trading engine
    
    Returns:
        Popen object or None if failed
    """
    # Check if script exists
    if not os.path.exists("realtime_trading_engine.py"):
        logger.error("realtime_trading_engine.py not found")
        return None
    
    try:
        # Start process
        process = subprocess.Popen(
            ["python", "realtime_trading_engine.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True
        )
        
        logger.info("Trading engine started")
        return process
    
    except Exception as e:
        logger.error(f"Error starting trading engine: {e}")
        return None

def stop_process(process: subprocess.Popen) -> None:
    """
    Stop a process
    
    Args:
        process: Process to stop
    """
    if process and process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=5)
        except:
            process.kill()
            process.wait(timeout=5)

def process_output_thread(process: subprocess.Popen, component: str) -> None:
    """
    Thread to process output from a component
    
    Args:
        process: Process to monitor
        component: Component name
    """
    global stop_all
    
    # Process stdout
    for line in iter(process.stdout.readline, ""):
        if stop_all:
            break
        
        # Strip whitespace
        line = line.strip()
        
        if line:
            logger.info(f"[{component}] {line}")
    
    # Process stderr
    for line in iter(process.stderr.readline, ""):
        if stop_all:
            break
        
        # Strip whitespace
        line = line.strip()
        
        if line:
            logger.error(f"[{component}] {line}")

def monitor_profits_thread() -> None:
    """Thread to monitor profits and report summary"""
    global stop_all
    
    config = load_config()
    report_interval = config.get("report_interval_min", 15) * 60  # Convert to seconds
    
    last_report_time = time.time()
    
    while not stop_all:
        try:
            # Check if it's time to report
            current_time = time.time()
            if current_time - last_report_time >= report_interval:
                report_profit_summary()
                last_report_time = current_time
            
            # Sleep a bit
            time.sleep(10)
        
        except Exception as e:
            logger.error(f"Error in profit monitor thread: {e}")
            time.sleep(10)

def report_profit_summary() -> None:
    """Report profit summary"""
    profit_log = load_profit_log()
    
    total_profit = profit_log.get("total_profit_usd", 0)
    num_trades = len(profit_log.get("trades", []))
    
    logger.info("=== Profit Summary ===")
    logger.info(f"Total profit: ${total_profit:.2f}")
    logger.info(f"Total trades: {num_trades}")
    
    # Daily profit
    daily_profit = profit_log.get("daily_profit", {})
    
    if daily_profit:
        logger.info("Daily profit:")
        
        # Sort by date
        for date, profit in sorted(daily_profit.items(), reverse=True)[:7]:  # Last 7 days
            logger.info(f"  {date}: ${profit:.2f}")
    
    logger.info("======================")

def cleanup() -> None:
    """Clean up processes on exit"""
    global processes, stop_all
    
    stop_all = True
    
    logger.info("Stopping all components...")
    
    for name, process in processes.items():
        if process and process.poll() is None:
            logger.info(f"Stopping {name}...")
            stop_process(process)
    
    logger.info("All components stopped")

def signal_handler(sig, frame) -> None:
    """Handle signals"""
    logger.info("Interrupt received, shutting down...")
    cleanup()
    sys.exit(0)

def start_all_components() -> None:
    """Start all trading system components"""
    global processes
    
    config = load_config()
    
    # Setup signal handler
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Check environment
    if not check_solana_private_key():
        logger.error("Solana private key not available, cannot start trading system")
        return
    
    check_birdeye_api_key()  # This is optional
    
    # Start market monitor if enabled
    if config.get("market_monitor_enabled", True):
        processes["market_monitor"] = start_market_monitor()
        
        if processes["market_monitor"]:
            # Start output thread
            threading.Thread(
                target=process_output_thread,
                args=(processes["market_monitor"], "MarketMonitor"),
                daemon=True
            ).start()
    
    # Start trading engine if enabled
    if config.get("trading_engine_enabled", True):
        processes["trading_engine"] = start_trading_engine()
        
        if processes["trading_engine"]:
            # Start output thread
            threading.Thread(
                target=process_output_thread,
                args=(processes["trading_engine"], "TradingEngine"),
                daemon=True
            ).start()
    
    # Start profit monitor thread
    threading.Thread(
        target=monitor_profits_thread,
        daemon=True
    ).start()
    
    logger.info("All components started")

def run_command_line() -> None:
    """Run command line interface"""
    parser = argparse.ArgumentParser(description="SMART MEMES BOT - Real-Time Trading System")
    
    # Subparsers
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Start command
    start_parser = subparsers.add_parser("start", help="Start the trading system")
    
    # Stop command
    stop_parser = subparsers.add_parser("stop", help="Stop the trading system")
    
    # Profit command
    profit_parser = subparsers.add_parser("profit", help="Show profit summary")
    
    # Record profit command
    record_parser = subparsers.add_parser("record", help="Record a profit")
    record_parser.add_argument("amount", type=float, help="Profit amount in USD")
    record_parser.add_argument("token", help="Token involved")
    record_parser.add_argument("--tx", help="Transaction hash")
    
    # Config command
    config_parser = subparsers.add_parser("config", help="Configure the trading system")
    config_parser.add_argument("--risk", choices=["low", "medium", "high"], help="Risk level")
    config_parser.add_argument("--max-sol", type=float, help="Maximum SOL per trade")
    config_parser.add_argument("--auto-trade", type=bool, help="Enable auto-trading")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Execute command
    if args.command == "start":
        start_all_components()
        
        # Keep alive
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            cleanup()
    
    elif args.command == "stop":
        cleanup()
    
    elif args.command == "profit":
        report_profit_summary()
    
    elif args.command == "record":
        record_profit(args.amount, args.token, args.tx)
    
    elif args.command == "config":
        config = load_config()
        
        # Update config
        if args.risk:
            config["risk_level"] = args.risk
        
        if args.max_sol:
            config["max_sol_per_trade"] = args.max_sol
        
        if args.auto_trade is not None:
            config["auto_trade_enabled"] = args.auto_trade
        
        # Save config
        save_config(config)
        
        # Show config
        print("Current configuration:")
        for key, value in config.items():
            print(f"  {key}: {value}")
    
    else:
        # No command, show help
        parser.print_help()

def main() -> None:
    """Main function"""
    try:
        run_command_line()
    
    except Exception as e:
        logger.error(f"Error in main function: {e}")
        cleanup()

if __name__ == "__main__":
    main()