# SMART MEMES BOT - User Guide

Welcome to SMART MEMES BOT, your advanced cryptocurrency trading assistant and automated money-making machine. This guide will help you get started with the system and maximize your profits.

## Getting Started

1. **Connect Your Wallet**: Your wallet address is already configured in the system:
   ```
   GWrigDjL6HsYvK32y5b7ZzwTH8Vw1ZR2miN5jMLrM8f1
   ```

2. **Start the Money Maker**: Run the following command to start the automated trading system:
   ```
   ./run_moneymaker.sh
   ```

3. **Access the Dashboard**: Once started, you can monitor your profits and trades at:
   ```
   http://localhost:8080
   ```

## Key Features

### 1. Automated Trading
The system automatically executes trades on your behalf using advanced AI algorithms and strategies:
- **Breakout Trading**: Identifies and trades market breakouts for quick profits
- **Trend Following**: Follows established market trends for consistent returns
- **Smart Sniper**: Targets new tokens with high growth potential
- **Dip Buying**: Buys during temporary price dips for maximum gains

### 2. Risk Management
Built-in risk management protects your capital:
- Dynamically adjusts trade sizes based on wallet balance
- Implements stop-loss to minimize potential losses
- Diversifies trades across multiple tokens and strategies

### 3. Real-Time Monitoring
The web dashboard provides:
- Real-time profit tracking
- Wallet balance monitoring
- Trade history and performance stats
- Token portfolio overview

## Advanced Configuration

### Trading Parameters
You can adjust trading parameters in `auto_trade_config.json`:
- `risk_level`: Set to "low", "medium", or "high"
- `max_trade_size_sol`: Maximum SOL per trade
- `trade_interval_seconds`: Time between trades

### Adding Tokens
To add new tokens for trading, edit the `tokens_to_trade` section in `auto_trade_config.json`:
```json
{
  "symbol": "TOKEN_SYMBOL",
  "address": "TOKEN_ADDRESS"
}
```

## Troubleshooting

### System Not Starting
If the system fails to start:
1. Make sure Python and required packages are installed
2. Check that all component files are present
3. Verify your wallet is properly connected

### Trading Issues
If trading is not working as expected:
1. Check your wallet balance
2. Ensure Jupiter API is accessible
3. Verify proper wallet address configuration

## Security Notes

Never share your:
- Private keys
- Seed phrases
- Wallet recovery information

The system is designed to work with your public wallet address only and doesn't require your private keys for simulated trading.

For real trades (not simulations), you would need to authorize transactions through your Phantom wallet directly.