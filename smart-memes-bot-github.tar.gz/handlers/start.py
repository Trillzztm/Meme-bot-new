"""
Start command handler for SMART MEMES BOT.

This module handles the /start command to welcome new users
and introduce them to the bot's capabilities.
"""

import logging
from typing import Dict, Any, Optional

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update
from telegram.ext import ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /start command - Welcome the user and introduce the bot.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_start(update, context)

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the start command - Welcome the user and provide introduction.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    user_first_name = update.effective_user.first_name if update.effective_user else "there"
    
    welcome_message = (
        f"🤖 *Welcome to SMART MEMES BOT, {user_first_name}!* 🚀\n\n"
        "I'm your AI-powered crypto assistant for Solana tokens. Here's what I can do for you:\n\n"
        "🔍 */tokeninfo* - Check safety and details of any token\n"
        "🛒 */manualsnipe* - Buy a token directly from the chat\n"
        "📊 */watchgroup* - Monitor a Telegram group for token mentions\n"
        "❓ */help* - See detailed instructions for all commands\n\n"
        "Try */tokeninfo* with a Solana token address to get started!"
    )
    
    await update.message.reply_text(welcome_message, parse_mode="Markdown")

async def handle_start_simple(bot, chat_id, params):
    """
    Process the start command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters (unused for start)
    """
    # Get user information if available
    user_first_name = "there"  # Default fallback
    
    welcome_message = (
        f"🤖 *Welcome to SMART MEMES BOT, {user_first_name}!* 🚀\n\n"
        "I'm your AI-powered crypto assistant for Solana tokens. Here's what I can do for you:\n\n"
        "🔍 */tokeninfo* - Check safety and details of any token\n"
        "🛒 */manualsnipe* - Buy a token directly from the chat\n"
        "📊 */watchgroup* - Monitor a Telegram group for token mentions\n"
        "❓ */help* - See detailed instructions for all commands\n\n"
        "Try */tokeninfo* with a Solana token address to get started!"
    )
    
    await bot.send_message(chat_id, welcome_message, parse_mode="Markdown")