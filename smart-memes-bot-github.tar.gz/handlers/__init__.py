"""
Command handlers package for SMART MEMES BOT.

This package contains all the command handlers for the bot.
"""

# Import all handlers for easy access
# Basic commands
from handlers.start import start, handle_start
from handlers.help import help, handle_help

# Token information and analysis
from handlers.tokeninfo import tokeninfo, handle_tokeninfo
from handlers.tokensafety import tokensafety, handle_tokensafety
from handlers.marketpredict import marketpredict, handle_marketpredict

# Trading commands
from handlers.manualsnipe import manualsnipe, handle_manualsnipe
from handlers.autosnipe import autosnipe, handle_autosnipe
from handlers.ai_trade import ai_trade_command, auto_snipe_token, get_handlers as get_ai_trade_handlers

# Monitoring commands
from handlers.watchgroup import watchgroup, handle_watchgroup
from handlers.trackwallet import trackwallet, handle_trackwallet

# Content generation
from handlers.generateprememe import generateprememe, handle_generateprememe

# AI advice
from handlers.aiadvice import aiadvice, handle_aiadvice

# For backward compatibility
__all__ = [
    # Basic commands
    'start', 'handle_start',
    'help', 'handle_help',
    
    # Token information and analysis
    'tokeninfo', 'handle_tokeninfo',
    'tokensafety', 'handle_tokensafety',
    'marketpredict', 'handle_marketpredict',
    
    # Trading commands
    'manualsnipe', 'handle_manualsnipe',
    'autosnipe', 'handle_autosnipe',
    'ai_trade_command', 'auto_snipe_token', 'get_ai_trade_handlers',
    
    # Monitoring commands
    'watchgroup', 'handle_watchgroup',
    'trackwallet', 'handle_trackwallet',
    
    # Content generation
    'generateprememe', 'handle_generateprememe',
    
    # AI advice
    'aiadvice', 'handle_aiadvice',
]