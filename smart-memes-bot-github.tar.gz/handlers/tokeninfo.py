"""
Token Information Handler for SMART MEMES BOT.

This module provides Telegram bot command handlers for retrieving detailed
token information, safety analysis, AI-powered profit potential, and trading
recommendations.
"""

import os
import time
import asyncio
import logging
import re
from typing import Dict, List, Tuple, Optional, Union, Any
from datetime import datetime, timedelta

# Try to import enhanced token safety
try:
    from utils.enhanced_token_safety import analyze_token_safety
    ENHANCED_SAFETY_AVAILABLE = True
except ImportError:
    ENHANCED_SAFETY_AVAILABLE = False
    logging.warning("Enhanced token safety not available for token info handler")

# Try to import AI token analyzer
try:
    from ai.ai_token_analyzer import analyze_token, get_profit_potential, get_trading_strategy
    AI_ANALYZER_AVAILABLE = True
except ImportError:
    AI_ANALYZER_AVAILABLE = False
    logging.warning("AI token analyzer not available for token info handler")

# Try to import token info
try:
    from utils.token_info import get_token_info
    TOKEN_INFO_AVAILABLE = True
except ImportError:
    TOKEN_INFO_AVAILABLE = False
    logging.warning("Token info not available for token info handler")

# Configure logging
logger = logging.getLogger(__name__)

# Helper function to validate token address
def is_valid_token_address(token_address: str) -> bool:
    """
    Check if a string is a valid token address.
    
    Args:
        token_address: Token address to validate
        
    Returns:
        True if valid, False otherwise
    """
    # Solana addresses are base58 encoded and typically 32-44 characters
    solana_pattern = r'^[1-9A-HJ-NP-Za-km-z]{32,44}$'
    
    # Ethereum-like addresses start with 0x followed by 40 hex characters
    eth_pattern = r'^0x[a-fA-F0-9]{40}$'
    
    return bool(re.match(solana_pattern, token_address)) or bool(re.match(eth_pattern, token_address))

# Helper function to format price
def format_price(price: float) -> str:
    """
    Format a price value for display.
    
    Args:
        price: Price value
        
    Returns:
        Formatted price string
    """
    if price is None:
        return "Unknown"
        
    if price == 0:
        return "0"
        
    if price < 0.00000001:
        return f"{price:.12f}"
    elif price < 0.0000001:
        return f"{price:.10f}"
    elif price < 0.000001:
        return f"{price:.9f}"
    elif price < 0.00001:
        return f"{price:.8f}"
    elif price < 0.0001:
        return f"{price:.7f}"
    elif price < 0.001:
        return f"{price:.6f}"
    elif price < 0.01:
        return f"{price:.5f}"
    elif price < 0.1:
        return f"{price:.4f}"
    elif price < 1:
        return f"{price:.3f}"
    elif price < 10:
        return f"{price:.2f}"
    else:
        return f"{price:,.2f}"

# Helper function to format large numbers
def format_large_number(number: Union[int, float, str]) -> str:
    """
    Format a large number for display.
    
    Args:
        number: Number to format
        
    Returns:
        Formatted number string
    """
    if number is None:
        return "Unknown"
    
    try:
        value = float(number)
    except (ValueError, TypeError):
        return str(number)
    
    if value == 0:
        return "0"
        
    if value < 1000:
        return str(round(value, 2))
    elif value < 1000000:
        return f"{value/1000:.1f}K"
    elif value < 1000000000:
        return f"{value/1000000:.1f}M"
    elif value < 1000000000000:
        return f"{value/1000000000:.1f}B"
    else:
        return f"{value/1000000000000:.1f}T"

# Token info command handler
async def handle_token_info(update, context):
    """
    Handle the /tokeninfo command.
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    chat_id = update.effective_chat.id
    message = update.message
    text = message.text
    
    # Check if a token address was provided
    parts = text.split(maxsplit=1)
    if len(parts) < 2:
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Please provide a token address.\n\n"
                 "Example: `/tokeninfo EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`",
            parse_mode="Markdown"
        )
        return
    
    # Extract token address
    token_address = parts[1].strip()
    
    # Validate token address
    if not is_valid_token_address(token_address):
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Invalid token address format. Please provide a valid Solana or Ethereum token address.",
            parse_mode="Markdown"
        )
        return
    
    # Send processing message
    processing_message = await context.bot.send_message(
        chat_id=chat_id,
        text="🔍 Analyzing token... Please wait.",
        parse_mode="Markdown"
    )
    
    try:
        # Get token info
        token_info = None
        if TOKEN_INFO_AVAILABLE:
            try:
                token_info = await get_token_info(token_address)
            except Exception as e:
                logger.error(f"Error getting token info: {str(e)}")
        
        if not token_info:
            token_info = {
                "symbol": "UNKNOWN",
                "name": "Unknown Token",
                "current_price": None,
                "market_cap": None,
                "volume_24h": None
            }
        
        # Get token safety analysis
        safety_analysis = None
        if ENHANCED_SAFETY_AVAILABLE:
            try:
                safety_score, safety_details = await analyze_token_safety(token_address)
                safety_analysis = {
                    "score": safety_score,
                    "details": safety_details
                }
            except Exception as e:
                logger.error(f"Error getting token safety analysis: {str(e)}")
        
        # Format token information message
        token_symbol = token_info.get("symbol", "UNKNOWN")
        token_name = token_info.get("name", "Unknown Token")
        
        message_text = f"🪙 *Token Information*\n\n"
        message_text += f"*Name:* {token_name}\n"
        message_text += f"*Symbol:* {token_symbol}\n"
        message_text += f"*Address:* `{token_address}`\n\n"
        
        # Add price and market info
        current_price = token_info.get("current_price")
        market_cap = token_info.get("market_cap")
        volume_24h = token_info.get("volume_24h")
        total_supply = token_info.get("total_supply")
        
        message_text += "💰 *Market Data*\n"
        message_text += f"*Price:* ${format_price(current_price)}\n"
        message_text += f"*Market Cap:* ${format_large_number(market_cap)}\n"
        message_text += f"*24h Volume:* ${format_large_number(volume_24h)}\n"
        if total_supply:
            message_text += f"*Total Supply:* {format_large_number(total_supply)}\n"
        
        # Add safety analysis if available
        if safety_analysis:
            safety_score = safety_analysis["score"]
            risk_level = safety_analysis["details"].get("risk_level", "unknown")
            
            # Emoji for risk level
            risk_emoji = "❓"
            if risk_level == "low":
                risk_emoji = "✅"
            elif risk_level == "medium":
                risk_emoji = "⚠️"
            elif risk_level == "high":
                risk_emoji = "🚨"
            elif risk_level == "extreme":
                risk_emoji = "💀"
            
            message_text += f"\n🛡️ *Safety Analysis*\n"
            message_text += f"*Safety Score:* {int(safety_score * 100)}/100\n"
            message_text += f"*Risk Level:* {risk_emoji} {risk_level.capitalize()}\n"
            
            # Add critical issues if any
            critical_issues = safety_analysis["details"].get("critical_issues", [])
            if critical_issues:
                message_text += "\n*Critical Issues:*\n"
                for issue in critical_issues[:3]:  # Show top 3 issues
                    message_text += f"• {issue}\n"
            
            # Add strengths if any
            strengths = []
            for key in safety_analysis["details"]:
                if key.endswith("_strengths"):
                    strengths.extend(safety_analysis["details"][key])
            
            if strengths:
                message_text += "\n*Security Strengths:*\n"
                for strength in strengths[:3]:  # Show top 3 strengths
                    message_text += f"• {strength}\n"
        
        # Update the processing message with the token info
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=message_text,
            parse_mode="Markdown"
        )
        
        # Check if AI analysis is available and requested
        if AI_ANALYZER_AVAILABLE:
            # Send a message that AI analysis is starting
            ai_processing_message = await context.bot.send_message(
                chat_id=chat_id,
                text="🧠 *AI Analysis in progress...*\n\nGenerating advanced insights with our AI.",
                parse_mode="Markdown"
            )
            
            try:
                # Prepare token data for AI analysis
                token_data = {
                    "token_info": token_info,
                    "safety_analysis": safety_analysis
                }
                
                # Get AI analysis
                ai_analysis = await analyze_token(token_address, token_data)
                
                if ai_analysis.get("success", False):
                    # Format AI analysis message
                    ai_result = ai_analysis.get("analysis", {})
                    
                    ai_message = f"🧠 *AI-Powered Token Analysis*\n\n"
                    ai_message += f"*Token:* {token_symbol} ({token_name})\n"
                    ai_message += f"*Overall Rating:* {ai_result.get('overall_rating', 'N/A')}/100\n"
                    ai_message += f"*Recommendation:* {ai_result.get('recommendation', 'N/A')}\n\n"
                    
                    # Add profit potential
                    profit = ai_result.get('profit_potential', {})
                    ai_message += "💰 *Profit Potential*\n"
                    ai_message += f"*Range:* {profit.get('min_percentage', 'N/A')}% to {profit.get('max_percentage', 'N/A')}%\n"
                    ai_message += f"*Timeframe:* {profit.get('timeframe_days', 'N/A')} days\n"
                    ai_message += f"*Investment Potential:* {ai_result.get('investment_potential', 'N/A')}\n\n"
                    
                    # Add risk assessment
                    ai_message += "⚠️ *Risk Assessment*\n"
                    ai_message += f"*Risk Level:* {ai_result.get('risk_assessment', 'N/A')}\n\n"
                    
                    # Add strengths
                    strengths = ai_result.get('strengths', [])
                    if strengths:
                        ai_message += "✅ *Strengths*\n"
                        for strength in strengths:
                            ai_message += f"• {strength}\n"
                        ai_message += "\n"
                    
                    # Add concerns
                    concerns = ai_result.get('concerns', [])
                    if concerns:
                        ai_message += "🚨 *Concerns*\n"
                        for concern in concerns:
                            ai_message += f"• {concern}\n"
                        ai_message += "\n"
                    
                    # Add trading strategy
                    ai_message += "📈 *Trading Strategy*\n"
                    ai_message += f"{ai_result.get('trading_strategy', 'N/A')}\n\n"
                    
                    # Add confidence
                    confidence = ai_result.get('confidence_score', 0)
                    ai_message += f"*AI Confidence:* {int(confidence * 100)}%"
                    
                    # Update the AI processing message with the analysis
                    await context.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=ai_processing_message.message_id,
                        text=ai_message,
                        parse_mode="Markdown"
                    )
                else:
                    # Update with error message
                    await context.bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=ai_processing_message.message_id,
                        text=f"❌ *AI Analysis Failed*\n\n{ai_analysis.get('error', 'Unknown error')}",
                        parse_mode="Markdown"
                    )
            except Exception as e:
                logger.error(f"Error performing AI analysis: {str(e)}")
                # Update with error message
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=ai_processing_message.message_id,
                    text=f"❌ *AI Analysis Error*\n\nCould not complete AI analysis: {str(e)}",
                    parse_mode="Markdown"
                )
    
    except Exception as e:
        logger.error(f"Error handling token info: {str(e)}")
        # Update the processing message with error
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=f"❌ *Error*\n\nCould not retrieve token information: {str(e)}",
            parse_mode="Markdown"
        )

# Token safety command handler
async def handle_token_safety(update, context):
    """
    Handle the /tokensafety command.
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    chat_id = update.effective_chat.id
    message = update.message
    text = message.text
    
    # Check if a token address was provided
    parts = text.split(maxsplit=1)
    if len(parts) < 2:
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Please provide a token address.\n\n"
                 "Example: `/tokensafety EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`",
            parse_mode="Markdown"
        )
        return
    
    # Extract token address
    token_address = parts[1].strip()
    
    # Validate token address
    if not is_valid_token_address(token_address):
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Invalid token address format. Please provide a valid Solana or Ethereum token address.",
            parse_mode="Markdown"
        )
        return
    
    # Send processing message
    processing_message = await context.bot.send_message(
        chat_id=chat_id,
        text="🛡️ Analyzing token safety... Please wait.",
        parse_mode="Markdown"
    )
    
    try:
        # Check if enhanced safety analysis is available
        if not ENHANCED_SAFETY_AVAILABLE:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=processing_message.message_id,
                text="❌ Token safety analysis is not available.",
                parse_mode="Markdown"
            )
            return
        
        # Get token info first (for name and symbol)
        token_info = None
        if TOKEN_INFO_AVAILABLE:
            try:
                token_info = await get_token_info(token_address)
            except Exception as e:
                logger.error(f"Error getting token info: {str(e)}")
        
        if not token_info:
            token_info = {
                "symbol": "UNKNOWN",
                "name": "Unknown Token"
            }
        
        token_symbol = token_info.get("symbol", "UNKNOWN")
        token_name = token_info.get("name", "Unknown Token")
        
        # Get token safety analysis
        safety_score, safety_details = await analyze_token_safety(token_address)
        
        # Format safety analysis message
        risk_level = safety_details.get("risk_level", "unknown")
        
        # Emoji for risk level
        risk_emoji = "❓"
        if risk_level == "low":
            risk_emoji = "✅"
        elif risk_level == "medium":
            risk_emoji = "⚠️"
        elif risk_level == "high":
            risk_emoji = "🚨"
        elif risk_level == "extreme":
            risk_emoji = "💀"
        
        message_text = f"🛡️ *Token Safety Analysis*\n\n"
        message_text += f"*Token:* {token_name} ({token_symbol})\n"
        message_text += f"*Address:* `{token_address}`\n\n"
        
        message_text += f"*Safety Score:* {int(safety_score * 100)}/100\n"
        message_text += f"*Risk Level:* {risk_emoji} {risk_level.capitalize()}\n\n"
        
        # Add summary assessment
        if safety_score >= 0.8:
            message_text += "✅ *Assessment: Low Risk*\n\n"
            message_text += "This token appears to have a solid safety profile. As always, do your own research before investing.\n\n"
        elif safety_score >= 0.5:
            message_text += "⚠️ *Assessment: Moderate Risk*\n\n"
            message_text += "This token has some risk factors to consider. Review the details carefully and use caution.\n\n"
        elif safety_score >= 0.3:
            message_text += "🚨 *Assessment: High Risk*\n\n"
            message_text += "This token has significant risk factors. Investing may result in loss of funds. Extreme caution advised.\n\n"
        else:
            message_text += "💀 *Assessment: Extreme Risk*\n\n"
            message_text += "This token has critical risk factors. High probability of scam or honeypot. AVOID INVESTING.\n\n"
        
        # Add critical issues if any
        critical_issues = safety_details.get("critical_issues", [])
        if critical_issues:
            message_text += "*Critical Issues:*\n"
            for issue in critical_issues:
                message_text += f"• {issue}\n"
            message_text += "\n"
        
        # Add other issues by category
        for category in ["contract", "liquidity", "holders", "social", "historical"]:
            if category in safety_details:
                category_issues = safety_details[category].get(f"{category}_issues", [])
                if category_issues:
                    message_text += f"*{category.capitalize()} Issues:*\n"
                    for issue in category_issues:
                        message_text += f"• {issue}\n"
                    message_text += "\n"
        
        # Add security strengths
        all_strengths = []
        for category in ["contract", "liquidity", "holders", "social", "historical"]:
            if category in safety_details:
                strengths = safety_details[category].get(f"{category}_strengths", [])
                all_strengths.extend(strengths)
        
        if all_strengths:
            message_text += "*Security Strengths:*\n"
            for strength in all_strengths[:5]:  # Show top 5 strengths
                message_text += f"• {strength}\n"
        
        # Add disclaimer
        message_text += "\n⚠️ *Disclaimer:* This analysis is for informational purposes only and does not constitute financial advice. Always do your own research before investing."
        
        # Update the processing message with the safety analysis
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=message_text,
            parse_mode="Markdown"
        )
    
    except Exception as e:
        logger.error(f"Error handling token safety: {str(e)}")
        # Update the processing message with error
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=f"❌ *Error*\n\nCould not analyze token safety: {str(e)}",
            parse_mode="Markdown"
        )

# Trading advice command handler
async def handle_trading_advice(update, context):
    """
    Handle the /tradingadvice command.
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    chat_id = update.effective_chat.id
    message = update.message
    text = message.text
    
    # Check if a token address was provided
    parts = text.split(maxsplit=1)
    if len(parts) < 2:
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Please provide a token address.\n\n"
                 "Example: `/tradingadvice EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`",
            parse_mode="Markdown"
        )
        return
    
    # Extract token address
    token_address = parts[1].strip()
    
    # Validate token address
    if not is_valid_token_address(token_address):
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ Invalid token address format. Please provide a valid Solana or Ethereum token address.",
            parse_mode="Markdown"
        )
        return
    
    # Check if AI analysis is available
    if not AI_ANALYZER_AVAILABLE:
        await context.bot.send_message(
            chat_id=chat_id,
            text="❌ AI-powered trading advice is not available.",
            parse_mode="Markdown"
        )
        return
    
    # Send processing message
    processing_message = await context.bot.send_message(
        chat_id=chat_id,
        text="🧠 Generating AI-powered trading advice... Please wait.",
        parse_mode="Markdown"
    )
    
    try:
        # Get token info first (for name and symbol)
        token_info = None
        if TOKEN_INFO_AVAILABLE:
            try:
                token_info = await get_token_info(token_address)
            except Exception as e:
                logger.error(f"Error getting token info: {str(e)}")
        
        if not token_info:
            token_info = {
                "symbol": "UNKNOWN",
                "name": "Unknown Token"
            }
        
        token_symbol = token_info.get("symbol", "UNKNOWN")
        token_name = token_info.get("name", "Unknown Token")
        
        # Get trading strategy
        strategy = await get_trading_strategy(token_address)
        
        if not strategy.get("success", False):
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=processing_message.message_id,
                text=f"❌ *Trading Advice Error*\n\n{strategy.get('error', 'Could not generate trading advice')}",
                parse_mode="Markdown"
            )
            return
        
        # Format trading advice message
        recommendation = strategy.get("recommendation", "Hold")
        trading_strategy = strategy.get("trading_strategy", "No specific strategy available")
        investment_potential = strategy.get("investment_potential", "Medium")
        confidence = strategy.get("confidence", 0)
        
        # Emoji for recommendation
        rec_emoji = "❓"
        if recommendation == "Strong Buy":
            rec_emoji = "🚀"
        elif recommendation == "Buy":
            rec_emoji = "✅"
        elif recommendation == "Hold":
            rec_emoji = "⏳"
        elif recommendation == "Sell":
            rec_emoji = "🔻"
        elif recommendation == "Strong Sell":
            rec_emoji = "⛔"
        
        message_text = f"🧠 *AI-Powered Trading Advice*\n\n"
        message_text += f"*Token:* {token_name} ({token_symbol})\n"
        message_text += f"*Address:* `{token_address}`\n\n"
        
        message_text += f"*Recommendation:* {rec_emoji} {recommendation}\n"
        message_text += f"*Investment Potential:* {investment_potential}\n"
        message_text += f"*AI Confidence:* {int(confidence * 100)}%\n\n"
        
        message_text += "📈 *Trading Strategy*\n"
        message_text += f"{trading_strategy}\n\n"
        
        # Get profit potential
        try:
            profit = await get_profit_potential(token_address)
            
            if profit.get("success", False):
                min_profit = profit.get("min_profit", 0)
                max_profit = profit.get("max_profit", 0)
                timeframe = profit.get("timeframe_days", 0)
                
                message_text += "💰 *Profit Potential*\n"
                message_text += f"*Estimated Range:* {min_profit}% to {max_profit}%\n"
                message_text += f"*Timeframe:* {timeframe} days\n\n"
        except Exception as e:
            logger.error(f"Error getting profit potential: {str(e)}")
        
        # Add disclaimer
        message_text += "⚠️ *Disclaimer:* This AI-generated trading advice is for informational purposes only and does not constitute financial advice. Always do your own research before investing. Past performance is not indicative of future results."
        
        # Update the processing message with the trading advice
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=message_text,
            parse_mode="Markdown"
        )
    
    except Exception as e:
        logger.error(f"Error handling trading advice: {str(e)}")
        # Update the processing message with error
        await context.bot.edit_message_text(
            chat_id=chat_id,
            message_id=processing_message.message_id,
            text=f"❌ *Error*\n\nCould not generate trading advice: {str(e)}",
            parse_mode="Markdown"
        )

# Function to register handlers
def register_handlers(dispatcher):
    """
    Register token info handlers with the dispatcher.
    
    Args:
        dispatcher: Telegram dispatcher
    """
    from telegram.ext import CommandHandler
    
    dispatcher.add_handler(CommandHandler("tokeninfo", handle_token_info))
    dispatcher.add_handler(CommandHandler("tokensafety", handle_token_safety))
    dispatcher.add_handler(CommandHandler("tradingadvice", handle_trading_advice))
    
    logger.info("Token info handlers registered")