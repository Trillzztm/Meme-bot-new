"""
Manual snipe command handler for SMART MEMES BOT.

This module handles the /manualsnipe command to manually buy tokens.
"""

import logging
from typing import Dict, Any, Optional, List
import re
import asyncio

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_info import is_valid_token_address, get_token_info
from utils.solana_utils import check_wallet_balance
from utils.solana_trade import execute_trade, check_token_liquidity
from config import MAX_SPEND, DEFAULT_SLIPPAGE, DEFAULT_WALLET

async def manualsnipe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /manualsnipe command - Manually buy a token.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_manualsnipe(update, context)

async def handle_manualsnipe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the manualsnipe command - Execute a token purchase.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Extract token address and parameters from the command
        if not context.args or len(context.args) < 1:
            await update.message.reply_text(
                "Please provide a token address.\n"
                "Usage: /manualsnipe <token_address> <amount_sol>\n"
                "Example: /manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5"
            )
            return
        
        token_address = context.args[0]
        
        # Parse optional parameters
        amount_sol = 0.01  # Default to a small amount
        slippage = DEFAULT_SLIPPAGE
        
        if len(context.args) >= 2:
            try:
                amount_sol = float(context.args[1])
            except ValueError:
                await update.message.reply_text(
                    f"Invalid amount: {context.args[1]}. Please provide a valid number."
                )
                return
        
        # Check amount limit
        if amount_sol > MAX_SPEND:
            await update.message.reply_text(
                f"⚠️ Amount exceeds maximum allowed ({MAX_SPEND} SOL). "
                f"Setting to {MAX_SPEND} SOL."
            )
            amount_sol = MAX_SPEND
        
        # Validate the token address
        if not is_valid_token_address(token_address):
            await update.message.reply_text(
                f"❌ Invalid token address format: {token_address}\n"
                "Please provide a valid Solana token address."
            )
            return
        
        # Check token info for validity
        try:
            token_data = get_token_info(token_address)
            if token_data and token_data.get("warnings", []):
                warnings_text = "\n".join([f"⚠️ {w}" for w in token_data.get("warnings", [])])
                await update.message.reply_text(
                    f"⚠️ Token warnings detected:\n{warnings_text}\n\n"
                    "Do you still want to proceed? Use /confirmbuy to confirm."
                    # In a real bot, we'd set up a context or database entry to track this
                )
                return
        except Exception as e:
            logger.error(f"Error checking token info: {e}")
            # Continue anyway, with a warning
            await update.message.reply_text(
                "⚠️ Could not verify token safety. Proceed with caution."
            )
        
        # Send "processing" message
        processing_message = await update.message.reply_text(
            f"🔄 Processing buy order for {token_address}...\n"
            f"Amount: {amount_sol} SOL\n"
            f"Slippage: {slippage}%\n"
            f"Checking liquidity and executing trade..."
        )
        
        # Check token liquidity first
        try:
            has_liquidity, liquidity_amount, liquidity_message = await check_token_liquidity(token_address)
            
            if not has_liquidity:
                await update.message.reply_text(
                    f"❌ Token has no liquidity: {liquidity_message}"
                )
                return
        except Exception as e:
            logger.error(f"Error checking token liquidity: {e}")
            await update.message.reply_text(
                f"❌ Error checking token liquidity: {str(e)}"
            )
            return
                
        # Execute the trade
        try:
            trade_result = await execute_trade(token_address, amount_sol, slippage)
            
            if not trade_result.get("success", False):
                await update.message.reply_text(
                    f"❌ Transaction failed: {trade_result.get('error', 'Unknown error')}"
                )
                return
            
            # Format success message
            success_message = (
                "✅ Transaction submitted successfully!\n\n"
                f"Bought token: {token_address}\n"
                f"Amount spent: {amount_sol} SOL\n"
                f"Estimated tokens received: {trade_result.get('estimated_tokens', 'Unknown')}\n"
                f"Transaction: {trade_result.get('url', 'No transaction URL')}"
            )
            
            await update.message.reply_text(success_message)
        except Exception as e:
            logger.error(f"Error executing trade: {e}")
            await update.message.reply_text(
                f"❌ Error executing transaction: {str(e)}"
            )
    except Exception as e:
        logger.error(f"Critical error in manualsnipe handler: {e}")
        await update.message.reply_text(
            "❌ An unexpected error occurred. Please try again later."
        )

async def handle_manualsnipe_simple(bot, chat_id, params):
    """
    Process the manualsnipe command for the simplified bot implementation.
    Ultra-reliable implementation with improved error handling.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    try:
        # Extract token address and parameters from the command
        if not params or len(params) < 1:
            await bot.send_message(
                chat_id,
                "Please provide a token address.\n"
                "Usage: /manualsnipe <token_address> <amount_sol>\n"
                "Example: /manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5"
            )
            return
        
        token_address = params[0]
        
        # Parse optional parameters
        amount_sol = 0.01  # Default to a small amount
        slippage = DEFAULT_SLIPPAGE
        
        if len(params) >= 2:
            try:
                amount_sol = float(params[1])
            except ValueError:
                await bot.send_message(
                    chat_id,
                    f"Invalid amount: {params[1]}. Please provide a valid number."
                )
                return
        
        # Check amount limit
        if amount_sol > MAX_SPEND:
            await bot.send_message(
                chat_id,
                f"⚠️ Amount exceeds maximum allowed ({MAX_SPEND} SOL). "
                f"Setting to {MAX_SPEND} SOL."
            )
            amount_sol = MAX_SPEND
        
        # Validate the token address
        if not is_valid_token_address(token_address):
            await bot.send_message(
                chat_id,
                f"❌ Invalid token address format: {token_address}\n"
                "Please provide a valid Solana token address."
            )
            return
        
        # Check token info for validity
        try:
            token_data = get_token_info(token_address)
            if token_data and token_data.get("warnings", []):
                warnings_text = "\n".join([f"⚠️ {w}" for w in token_data.get("warnings", [])])
                await bot.send_message(
                    chat_id,
                    f"⚠️ Token warnings detected:\n{warnings_text}\n\n"
                    "Do you still want to proceed? Use /confirmbuy to confirm."
                )
                return
        except Exception as e:
            logger.error(f"Error checking token info: {e}")
            # Continue anyway, with a warning
            await bot.send_message(
                chat_id,
                "⚠️ Could not verify token safety. Proceed with caution."
            )
        
        # Send "processing" message
        await bot.send_message(
            chat_id,
            f"🔄 Processing buy order for {token_address}...\n"
            f"Amount: {amount_sol} SOL\n"
            f"Slippage: {slippage}%\n"
            f"Checking liquidity and executing trade..."
        )
        
        # Use try-except blocks for each critical operation
        
        # Check token liquidity first
        try:
            has_liquidity, liquidity_amount, liquidity_message = await check_token_liquidity(token_address)
            
            if not has_liquidity:
                await bot.send_message(
                    chat_id,
                    f"❌ Token has no liquidity: {liquidity_message}"
                )
                return
        except Exception as e:
            logger.error(f"Error checking token liquidity: {e}")
            await bot.send_message(
                chat_id,
                f"❌ Error checking token liquidity: {str(e)}"
            )
            return
            
        # Execute the trade
        try:
            trade_result = await execute_trade(token_address, amount_sol, slippage)
            
            if not trade_result.get("success", False):
                await bot.send_message(
                    chat_id,
                    f"❌ Transaction failed: {trade_result.get('error', 'Unknown error')}"
                )
                return
            
            # Format success message
            success_message = (
                "✅ Transaction submitted successfully!\n\n"
                f"Bought token: {token_address}\n"
                f"Amount spent: {amount_sol} SOL\n"
                f"Estimated tokens received: {trade_result.get('estimated_tokens', 'Unknown')}\n"
                f"Transaction: {trade_result.get('url', 'No transaction URL')}"
            )
            
            await bot.send_message(chat_id, success_message)
        except Exception as e:
            logger.error(f"Error executing trade: {e}")
            await bot.send_message(
                chat_id,
                f"❌ Error executing transaction: {str(e)}"
            )
    except Exception as e:
        logger.error(f"Critical error in manualsnipe_simple handler: {e}")
        await bot.send_message(
            chat_id,
            "❌ An unexpected error occurred. Please try again later."
        )