"""
Settings command handler for SMART MEMES BOT.

This module handles the /settings command to allow users to configure
bot settings and preferences.
"""

import logging
from typing import Dict, Any, Optional, List

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
try:
    from telegram import Update
    from telegram.ext import ContextTypes
except ImportError:
    logger.warning("Could not import telegram libraries, using simplified implementation")

# Import configuration and database utilities
from config import MAX_SPEND, DEFAULT_SLIPPAGE
try:
    from database import get_user_settings, update_user_settings, get_or_create_user
except ImportError:
    logger.warning("Could not import database utilities, using mock implementation")
    
    # Mock implementations
    def get_user_settings(telegram_id):
        return {}
        
    def update_user_settings(telegram_id, settings_dict):
        return settings_dict
        
    def get_or_create_user(telegram_id, username=None):
        return {"id": telegram_id, "username": username}

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /settings command - Configure bot settings and preferences.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_settings(update, context)

async def handle_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the settings command - Display and update user settings.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Get user and chat info
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    # Parse arguments
    if context.args and len(context.args) > 0:
        category = context.args[0].lower()
        # Handle specific categories
        if category == "trading":
            await handle_trading_settings(update, context)
        elif category == "notifications":
            await handle_notification_settings(update, context)
        elif category == "security":
            await handle_security_settings(update, context)
        elif category == "display":
            await handle_display_settings(update, context)
        else:
            await update.message.reply_text(
                f"Unknown settings category: {category}\n"
                "Try /settings for a list of available categories."
            )
        return
    
    # No specific category - show main settings menu
    settings_text = (
        "⚙️ *Bot Settings*\n\n"
        "Configure your trading preferences and notification settings.\n\n"
        "*Available Settings Categories:*\n"
        "• `/settings trading` - Trading parameters and defaults\n"
        "• `/settings notifications` - Alert preferences and channels\n"
        "• `/settings security` - Security settings and verification levels\n"
        "• `/settings display` - UI preferences and display options\n\n"
        "Use `/settings <category>` to view and configure specific settings."
    )
    
    await update.message.reply_text(settings_text, parse_mode="Markdown")

async def handle_trading_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle trading settings category."""
    user_id = update.effective_user.id
    current_settings = get_user_settings(user_id)
    
    # Default values if not set
    default_amount = current_settings.get('default_amount', 0.1)
    default_slippage = current_settings.get('default_slippage', DEFAULT_SLIPPAGE)
    default_gas = current_settings.get('default_gas', 'medium')
    auto_take_profit = current_settings.get('auto_take_profit', 200)
    auto_stop_loss = current_settings.get('auto_stop_loss', 50)
    
    # Parse arguments to update settings
    if len(context.args) > 1:
        updates = {}
        for arg in context.args[1:]:
            if '=' in arg:
                key, value = arg.split('=', 1)
                if key == 'amount':
                    try:
                        amount = float(value)
                        if 0 < amount <= MAX_SPEND:
                            updates['default_amount'] = amount
                        else:
                            await update.message.reply_text(f"Amount must be between 0 and {MAX_SPEND}")
                    except ValueError:
                        await update.message.reply_text(f"Invalid amount value: {value}")
                elif key == 'slippage':
                    try:
                        slippage = float(value)
                        if 0.1 <= slippage <= 50:
                            updates['default_slippage'] = slippage
                        else:
                            await update.message.reply_text("Slippage must be between 0.1 and 50")
                    except ValueError:
                        await update.message.reply_text(f"Invalid slippage value: {value}")
                elif key == 'gas':
                    if value in ['low', 'medium', 'high', 'rapid']:
                        updates['default_gas'] = value
                    else:
                        await update.message.reply_text("Gas must be one of: low, medium, high, rapid")
                elif key == 'takeprofit':
                    try:
                        take_profit = float(value)
                        if 110 <= take_profit <= 1000:
                            updates['auto_take_profit'] = take_profit
                        else:
                            await update.message.reply_text("Take profit must be between 110 and 1000")
                    except ValueError:
                        await update.message.reply_text(f"Invalid take profit value: {value}")
                elif key == 'stoploss':
                    try:
                        stop_loss = float(value)
                        if 10 <= stop_loss <= 90:
                            updates['auto_stop_loss'] = stop_loss
                        else:
                            await update.message.reply_text("Stop loss must be between 10 and 90")
                    except ValueError:
                        await update.message.reply_text(f"Invalid stop loss value: {value}")
        
        # Update settings if we have changes
        if updates:
            update_user_settings(user_id, updates)
            current_settings = get_user_settings(user_id)
            await update.message.reply_text("Settings updated successfully.")
    
    # Re-read values in case they were updated
    default_amount = current_settings.get('default_amount', 0.1)
    default_slippage = current_settings.get('default_slippage', DEFAULT_SLIPPAGE)
    default_gas = current_settings.get('default_gas', 'medium')
    auto_take_profit = current_settings.get('auto_take_profit', 200)
    auto_stop_loss = current_settings.get('auto_stop_loss', 50)
    
    # Display current settings
    settings_text = (
        "⚙️ *Trading Settings*\n\n"
        f"• Default Amount: `{default_amount} SOL`\n"
        f"• Default Slippage: `{default_slippage}%`\n"
        f"• Default Gas: `{default_gas}`\n"
        f"• Auto Take Profit: `{auto_take_profit}%`\n"
        f"• Auto Stop Loss: `{auto_stop_loss}%`\n\n"
        "To update a setting, use:\n"
        "`/settings trading <parameter>=<value>`\n\n"
        "*Examples:*\n"
        "• `/settings trading amount=0.5`\n"
        "• `/settings trading slippage=1 gas=high`"
    )
    
    await update.message.reply_text(settings_text, parse_mode="Markdown")

async def handle_notification_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle notification settings category."""
    await update.message.reply_text(
        "🔔 *Notification Settings*\n\n"
        "Configure how and when you receive alerts.\n\n"
        "This feature is coming soon. Check back for updates!",
        parse_mode="Markdown"
    )

async def handle_security_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle security settings category."""
    await update.message.reply_text(
        "🔒 *Security Settings*\n\n"
        "Configure security options and verification levels.\n\n"
        "This feature is coming soon. Check back for updates!",
        parse_mode="Markdown"
    )

async def handle_display_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle display settings category."""
    await update.message.reply_text(
        "🖥️ *Display Settings*\n\n"
        "Configure UI preferences and display options.\n\n"
        "This feature is coming soon. Check back for updates!",
        parse_mode="Markdown"
    )

async def handle_settings_simple(bot, chat_id, params):
    """
    Process the settings command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # Parse arguments
    if params and len(params) > 0:
        category = params[0].lower()
        # Handle specific categories (simplified implementation just shows info)
        if category == "trading":
            await bot.send_message(
                chat_id,
                "⚙️ *Trading Settings*\n\n"
                "• Default Amount: `0.1 SOL`\n"
                "• Default Slippage: `0.5%`\n"
                "• Default Gas: `medium`\n"
                "• Auto Take Profit: `200%`\n"
                "• Auto Stop Loss: `50%`\n\n"
                "To update a setting, use:\n"
                "`/settings trading <parameter>=<value>`\n\n"
                "*Examples:*\n"
                "• `/settings trading amount=0.5`\n"
                "• `/settings trading slippage=1 gas=high`",
                parse_mode="Markdown"
            )
        elif category in ["notifications", "security", "display"]:
            await bot.send_message(
                chat_id,
                f"⚙️ *{category.capitalize()} Settings*\n\n"
                f"Configure {category} options and preferences.\n\n"
                "This feature is coming soon. Check back for updates!",
                parse_mode="Markdown"
            )
        else:
            await bot.send_message(
                chat_id,
                f"Unknown settings category: {category}\n"
                "Try /settings for a list of available categories."
            )
        return
    
    # No specific category - show main settings menu
    settings_text = (
        "⚙️ *Bot Settings*\n\n"
        "Configure your trading preferences and notification settings.\n\n"
        "*Available Settings Categories:*\n"
        "• `/settings trading` - Trading parameters and defaults\n"
        "• `/settings notifications` - Alert preferences and channels\n"
        "• `/settings security` - Security settings and verification levels\n"
        "• `/settings display` - UI preferences and display options\n\n"
        "Use `/settings <category>` to view and configure specific settings."
    )
    
    await bot.send_message(chat_id, settings_text, parse_mode="Markdown")