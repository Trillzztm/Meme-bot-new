"""
AI-powered advice handler for SMART MEMES BOT.

This module provides AI-powered trading and cryptocurrency advice using OpenAI.
"""

import logging
import asyncio
import os
from typing import Dict, Any, Optional, List, Tuple
import json

from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, CallbackContext

# Import OpenAI API client
try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

# Configure logger
logger = logging.getLogger(__name__)

# Initialize OpenAI API client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai_client = None

if HAS_OPENAI and OPENAI_API_KEY:
    try:
        openai_client = OpenAI(api_key=OPENAI_API_KEY)
        logger.info("OpenAI client initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize OpenAI client: {str(e)}")

async def aiadvice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle AI advice command (/aiadvice).
    
    Provides AI-powered advice on trading and cryptocurrency topics.
    
    Args:
        update: Telegram update
        context: Callback context
    """
    # Create a simplified version for direct use
    await handle_aiadvice(update, context)

async def handle_aiadvice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle AI advice command (/aiadvice).
    
    Provides AI-powered advice on trading and cryptocurrency topics.
    
    Args:
        update: Telegram update
        context: Callback context
    """
    if not HAS_OPENAI or not openai_client:
        await update.message.reply_text(
            "❌ AI advice service is not available at this moment.\n"
            "Please check back later or contact the administrator."
        )
        return
    
    if not context.args:
        await update.message.reply_text(
            "Please provide a question or topic for AI advice.\n\n"
            "Example: /aiadvice What's the best strategy for DeFi investing?\n\n"
            "Topics you can ask about:\n"
            "• Trading strategies\n"
            "• Token analysis\n"
            "• Market trends\n"
            "• DeFi protocols\n"
            "• Risk management\n"
            "• Technical analysis\n"
            "• Blockchain technology"
        )
        return
    
    # Get the user's question
    question = " ".join(context.args)
    
    # Send a "thinking" message
    thinking_message = await update.message.reply_text(
        "🧠 Thinking...\n\n"
        "I'm consulting my AI brain to provide you with the best advice on this topic."
    )
    
    try:
        # Setup system prompt to guide the AI
        system_prompt = (
            "You are a crypto trading expert assistant providing advice through a Telegram bot called 'SMART MEMES BOT'. "
            "You specialize in cryptocurrency trading, token analysis, market trends, blockchain technology, and DeFi. "
            "Provide clear, concise, and educational responses that give practical advice. "
            "Focus on risk management and responsible trading practices. "
            "Keep responses under 500 words. Always include both the benefits and risks of any strategy. "
            "Never predict specific price movements or make promises about returns. "
            "End your response with a brief 'SMART TIP:' that summarizes the key takeaway."
        )
        
        # Call OpenAI API
        response = openai_client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            max_tokens=800
        )
        
        # Get the AI's response
        ai_response = response.choices[0].message.content
        
        # Format the final message
        formatted_response = (
            f"🔮 *SMART MEMES BOT AI Advice* 🔮\n\n"
            f"*Question:* {question}\n\n"
            f"{ai_response}"
        )
        
        # Edit the "thinking" message with the AI's response
        await thinking_message.edit_text(
            formatted_response,
            parse_mode="Markdown"
        )
        
        # Log the successful interaction
        logger.info(f"AI advice provided for question: {question[:50]}...")
        
    except Exception as e:
        # Handle errors
        error_message = (
            f"❌ Sorry, I encountered an error while processing your request.\n\n"
            f"Error: {str(e)}\n\n"
            f"Please try again with a different question, or contact the administrator."
        )
        
        await thinking_message.edit_text(error_message)
        logger.error(f"AI advice error: {str(e)} for question: {question[:50]}...")

def get_handlers():
    """
    Get AI advice command handlers.
    
    Returns:
        List of handlers
    """
    return [
        CommandHandler("aiadvice", handle_aiadvice),
        CommandHandler("advice", handle_aiadvice)
    ]