"""
Token Tracking Command Handler for SMART MEMES BOT.

This module handles the /tracktoken command which provides advanced token tracking
and price alerts with detailed historical information and analysis.
"""

import logging
import json
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports - using try/except for compatibility with simplified bot
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
    TELEGRAM_IMPORTS_AVAILABLE = True
except ImportError:
    # For simplified bot mode
    logger.warning("Telegram imports not available, using mock classes")
    Update = None
    InlineKeyboardButton = None
    InlineKeyboardMarkup = None
    ContextTypes = None
    TELEGRAM_IMPORTS_AVAILABLE = False

# Import profit tracker
try:
    from utils.profit_tracker import (
        track_token_with_alerts,
        get_tracked_token_info,
        get_tracked_tokens_list,
        calculate_token_performance,
        get_price_history,
        subscribe_to_alerts,
        unsubscribe_from_alerts
    )
    from utils.token_info import get_token_price, get_token_info
    TRACKER_IMPORTS_AVAILABLE = True
except ImportError as e:
    logger.error(f"Error importing profit tracker: {e}")
    TRACKER_IMPORTS_AVAILABLE = False

# Constants
DEFAULT_INTERVALS = [5, 10, 30, 60, 240]  # Minutes
USER_SUBSCRIPTIONS_FILE = "data/user_subscriptions.json"

async def tracktoken_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /tracktoken command which tracks a token's price with
    detailed analysis and optional price alerts.
    
    Command format: /tracktoken <token_address> [alerts=yes]
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    if not TRACKER_IMPORTS_AVAILABLE:
        await update.message.reply_text(
            "❌ Token tracking functionality is not available. Please contact the administrator."
        )
        return
    
    try:
        # Check if user provided arguments
        if not context.args:
            await update.message.reply_text(
                "❌ *Missing Token Address*\n\n"
                "Please provide a token address to track:\n"
                "`/tracktoken <token_address> [alerts=yes]`\n\n"
                "Or use `/tracktoken list` to see all tracked tokens.",
                parse_mode="Markdown"
            )
            return
        
        command = context.args[0].lower()
        
        # Handle list subcommand
        if command == "list":
            await show_tracked_tokens_list(update, context)
            return
        
        # Handle info subcommand
        if command == "info" and len(context.args) > 1:
            token_address = context.args[1]
            await show_token_tracking_info(update, context, token_address)
            return
        
        # Regular tracking command - first arg is the token address
        token_address = context.args[0]
        
        # Check for alerts parameter
        enable_alerts = False
        for arg in context.args[1:]:
            if arg.lower().startswith("alerts="):
                value = arg.split("=")[1].lower()
                if value in ["yes", "true", "1", "y"]:
                    enable_alerts = True
        
        # Send initial message
        message = await update.message.reply_text(
            f"🔍 *Tracking Token*\n\n"
            f"Setting up advanced tracking for: `{token_address}`\n"
            f"Fetching initial price data...",
            parse_mode="Markdown"
        )
        
        # Check if token is valid by getting initial price
        initial_price = await get_token_price(token_address)
        
        if not initial_price or initial_price <= 0:
            await message.edit_text(
                f"❌ *Invalid Token*\n\n"
                f"Could not get price data for: `{token_address}`\n"
                f"Please check the token address and try again.",
                parse_mode="Markdown"
            )
            return
        
        # Set up alert notification callback if alerts are enabled
        notify_callback = None
        if enable_alerts:
            # Save user subscription
            await save_user_subscription(update.effective_user.id, token_address)
            
            # Create notification callback
            notify_callback = lambda message, token: send_alert_notification(
                update.effective_user.id, message, token
            )
        
        # Get group name if in a group
        group_name = None
        if update.effective_chat.type in ["group", "supergroup"]:
            group_name = update.effective_chat.title
        
        # Start tracking in background
        asyncio.create_task(
            track_token_with_alerts(
                token_address, 
                group_name, 
                notify_callback,
                DEFAULT_INTERVALS
            )
        )
        
        # Get token info (name, symbol) if available
        token_info = await get_token_info(token_address)
        token_name = token_info.get("name", "Unknown Token") if token_info else "Unknown Token"
        token_symbol = token_info.get("symbol", "???") if token_info else "???"
        
        # Format success message
        alert_status = "🔔 Price alerts enabled" if enable_alerts else "🔕 No alerts (use alerts=yes to enable)"
        
        tracking_message = (
            f"✅ *Token Tracking Started*\n\n"
            f"*Token:* {token_name} ({token_symbol})\n"
            f"*Address:* `{token_address}`\n"
            f"*Initial Price:* ${initial_price:.8f}\n"
            f"*Tracking Intervals:* 5m, 10m, 30m, 1h, 4h\n"
            f"*Alert Status:* {alert_status}\n\n"
            f"Use `/tracktoken info {token_address}` to see performance data."
        )
        
        # Create keyboard for additional options
        keyboard = [
            [
                InlineKeyboardButton("📊 View Performance", callback_data=f"track_info_{token_address}"),
                InlineKeyboardButton("📈 Price Chart", callback_data=f"track_chart_{token_address}")
            ]
        ]
        
        if enable_alerts:
            keyboard.append([
                InlineKeyboardButton("🔕 Disable Alerts", callback_data=f"track_alerts_off_{token_address}")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🔔 Enable Alerts", callback_data=f"track_alerts_on_{token_address}")
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Update the message
        await message.edit_text(
            tracking_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    
    except Exception as e:
        logger.error(f"Error in tracktoken command: {str(e)}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def show_tracked_tokens_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show a list of all tracked tokens.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get list of tracked tokens
        tokens = get_tracked_tokens_list()
        
        if not tokens:
            await update.message.reply_text(
                "📊 *Tracked Tokens*\n\n"
                "No tokens are currently being tracked.\n"
                "Use `/tracktoken <token_address>` to start tracking a token.",
                parse_mode="Markdown"
            )
            return
        
        # Format response
        response = "📊 *Tracked Tokens*\n\n"
        
        for i, token_address in enumerate(tokens[:10], 1):
            # Get token performance
            performance = calculate_token_performance(token_address)
            
            if not performance:
                continue
            
            # Get basic info
            group_name = performance.get("group_name", "Unknown")
            current_pct = performance.get("current_pct_change", 0)
            ath_pct = performance.get("ath_pct_change", 0)
            
            # Format entry
            emoji = "📈" if current_pct >= 0 else "📉"
            response += (
                f"{i}. {emoji} `{token_address[:6]}...{token_address[-4:]}`\n"
                f"   Current: {current_pct:.1f}% | ATH: {ath_pct:.1f}%\n"
                f"   Group: {group_name}\n\n"
            )
        
        # Add note if there are more tokens
        if len(tokens) > 10:
            response += f"_...and {len(tokens) - 10} more tokens._\n\n"
        
        response += "Use `/tracktoken info <token_address>` to see detailed performance."
        
        # Create keyboard for pagination if needed
        keyboard = []
        for i, token in enumerate(tokens[:5]):
            short_addr = f"{token[:6]}...{token[-4:]}"
            keyboard.append([
                InlineKeyboardButton(f"📊 {short_addr}", callback_data=f"track_info_{token}")
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Send response
        await update.message.reply_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    
    except Exception as e:
        logger.error(f"Error showing tracked tokens list: {str(e)}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def show_token_tracking_info(update: Update, context: ContextTypes.DEFAULT_TYPE, token_address: str) -> None:
    """
    Show detailed information about a tracked token.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        token_address: The token address to show info for
    """
    try:
        # Get token info
        performance = calculate_token_performance(token_address)
        
        if not performance:
            await update.message.reply_text(
                f"❌ *Token Not Found*\n\n"
                f"No tracking data available for: `{token_address}`\n"
                f"Use `/tracktoken {token_address}` to start tracking this token.",
                parse_mode="Markdown"
            )
            return
        
        # Get user subscription status
        is_subscribed = await check_user_subscription(update.effective_user.id, token_address)
        
        # Calculate time since launch
        launch_time = performance.get("launch_time", 0)
        update_time = performance.get("update_time", 0)
        current_time = datetime.now().timestamp()
        
        # Format duration
        if launch_time > 0:
            time_since_launch = format_duration(current_time - launch_time)
        else:
            time_since_launch = "Unknown"
        
        if update_time > 0:
            time_since_update = format_duration(current_time - update_time)
        else:
            time_since_update = "Unknown"
        
        # Format performance data
        current_pct = performance.get("current_pct_change", 0)
        ath_pct = performance.get("ath_pct_change", 0)
        atl_pct = performance.get("atl_pct_change", 0)
        
        interval_data = performance.get("interval_performance", {})
        interval_text = ""
        
        for interval, data in sorted(interval_data.items(), key=lambda x: int(x[0].replace("min", ""))):
            pct_change = data.get("pct_change", 0)
            emoji = "📈" if pct_change >= 0 else "📉"
            interval_text += f"• *{interval}:* {emoji} {pct_change:.1f}%\n"
        
        # Format response
        response = (
            f"📊 *Token Performance: {performance.get('group_name', 'Unknown')}*\n\n"
            f"*Address:* `{token_address}`\n"
            f"*Launch Price:* ${performance.get('launch_price', 0):.8f}\n"
            f"*Current Price:* ${performance.get('current_price', 0):.8f}\n"
            f"*Current Change:* {current_pct:.1f}%\n"
            f"*All-Time High:* {ath_pct:.1f}%\n"
            f"*All-Time Low:* {atl_pct:.1f}%\n"
            f"*Tracked Since:* {time_since_launch} ago\n"
            f"*Last Update:* {time_since_update} ago\n\n"
            f"*Interval Performance:*\n{interval_text}\n"
            f"*Price Alerts:* {'🔔 Enabled' if is_subscribed else '🔕 Disabled'}"
        )
        
        # Create keyboard for additional options
        keyboard = [
            [
                InlineKeyboardButton("📈 Price Chart", callback_data=f"track_chart_{token_address}"),
                InlineKeyboardButton("📋 All Tokens", callback_data="track_list")
            ]
        ]
        
        if is_subscribed:
            keyboard.append([
                InlineKeyboardButton("🔕 Disable Alerts", callback_data=f"track_alerts_off_{token_address}")
            ])
        else:
            keyboard.append([
                InlineKeyboardButton("🔔 Enable Alerts", callback_data=f"track_alerts_on_{token_address}")
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            # This is a callback query
            await update.callback_query.edit_message_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        else:
            # This is a direct command
            await update.message.reply_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
    
    except Exception as e:
        logger.error(f"Error showing token info: {str(e)}")
        error_message = f"❌ An error occurred: {str(e)}"
        
        if update.callback_query:
            await update.callback_query.edit_message_text(error_message)
        else:
            await update.message.reply_text(error_message)

async def handle_tracktoken_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback queries for tracktoken buttons.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    data = query.data
    
    # Answer the callback query to stop the loading indicator
    await query.answer()
    
    try:
        if data == "track_list":
            # Convert to fake update with message
            fake_update = update
            fake_update.message = update.effective_message
            await show_tracked_tokens_list(fake_update, context)
            
        elif data.startswith("track_info_"):
            # Extract token address
            token_address = data.replace("track_info_", "")
            await show_token_tracking_info(update, context, token_address)
            
        elif data.startswith("track_chart_"):
            # Extract token address
            token_address = data.replace("track_chart_", "")
            await show_token_price_chart(update, context, token_address)
            
        elif data.startswith("track_alerts_on_"):
            # Extract token address
            token_address = data.replace("track_alerts_on_", "")
            
            # Enable alerts
            await save_user_subscription(update.effective_user.id, token_address)
            
            # Show confirmation
            await query.edit_message_text(
                f"🔔 *Price Alerts Enabled*\n\n"
                f"You will now receive alerts for significant price movements of token:\n"
                f"`{token_address}`\n\n"
                f"Use `/tracktoken info {token_address}` to see current performance.",
                parse_mode="Markdown"
            )
            
        elif data.startswith("track_alerts_off_"):
            # Extract token address
            token_address = data.replace("track_alerts_off_", "")
            
            # Disable alerts
            await delete_user_subscription(update.effective_user.id, token_address)
            
            # Show confirmation
            await query.edit_message_text(
                f"🔕 *Price Alerts Disabled*\n\n"
                f"You will no longer receive alerts for token:\n"
                f"`{token_address}`\n\n"
                f"Use `/tracktoken info {token_address}` to see current performance.",
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Error handling tracktoken callback: {str(e)}")
        await query.edit_message_text(f"❌ An error occurred: {str(e)}")

async def show_token_price_chart(update: Update, context: ContextTypes.DEFAULT_TYPE, token_address: str) -> None:
    """
    Show a text-based price chart for a token.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        token_address: The token address to show chart for
    """
    try:
        # Get price history
        history = get_price_history(token_address)
        
        if not history:
            await update.callback_query.edit_message_text(
                f"❌ *No Price History*\n\n"
                f"No price history available for: `{token_address}`",
                parse_mode="Markdown"
            )
            return
        
        # Format text-based chart
        chart = "📊 *Token Price Chart*\n\n"
        chart += f"```\n"  # Start code block for monospace formatting
        
        # Extract timestamps and percentages
        data_points = []
        
        for entry in history:
            ts = entry.get("timestamp", 0)
            pct = entry.get("pct_change", 0)
            data_points.append((ts, pct))
        
        # Sort by timestamp
        data_points.sort(key=lambda x: x[0])
        
        # Generate simple ASCII chart
        max_bars = 20
        for ts, pct in data_points:
            # Format timestamp
            dt = datetime.fromtimestamp(ts)
            time_str = dt.strftime("%H:%M")
            
            # Create bar
            bar_length = min(max_bars, int(abs(pct) / 5))
            bar = "█" * bar_length
            
            if pct >= 0:
                chart += f"{time_str} {pct:+6.1f}% |{bar}\n"
            else:
                chart += f"{time_str} {pct:+6.1f}% |{bar}\n"
        
        chart += "```\n"  # End code block
        
        # Add note about intervals
        first_time = datetime.fromtimestamp(data_points[0][0]).strftime("%H:%M")
        last_time = datetime.fromtimestamp(data_points[-1][0]).strftime("%H:%M")
        
        chart += f"\nShowing price changes from {first_time} to {last_time}\n"
        chart += f"Token: `{token_address}`"
        
        # Create keyboard for back to info button
        keyboard = [
            [
                InlineKeyboardButton("📊 View Performance", callback_data=f"track_info_{token_address}"),
                InlineKeyboardButton("📋 All Tokens", callback_data="track_list")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Update the message
        await update.callback_query.edit_message_text(
            chart,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    
    except Exception as e:
        logger.error(f"Error showing token price chart: {str(e)}")
        await update.callback_query.edit_message_text(f"❌ An error occurred: {str(e)}")

async def send_alert_notification(user_id: int, message: str, token_address: str) -> None:
    """
    Send a price alert notification to a user.
    
    Args:
        user_id: Telegram user ID
        message: Message to send
        token_address: Token address
    """
    try:
        # Check if user is subscribed to this token
        is_subscribed = await check_user_subscription(user_id, token_address)
        
        if not is_subscribed:
            logger.info(f"User {user_id} not subscribed to {token_address}, skipping alert")
            return
        
        # Create keyboard
        keyboard = [
            [
                InlineKeyboardButton("📊 View Performance", callback_data=f"track_info_{token_address}"),
                InlineKeyboardButton("🔕 Disable Alerts", callback_data=f"track_alerts_off_{token_address}")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Check if we have a bot instance available in context
        from telegram.bot import Bot
        import os
        
        # Create a bot instance with the token from environment
        token = os.environ.get("TELEGRAM_BOT_TOKEN")
        if not token:
            logger.error("TELEGRAM_BOT_TOKEN not found in environment")
            return
        
        bot = Bot(token=token)
        
        # Send notification
        await bot.send_message(
            chat_id=user_id,
            text=message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
        logger.info(f"Sent price alert to user {user_id} for token {token_address}")
    
    except Exception as e:
        logger.error(f"Error sending alert notification: {str(e)}")

async def save_user_subscription(user_id: int, token_address: str) -> None:
    """
    Save a user's subscription to price alerts.
    
    Args:
        user_id: Telegram user ID
        token_address: Token address to subscribe to
    """
    try:
        # Load existing subscriptions
        subscriptions = {}
        
        if os.path.exists(USER_SUBSCRIPTIONS_FILE):
            try:
                with open(USER_SUBSCRIPTIONS_FILE, 'r') as f:
                    subscriptions = json.load(f)
            except json.JSONDecodeError:
                subscriptions = {}
        
        # Convert user_id to string for JSON
        user_id_str = str(user_id)
        
        # Add subscription
        if user_id_str not in subscriptions:
            subscriptions[user_id_str] = []
        
        if token_address not in subscriptions[user_id_str]:
            subscriptions[user_id_str].append(token_address)
        
        # Save updated subscriptions
        os.makedirs(os.path.dirname(USER_SUBSCRIPTIONS_FILE), exist_ok=True)
        with open(USER_SUBSCRIPTIONS_FILE, 'w') as f:
            json.dump(subscriptions, f, indent=2)
        
        # Update tracker subscriptions
        await subscribe_to_alerts(user_id, token_address)
    
    except Exception as e:
        logger.error(f"Error saving user subscription: {str(e)}")

async def delete_user_subscription(user_id: int, token_address: str) -> None:
    """
    Delete a user's subscription to price alerts.
    
    Args:
        user_id: Telegram user ID
        token_address: Token address to unsubscribe from
    """
    try:
        # Load existing subscriptions
        if not os.path.exists(USER_SUBSCRIPTIONS_FILE):
            return
        
        with open(USER_SUBSCRIPTIONS_FILE, 'r') as f:
            subscriptions = json.load(f)
        
        # Convert user_id to string for JSON
        user_id_str = str(user_id)
        
        # Remove subscription
        if user_id_str in subscriptions and token_address in subscriptions[user_id_str]:
            subscriptions[user_id_str].remove(token_address)
        
        # Save updated subscriptions
        with open(USER_SUBSCRIPTIONS_FILE, 'w') as f:
            json.dump(subscriptions, f, indent=2)
        
        # Update tracker subscriptions
        await unsubscribe_from_alerts(user_id, token_address)
    
    except Exception as e:
        logger.error(f"Error deleting user subscription: {str(e)}")

async def check_user_subscription(user_id: int, token_address: str) -> bool:
    """
    Check if a user is subscribed to price alerts for a token.
    
    Args:
        user_id: Telegram user ID
        token_address: Token address to check
        
    Returns:
        bool: True if user is subscribed, False otherwise
    """
    try:
        # Load existing subscriptions
        if not os.path.exists(USER_SUBSCRIPTIONS_FILE):
            return False
        
        with open(USER_SUBSCRIPTIONS_FILE, 'r') as f:
            subscriptions = json.load(f)
        
        # Convert user_id to string for JSON
        user_id_str = str(user_id)
        
        # Check subscription
        return user_id_str in subscriptions and token_address in subscriptions[user_id_str]
    
    except Exception as e:
        logger.error(f"Error checking user subscription: {str(e)}")
        return False

def format_duration(seconds: float) -> str:
    """
    Format a duration in seconds to a human-readable string.
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        str: Formatted duration string
    """
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        return f"{int(seconds / 60)}m"
    elif seconds < 86400:
        return f"{int(seconds / 3600)}h"
    else:
        return f"{int(seconds / 86400)}d"

def get_tracktoken_handlers():
    """
    Get command handlers for the tracktoken command.
    
    Returns:
        list: List of handlers
    """
    if not TELEGRAM_IMPORTS_AVAILABLE:
        return []
    
    return [
        CommandHandler("tracktoken", tracktoken_command),
        CallbackQueryHandler(handle_tracktoken_callback, pattern="^track_")
    ]

# For simplified bot
async def handle_tracktoken_simple(bot, chat_id, params):
    """
    Handle the /tracktoken command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: Command parameters
    """
    if not TRACKER_IMPORTS_AVAILABLE:
        await bot.send_message(
            chat_id=chat_id,
            text="❌ Token tracking functionality is not available. Please contact the administrator."
        )
        return
    
    try:
        # Check if user provided arguments
        if not params:
            await bot.send_message(
                chat_id=chat_id,
                text="❌ *Missing Token Address*\n\n"
                "Please provide a token address to track:\n"
                "`/tracktoken <token_address> [alerts=yes]`\n\n"
                "Or use `/tracktoken list` to see all tracked tokens.",
                parse_mode="Markdown"
            )
            return
        
        command = params[0].lower()
        
        # Handle list subcommand
        if command == "list":
            # Get list of tracked tokens
            tokens = get_tracked_tokens_list()
            
            if not tokens:
                await bot.send_message(
                    chat_id=chat_id,
                    text="📊 *Tracked Tokens*\n\n"
                    "No tokens are currently being tracked.\n"
                    "Use `/tracktoken <token_address>` to start tracking a token.",
                    parse_mode="Markdown"
                )
                return
            
            # Format response
            response = "📊 *Tracked Tokens*\n\n"
            
            for i, token_address in enumerate(tokens[:10], 1):
                # Get token performance
                performance = calculate_token_performance(token_address)
                
                if not performance:
                    continue
                
                # Get basic info
                group_name = performance.get("group_name", "Unknown")
                current_pct = performance.get("current_pct_change", 0)
                ath_pct = performance.get("ath_pct_change", 0)
                
                # Format entry
                emoji = "📈" if current_pct >= 0 else "📉"
                response += (
                    f"{i}. {emoji} `{token_address[:6]}...{token_address[-4:]}`\n"
                    f"   Current: {current_pct:.1f}% | ATH: {ath_pct:.1f}%\n"
                    f"   Group: {group_name}\n\n"
                )
            
            # Add note if there are more tokens
            if len(tokens) > 10:
                response += f"_...and {len(tokens) - 10} more tokens._\n\n"
            
            response += "Use `/tracktoken info <token_address>` to see detailed performance."
            
            await bot.send_message(
                chat_id=chat_id,
                text=response,
                parse_mode="Markdown"
            )
            return
        
        # Handle info subcommand
        if command == "info" and len(params) > 1:
            token_address = params[1]
            
            # Get token info
            performance = calculate_token_performance(token_address)
            
            if not performance:
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"❌ *Token Not Found*\n\n"
                    f"No tracking data available for: `{token_address}`\n"
                    f"Use `/tracktoken {token_address}` to start tracking this token.",
                    parse_mode="Markdown"
                )
                return
            
            # Calculate time since launch
            launch_time = performance.get("launch_time", 0)
            update_time = performance.get("update_time", 0)
            current_time = datetime.now().timestamp()
            
            # Format duration
            if launch_time > 0:
                time_since_launch = format_duration(current_time - launch_time)
            else:
                time_since_launch = "Unknown"
            
            if update_time > 0:
                time_since_update = format_duration(current_time - update_time)
            else:
                time_since_update = "Unknown"
            
            # Format performance data
            current_pct = performance.get("current_pct_change", 0)
            ath_pct = performance.get("ath_pct_change", 0)
            atl_pct = performance.get("atl_pct_change", 0)
            
            interval_data = performance.get("interval_performance", {})
            interval_text = ""
            
            for interval, data in sorted(interval_data.items(), key=lambda x: int(x[0].replace("min", ""))):
                pct_change = data.get("pct_change", 0)
                emoji = "📈" if pct_change >= 0 else "📉"
                interval_text += f"• *{interval}:* {emoji} {pct_change:.1f}%\n"
            
            # Format response
            response = (
                f"📊 *Token Performance: {performance.get('group_name', 'Unknown')}*\n\n"
                f"*Address:* `{token_address}`\n"
                f"*Launch Price:* ${performance.get('launch_price', 0):.8f}\n"
                f"*Current Price:* ${performance.get('current_price', 0):.8f}\n"
                f"*Current Change:* {current_pct:.1f}%\n"
                f"*All-Time High:* {ath_pct:.1f}%\n"
                f"*All-Time Low:* {atl_pct:.1f}%\n"
                f"*Tracked Since:* {time_since_launch} ago\n"
                f"*Last Update:* {time_since_update} ago\n\n"
                f"*Interval Performance:*\n{interval_text}"
            )
            
            await bot.send_message(
                chat_id=chat_id,
                text=response,
                parse_mode="Markdown"
            )
            return
        
        # Regular tracking command - first arg is the token address
        token_address = params[0]
        
        # Send initial message
        await bot.send_message(
            chat_id=chat_id,
            text=f"🔍 *Tracking Token*\n\n"
            f"Setting up advanced tracking for: `{token_address}`\n"
            f"Fetching initial price data...",
            parse_mode="Markdown"
        )
        
        # Check if token is valid by getting initial price
        initial_price = await get_token_price(token_address)
        
        if not initial_price or initial_price <= 0:
            await bot.send_message(
                chat_id=chat_id,
                text=f"❌ *Invalid Token*\n\n"
                f"Could not get price data for: `{token_address}`\n"
                f"Please check the token address and try again.",
                parse_mode="Markdown"
            )
            return
        
        # Start tracking in background
        asyncio.create_task(track_token_price(token_address, "SimpleBot Command"))
        
        # Format success message
        tracking_message = (
            f"✅ *Token Tracking Started*\n\n"
            f"*Address:* `{token_address}`\n"
            f"*Initial Price:* ${initial_price:.8f}\n"
            f"*Tracking Intervals:* 5m, 10m, 30m, 1h, 4h\n\n"
            f"Use `/tracktoken info {token_address}` to see performance data."
        )
        
        await bot.send_message(
            chat_id=chat_id,
            text=tracking_message,
            parse_mode="Markdown"
        )
    
    except Exception as e:
        logger.error(f"Error in tracktoken command (simple): {str(e)}")
        await bot.send_message(
            chat_id=chat_id,
            text=f"❌ An error occurred: {str(e)}"
        )