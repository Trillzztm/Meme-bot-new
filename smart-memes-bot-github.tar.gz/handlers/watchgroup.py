"""
Telegram group monitoring handler for SMART MEMES BOT.

This module provides functionality to:
1. Watch Telegram groups for token mentions
2. Analyze mentioned tokens for safety and potential
3. Optionally auto-snipe tokens that meet safety criteria
"""

import re
import asyncio
import logging
from typing import Dict, Any, List, Optional, Set, Tuple

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_analyzer import analyze_token
from utils.token_info import is_valid_token_address
from handlers.sniper import sniper  # Import the enhanced sniper implementation
from database import add_token_mention, add_watched_group, get_user_watched_groups
from config import MAX_AUTO_SNIPE_AMOUNT  # Maximum amount to use for auto-sniping

# Constants
DEFAULT_AUTO_SNIPE_THRESHOLD = 3  # Mention threshold for auto-sniping
DEFAULT_AUTO_SNIPE_AMOUNT = 0.05  # Default SOL amount for auto-sniping

async def watchgroup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /watchgroup command - Add a Telegram group to monitoring.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_watchgroup(update, context)

async def handle_watchgroup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the watchgroup command - Add a Telegram group to monitoring.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Check if arguments provided
        if not context.args or len(context.args) < 1:
            await update.message.reply_text(
                "Please provide a group link to watch.\n"
                "Usage: /watchgroup <group_link> [options]\n\n"
                "Options:\n"
                "• auto=yes|no - Enable auto-sniping (default: no)\n"
                "• min=<number> - Minimum mentions before auto-snipe (default: 3)\n"
                "• amount=<SOL> - Amount to use for auto-sniping (default: 0.05)\n\n"
                "Example: /watchgroup t.me/cryptogems auto=yes min=5 amount=0.1"
            )
            return
        
        # Get group link
        group_link = context.args[0]
        
        # Validate group link (basic validation)
        if not group_link.startswith(("https://t.me/", "t.me/")):
            await update.message.reply_text(
                "❌ Invalid group link format. Please provide a valid Telegram group link.\n"
                "Example: t.me/cryptogems"
            )
            return
            
        # Parse options
        auto_snipe = False
        min_mentions = DEFAULT_AUTO_SNIPE_THRESHOLD
        amount = DEFAULT_AUTO_SNIPE_AMOUNT
        
        for arg in context.args[1:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                
                if key.lower() == "auto":
                    auto_snipe = value.lower() in ["yes", "true", "y", "1"]
                elif key.lower() == "min":
                    try:
                        min_mentions = int(value)
                    except ValueError:
                        await update.message.reply_text(f"Invalid min value: {value}. Using default: {DEFAULT_AUTO_SNIPE_THRESHOLD}")
                elif key.lower() == "amount":
                    try:
                        amount = float(value)
                        if amount > MAX_AUTO_SNIPE_AMOUNT:
                            await update.message.reply_text(
                                f"⚠️ Auto-snipe amount {amount} SOL exceeds maximum ({MAX_AUTO_SNIPE_AMOUNT} SOL). "
                                f"Setting to {MAX_AUTO_SNIPE_AMOUNT} SOL."
                            )
                            amount = MAX_AUTO_SNIPE_AMOUNT
                    except ValueError:
                        await update.message.reply_text(f"Invalid amount value: {value}. Using default: {DEFAULT_AUTO_SNIPE_AMOUNT}")
                        
        # Extract group name from link
        group_name = group_link.split("/")[-1] if "/" in group_link else group_link
        
        # Get user ID
        user_id = update.effective_user.id
        
        # Add group to database
        try:
            from database import add_watched_group
            result = add_watched_group(
                telegram_id=user_id,
                group_link=group_link,
                group_name=group_name,
                auto_snipe=auto_snipe,
                auto_snipe_threshold=min_mentions
            )
            
            # Store auto-snipe amount in user context
            if not hasattr(context, "user_data"):
                context.user_data = {}
            
            if "auto_snipe_amounts" not in context.user_data:
                context.user_data["auto_snipe_amounts"] = {}
                
            context.user_data["auto_snipe_amounts"][group_link] = amount
            
            # Success message
            await update.message.reply_text(
                f"✅ Now watching group {group_name}\n\n"
                f"Auto-sniping: {'Enabled' if auto_snipe else 'Disabled'}\n"
                f"Mention threshold: {min_mentions}\n"
                f"Auto-snipe amount: {amount} SOL\n\n"
                "I'll notify you when tokens are mentioned in this group."
            )
            
        except Exception as db_error:
            logger.error(f"Error adding group to database: {db_error}")
            await update.message.reply_text(f"❌ Error adding group to database: {str(db_error)}")
        
    except Exception as e:
        logger.error(f"Error in watchgroup handler: {e}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def handle_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process messages in watched groups and detect/analyze token mentions.
    This would be registered as a message handler for all messages.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Check if this is a group message
        if not update.message or not update.message.chat or update.message.chat.type not in ["group", "supergroup"]:
            return
            
        # Get message text
        text = update.message.text or ""
        if not text:
            return
            
        # Extract group info
        group_id = update.message.chat.id
        group_name = update.message.chat.title
        group_link = f"t.me/{update.message.chat.username}" if update.message.chat.username else None
        
        if not group_link:
            # Can't track this group
            return
            
        # Check if this group is being watched by any users
        try:
            watched_groups = []
            # In a real implementation, query the database to get users watching this group
            # For now, we'll simulate this
            
            # If no users are watching this group, return
            if not watched_groups:
                return
                
        except Exception as db_error:
            logger.error(f"Error checking watched groups: {db_error}")
            return
            
        # Extract potential token addresses using regex
        # This regex looks for hexadecimal strings that could be token addresses
        # Note: This is a simplified approach - real detection would be more sophisticated
        token_pattern = r"[A-Za-z0-9]{32,}"
        potential_tokens = re.findall(token_pattern, text)
        
        # Filter to valid token addresses
        valid_tokens = [token for token in set(potential_tokens) if is_valid_token_address(token)]
        
        if not valid_tokens:
            return
            
        # Process each valid token
        for token_address in valid_tokens:
            # Record mention in database
            try:
                # Add mention to database for each watching user
                for group in watched_groups:
                    add_token_mention(
                        group_id=group.id,
                        token_address=token_address
                    )
            except Exception as mention_error:
                logger.error(f"Error recording token mention: {mention_error}")
                
            # Analyze the token
            try:
                # Use our enhanced token analyzer
                safety_score, summary, token_data = await analyze_token(token_address)
                
                # Format token name for display
                token_name = token_data.get("name") or token_data.get("symbol") or token_address[:10] + "..."
                
                # Check if any user has auto-snipe enabled for this group and the token meets criteria
                for group in watched_groups:
                    # Get mention count from database
                    # In a real implementation, query the database to get mention count
                    mention_count = 1  # Placeholder for actual database query
                    
                    # Check if auto-snipe is enabled and criteria are met
                    if (group.auto_snipe and 
                        safety_score >= 7 and  # Safe token
                        mention_count >= group.auto_snipe_threshold):  # Enough mentions
                        
                        # Get auto-snipe amount
                        amount = DEFAULT_AUTO_SNIPE_AMOUNT
                        if hasattr(context, "user_data") and "auto_snipe_amounts" in context.user_data:
                            amount = context.user_data["auto_snipe_amounts"].get(group_link, DEFAULT_AUTO_SNIPE_AMOUNT)
                        
                        # Execute the auto-snipe
                        # Here we would call the sniper functionality
                        # For now, we'll just log the action
                        logger.info(f"Auto-sniping token {token_address} with {amount} SOL for user {group.telegram_id}")
                        
                        # Notify the user
                        try:
                            await context.bot.send_message(
                                chat_id=group.telegram_id,
                                text=(
                                    f"🚨 *AUTO-SNIPE TRIGGERED* 🚨\n\n"
                                    f"Token: `{token_name}` ({token_address})\n"
                                    f"Safety Score: {safety_score}/10\n"
                                    f"Group: {group_name}\n"
                                    f"Mentions: {mention_count}\n"
                                    f"Amount: {amount} SOL\n\n"
                                    "Executing purchase transaction..."
                                ),
                                parse_mode="Markdown"
                            )
                            
                            # Create a mock update and context for the sniper command
                            # In a real implementation, this would be more sophisticated
                            # For now, we'll just log the action
                            logger.info(f"Would execute sniper command for {token_address}")
                            
                        except Exception as notify_error:
                            logger.error(f"Error notifying user of auto-snipe: {notify_error}")
                
            except Exception as analyze_error:
                logger.error(f"Error analyzing token: {analyze_error}")
        
    except Exception as e:
        logger.error(f"Error in group message handler: {e}")
        
def handle_watchgroup_simple(bot, chat_id, params):
    """
    Process the watchgroup command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # This is a simplified version that doesn't interact with Update/Context objects
    try:
        # Check if arguments provided
        if not params or len(params) < 1:
            bot.send_message(
                chat_id,
                "Please provide a group link to watch.\n"
                "Usage: /watchgroup <group_link> [options]\n\n"
                "Options:\n"
                "• auto=yes|no - Enable auto-sniping (default: no)\n"
                "• min=<number> - Minimum mentions before auto-snipe (default: 3)\n"
                "• amount=<SOL> - Amount to use for auto-sniping (default: 0.05)\n\n"
                "Example: /watchgroup t.me/cryptogems auto=yes min=5 amount=0.1"
            )
            return
        
        # Get group link
        group_link = params[0]
        
        # Validate group link (basic validation)
        if not group_link.startswith(("https://t.me/", "t.me/")):
            bot.send_message(
                chat_id,
                "❌ Invalid group link format. Please provide a valid Telegram group link.\n"
                "Example: t.me/cryptogems"
            )
            return
            
        # Parse options
        auto_snipe = False
        min_mentions = DEFAULT_AUTO_SNIPE_THRESHOLD
        amount = DEFAULT_AUTO_SNIPE_AMOUNT
        
        for arg in params[1:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                
                if key.lower() == "auto":
                    auto_snipe = value.lower() in ["yes", "true", "y", "1"]
                elif key.lower() == "min":
                    try:
                        min_mentions = int(value)
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid min value: {value}. Using default: {DEFAULT_AUTO_SNIPE_THRESHOLD}")
                elif key.lower() == "amount":
                    try:
                        amount = float(value)
                        if amount > MAX_AUTO_SNIPE_AMOUNT:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Auto-snipe amount {amount} SOL exceeds maximum ({MAX_AUTO_SNIPE_AMOUNT} SOL). "
                                f"Setting to {MAX_AUTO_SNIPE_AMOUNT} SOL."
                            )
                            amount = MAX_AUTO_SNIPE_AMOUNT
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid amount value: {value}. Using default: {DEFAULT_AUTO_SNIPE_AMOUNT}")
                        
        # Extract group name from link
        group_name = group_link.split("/")[-1] if "/" in group_link else group_link
        
        # Add group to database
        try:
            result = add_watched_group(
                telegram_id=chat_id,
                group_link=group_link,
                group_name=group_name,
                auto_snipe=auto_snipe,
                auto_snipe_threshold=min_mentions
            )
            
            # Store auto-snipe amount in simpified bot user data
            # For this simplified implementation, we can't easily store per-user settings
            # In a real implementation, this would be stored in a database
            
            # Success message
            bot.send_message(
                chat_id,
                f"✅ Now watching group {group_name}\n\n"
                f"Auto-sniping: {'Enabled' if auto_snipe else 'Disabled'}\n"
                f"Mention threshold: {min_mentions}\n"
                f"Auto-snipe amount: {amount} SOL\n\n"
                "I'll notify you when tokens are mentioned in this group."
            )
            
        except Exception as db_error:
            logger.error(f"Error adding group to database: {db_error}")
            bot.send_message(chat_id, f"❌ Error adding group to database: {str(db_error)}")
        
    except Exception as e:
        logger.error(f"Error in watchgroup simple handler: {e}")
        bot.send_message(chat_id, f"❌ An error occurred: {str(e)}")