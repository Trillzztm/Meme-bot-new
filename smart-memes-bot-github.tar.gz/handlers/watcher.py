"""
Group Message Watcher for SMART MEMES BOT

This module automatically monitors messages in Telegram groups for token mentions
and immediately snipes promising tokens when they're first announced.

Features:
- Regex detection of token addresses in messages
- Keyword filtering to identify new launches
- Automatic token safety checking before purchase
- Performance tracking after purchase
- Group quality scoring based on success rate
"""

import re
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional

from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters

# Import trading functions
from utils.trading import execute_trade
from utils.token_safety import check_token_safety
from utils.token_analyzer import get_token_price
from utils.group_ranker import update_group_score, should_auto_snipe, get_group_stats

# Configure logger
logger = logging.getLogger(__name__)

# Watch for keywords that usually indicate a new launch
LAUNCH_KEYWORDS = [
    "live now", "chart", "ca:", "contract:", "launch", "deployed", "just launched",
    "stealth launch", "fair launch", "listing", "listed", "new gem", "x100", "100x",
    "moonshot", "moon soon", "address:", "going live", "active now"
]

# Regex pattern to extract token addresses
TOKEN_ADDRESS_PATTERN = re.compile(r"(CA[:\s]*|Contract[:\s]*|Address[:\s]*)?([a-zA-Z0-9]{32,44})")

# Store successful groups for prioritization
successful_groups = {}

# Auto-snipe configuration
DEFAULT_SNIPE_AMOUNT = 0.01  # SOL
EVALUATION_TIME = 300  # 5 minutes
MIN_PROFIT_THRESHOLD = 1.25  # 25% profit to mark as success

async def watcher(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Watch for token mentions in group messages and auto-snipe promising tokens.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Skip if not a message or no text
        if not update.message or not update.message.text:
            return
        
        # Extract group info
        chat_id = update.effective_chat.id
        group_name = update.effective_chat.title
        user_id = update.effective_user.id
        
        # Get message text and convert to lowercase for keyword matching
        message = update.message.text
        message_lower = message.lower()
        
        # Skip if no launch keywords found (to reduce processing)
        if not any(keyword in message_lower for keyword in LAUNCH_KEYWORDS):
            return
        
        logger.info(f"Detected launch keywords in group {group_name} ({chat_id})")
        
        # Extract potential token addresses
        token_matches = TOKEN_ADDRESS_PATTERN.findall(message)
        
        if not token_matches:
            return
        
        # Process each potential token address
        for _, token_address in token_matches:
            # Clean up the token address
            token_address = token_address.strip()
            
            if len(token_address) < 32:  # Skip if too short to be a valid address
                continue
            
            logger.info(f"Found potential token address in group: {token_address}")
            
            # Check if token is safe before proceeding
            try:
                safety_result = await check_token_safety(token_address)
                
                if not safety_result.get('safe', False):
                    reason = safety_result.get('reason', 'Unknown safety issue')
                    logger.warning(f"Skipping unsafe token {token_address}: {reason}")
                    continue
                
                # Get group-specific auto-snipe settings (if any)
                group_settings = context.bot_data.get('group_settings', {}).get(str(chat_id), {})
                snipe_amount = group_settings.get('auto_snipe_amount', DEFAULT_SNIPE_AMOUNT)
                
                # Only auto-snipe if enabled for this group
                if not group_settings.get('auto_snipe_enabled', False):
                    logger.info(f"Auto-snipe disabled for group {group_name}, skipping")
                    continue
                
                # Auto-snipe the token
                logger.info(f"Auto-sniping token {token_address} with {snipe_amount} SOL")
                
                trade_result = await execute_trade(token_address, amount=snipe_amount)
                
                if not trade_result.get('success', False):
                    logger.error(f"Failed to auto-snipe {token_address}: {trade_result.get('error', 'Unknown error')}")
                    continue
                
                # Record the auto-snipe
                tx_hash = trade_result.get('tx_hash', 'unknown')
                entry_price = trade_result.get('price', 0)
                
                auto_snipe_info = {
                    'token_address': token_address,
                    'amount': snipe_amount,
                    'entry_price': entry_price,
                    'tx_hash': tx_hash,
                    'timestamp': datetime.now().isoformat(),
                    'group_id': chat_id,
                    'group_name': group_name,
                    'message_id': update.message.message_id,
                    'evaluated': False
                }
                
                # Store the auto-snipe info
                if 'auto_snipes' not in context.bot_data:
                    context.bot_data['auto_snipes'] = []
                
                context.bot_data['auto_snipes'].append(auto_snipe_info)
                
                # Schedule evaluation after EVALUATION_TIME seconds
                context.job_queue.run_once(
                    evaluate_auto_snipe,
                    EVALUATION_TIME,
                    context=(chat_id, token_address, auto_snipe_info)
                )
                
                # Notify in the group if configured to do so
                if group_settings.get('notify_snipe', False):
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"🚀 *Auto-sniped Token* 🚀\n\n"
                             f"Address: `{token_address}`\n"
                             f"Amount: {snipe_amount} SOL\n"
                             f"TX: `{tx_hash}`\n\n"
                             f"Evaluating performance in 5 minutes...",
                        parse_mode="Markdown"
                    )
                
            except Exception as e:
                logger.error(f"Error processing token {token_address}: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error in watcher: {str(e)}")

async def evaluate_auto_snipe(context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Evaluate the performance of an auto-sniped token after the evaluation period.
    
    Args:
        context: The context object containing the job data
    """
    try:
        # Extract data from job context
        chat_id, token_address, auto_snipe_info = context.job.data
        
        # Mark as evaluated to avoid duplicate evaluations
        auto_snipe_info['evaluated'] = True
        
        # Get current price
        current_price = await get_token_price(token_address)
        entry_price = auto_snipe_info.get('entry_price', 0)
        
        if entry_price == 0 or current_price == 0:
            logger.warning(f"Invalid prices for evaluation: entry={entry_price}, current={current_price}")
            return
        
        # Calculate profit multiple
        profit_multiple = current_price / entry_price
        auto_snipe_info['profit_multiple'] = profit_multiple
        auto_snipe_info['exit_price'] = current_price
        auto_snipe_info['evaluation_timestamp'] = datetime.now().isoformat()
        
        # Update group ranking in the persistent database
        group_id = str(auto_snipe_info.get('group_id', ''))
        group_name = auto_snipe_info.get('group_name', 'Unknown Group')
        
        if group_id:
            # Update the group score in our persistent database
            update_group_score(group_id, group_name, profit_multiple, token_address)
            
            # Get the updated stats for the group
            group_data = get_group_stats(group_id)
        
        # Get group settings to check if we should notify
        group_settings = context.bot_data.get('group_settings', {}).get(group_id, {})
        
        # Only notify if configured to do so
        if group_settings.get('notify_evaluation', False) and profit_multiple >= MIN_PROFIT_THRESHOLD:
            # Send a message to the group about the performance
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"📊 *Auto-Snipe Evaluation* 📊\n\n"
                     f"Token: `{token_address}`\n"
                     f"Profit: {profit_multiple:.2f}x ({(profit_multiple-1)*100:.1f}%)\n"
                     f"Status: {'✅ PROFIT' if profit_multiple >= MIN_PROFIT_THRESHOLD else '❌ LOSS'}\n\n"
                     f"This group has dropped {group_data.get('wins', 0)} profitable tokens "
                     f"out of {group_data.get('wins', 0) + group_data.get('losses', 0)} evaluated.",
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Error evaluating auto-snipe: {str(e)}")

def get_group_stats(group_id: str) -> Dict[str, Any]:
    """
    Get statistics for a specific group.
    
    Args:
        group_id: The group ID to get stats for
        
    Returns:
        Dictionary with group statistics
    """
    return successful_groups.get(str(group_id), {
        'name': 'Unknown Group',
        'tokens_evaluated': 0,
        'successful_tokens': 0,
        'total_profit': 0,
        'last_evaluated': None
    })

def get_top_groups(limit: int = 10) -> list:
    """
    Get the top performing groups based on success rate.
    
    Args:
        limit: Maximum number of groups to return
        
    Returns:
        List of top groups with their stats
    """
    # Calculate success rate for each group
    for group_id, stats in successful_groups.items():
        if stats['tokens_evaluated'] > 0:
            stats['success_rate'] = stats['successful_tokens'] / stats['tokens_evaluated']
        else:
            stats['success_rate'] = 0
    
    # Sort by success rate (for groups with at least 3 evaluations)
    qualified_groups = [
        {'id': group_id, **stats}
        for group_id, stats in successful_groups.items()
        if stats['tokens_evaluated'] >= 3
    ]
    
    sorted_groups = sorted(
        qualified_groups,
        key=lambda x: x['success_rate'],
        reverse=True
    )
    
    return sorted_groups[:limit]

def get_watcher_handler():
    """Get the message handler for the watcher."""
    return MessageHandler(filters.TEXT & (~filters.COMMAND) & filters.ChatType.GROUPS, watcher)


async def process_message(bot, update):
    """
    Process a message for the SimpleTelegramBot implementation.
    This adapts our watcher for the simplified bot format.
    
    Args:
        bot: The SimpleTelegramBot instance
        update: The update dictionary from Telegram
    """
    try:
        # Extract message data
        message = update.get("message", {})
        text = message.get("text", "")
        chat = message.get("chat", {})
        chat_id = chat.get("id")
        chat_type = chat.get("type", "")
        
        # Only process group messages
        if chat_type not in ["group", "supergroup"]:
            return
            
        # Skip if no message text
        if not text:
            return
            
        # Extract group info
        group_name = chat.get("title", "Unknown Group")
        user = update.get("from", {})
        user_id = user.get("id")
        
        # Get message text and convert to lowercase for keyword matching
        message_lower = text.lower()
        
        # Skip if no launch keywords found (to reduce processing)
        if not any(keyword in message_lower for keyword in LAUNCH_KEYWORDS):
            return
        
        logger.info(f"Detected launch keywords in group {group_name} ({chat_id})")
        
        # Extract potential token addresses
        token_matches = TOKEN_ADDRESS_PATTERN.findall(text)
        
        if not token_matches:
            return
        
        # Process each potential token address
        for _, token_address in token_matches:
            # Clean up the token address
            token_address = token_address.strip()
            
            if len(token_address) < 32:  # Skip if too short to be a valid address
                continue
            
            logger.info(f"Found potential token address in group: {token_address}")
            
            # Check if token is safe before proceeding
            try:
                safety_result = await check_token_safety(token_address)
                
                if not safety_result.get('safe', False):
                    reason = safety_result.get('reason', 'Unknown safety issue')
                    logger.warning(f"Skipping unsafe token {token_address}: {reason}")
                    continue
                
                # Get auto-snipe configuration
                # For the simplified bot, we'll use a default configuration
                auto_snipe_config = {
                    'enabled': True,
                    'amount': DEFAULT_SNIPE_AMOUNT,
                    'min_success_rate': 0.5,
                    'max_amount': 0.1
                }
                
                # Check if this group should be auto-sniped based on its performance history
                should_snipe, optimal_amount = should_auto_snipe(str(chat_id), auto_snipe_config)
                
                # Only auto-snipe if enabled for this group
                if not should_snipe:
                    logger.info(f"Auto-snipe disabled for group {group_name}, skipping")
                    continue
                
                # Auto-snipe the token
                snipe_amount = optimal_amount
                logger.info(f"Auto-sniping token {token_address} with {snipe_amount} SOL")
                
                trade_result = await execute_trade(token_address, amount=snipe_amount)
                
                if not trade_result.get('success', False):
                    logger.error(f"Failed to auto-snipe {token_address}: {trade_result.get('error', 'Unknown error')}")
                    continue
                
                # Record the auto-snipe
                tx_hash = trade_result.get('tx_hash', 'unknown')
                entry_price = trade_result.get('price', 0)
                
                auto_snipe_info = {
                    'token_address': token_address,
                    'amount': snipe_amount,
                    'entry_price': entry_price,
                    'tx_hash': tx_hash,
                    'timestamp': datetime.now().isoformat(),
                    'group_id': chat_id,
                    'group_name': group_name,
                    'message_id': message.get("message_id"),
                    'evaluated': False
                }
                
                # Store the auto-snipe info (simplified for now)
                # In a real implementation, we'd schedule evaluation later
                
                # Send a notification if needed
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"🚀 *Auto-sniped Token* 🚀\n\n"
                         f"Address: `{token_address}`\n"
                         f"Amount: {snipe_amount} SOL\n"
                         f"TX: `{tx_hash}`\n\n"
                         f"Evaluating performance in 5 minutes...",
                    parse_mode="Markdown"
                )
                
                # Schedule evaluation (this will be handled outside this function)
                # For a real implementation, we would use asyncio scheduling
                
            except Exception as e:
                logger.error(f"Error processing token {token_address}: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error in process_message: {str(e)}")