"""
Help command handler for SMART MEMES BOT.

This module handles the /help command to provide detailed instructions
for all the bot's commands and features.
"""

import logging
from typing import Dict, Any, Optional, List

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Import configuration
from config import MAX_SPEND, DEFAULT_SLIPPAGE, MEME_TEMPLATES

async def help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /help command - Show detailed information about all commands.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_help(update, context)

async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the help command - Display help information based on arguments.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Check if a specific command was requested
    if context.args and len(context.args) > 0:
        command = context.args[0].lower().strip('/')
        await send_specific_help(update, command)
        return
    
    # If no specific command, send general help with button menu
    keyboard = [
        [
            InlineKeyboardButton("Token Info", callback_data="help_tokeninfo"),
            InlineKeyboardButton("Manual Snipe", callback_data="help_manualsnipe")
        ],
        [
            InlineKeyboardButton("Watch Group", callback_data="help_watchgroup"),
            InlineKeyboardButton("Wallet Tracking", callback_data="help_wallettrack")
        ],
        [
            InlineKeyboardButton("Auto Snipe", callback_data="help_autosnipe"),
            InlineKeyboardButton("Meme Generator", callback_data="help_memegen")
        ],
        [
            InlineKeyboardButton("Advanced Settings", callback_data="help_settings")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    help_text = (
        "🤖 *SMART MEMES BOT Help Center* 🚀\n\n"
        "I'm your advanced crypto trading and monitoring assistant designed for serious traders. "
        "Choose a topic below to see detailed instructions, or use /help <command> for specific help.\n\n"
        "*Available Commands:*\n"
        "• /tokeninfo <address> - Advanced token analytics and safety analysis\n"
        "• /manualsnipe <address> <amount> - Execute precision trades with custom parameters\n"
        "• /sniper <address> <amount> - Super-reliable simplified token sniping\n"
        "• /watchgroup <link> - Monitor groups with AI-powered token detection\n"
        "• /trackwallet <address> - Set up real-time whale wallet monitoring\n"
        "• /autosnipe set <params> - Configure automated trading strategies\n"
        "• /generateprememe <token> - Create viral-ready memes for tokens\n"
        "• /settings - Access advanced trading configuration\n\n"
        "🔐 *Security Guarantee:* All transactions secured with multi-layered verification and real-time monitoring."
    )
    
    await update.message.reply_text(
        help_text,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def send_specific_help(update: Update, command: str) -> None:
    """
    Send help information for a specific command.
    
    Args:
        update: The update object from Telegram
        command: The command to provide help for
    """
    if command == "tokeninfo":
        help_text = (
            "*📊 TOKENINFO - Advanced Token Analytics*\n\n"
            "Perform comprehensive token analysis with real-time data from multiple sources.\n\n"
            "*Usage:* `/tokeninfo <token_address> [options]`\n\n"
            "*Options:*\n"
            "• `detailed=yes` - Full blockchain analytics report\n"
            "• `holders=yes` - Show top wallet concentration\n"
            "• `history=<days>` - Price history (1-30 days)\n\n"
            "*Examples:*\n"
            "• `/tokeninfo Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu`\n"
            "• `/tokeninfo Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu detailed=yes history=7`\n\n"
            "The analysis includes liquidity depth, holder distribution, transaction velocity, mint authority status, "
            "contract verification, hidden backdoor detection, and cross-reference with known scams."
        )
    
    elif command == "manualsnipe":
        help_text = (
            "*🎯 MANUALSNIPE - Precision Trading*\n\n"
            "Execute high-precision trades with advanced parameters for maximum profit potential.\n\n"
            "*Usage:* `/manualsnipe <token_address> <amount> [options]`\n\n"
            "*Options:*\n"
            f"• `amount=<value>` - Amount to spend (max: {MAX_SPEND} SOL)\n"
            f"• `slippage=<percent>` - Custom slippage (default: {DEFAULT_SLIPPAGE}%)\n"
            "• `gas=low|medium|high|rapid` - Transaction priority\n"
            "• `autosell=<percent>` - Set take-profit level\n"
            "• `stoploss=<percent>` - Set stop-loss level\n\n"
            "*Examples:*\n"
            "• `/manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5`\n"
            "• `/manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu amount=0.5 slippage=1 gas=high autosell=200 stoploss=50`\n\n"
            "The system automatically performs pre-trade contract analysis and verifies liquidity levels "
            "before execution to protect against honeypots and rug pulls."
        )
    
    elif command == "sniper":
        help_text = (
            "*🚀 SNIPER - Ultra-Reliable Token Sniping*\n\n"
            "Execute high-speed token purchases with bulletproof reliability and safety checks.\n\n"
            "*Usage:* `/sniper <token_address> <amount>`\n\n"
            "*Features:*\n"
            "• Simplified command structure for fast execution\n"
            "• Enhanced reliability with multiple RPC fallbacks\n"
            "• Automatic safety analysis before purchase\n"
            "• Built-in liquidity verification\n"
            f"• Maximum spending limit of {MAX_SPEND} SOL per transaction\n"
            f"• Default slippage of {DEFAULT_SLIPPAGE}% for optimal execution\n\n"
            "*Examples:*\n"
            "• `/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5`\n\n"
            "This command uses our next-generation direct API implementation with enhanced error handling "
            "and multi-layered safety checks to provide the most reliable sniping experience possible."
        )
    
    elif command == "watchgroup":
        help_text = (
            "*👁️ WATCHGROUP - AI-Powered Group Monitoring*\n\n"
            "Monitor Telegram groups for token mentions with intelligent filtering and auto-sniping.\n\n"
            "*Usage:* `/watchgroup <group_link> [options]`\n\n"
            "*Options:*\n"
            "• `auto=yes|no` - Enable auto-sniping (default: no)\n"
            "• `min=<number>` - Minimum mentions threshold\n"
            "• `amount=<value>` - Amount to use for auto-sniping\n"
            "• `delay=<seconds>` - Delay before sniping\n"
            "• `filter=high|medium|low` - Safety filter level\n\n"
            "*Examples:*\n"
            "• `/watchgroup t.me/cryptogems`\n"
            "• `/watchgroup t.me/cryptogems auto=yes min=5 amount=0.2 filter=high`\n\n"
            "Our AI engine analyzes message patterns and identifies genuine opportunities while "
            "filtering out scams and pump-and-dump schemes. Multiple security checkpoints verify "
            "token legitimacy before any auto-snipe occurs."
        )
    
    elif command == "trackwallet":
        help_text = (
            "*👛 TRACKWALLET - Whale Monitoring System*\n\n"
            "Track any wallet for real-time transaction alerts and pattern analysis.\n\n"
            "*Usage:* `/trackwallet <wallet_address> [options]`\n\n"
            "*Options:*\n"
            "• `name=<alias>` - Custom name for the wallet\n"
            "• `min=<amount>` - Minimum transaction value to alert\n"
            "• `notify=all|buy|sell` - Transaction types to notify\n"
            "• `copy=yes|no` - Enable trade copying\n"
            "• `copylimit=<amount>` - Maximum amount for copy trades\n\n"
            "*Examples:*\n"
            "• `/trackwallet DtdyJcRYYfYMaUmY6WEJ44f3x6DDhkzMVGBFcAjeXvne`\n"
            "• `/trackwallet DtdyJcRYYfYMaUmY6WEJ44f3x6DDhkzMVGBFcAjeXvne name=WhaleTrader1 min=5 notify=buy copy=yes copylimit=0.2`\n\n"
            "Our system monitors blockchain activity 24/7 with <1 second latency for near-instant alerts on "
            "high-value transactions. AI pattern recognition identifies accumulation and distribution phases."
        )
    
    elif command == "autosnipe":
        help_text = (
            "*⚡ AUTOSNIPE - Automated Trading Strategies*\n\n"
            "Configure advanced auto-sniping rules and strategies for passive income generation.\n\n"
            "*Usage:* `/autosnipe <action> [options]`\n\n"
            "*Actions:*\n"
            "• `set` - Configure auto-sniping parameters\n"
            "• `list` - Show current auto-snipe settings\n"
            "• `pause` - Temporarily pause all auto-sniping\n"
            "• `resume` - Resume auto-sniping activities\n\n"
            "*Options for 'set':*\n"
            "• `amount=<value>` - Amount per auto-snipe\n"
            "• `maxdaily=<value>` - Maximum daily spending\n"
            "• `minscore=<0-10>` - Minimum safety score\n"
            "• `minliquidity=<amount>` - Minimum liquidity requirement\n"
            "• `takeproft=<percent>` - Auto take-profit percentage\n"
            "• `stoploss=<percent>` - Auto stop-loss percentage\n\n"
            "*Examples:*\n"
            "• `/autosnipe set amount=0.1 maxdaily=0.5 minscore=7 minliquidity=5`\n"
            "• `/autosnipe list`\n\n"
            "Our proprietary multi-factor algorithm evaluates dozens of parameters before executing "
            "any auto-snipe transaction, including token contract analysis, trade volume patterns, "
            "social sentiment, and market trend correlation."
        )
    
    elif command == "generateprememe":
        templates = ", ".join(MEME_TEMPLATES)
        help_text = (
            "*🎨 GENERATEPREMEME - Viral Marketing Tool*\n\n"
            "Generate high-quality crypto memes for viral marketing of your tokens.\n\n"
            "*Usage:* `/generateprememe <token_address> [options]`\n\n"
            "*Options:*\n"
            f"• `template=<n>` - Select template ({templates})\n"
            "• `top=<text>` - Top text for the meme\n"
            "• `bottom=<text>` - Bottom text for the meme\n"
            "• `style=bullish|bearish|neutral` - Emotional tone\n"
            "• `share=twitter|telegram` - Auto-share option\n\n"
            "*Examples:*\n"
            "• `/generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu`\n"
            "• `/generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu template=moon_lambo top=\"When your token\" bottom=\"goes 100x\" share=telegram`\n\n"
            "Our advanced AI system automatically incorporates token price data, logo, and performance metrics "
            "into professionally designed templates with viral-optimized captions."
        )
    
    elif command == "settings":
        help_text = (
            "*⚙️ SETTINGS - Advanced Configuration*\n\n"
            "Configure advanced bot settings for personalized trading experience.\n\n"
            "*Usage:* `/settings <section> [options]`\n\n"
            "*Sections:*\n"
            "• `trading` - Trading parameters\n"
            "• `notifications` - Alert preferences\n"
            "• `security` - Security settings\n"
            "• `display` - UI preferences\n"
            "• `backup` - Backup/restore settings\n\n"
            "*Examples:*\n"
            "• `/settings trading defaultamount=0.2 defaultslippage=1`\n"
            "• `/settings notifications alertsounds=on pricechanges=5`\n"
            "• `/settings security confirmation=high trustedtokens=list`\n\n"
            "The settings panel gives you granular control over every aspect of the bot's operation, "
            "from trade execution parameters to notification thresholds and security verification levels."
        )
    
    else:
        # Unknown command
        help_text = (
            "❓ *Unknown Command*\n\n"
            f"Sorry, I don't have specific help for '/{command}'.\n"
            "Try `/help` for a list of all available commands."
        )
    
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def handle_help_simple(bot, chat_id, params):
    """
    Process the help command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # Check if a specific command was requested
    if params and len(params) > 0:
        command = params[0].lower().strip('/')
        await send_specific_help_simple(bot, chat_id, command)
        return
    
    # If no specific command, send general help
    help_text = (
        "🤖 *SMART MEMES BOT Help Center* 🚀\n\n"
        "I'm your advanced crypto trading and monitoring assistant designed for serious traders.\n\n"
        "*Available Commands:*\n"
        "• /tokeninfo <address> - Advanced token analytics and safety analysis\n"
        "• /manualsnipe <address> <amount> - Execute precision trades with custom parameters\n"
        "• /sniper <address> <amount> - Super-reliable simplified token sniping\n"
        "• /watchgroup <link> - Monitor groups with AI-powered token detection\n"
        "• /trackwallet <address> - Set up real-time whale wallet monitoring\n"
        "• /autosnipe set <params> - Configure automated trading strategies\n"
        "• /generateprememe <token> - Create viral-ready memes for tokens\n"
        "• /settings - Access advanced trading configuration\n\n"
        "For detailed help on any command, use /help <command>.\n\n"
        "🔐 *Security Guarantee:* All transactions secured with multi-layered verification and real-time monitoring."
    )
    
    await bot.send_message(chat_id, help_text, parse_mode="Markdown")

async def send_specific_help_simple(bot, chat_id, command):
    """
    Send help information for a specific command using the simplified bot.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        command: The command to provide help for
    """
    if command == "tokeninfo":
        help_text = (
            "*📊 TOKENINFO - Advanced Token Analytics*\n\n"
            "Perform comprehensive token analysis with real-time data from multiple sources.\n\n"
            "*Usage:* `/tokeninfo <token_address> [options]`\n\n"
            "*Options:*\n"
            "• `detailed=yes` - Full blockchain analytics report\n"
            "• `holders=yes` - Show top wallet concentration\n"
            "• `history=<days>` - Price history (1-30 days)\n\n"
            "*Examples:*\n"
            "• `/tokeninfo Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu`\n"
            "• `/tokeninfo Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu detailed=yes history=7`\n\n"
            "The analysis includes liquidity depth, holder distribution, transaction velocity, mint authority status, "
            "contract verification, hidden backdoor detection, and cross-reference with known scams."
        )
    
    elif command == "manualsnipe":
        help_text = (
            "*🎯 MANUALSNIPE - Precision Trading*\n\n"
            "Execute high-precision trades with advanced parameters for maximum profit potential.\n\n"
            "*Usage:* `/manualsnipe <token_address> <amount> [options]`\n\n"
            "*Options:*\n"
            f"• `amount=<value>` - Amount to spend (max: {MAX_SPEND} SOL)\n"
            f"• `slippage=<percent>` - Custom slippage (default: {DEFAULT_SLIPPAGE}%)\n"
            "• `gas=low|medium|high|rapid` - Transaction priority\n"
            "• `autosell=<percent>` - Set take-profit level\n"
            "• `stoploss=<percent>` - Set stop-loss level\n\n"
            "*Examples:*\n"
            "• `/manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5`\n"
            "• `/manualsnipe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu amount=0.5 slippage=1 gas=high autosell=200 stoploss=50`\n\n"
            "The system automatically performs pre-trade contract analysis and verifies liquidity levels "
            "before execution to protect against honeypots and rug pulls."
        )
    
    elif command == "sniper":
        help_text = (
            "*🚀 SNIPER - Ultra-Reliable Token Sniping*\n\n"
            "Execute high-speed token purchases with bulletproof reliability and safety checks.\n\n"
            "*Usage:* `/sniper <token_address> <amount>`\n\n"
            "*Features:*\n"
            "• Simplified command structure for fast execution\n"
            "• Enhanced reliability with multiple RPC fallbacks\n"
            "• Automatic safety analysis before purchase\n"
            "• Built-in liquidity verification\n"
            f"• Maximum spending limit of {MAX_SPEND} SOL per transaction\n"
            f"• Default slippage of {DEFAULT_SLIPPAGE}% for optimal execution\n\n"
            "*Examples:*\n"
            "• `/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5`\n\n"
            "This command uses our next-generation direct API implementation with enhanced error handling "
            "and multi-layered safety checks to provide the most reliable sniping experience possible."
        )
    
    elif command == "watchgroup":
        help_text = (
            "*👁️ WATCHGROUP - AI-Powered Group Monitoring*\n\n"
            "Monitor Telegram groups for token mentions with intelligent filtering and auto-sniping.\n\n"
            "*Usage:* `/watchgroup <group_link> [options]`\n\n"
            "*Options:*\n"
            "• `auto=yes|no` - Enable auto-sniping (default: no)\n"
            "• `min=<number>` - Minimum mentions threshold\n"
            "• `amount=<value>` - Amount to use for auto-sniping\n"
            "• `delay=<seconds>` - Delay before sniping\n"
            "• `filter=high|medium|low` - Safety filter level\n\n"
            "*Examples:*\n"
            "• `/watchgroup t.me/cryptogems`\n"
            "• `/watchgroup t.me/cryptogems auto=yes min=5 amount=0.2 filter=high`\n\n"
            "Our AI engine analyzes message patterns and identifies genuine opportunities while "
            "filtering out scams and pump-and-dump schemes. Multiple security checkpoints verify "
            "token legitimacy before any auto-snipe occurs."
        )
    
    elif command == "trackwallet":
        help_text = (
            "*👛 TRACKWALLET - Whale Monitoring System*\n\n"
            "Track any wallet for real-time transaction alerts and pattern analysis.\n\n"
            "*Usage:* `/trackwallet <wallet_address> [options]`\n\n"
            "*Options:*\n"
            "• `name=<alias>` - Custom name for the wallet\n"
            "• `min=<amount>` - Minimum transaction value to alert\n"
            "• `notify=all|buy|sell` - Transaction types to notify\n"
            "• `copy=yes|no` - Enable trade copying\n"
            "• `copylimit=<amount>` - Maximum amount for copy trades\n\n"
            "*Examples:*\n"
            "• `/trackwallet DtdyJcRYYfYMaUmY6WEJ44f3x6DDhkzMVGBFcAjeXvne`\n"
            "• `/trackwallet DtdyJcRYYfYMaUmY6WEJ44f3x6DDhkzMVGBFcAjeXvne name=WhaleTrader1 min=5 notify=buy copy=yes copylimit=0.2`\n\n"
            "Our system monitors blockchain activity 24/7 with <1 second latency for near-instant alerts on "
            "high-value transactions. AI pattern recognition identifies accumulation and distribution phases."
        )
    
    elif command == "autosnipe":
        help_text = (
            "*⚡ AUTOSNIPE - Automated Trading Strategies*\n\n"
            "Configure advanced auto-sniping rules and strategies for passive income generation.\n\n"
            "*Usage:* `/autosnipe <action> [options]`\n\n"
            "*Actions:*\n"
            "• `set` - Configure auto-sniping parameters\n"
            "• `list` - Show current auto-snipe settings\n"
            "• `pause` - Temporarily pause all auto-sniping\n"
            "• `resume` - Resume auto-sniping activities\n\n"
            "*Options for 'set':*\n"
            "• `amount=<value>` - Amount per auto-snipe\n"
            "• `maxdaily=<value>` - Maximum daily spending\n"
            "• `minscore=<0-10>` - Minimum safety score\n"
            "• `minliquidity=<amount>` - Minimum liquidity requirement\n"
            "• `takeproft=<percent>` - Auto take-profit percentage\n"
            "• `stoploss=<percent>` - Auto stop-loss percentage\n\n"
            "*Examples:*\n"
            "• `/autosnipe set amount=0.1 maxdaily=0.5 minscore=7 minliquidity=5`\n"
            "• `/autosnipe list`\n\n"
            "Our proprietary multi-factor algorithm evaluates dozens of parameters before executing "
            "any auto-snipe transaction, including token contract analysis, trade volume patterns, "
            "social sentiment, and market trend correlation."
        )
    
    elif command == "generateprememe":
        templates = ", ".join(MEME_TEMPLATES)
        help_text = (
            "*🎨 GENERATEPREMEME - Viral Marketing Tool*\n\n"
            "Generate high-quality crypto memes for viral marketing of your tokens.\n\n"
            "*Usage:* `/generateprememe <token_address> [options]`\n\n"
            "*Options:*\n"
            f"• `template=<n>` - Select template ({templates})\n"
            "• `top=<text>` - Top text for the meme\n"
            "• `bottom=<text>` - Bottom text for the meme\n"
            "• `style=bullish|bearish|neutral` - Emotional tone\n"
            "• `share=twitter|telegram` - Auto-share option\n\n"
            "*Examples:*\n"
            "• `/generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu`\n"
            "• `/generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu template=moon_lambo top=\"When your token\" bottom=\"goes 100x\" share=telegram`\n\n"
            "Our advanced AI system automatically incorporates token price data, logo, and performance metrics "
            "into professionally designed templates with viral-optimized captions."
        )
    
    elif command == "settings":
        help_text = (
            "*⚙️ SETTINGS - Advanced Configuration*\n\n"
            "Configure advanced bot settings for personalized trading experience.\n\n"
            "*Usage:* `/settings <section> [options]`\n\n"
            "*Sections:*\n"
            "• `trading` - Trading parameters\n"
            "• `notifications` - Alert preferences\n"
            "• `security` - Security settings\n"
            "• `display` - UI preferences\n"
            "• `backup` - Backup/restore settings\n\n"
            "*Examples:*\n"
            "• `/settings trading defaultamount=0.2 defaultslippage=1`\n"
            "• `/settings notifications alertsounds=on pricechanges=5`\n"
            "• `/settings security confirmation=high trustedtokens=list`\n\n"
            "The settings panel gives you granular control over every aspect of the bot's operation, "
            "from trade execution parameters to notification thresholds and security verification levels."
        )
    
    else:
        # Unknown command
        help_text = (
            "❓ *Unknown Command*\n\n"
            f"Sorry, I don't have specific help for '/{command}'.\n"
            "Try `/help` for a list of all available commands."
        )
    
    await bot.send_message(chat_id, help_text, parse_mode="Markdown")