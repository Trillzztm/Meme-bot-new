"""
Enhanced token sniping handler for SMART MEMES BOT.

This module provides a more reliable token sniping implementation with:
1. Advanced safety checks
2. Multi-endpoint trade execution with retry logic
3. Auto-sell functionality based on profit targets
4. Stop-loss protection
5. Detailed transaction tracking
"""

import re
import asyncio
import logging
from typing import Dict, Any, List, Optional, Tuple
import time

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_analyzer import is_valid_token_address
from handlers.advanced_safety import analyze_token
from utils.enhanced_solana_trade import execute_trade
from utils.solana_utils import transfer_sol, get_wallet_balance
from utils.pricing import get_token_price, get_price_change
from database import record_snipe_transaction, update_snipe_status
from config import DEFAULT_SLIPPAGE, MAX_SPEND

# Constants
DEFAULT_AUTO_SELL_PERCENT = 200  # Default auto-sell at 2x (200% of initial price)
DEFAULT_STOP_LOSS_PERCENT = 50   # Default stop-loss at 50% of initial price
PRICE_CHECK_INTERVAL = 60        # Check price every 60 seconds for auto-sell/stop-loss

async def sniper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /sniper command - Enhanced token sniping with safety checks.
    
    Command format:
    /sniper <token_address> <amount_in_sol> [autosell=X] [stoploss=Y] [track=yes/no]
    
    Examples:
    /sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.1
    /sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 autosell=200 stoploss=50 track=yes
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Call the common handler
    await handle_sniper(update, context)

async def handle_sniper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the sniper command logic for both standard and simplified bot implementations.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Check for arguments
        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "🎯 *SNIPER Command Usage*\n\n"
                "The sniper command allows you to buy tokens with enhanced reliability and safety.\n\n"
                "*Required parameters:*\n"
                "• `token_address` - The token's address\n"
                "• `amount` - Amount in SOL to spend\n\n"
                "*Optional parameters:*\n"
                "• `autosell=X` - Automatically sell when profit reaches X% (default: disabled)\n"
                "• `stoploss=Y` - Automatically sell when loss reaches Y% (default: disabled)\n"
                "• `track=yes/no` - Track token price after purchase (default: no)\n\n"
                "*Examples:*\n"
                "/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.1\n"
                "/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 autosell=200 stoploss=50 track=yes",
                parse_mode="Markdown"
            )
            return
        
        # Get token address and amount
        token_address = context.args[0]
        
        # Validate token address
        if not is_valid_token_address(token_address):
            await update.message.reply_text(
                "❌ Invalid token address format. Please provide a valid Solana token address."
            )
            return
            
        # Parse amount
        try:
            amount = float(context.args[1])
            if amount <= 0:
                raise ValueError("Amount must be positive")
                
            if amount > MAX_SPEND:
                await update.message.reply_text(
                    f"⚠️ Amount {amount} SOL exceeds maximum ({MAX_SPEND} SOL). "
                    f"Setting to {MAX_SPEND} SOL."
                )
                amount = MAX_SPEND
                
        except ValueError as e:
            await update.message.reply_text(
                f"❌ Invalid amount: {context.args[1]}. Please provide a valid number."
            )
            return
            
        # Parse optional parameters
        auto_sell = None
        stop_loss = None
        track_price = False
        slippage = DEFAULT_SLIPPAGE
        
        for arg in context.args[2:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                key = key.lower()
                
                if key == "autosell":
                    try:
                        auto_sell = float(value)
                        if auto_sell <= 100:
                            await update.message.reply_text(
                                f"⚠️ Auto-sell value {auto_sell}% is below 100% (break-even). "
                                "You might want to increase this value."
                            )
                    except ValueError:
                        await update.message.reply_text(f"Invalid auto-sell value: {value}. Ignoring.")
                        
                elif key == "stoploss":
                    try:
                        stop_loss = float(value)
                        if stop_loss < 1 or stop_loss > 99:
                            await update.message.reply_text(
                                f"⚠️ Stop-loss value {stop_loss}% is outside the recommended range (1-99%). "
                                "Setting to 50%."
                            )
                            stop_loss = 50
                    except ValueError:
                        await update.message.reply_text(f"Invalid stop-loss value: {value}. Ignoring.")
                        
                elif key == "track":
                    track_price = value.lower() in ["yes", "true", "y", "1"]
                    
                elif key == "slippage":
                    try:
                        slippage = float(value)
                        if slippage < 0.1 or slippage > 50:
                            await update.message.reply_text(
                                f"⚠️ Slippage value {slippage}% is outside the recommended range (0.1-50%). "
                                f"Setting to {DEFAULT_SLIPPAGE}%."
                            )
                            slippage = DEFAULT_SLIPPAGE
                    except ValueError:
                        await update.message.reply_text(f"Invalid slippage value: {value}. Using default {DEFAULT_SLIPPAGE}%.")
        
        # Get user ID for database tracking
        user_id = update.effective_user.id
        
        # Inform user we're proceeding
        progress_message = await update.message.reply_text(
            f"🔍 Analyzing token {token_address}..."
        )
        
        # Record transaction in database as "pending"
        try:
            from database import record_snipe_transaction
            transaction_id = record_snipe_transaction(
                telegram_id=user_id,
                token_address=token_address,
                amount_spent=amount,
                status="pending",
                slippage=slippage,
                is_auto=False
            )
        except Exception as db_error:
            logger.error(f"Error recording transaction: {db_error}")
            transaction_id = None
            
        try:
            # Step 1: Analyze token safety
            safety_score, summary, token_data = await analyze_token(token_address)
            
            # Update progress
            await progress_message.edit_text(
                f"🔍 Token analysis complete (Safety: {safety_score}/10)\n"
                f"⏳ Checking liquidity..."
            )
            
            # Step 2: Check liquidity (part of execute_trade)
            # This is now handled inside execute_trade for simplicity
            
            # Step 3: Execute the trade
            await progress_message.edit_text(
                f"🔍 Token analysis complete (Safety: {safety_score}/10)\n"
                f"⏳ Executing purchase transaction..."
            )
            
            # Perform the trade
            result = await execute_trade(token_address, amount, slippage)
            
            # Check if the trade was successful
            if result.get("success"):
                # Extract information from the result
                tx_hash = result.get("transaction_hash", "Unknown")
                tokens_received = result.get("tokens_received", 0)
                entry_price = result.get("price_per_token", 0)
                
                # Update transaction in database
                if transaction_id:
                    try:
                        update_snipe_status(
                            snipe_id=transaction_id,
                            status="completed",
                            tx_hash=tx_hash,
                            tokens_received=tokens_received,
                            current_price=entry_price
                        )
                    except Exception as update_error:
                        logger.error(f"Error updating transaction: {update_error}")
                
                # Format the success message
                token_name = token_data.get("name") or token_data.get("symbol") or token_address[:10] + "..."
                explorer_url = f"https://solscan.io/tx/{tx_hash}"
                
                success_message = (
                    f"✅ *Purchase Successful!*\n\n"
                    f"*Token:* `{token_name}`\n"
                    f"*Amount Spent:* {amount} SOL\n"
                    f"*Tokens Received:* {tokens_received:,.0f}\n"
                    f"*Entry Price:* ${entry_price:.10f}\n"
                    f"*Transaction:* [View on Explorer]({explorer_url})\n"
                )
                
                # Add auto-sell information if enabled
                if auto_sell is not None:
                    target_price = entry_price * (auto_sell / 100)
                    success_message += f"\n*Auto-sell:* Enabled @ ${target_price:.10f} (+{auto_sell-100:.0f}%)"
                    
                # Add stop-loss information if enabled
                if stop_loss is not None:
                    stop_price = entry_price * ((100 - stop_loss) / 100)
                    success_message += f"\n*Stop-loss:* Enabled @ ${stop_price:.10f} (-{stop_loss:.0f}%)"
                    
                # Add price tracking information if enabled
                if track_price:
                    success_message += f"\n*Price Tracking:* Enabled (every {PRICE_CHECK_INTERVAL}s)"
                
                # Send the success message
                await update.message.reply_text(
                    success_message,
                    parse_mode="Markdown",
                    disable_web_page_preview=True
                )
                
                # Clean up progress message
                await progress_message.delete()
                
                # Start price tracking if requested
                if auto_sell is not None or stop_loss is not None or track_price:
                    # Create and store a background task for price tracking
                    tracking_task = asyncio.create_task(
                        track_token_price(
                            update=update,
                            token_address=token_address,
                            token_name=token_name,
                            tokens_received=tokens_received,
                            entry_price=entry_price,
                            auto_sell_percent=auto_sell,
                            stop_loss_percent=stop_loss,
                            transaction_id=transaction_id
                        )
                    )
                    
                    # Store the task somewhere to prevent garbage collection
                    if not hasattr(context, "user_data"):
                        context.user_data = {}
                    
                    if "tracking_tasks" not in context.user_data:
                        context.user_data["tracking_tasks"] = []
                        
                    context.user_data["tracking_tasks"].append(tracking_task)
            else:
                # Trade failed
                error_message = result.get("error", "Unknown error")
                
                # Update transaction in database
                if transaction_id:
                    try:
                        update_snipe_status(
                            snipe_id=transaction_id,
                            status="failed",
                            error_message=error_message
                        )
                    except Exception as update_error:
                        logger.error(f"Error updating transaction: {update_error}")
                
                # Send error message
                await update.message.reply_text(
                    f"❌ Transaction failed: {error_message}\n\n"
                    f"Please make sure you have enough SOL for the purchase and gas fees."
                )
                
                # Clean up progress message
                await progress_message.delete()
                
        except Exception as e:
            logger.error(f"Error in sniper handler: {e}")
            
            # Update transaction in database
            if transaction_id:
                try:
                    update_snipe_status(
                        snipe_id=transaction_id,
                        status="failed",
                        error_message=str(e)
                    )
                except Exception as update_error:
                    logger.error(f"Error updating transaction: {update_error}")
            
            # Send error message
            await update.message.reply_text(
                f"❌ An error occurred: {str(e)}\n\n"
                "Please try again with a different token or amount."
            )
            
            # Clean up progress message if it exists
            try:
                await progress_message.delete()
            except:
                pass
            
    except Exception as e:
        logger.error(f"Unexpected error in sniper handler: {e}")
        await update.message.reply_text(
            f"❌ An unexpected error occurred: {str(e)}"
        )

async def track_token_price(
    update: Update,
    token_address: str,
    token_name: str,
    tokens_received: float,
    entry_price: float,
    auto_sell_percent: Optional[float] = None,
    stop_loss_percent: Optional[float] = None,
    transaction_id: Optional[int] = None,
    check_interval: int = PRICE_CHECK_INTERVAL
) -> None:
    """
    Background task to track token price and execute auto-sell/stop-loss.
    
    Args:
        update: The update object from Telegram
        token_address: The token address
        token_name: Human-readable token name
        tokens_received: Number of tokens received
        entry_price: Initial token price
        auto_sell_percent: Percentage of initial price to auto-sell at
        stop_loss_percent: Percentage of initial price to stop-loss at
        transaction_id: Database transaction ID
        check_interval: Seconds between price checks
    """
    try:
        chat_id = update.effective_message.chat_id
        check_count = 0
        last_notification = 0  # timestamp of last notification
        notification_interval = 300  # 5 minutes between notifications
        
        # Calculate target prices
        auto_sell_price = entry_price * (auto_sell_percent / 100) if auto_sell_percent else None
        stop_loss_price = entry_price * ((100 - stop_loss_percent) / 100) if stop_loss_percent else None
        
        # Log the tracking start
        logger.info(
            f"Started price tracking for {token_address}. "
            f"Entry: ${entry_price:.10f}, "
            f"Auto-sell: {'$' + str(auto_sell_price) if auto_sell_price else 'Disabled'}, "
            f"Stop-loss: {'$' + str(stop_loss_price) if stop_loss_price else 'Disabled'}"
        )
        
        while True:
            try:
                # Sleep between checks
                await asyncio.sleep(check_interval)
                
                # Get current token price
                # In a real implementation, this would query an API or blockchain
                # For now, we'll use a simplified approach
                try:
                    # Use token analyzer to get current price
                    _, _, token_data = await analyze_token(token_address)
                    current_price = token_data.get("market_data", {}).get("price")
                    
                    # Convert to float if it's a string
                    if isinstance(current_price, str):
                        current_price = float(current_price)
                        
                    # If we couldn't get a price, skip this check
                    if current_price is None:
                        logger.warning(f"Could not get current price for {token_address}")
                        continue
                        
                except Exception as price_error:
                    logger.error(f"Error getting price for {token_address}: {price_error}")
                    continue
                
                # Calculate current value and profit/loss
                current_value = tokens_received * current_price
                profit_loss_percent = ((current_price / entry_price) * 100) - 100
                
                # Update transaction in database
                if transaction_id:
                    try:
                        update_snipe_status(
                            snipe_id=transaction_id,
                            status="tracking",
                            current_price=current_price,
                            current_value=current_value,
                            profit_loss=profit_loss_percent
                        )
                    except Exception as update_error:
                        logger.error(f"Error updating transaction: {update_error}")
                
                # Check for auto-sell condition
                if auto_sell_price and current_price >= auto_sell_price:
                    # Auto-sell triggered!
                    message = (
                        f"🚀 *AUTO-SELL TRIGGERED* 🚀\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Target:* ${auto_sell_price:.10f} (+{auto_sell_percent-100:.0f}%)\n"
                        f"*Current:* ${current_price:.10f} (+{profit_loss_percent:.2f}%)\n"
                        f"*Value:* ${current_value:.2f}\n\n"
                        f"Executing sell transaction...\n\n"
                        f"(Not implemented in this example)"
                    )
                    
                    await update.effective_message.reply_text(
                        message,
                        parse_mode="Markdown"
                    )
                    
                    # In a real implementation, this would execute a sell transaction
                    # For now, we'll just log it
                    logger.info(f"Auto-sell triggered for {token_address} at ${current_price:.10f}")
                    
                    # End tracking
                    return
                    
                # Check for stop-loss condition
                if stop_loss_price and current_price <= stop_loss_price:
                    # Stop-loss triggered!
                    message = (
                        f"🔴 *STOP-LOSS TRIGGERED* 🔴\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Threshold:* ${stop_loss_price:.10f} (-{stop_loss_percent:.0f}%)\n"
                        f"*Current:* ${current_price:.10f} ({profit_loss_percent:.2f}%)\n"
                        f"*Value:* ${current_value:.2f}\n\n"
                        f"Executing sell transaction...\n\n"
                        f"(Not implemented in this example)"
                    )
                    
                    await update.effective_message.reply_text(
                        message,
                        parse_mode="Markdown"
                    )
                    
                    # In a real implementation, this would execute a sell transaction
                    # For now, we'll just log it
                    logger.info(f"Stop-loss triggered for {token_address} at ${current_price:.10f}")
                    
                    # End tracking
                    return
                
                # Periodic price updates (every 5 minutes)
                now = time.time()
                if (now - last_notification) >= notification_interval:
                    # Send a price update
                    message = (
                        f"📊 *PRICE UPDATE* 📊\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Entry:* ${entry_price:.10f}\n"
                        f"*Current:* ${current_price:.10f} ({profit_loss_percent:+.2f}%)\n"
                        f"*Value:* ${current_value:.2f}"
                    )
                    
                    # Add auto-sell/stop-loss info if enabled
                    if auto_sell_price:
                        auto_sell_diff = ((auto_sell_price - current_price) / current_price) * 100
                        message += f"\n*Auto-sell:* ${auto_sell_price:.10f} ({auto_sell_diff:.2f}% away)"
                        
                    if stop_loss_price:
                        stop_loss_diff = ((current_price - stop_loss_price) / current_price) * 100
                        message += f"\n*Stop-loss:* ${stop_loss_price:.10f} ({stop_loss_diff:.2f}% away)"
                    
                    await update.effective_message.reply_text(
                        message,
                        parse_mode="Markdown"
                    )
                    
                    # Update last notification time
                    last_notification = now
                
                # Increment check count
                check_count += 1
                
                # Optional: End tracking after a certain number of checks
                # if check_count >= MAX_CHECKS:
                #     logger.info(f"Ending price tracking for {token_address} after {check_count} checks")
                #     return
                
            except asyncio.CancelledError:
                logger.info(f"Price tracking for {token_address} was cancelled")
                return
                
            except Exception as e:
                logger.error(f"Error in price tracking for {token_address}: {e}")
                # Continue tracking despite errors
        
    except Exception as e:
        logger.error(f"Fatal error in price tracking for {token_address}: {e}")

async def handle_sniper_simple(bot, chat_id, params):
    """
    Process the sniper command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    try:
        # Check for arguments
        if not params or len(params) < 2:
            bot.send_message(
                chat_id,
                "🎯 *SNIPER Command Usage*\n\n"
                "The sniper command allows you to buy tokens with enhanced reliability and safety.\n\n"
                "*Required parameters:*\n"
                "• `token_address` - The token's address\n"
                "• `amount` - Amount in SOL to spend\n\n"
                "*Optional parameters:*\n"
                "• `autosell=X` - Automatically sell when profit reaches X% (default: disabled)\n"
                "• `stoploss=Y` - Automatically sell when loss reaches Y% (default: disabled)\n"
                "• `track=yes/no` - Track token price after purchase (default: no)\n\n"
                "*Examples:*\n"
                "/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.1\n"
                "/sniper Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 autosell=200 stoploss=50 track=yes",
                parse_mode="Markdown"
            )
            return
        
        # Get token address and amount
        token_address = params[0]
        
        # Validate token address
        if not is_valid_token_address(token_address):
            bot.send_message(
                chat_id,
                "❌ Invalid token address format. Please provide a valid Solana token address."
            )
            return
            
        # Parse amount
        try:
            amount = float(params[1])
            if amount <= 0:
                raise ValueError("Amount must be positive")
                
            if amount > MAX_SPEND:
                bot.send_message(
                    chat_id,
                    f"⚠️ Amount {amount} SOL exceeds maximum ({MAX_SPEND} SOL). "
                    f"Setting to {MAX_SPEND} SOL."
                )
                amount = MAX_SPEND
                
        except ValueError as e:
            bot.send_message(
                chat_id,
                f"❌ Invalid amount: {params[1]}. Please provide a valid number."
            )
            return
            
        # Parse optional parameters
        auto_sell = None
        stop_loss = None
        track_price = False
        slippage = DEFAULT_SLIPPAGE
        
        for arg in params[2:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                key = key.lower()
                
                if key == "autosell":
                    try:
                        auto_sell = float(value)
                        if auto_sell <= 100:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Auto-sell value {auto_sell}% is below 100% (break-even). "
                                "You might want to increase this value."
                            )
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid auto-sell value: {value}. Ignoring.")
                        
                elif key == "stoploss":
                    try:
                        stop_loss = float(value)
                        if stop_loss < 1 or stop_loss > 99:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Stop-loss value {stop_loss}% is outside the recommended range (1-99%). "
                                "Setting to 50%."
                            )
                            stop_loss = 50
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid stop-loss value: {value}. Ignoring.")
                        
                elif key == "track":
                    track_price = value.lower() in ["yes", "true", "y", "1"]
                    
                elif key == "slippage":
                    try:
                        slippage = float(value)
                        if slippage < 0.1 or slippage > 50:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Slippage value {slippage}% is outside the recommended range (0.1-50%). "
                                f"Setting to {DEFAULT_SLIPPAGE}%."
                            )
                            slippage = DEFAULT_SLIPPAGE
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid slippage value: {value}. Using default {DEFAULT_SLIPPAGE}%.")
        
        # For simplified bot, we have to use a different approach for background tasks
        # since we don't have the Update/Context objects
        
        # Inform user we're proceeding
        progress_message = bot.send_message(
            chat_id,
            f"🔍 Analyzing token {token_address}..."
        )
        progress_message_id = progress_message["message_id"]
        
        # Record transaction in database as "pending"
        try:
            from database import record_snipe_transaction
            transaction_id = record_snipe_transaction(
                telegram_id=chat_id,
                token_address=token_address,
                amount_spent=amount,
                status="pending",
                slippage=slippage,
                is_auto=False
            )
        except Exception as db_error:
            logger.error(f"Error recording transaction: {db_error}")
            transaction_id = None
            
        # Execute this in a background task
        asyncio.create_task(
            execute_sniper_simple_background(
                bot=bot,
                chat_id=chat_id,
                token_address=token_address,
                amount=amount,
                slippage=slippage,
                auto_sell=auto_sell,
                stop_loss=stop_loss,
                track_price=track_price,
                transaction_id=transaction_id,
                progress_message_id=progress_message_id
            )
        )
        
    except Exception as e:
        logger.error(f"Error in sniper simple handler: {e}")
        bot.send_message(
            chat_id,
            f"❌ An unexpected error occurred: {str(e)}"
        )

async def execute_sniper_simple_background(
    bot, chat_id, token_address, amount, slippage,
    auto_sell, stop_loss, track_price, transaction_id, progress_message_id
):
    """
    Execute the sniper operation in a background task for the simplified bot.
    
    This handles the asynchronous parts of the sniper command for the simplified bot implementation.
    """
    try:
        # Step 1: Analyze token safety
        safety_score, summary, token_data = await analyze_token(token_address)
        
        # Update progress
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=progress_message_id,
            text=f"🔍 Token analysis complete (Safety: {safety_score}/10)\n"
                 f"⏳ Checking liquidity..."
        )
        
        # Step 2: Check liquidity (part of execute_trade)
        # This is now handled inside execute_trade for simplicity
        
        # Step 3: Execute the trade
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=progress_message_id,
            text=f"🔍 Token analysis complete (Safety: {safety_score}/10)\n"
                 f"⏳ Executing purchase transaction..."
        )
        
        # Perform the trade
        result = await execute_trade(token_address, amount, slippage)
        
        # Check if the trade was successful
        if result.get("success"):
            # Extract information from the result
            tx_hash = result.get("transaction_hash", "Unknown")
            tokens_received = result.get("tokens_received", 0)
            entry_price = result.get("price_per_token", 0)
            
            # Update transaction in database
            if transaction_id:
                try:
                    update_snipe_status(
                        snipe_id=transaction_id,
                        status="completed",
                        tx_hash=tx_hash,
                        tokens_received=tokens_received,
                        current_price=entry_price
                    )
                except Exception as update_error:
                    logger.error(f"Error updating transaction: {update_error}")
            
            # Format the success message
            token_name = token_data.get("name") or token_data.get("symbol") or token_address[:10] + "..."
            explorer_url = f"https://solscan.io/tx/{tx_hash}"
            
            success_message = (
                f"✅ *Purchase Successful!*\n\n"
                f"*Token:* `{token_name}`\n"
                f"*Amount Spent:* {amount} SOL\n"
                f"*Tokens Received:* {tokens_received:,.0f}\n"
                f"*Entry Price:* ${entry_price:.10f}\n"
                f"*Transaction:* [View on Explorer]({explorer_url})\n"
            )
            
            # Add auto-sell information if enabled
            if auto_sell is not None:
                target_price = entry_price * (auto_sell / 100)
                success_message += f"\n*Auto-sell:* Enabled @ ${target_price:.10f} (+{auto_sell-100:.0f}%)"
                
            # Add stop-loss information if enabled
            if stop_loss is not None:
                stop_price = entry_price * ((100 - stop_loss) / 100)
                success_message += f"\n*Stop-loss:* Enabled @ ${stop_price:.10f} (-{stop_loss:.0f}%)"
                
            # Add price tracking information if enabled
            if track_price:
                success_message += f"\n*Price Tracking:* Enabled (every {PRICE_CHECK_INTERVAL}s)"
            
            # Send the success message
            bot.send_message(
                chat_id=chat_id,
                text=success_message,
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
            
            # Delete the progress message
            try:
                bot.delete_message(
                    chat_id=chat_id,
                    message_id=progress_message_id
                )
            except:
                pass
            
            # Start price tracking if requested
            if auto_sell is not None or stop_loss is not None or track_price:
                # Start tracking in a background task
                asyncio.create_task(
                    track_token_price_simple(
                        bot=bot,
                        chat_id=chat_id,
                        token_address=token_address,
                        token_name=token_name,
                        tokens_received=tokens_received,
                        entry_price=entry_price,
                        auto_sell_percent=auto_sell,
                        stop_loss_percent=stop_loss,
                        transaction_id=transaction_id
                    )
                )
        else:
            # Trade failed
            error_message = result.get("error", "Unknown error")
            
            # Update transaction in database
            if transaction_id:
                try:
                    update_snipe_status(
                        snipe_id=transaction_id,
                        status="failed",
                        error_message=error_message
                    )
                except Exception as update_error:
                    logger.error(f"Error updating transaction: {update_error}")
            
            # Send error message
            bot.send_message(
                chat_id=chat_id,
                text=f"❌ Transaction failed: {error_message}\n\n"
                     f"Please make sure you have enough SOL for the purchase and gas fees."
            )
            
            # Delete the progress message
            try:
                bot.delete_message(
                    chat_id=chat_id,
                    message_id=progress_message_id
                )
            except:
                pass
            
    except Exception as e:
        logger.error(f"Error in sniper background task: {e}")
        
        # Update transaction in database
        if transaction_id:
            try:
                update_snipe_status(
                    snipe_id=transaction_id,
                    status="failed",
                    error_message=str(e)
                )
            except Exception as update_error:
                logger.error(f"Error updating transaction: {update_error}")
        
        # Send error message
        bot.send_message(
            chat_id=chat_id,
            text=f"❌ An error occurred: {str(e)}\n\n"
                 "Please try again with a different token or amount."
        )
        
        # Delete the progress message
        try:
            bot.delete_message(
                chat_id=chat_id,
                message_id=progress_message_id
            )
        except:
            pass

async def track_token_price_simple(
    bot, chat_id, token_address, token_name, tokens_received, entry_price,
    auto_sell_percent=None, stop_loss_percent=None, transaction_id=None,
    check_interval=PRICE_CHECK_INTERVAL
):
    """
    Simplified version of price tracking for the basic bot.
    
    This is similar to track_token_price but works with the simplified bot implementation.
    """
    try:
        check_count = 0
        last_notification = 0  # timestamp of last notification
        notification_interval = 300  # 5 minutes between notifications
        
        # Calculate target prices
        auto_sell_price = entry_price * (auto_sell_percent / 100) if auto_sell_percent else None
        stop_loss_price = entry_price * ((100 - stop_loss_percent) / 100) if stop_loss_percent else None
        
        # Log the tracking start
        logger.info(
            f"Started price tracking for {token_address}. "
            f"Entry: ${entry_price:.10f}, "
            f"Auto-sell: {'$' + str(auto_sell_price) if auto_sell_price else 'Disabled'}, "
            f"Stop-loss: {'$' + str(stop_loss_price) if stop_loss_price else 'Disabled'}"
        )
        
        while True:
            try:
                # Sleep between checks
                await asyncio.sleep(check_interval)
                
                # Get current token price
                # In a real implementation, this would query an API or blockchain
                # For now, we'll use a simplified approach
                try:
                    # Use token analyzer to get current price
                    _, _, token_data = await analyze_token(token_address)
                    current_price = token_data.get("market_data", {}).get("price")
                    
                    # Convert to float if it's a string
                    if isinstance(current_price, str):
                        current_price = float(current_price)
                        
                    # If we couldn't get a price, skip this check
                    if current_price is None:
                        logger.warning(f"Could not get current price for {token_address}")
                        continue
                        
                except Exception as price_error:
                    logger.error(f"Error getting price for {token_address}: {price_error}")
                    continue
                
                # Calculate current value and profit/loss
                current_value = tokens_received * current_price
                profit_loss_percent = ((current_price / entry_price) * 100) - 100
                
                # Update transaction in database
                if transaction_id:
                    try:
                        update_snipe_status(
                            snipe_id=transaction_id,
                            status="tracking",
                            current_price=current_price,
                            current_value=current_value,
                            profit_loss=profit_loss_percent
                        )
                    except Exception as update_error:
                        logger.error(f"Error updating transaction: {update_error}")
                
                # Check for auto-sell condition
                if auto_sell_price and current_price >= auto_sell_price:
                    # Auto-sell triggered!
                    message = (
                        f"🚀 *AUTO-SELL TRIGGERED* 🚀\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Target:* ${auto_sell_price:.10f} (+{auto_sell_percent-100:.0f}%)\n"
                        f"*Current:* ${current_price:.10f} (+{profit_loss_percent:.2f}%)\n"
                        f"*Value:* ${current_value:.2f}\n\n"
                        f"Executing sell transaction...\n\n"
                        f"(Not implemented in this example)"
                    )
                    
                    bot.send_message(
                        chat_id=chat_id,
                        text=message,
                        parse_mode="Markdown"
                    )
                    
                    # In a real implementation, this would execute a sell transaction
                    # For now, we'll just log it
                    logger.info(f"Auto-sell triggered for {token_address} at ${current_price:.10f}")
                    
                    # End tracking
                    return
                    
                # Check for stop-loss condition
                if stop_loss_price and current_price <= stop_loss_price:
                    # Stop-loss triggered!
                    message = (
                        f"🔴 *STOP-LOSS TRIGGERED* 🔴\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Threshold:* ${stop_loss_price:.10f} (-{stop_loss_percent:.0f}%)\n"
                        f"*Current:* ${current_price:.10f} ({profit_loss_percent:.2f}%)\n"
                        f"*Value:* ${current_value:.2f}\n\n"
                        f"Executing sell transaction...\n\n"
                        f"(Not implemented in this example)"
                    )
                    
                    bot.send_message(
                        chat_id=chat_id,
                        text=message,
                        parse_mode="Markdown"
                    )
                    
                    # In a real implementation, this would execute a sell transaction
                    # For now, we'll just log it
                    logger.info(f"Stop-loss triggered for {token_address} at ${current_price:.10f}")
                    
                    # End tracking
                    return
                
                # Periodic price updates (every 5 minutes)
                now = time.time()
                if (now - last_notification) >= notification_interval:
                    # Send a price update
                    message = (
                        f"📊 *PRICE UPDATE* 📊\n\n"
                        f"*Token:* `{token_name}`\n"
                        f"*Entry:* ${entry_price:.10f}\n"
                        f"*Current:* ${current_price:.10f} ({profit_loss_percent:+.2f}%)\n"
                        f"*Value:* ${current_value:.2f}"
                    )
                    
                    # Add auto-sell/stop-loss info if enabled
                    if auto_sell_price:
                        auto_sell_diff = ((auto_sell_price - current_price) / current_price) * 100
                        message += f"\n*Auto-sell:* ${auto_sell_price:.10f} ({auto_sell_diff:.2f}% away)"
                        
                    if stop_loss_price:
                        stop_loss_diff = ((current_price - stop_loss_price) / current_price) * 100
                        message += f"\n*Stop-loss:* ${stop_loss_price:.10f} ({stop_loss_diff:.2f}% away)"
                    
                    bot.send_message(
                        chat_id=chat_id,
                        text=message,
                        parse_mode="Markdown"
                    )
                    
                    # Update last notification time
                    last_notification = now
                
                # Increment check count
                check_count += 1
                
            except asyncio.CancelledError:
                logger.info(f"Price tracking for {token_address} was cancelled")
                return
                
            except Exception as e:
                logger.error(f"Error in price tracking for {token_address}: {e}")
                # Continue tracking despite errors
        
    except Exception as e:
        logger.error(f"Fatal error in price tracking for {token_address}: {e}")

# Example usage
def example():
    # This is just for demonstration purposes
    # In a real implementation, this would be called by the bot framework
    pass