"""
Profit Optimizer command handler for SMART MEMES BOT.

This module handles the /profit command which allows users to log and track
profits, analyze group performance, and optimize trading strategies.
"""

import json
import os
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports - using try/except for compatibility
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
except ImportError:
    # For simplified bot mode
    Update = None
    InlineKeyboardButton = None
    InlineKeyboardMarkup = None
    ContextTypes = None

# Import profit-related utilities
from utils.reinvest import update_profit, get_profit_summary, add_trade_history_entry
try:
    from utils.advanced_profit_controller import get_profit_controller
    ADVANCED_CONTROLLER_AVAILABLE = True
except ImportError:
    logger.warning("Advanced profit controller not available")
    ADVANCED_CONTROLLER_AVAILABLE = False

# Constants
GROUP_SCORES_FILE = "data/group_scores.json"
TOP_PERFORMERS_CACHE_FILE = "data/cache/top_performers.json"
PROFIT_HISTORY_FILE = "data/profit_history.json"
PROFIT_METRICS_FILE = "data/metrics/profit_metrics.json"

# Ensure directories exist
os.makedirs(os.path.dirname(GROUP_SCORES_FILE), exist_ok=True)
os.makedirs(os.path.dirname(TOP_PERFORMERS_CACHE_FILE), exist_ok=True)
os.makedirs(os.path.dirname(PROFIT_HISTORY_FILE), exist_ok=True)
os.makedirs(os.path.dirname(PROFIT_METRICS_FILE), exist_ok=True)

async def profit_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /profit command to log profits and manage profit-related features.
    
    Command format: /profit [log <amount> [token] | stats | optimize | groups]
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Parse arguments
        if not context.args:
            await show_profit_help(update, context)
            return
        
        subcommand = context.args[0].lower()
        
        if subcommand == "log":
            # Log a new profit
            if len(context.args) < 2:
                await update.message.reply_text(
                    "❌ Missing profit amount. Use: `/profit log <amount> [token_address] [group]`",
                    parse_mode="Markdown"
                )
                return
            
            try:
                amount = float(context.args[1])
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid profit amount. Please provide a number.",
                    parse_mode="Markdown"
                )
                return
            
            # Optional token address
            token_address = context.args[2] if len(context.args) > 2 else None
            
            # Optional group name
            group = " ".join(context.args[3:]) if len(context.args) > 3 else update.effective_chat.title
            if not group:
                group = "Default Group"
            
            await log_profit(update, context, amount, token_address, group)
            
        elif subcommand == "stats":
            # Show profit statistics
            days = 7  # Default
            if len(context.args) > 1:
                try:
                    days = int(context.args[1])
                    days = min(max(1, days), 30)  # Limit between 1 and 30
                except ValueError:
                    pass
            
            await show_profit_stats(update, context, days)
            
        elif subcommand == "optimize":
            # Run profit optimization analysis
            await optimize_profits(update, context)
            
        elif subcommand == "groups":
            # Show group performance ranking
            limit = 5  # Default
            if len(context.args) > 1:
                try:
                    limit = int(context.args[1])
                    limit = min(max(1, limit), 20)  # Limit between 1 and 20
                except ValueError:
                    pass
            
            await show_top_groups(update, context, limit)
            
        elif subcommand == "loss":
            # Log a loss (negative profit)
            if len(context.args) < 2:
                await update.message.reply_text(
                    "❌ Missing loss amount. Use: `/profit loss <amount> [token_address] [group]`",
                    parse_mode="Markdown"
                )
                return
            
            try:
                amount = -abs(float(context.args[1]))  # Make sure it's negative
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid loss amount. Please provide a number.",
                    parse_mode="Markdown"
                )
                return
            
            # Optional token address
            token_address = context.args[2] if len(context.args) > 2 else None
            
            # Optional group name
            group = " ".join(context.args[3:]) if len(context.args) > 3 else update.effective_chat.title
            if not group:
                group = "Default Group"
            
            await log_profit(update, context, amount, token_address, group)
            
        elif subcommand == "analyze":
            # Run a deep analysis of profit patterns
            await analyze_profit_patterns(update, context)
            
        else:
            await show_profit_help(update, context)
    
    except Exception as e:
        logger.error(f"Error in profit command: {str(e)}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def show_profit_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show help information for the /profit command.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    help_text = (
        "*💰 PROFIT - Profit Management System*\n\n"
        "Track and optimize your trading profits with advanced analytics.\n\n"
        "*Commands:*\n"
        "• `/profit log <amount> [token] [group]` - Log a new profit\n"
        "• `/profit loss <amount> [token] [group]` - Log a loss\n"
        "• `/profit stats [days]` - View profit statistics (default: 7 days)\n"
        "• `/profit groups [limit]` - View top-performing groups (default: 5)\n"
        "• `/profit optimize` - Get optimization recommendations\n"
        "• `/profit analyze` - Deep analysis of profit patterns\n\n"
        "*Examples:*\n"
        "• `/profit log 0.5` - Log a 0.5 SOL profit\n"
        "• `/profit log 1.2 Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu Crypto Gems` - Log profit with token and group\n"
        "• `/profit stats 14` - View 14-day profit statistics\n\n"
        "The profit system tracks performance and automatically adjusts your trading capital through the reinvestment system."
    )
    
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def direct_log_profit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /logprofit command to directly log a profit.
    
    Command format: /logprofit <amount> [token_address] [group]
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Parse arguments
        if not context.args:
            await update.message.reply_text(
                "❌ Missing profit amount. Use: `/logprofit <amount> [token_address] [group]`",
                parse_mode="Markdown"
            )
            return
        
        try:
            amount = float(context.args[0])
        except ValueError:
            await update.message.reply_text(
                "❌ Invalid profit amount. Please provide a number.",
                parse_mode="Markdown"
            )
            return
        
        # Optional token address
        token_address = context.args[1] if len(context.args) > 1 else None
        
        # Optional group name
        group = " ".join(context.args[2:]) if len(context.args) > 2 else update.effective_chat.title
        
        # Call the actual log_profit function
        await log_profit(update, context, amount, token_address, group)
        
    except Exception as e:
        logger.error(f"Error in logprofit command: {str(e)}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def log_profit(update: Update, context: ContextTypes.DEFAULT_TYPE, 
               amount: float, token_address: Optional[str] = None, 
               group: Optional[str] = None) -> None:
    """
    Log a profit entry and update various tracking systems.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        amount: The profit amount (can be negative for losses)
        token_address: Optional token address involved
        group: Optional group name where the profit was made
    """
    try:
        # Default group name if not provided
        if not group:
            group = update.effective_chat.title or "Default Group"
        
        # 1. Update reinvestment system
        result = update_profit(amount)
        
        # 2. Add to trade history
        trade_type = "manual"
        if group and group != "Default Group":
            trade_type = "group"
        
        add_trade_history_entry(amount, token_address, trade_type)
        
        # 3. Update group scores
        await update_group_scores(group, amount, token_address)
        
        # 4. Update profit history
        await update_profit_history(amount, token_address, group)
        
        # 5. Update the advanced profit controller if available
        if ADVANCED_CONTROLLER_AVAILABLE:
            controller = get_profit_controller()
            if controller.running:
                # This would be implemented in the real controller
                pass
        
        # Generate response message
        if amount > 0:
            emoji = "📈"
            action_text = "profit"
        else:
            emoji = "📉"
            action_text = "loss"
        
        response = (
            f"{emoji} *{action_text.capitalize()} Logged Successfully*\n\n"
            f"Amount: *{abs(amount):.4f} SOL* {'profit' if amount > 0 else 'loss'}\n"
        )
        
        if token_address:
            # Truncate token address for display
            display_token = f"{token_address[:6]}...{token_address[-4:]}" if len(token_address) > 10 else token_address
            response += f"Token: `{display_token}`\n"
        
        if group and group != "Default Group":
            response += f"Group: *{group}*\n"
        
        response += (
            f"\nCurrent Bag Size: *{result['current_bag']:.2f} SOL*\n"
            f"Progress to Next Reinvest: *{result['total_profit']:.2f}/100 SOL*"
        )
        
        # Create keyboard for additional options
        keyboard = [
            [
                InlineKeyboardButton("📊 Profit Stats", callback_data="profit_stats_7"),
                InlineKeyboardButton("🏆 Top Groups", callback_data="profit_groups_5")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error logging profit: {str(e)}")
        await update.message.reply_text(f"❌ Failed to log profit: {str(e)}")

async def update_group_scores(group: str, amount: float, token_address: Optional[str] = None) -> None:
    """
    Update the performance scores for a group.
    
    Args:
        group: The group name
        amount: The profit amount
        token_address: Optional token address involved
    """
    try:
        # Load existing scores
        if os.path.exists(GROUP_SCORES_FILE):
            with open(GROUP_SCORES_FILE, "r") as f:
                scores = json.load(f)
        else:
            scores = {}
        
        # Initialize group entry if not exists
        if group not in scores:
            scores[group] = {
                "wins": 0,
                "losses": 0,
                "total_profit": 0.0,
                "avg_profit": 0.0,
                "max_profit": 0.0,
                "max_loss": 0.0,
                "tokens": {},
                "last_updated": datetime.now().isoformat()
            }
        
        # Update scores
        if amount > 0:
            scores[group]["wins"] += 1
            if amount > scores[group]["max_profit"]:
                scores[group]["max_profit"] = amount
        else:
            scores[group]["losses"] += 1
            if amount < scores[group]["max_loss"]:
                scores[group]["max_loss"] = amount
        
        scores[group]["total_profit"] += amount
        
        total_trades = scores[group]["wins"] + scores[group]["losses"]
        if total_trades > 0:
            scores[group]["avg_profit"] = scores[group]["total_profit"] / total_trades
        
        # Update token-specific data
        if token_address:
            tokens = scores[group].get("tokens", {})
            if token_address not in tokens:
                tokens[token_address] = {
                    "wins": 0,
                    "losses": 0,
                    "total_profit": 0.0
                }
            
            if amount > 0:
                tokens[token_address]["wins"] += 1
            else:
                tokens[token_address]["losses"] += 1
                
            tokens[token_address]["total_profit"] += amount
            scores[group]["tokens"] = tokens
        
        scores[group]["last_updated"] = datetime.now().isoformat()
        
        # Save updated scores
        with open(GROUP_SCORES_FILE, "w") as f:
            json.dump(scores, f, indent=2)
        
        # Update top performers cache if this group is a top performer
        await update_top_performers_cache()
        
    except Exception as e:
        logger.error(f"Error updating group scores: {str(e)}")

async def update_profit_history(amount: float, token_address: Optional[str] = None, 
                         group: Optional[str] = None) -> None:
    """
    Update the profit history log.
    
    Args:
        amount: The profit amount
        token_address: Optional token address involved
        group: Optional group name
    """
    try:
        # Load existing history
        if os.path.exists(PROFIT_HISTORY_FILE):
            with open(PROFIT_HISTORY_FILE, "r") as f:
                history = json.load(f)
        else:
            history = []
        
        # Create new entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "amount": amount,
            "token_address": token_address,
            "group": group
        }
        
        # Add to history
        history.append(entry)
        
        # Save updated history
        with open(PROFIT_HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
        
        # Update metrics
        await update_profit_metrics()
        
    except Exception as e:
        logger.error(f"Error updating profit history: {str(e)}")

async def update_top_performers_cache() -> None:
    """Update the cache of top-performing groups."""
    try:
        # Load group scores
        if not os.path.exists(GROUP_SCORES_FILE):
            return
        
        with open(GROUP_SCORES_FILE, "r") as f:
            scores = json.load(f)
        
        # Calculate performance score for each group
        for group, data in scores.items():
            total_trades = data.get("wins", 0) + data.get("losses", 0)
            if total_trades > 0:
                win_rate = data.get("wins", 0) / total_trades
            else:
                win_rate = 0
                
            avg_profit = data.get("avg_profit", 0)
            
            # Performance score = win rate * average profit
            performance_score = win_rate * max(0, avg_profit)
            data["performance_score"] = performance_score
        
        # Sort groups by performance score
        sorted_groups = sorted(
            scores.items(),
            key=lambda x: x[1].get("performance_score", 0),
            reverse=True
        )
        
        # Save top performers cache
        top_performers = {
            "timestamp": datetime.now().isoformat(),
            "groups": [{"name": g[0], **g[1]} for g in sorted_groups[:20]]  # Top 20
        }
        
        with open(TOP_PERFORMERS_CACHE_FILE, "w") as f:
            json.dump(top_performers, f, indent=2)
        
    except Exception as e:
        logger.error(f"Error updating top performers cache: {str(e)}")

async def update_profit_metrics() -> None:
    """Update profit metrics based on profit history."""
    try:
        # Load profit history
        if not os.path.exists(PROFIT_HISTORY_FILE):
            return
        
        with open(PROFIT_HISTORY_FILE, "r") as f:
            history = json.load(f)
        
        # Initialize metrics
        metrics = {
            "total_profit": 0.0,
            "daily_profits": {},
            "weekly_profits": {},
            "monthly_profits": {},
            "win_rate": 0.0,
            "avg_profit": 0.0,
            "avg_loss": 0.0,
            "profitable_tokens": {},
            "top_groups": {},
            "last_updated": datetime.now().isoformat()
        }
        
        # Calculate metrics
        wins = 0
        losses = 0
        total_profit = 0.0
        total_win_amount = 0.0
        total_loss_amount = 0.0
        
        for entry in history:
            amount = entry.get("amount", 0)
            timestamp = entry.get("timestamp", "")
            token = entry.get("token_address")
            group = entry.get("group")
            
            # Skip invalid entries
            if not timestamp:
                continue
            
            # Parse timestamp
            try:
                dt = datetime.fromisoformat(timestamp)
                date_key = dt.strftime("%Y-%m-%d")
                week_key = f"{dt.year}-W{dt.isocalendar()[1]}"
                month_key = dt.strftime("%Y-%m")
            except (ValueError, TypeError):
                continue
            
            # Update total profit
            total_profit += amount
            
            # Update win/loss counts
            if amount > 0:
                wins += 1
                total_win_amount += amount
            else:
                losses += 1
                total_loss_amount += amount
            
            # Update daily profits
            if date_key in metrics["daily_profits"]:
                metrics["daily_profits"][date_key] += amount
            else:
                metrics["daily_profits"][date_key] = amount
            
            # Update weekly profits
            if week_key in metrics["weekly_profits"]:
                metrics["weekly_profits"][week_key] += amount
            else:
                metrics["weekly_profits"][week_key] = amount
            
            # Update monthly profits
            if month_key in metrics["monthly_profits"]:
                metrics["monthly_profits"][month_key] += amount
            else:
                metrics["monthly_profits"][month_key] = amount
            
            # Update token stats
            if token:
                if token not in metrics["profitable_tokens"]:
                    metrics["profitable_tokens"][token] = {
                        "total_profit": 0.0,
                        "wins": 0,
                        "losses": 0
                    }
                
                metrics["profitable_tokens"][token]["total_profit"] += amount
                if amount > 0:
                    metrics["profitable_tokens"][token]["wins"] += 1
                else:
                    metrics["profitable_tokens"][token]["losses"] += 1
            
            # Update group stats
            if group:
                if group not in metrics["top_groups"]:
                    metrics["top_groups"][group] = {
                        "total_profit": 0.0,
                        "wins": 0,
                        "losses": 0
                    }
                
                metrics["top_groups"][group]["total_profit"] += amount
                if amount > 0:
                    metrics["top_groups"][group]["wins"] += 1
                else:
                    metrics["top_groups"][group]["losses"] += 1
        
        # Calculate derived metrics
        metrics["total_profit"] = total_profit
        
        total_trades = wins + losses
        if total_trades > 0:
            metrics["win_rate"] = (wins / total_trades) * 100
        
        if wins > 0:
            metrics["avg_profit"] = total_win_amount / wins
        
        if losses > 0:
            metrics["avg_loss"] = total_loss_amount / losses
        
        # Save metrics
        with open(PROFIT_METRICS_FILE, "w") as f:
            json.dump(metrics, f, indent=2)
        
    except Exception as e:
        logger.error(f"Error updating profit metrics: {str(e)}")

async def show_profit_stats(update: Update, context: ContextTypes.DEFAULT_TYPE, days: int = 7) -> None:
    """
    Show profit statistics.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        days: Number of days to show stats for
    """
    try:
        # Load reinvestment data
        summary = get_profit_summary()
        
        # Load profit metrics
        if os.path.exists(PROFIT_METRICS_FILE):
            with open(PROFIT_METRICS_FILE, "r") as f:
                metrics = json.load(f)
        else:
            metrics = {
                "total_profit": 0.0,
                "daily_profits": {},
                "win_rate": 0.0,
                "avg_profit": 0.0,
                "avg_loss": 0.0
            }
        
        # Calculate recent profit (last N days)
        recent_profit = 0.0
        if metrics.get("daily_profits"):
            cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
            recent_daily_profits = {
                date: profit for date, profit in metrics.get("daily_profits", {}).items()
                if date >= cutoff_date
            }
            recent_profit = sum(recent_daily_profits.values())
        
        # Format response
        response = (
            f"📊 *Profit Statistics ({days} Days)*\n\n"
            f"*Current Bag Size:* {summary.get('current_bag', 0):.2f} SOL\n"
            f"*Unreinvested Profit:* {summary.get('unreinvested_profit', 0):.2f} SOL\n"
            f"*Recent Profit:* {recent_profit:.4f} SOL\n\n"
            f"*Win Rate:* {metrics.get('win_rate', 0):.1f}%\n"
            f"*Avg Profit:* {metrics.get('avg_profit', 0):.4f} SOL\n"
            f"*Avg Loss:* {metrics.get('avg_loss', 0):.4f} SOL\n\n"
            f"*Performance Breakdown:*\n"
        )
        
        # Add daily breakdown
        if metrics.get("daily_profits"):
            # Get recent days sorted by date (newest first)
            cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
            recent_days = sorted(
                [(date, profit) for date, profit in metrics.get("daily_profits", {}).items() if date >= cutoff_date],
                reverse=True
            )
            
            for date, profit in recent_days:
                emoji = "📈" if profit > 0 else "📉"
                response += f"{date}: {emoji} {profit:.4f} SOL\n"
        
        # Create keyboard for different time periods
        keyboard = [
            [
                InlineKeyboardButton("7 Days", callback_data="profit_stats_7"),
                InlineKeyboardButton("14 Days", callback_data="profit_stats_14"),
                InlineKeyboardButton("30 Days", callback_data="profit_stats_30")
            ],
            [
                InlineKeyboardButton("📈 Profit History", callback_data="profit_history"),
                InlineKeyboardButton("⚙️ Optimize", callback_data="profit_optimize")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            await update.callback_query.edit_message_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        
    except Exception as e:
        logger.error(f"Error showing profit stats: {str(e)}")
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            await update.callback_query.edit_message_text(f"❌ Error showing profit stats: {str(e)}")
        else:
            await update.message.reply_text(f"❌ Error showing profit stats: {str(e)}")

async def show_top_groups(update: Update, context: ContextTypes.DEFAULT_TYPE, limit: int = 5) -> None:
    """
    Show top-performing groups.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        limit: Maximum number of groups to show
    """
    try:
        # Load from cache first
        if os.path.exists(TOP_PERFORMERS_CACHE_FILE):
            with open(TOP_PERFORMERS_CACHE_FILE, "r") as f:
                cache = json.load(f)
            
            # Check if cache is fresh (less than 1 hour old)
            cache_time = datetime.fromisoformat(cache.get("timestamp", "2000-01-01T00:00:00"))
            if datetime.now() - cache_time < timedelta(hours=1):
                top_groups = cache.get("groups", [])[:limit]
                
                # Format response
                response = f"🏆 *Top {limit} Performing Groups*\n\n"
                
                for i, group in enumerate(top_groups, 1):
                    name = group.get("name", "Unknown Group")
                    total_profit = group.get("total_profit", 0)
                    wins = group.get("wins", 0)
                    losses = group.get("losses", 0)
                    
                    total_trades = wins + losses
                    if total_trades > 0:
                        win_rate = (wins / total_trades) * 100
                    else:
                        win_rate = 0
                    
                    response += (
                        f"{i}. *{name}*\n"
                        f"   Profit: {total_profit:.4f} SOL\n"
                        f"   Win Rate: {win_rate:.1f}%\n"
                        f"   Trades: {wins}/{total_trades}\n\n"
                    )
                
                # Add note about update time
                response += f"*Last Updated:* {cache_time.strftime('%Y-%m-%d %H:%M:%S')}"
                
                # Create keyboard
                keyboard = [
                    [
                        InlineKeyboardButton("Top 5", callback_data="profit_groups_5"),
                        InlineKeyboardButton("Top 10", callback_data="profit_groups_10"),
                        InlineKeyboardButton("Top 20", callback_data="profit_groups_20")
                    ],
                    [
                        InlineKeyboardButton("📊 Profit Stats", callback_data="profit_stats_7")
                    ]
                ]
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                # Check if we're responding to a callback query or a direct command
                if update.callback_query:
                    await update.callback_query.edit_message_text(
                        response,
                        parse_mode="Markdown",
                        reply_markup=reply_markup
                    )
                else:
                    await update.message.reply_text(
                        response,
                        parse_mode="Markdown",
                        reply_markup=reply_markup
                    )
                
                return
        
        # If cache is not available or stale, load from raw data
        if os.path.exists(GROUP_SCORES_FILE):
            with open(GROUP_SCORES_FILE, "r") as f:
                scores = json.load(f)
        else:
            scores = {}
        
        # Calculate performance score for each group
        for group, data in scores.items():
            total_trades = data.get("wins", 0) + data.get("losses", 0)
            if total_trades > 0:
                win_rate = data.get("wins", 0) / total_trades
            else:
                win_rate = 0
                
            avg_profit = data.get("avg_profit", 0)
            
            # Performance score = win rate * average profit
            performance_score = win_rate * max(0, avg_profit)
            data["performance_score"] = performance_score
        
        # Sort groups by performance score
        sorted_groups = sorted(
            scores.items(),
            key=lambda x: x[1].get("performance_score", 0),
            reverse=True
        )[:limit]
        
        # Format response
        response = f"🏆 *Top {limit} Performing Groups*\n\n"
        
        for i, (name, data) in enumerate(sorted_groups, 1):
            total_profit = data.get("total_profit", 0)
            wins = data.get("wins", 0)
            losses = data.get("losses", 0)
            
            total_trades = wins + losses
            if total_trades > 0:
                win_rate = (wins / total_trades) * 100
            else:
                win_rate = 0
            
            response += (
                f"{i}. *{name}*\n"
                f"   Profit: {total_profit:.4f} SOL\n"
                f"   Win Rate: {win_rate:.1f}%\n"
                f"   Trades: {wins}/{total_trades}\n\n"
            )
        
        # Create keyboard
        keyboard = [
            [
                InlineKeyboardButton("Top 5", callback_data="profit_groups_5"),
                InlineKeyboardButton("Top 10", callback_data="profit_groups_10"),
                InlineKeyboardButton("Top 20", callback_data="profit_groups_20")
            ],
            [
                InlineKeyboardButton("📊 Profit Stats", callback_data="profit_stats_7")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            await update.callback_query.edit_message_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text(
                response,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        
        # Update cache for future use
        await update_top_performers_cache()
        
    except Exception as e:
        logger.error(f"Error showing top groups: {str(e)}")
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            await update.callback_query.edit_message_text(f"❌ Error showing top groups: {str(e)}")
        else:
            await update.message.reply_text(f"❌ Error showing top groups: {str(e)}")

async def optimize_profits(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Analyze profit data and provide optimization recommendations.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Send initial message
        message = await update.message.reply_text(
            "🔍 *Analyzing Profit Patterns*\n\n"
            "Running comprehensive profit analysis...",
            parse_mode="Markdown"
        )
        
        # Load profit metrics
        if os.path.exists(PROFIT_METRICS_FILE):
            with open(PROFIT_METRICS_FILE, "r") as f:
                metrics = json.load(f)
        else:
            metrics = {}
        
        # Load group scores
        if os.path.exists(GROUP_SCORES_FILE):
            with open(GROUP_SCORES_FILE, "r") as f:
                group_scores = json.load(f)
        else:
            group_scores = {}
        
        # Simulate analysis time
        await asyncio.sleep(2)
        
        # Generate optimization recommendations
        recommendations = []
        
        # 1. Check win rate
        win_rate = metrics.get("win_rate", 0)
        if win_rate < 50:
            recommendations.append(
                "🔴 *Low Win Rate* - Consider implementing stronger safety checks "
                "before executing trades and use smaller position sizes."
            )
        elif win_rate >= 70:
            recommendations.append(
                "🟢 *High Win Rate* - Your strategy is working well. Consider "
                "increasing position sizes to maximize returns."
            )
        
        # 2. Check avg profit vs loss
        avg_profit = metrics.get("avg_profit", 0)
        avg_loss = abs(metrics.get("avg_loss", 0))
        
        if avg_profit > 0 and avg_loss > 0:
            risk_reward = avg_profit / avg_loss
            
            if risk_reward < 1:
                recommendations.append(
                    "🔴 *Poor Risk/Reward* - Your average loss is larger than your average profit. "
                    "Adjust your take-profit and stop-loss levels for better balance."
                )
            elif risk_reward > 2:
                recommendations.append(
                    "🟢 *Excellent Risk/Reward* - Your profits outweigh your losses by a healthy margin. "
                    "Consider increasing position sizes to capitalize on this edge."
                )
        
        # 3. Identify best performing groups
        top_groups = []
        for group, data in group_scores.items():
            total_trades = data.get("wins", 0) + data.get("losses", 0)
            if total_trades >= 5:  # Minimum sample size
                if data.get("wins", 0) / total_trades >= 0.7:  # 70% win rate
                    top_groups.append((group, data.get("avg_profit", 0)))
        
        if top_groups:
            # Sort by average profit
            top_groups.sort(key=lambda x: x[1], reverse=True)
            groups_text = ", ".join([f"*{g[0]}*" for g in top_groups[:3]])
            
            recommendations.append(
                f"🟢 *High-Performing Groups* - Focus on {groups_text} for the best results. "
                f"Consider increasing allocation to these groups."
            )
        
        # 4. Check profit trend
        if metrics.get("daily_profits"):
            recent_days = sorted(metrics["daily_profits"].keys())[-7:]  # Last 7 days
            recent_profits = [metrics["daily_profits"][day] for day in recent_days]
            
            if sum(recent_profits) < 0:
                recommendations.append(
                    "🔴 *Recent Downtrend* - Your recent performance has been negative. "
                    "Consider reducing position sizes and reviewing your strategy."
                )
            elif sum(recent_profits) > sum(recent_profits[:4]):  # Second half better than first half
                recommendations.append(
                    "🟢 *Recent Uptrend* - Your recent performance is improving. "
                    "Stick with your current strategy and consider scaling up gradually."
                )
        
        # If we have the advanced controller available, add its suggestions
        if ADVANCED_CONTROLLER_AVAILABLE:
            controller = get_profit_controller()
            if controller.running:
                # This would be implemented in the real controller
                pass
        
        # If no specific recommendations, add general ones
        if not recommendations:
            recommendations = [
                "🟡 *Diversify Trading Approach* - Consider exploring multiple trading strategies "
                "to find what works best in different market conditions.",
                
                "🟡 *Regular Review* - Analyze your trading history weekly to identify "
                "patterns and adjust your strategy accordingly.",
                
                "🟡 *Risk Management* - Never risk more than 2% of your capital on a single trade "
                "to ensure long-term sustainability."
            ]
        
        # Format response
        response = "🚀 *Profit Optimization Recommendations*\n\n"
        
        for i, rec in enumerate(recommendations, 1):
            response += f"{i}. {rec}\n\n"
        
        # Add summary of current metrics
        response += (
            "*Current Metrics:*\n"
            f"• Win Rate: {win_rate:.1f}%\n"
            f"• Avg Profit: {avg_profit:.4f} SOL\n"
            f"• Avg Loss: {abs(metrics.get('avg_loss', 0)):.4f} SOL\n"
            f"• Risk/Reward: {risk_reward:.2f}\n\n"
            "*Note:* These recommendations are based on your historical trading data and "
            "should be considered alongside your own trading strategy and risk tolerance."
        )
        
        # Update the message
        await message.edit_text(
            response,
            parse_mode="Markdown"
        )
        
    except Exception as e:
        logger.error(f"Error optimizing profits: {str(e)}")
        await update.message.reply_text(f"❌ Error generating recommendations: {str(e)}")

async def analyze_profit_patterns(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Perform deep analysis of profit patterns and trends.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Send initial message
        message = await update.message.reply_text(
            "🧠 *Deep Pattern Analysis*\n\n"
            "Analyzing profit patterns and identifying trends...",
            parse_mode="Markdown"
        )
        
        # Load profit history
        if os.path.exists(PROFIT_HISTORY_FILE):
            with open(PROFIT_HISTORY_FILE, "r") as f:
                history = json.load(f)
        else:
            history = []
        
        # Load profit metrics
        if os.path.exists(PROFIT_METRICS_FILE):
            with open(PROFIT_METRICS_FILE, "r") as f:
                metrics = json.load(f)
        else:
            metrics = {}
        
        # Simulate analysis time
        await asyncio.sleep(3)
        
        # Exit early if not enough data
        if len(history) < 5:
            await message.edit_text(
                "❌ *Insufficient Data*\n\n"
                "Need at least 5 profit entries to perform pattern analysis. "
                "Please log more profits and try again.",
                parse_mode="Markdown"
            )
            return
        
        # Perform actual analysis
        # 1. Group trading by time of day
        hour_performance = {}
        for entry in history:
            if "timestamp" not in entry:
                continue
                
            try:
                dt = datetime.fromisoformat(entry["timestamp"])
                hour = dt.hour
                
                if hour not in hour_performance:
                    hour_performance[hour] = {
                        "count": 0,
                        "profit": 0.0
                    }
                
                hour_performance[hour]["count"] += 1
                hour_performance[hour]["profit"] += entry.get("amount", 0)
                
            except (ValueError, TypeError):
                pass
        
        # Find best performing hours
        for hour, data in hour_performance.items():
            if data["count"] > 0:
                data["avg_profit"] = data["profit"] / data["count"]
        
        best_hours = sorted(
            hour_performance.items(),
            key=lambda x: x[1].get("avg_profit", 0),
            reverse=True
        )[:3]
        
        # 2. Group trading by day of week
        day_performance = {}
        for entry in history:
            if "timestamp" not in entry:
                continue
                
            try:
                dt = datetime.fromisoformat(entry["timestamp"])
                day = dt.strftime("%A")  # Monday, Tuesday, etc.
                
                if day not in day_performance:
                    day_performance[day] = {
                        "count": 0,
                        "profit": 0.0
                    }
                
                day_performance[day]["count"] += 1
                day_performance[day]["profit"] += entry.get("amount", 0)
                
            except (ValueError, TypeError):
                pass
        
        # Find best performing days
        for day, data in day_performance.items():
            if data["count"] > 0:
                data["avg_profit"] = data["profit"] / data["count"]
        
        best_days = sorted(
            day_performance.items(),
            key=lambda x: x[1].get("avg_profit", 0),
            reverse=True
        )[:3]
        
        # 3. Identify most profitable token types
        token_performance = {}
        for entry in history:
            token = entry.get("token_address")
            if not token:
                continue
                
            if token not in token_performance:
                token_performance[token] = {
                    "count": 0,
                    "profit": 0.0
                }
            
            token_performance[token]["count"] += 1
            token_performance[token]["profit"] += entry.get("amount", 0)
        
        # Find best performing tokens
        for token, data in token_performance.items():
            if data["count"] > 0:
                data["avg_profit"] = data["profit"] / data["count"]
        
        best_tokens = sorted(
            token_performance.items(),
            key=lambda x: x[1].get("avg_profit", 0),
            reverse=True
        )[:3]
        
        # Format response
        response = "🧠 *Profit Pattern Analysis*\n\n"
        
        # Add best hours
        if best_hours:
            response += "*Best Trading Hours:*\n"
            for hour, data in best_hours:
                # Convert 24h to 12h format
                hour_12 = hour % 12
                if hour_12 == 0:
                    hour_12 = 12
                ampm = "AM" if hour < 12 else "PM"
                
                response += (
                    f"• *{hour_12} {ampm}*: {data['avg_profit']:.4f} SOL avg profit "
                    f"({data['count']} trades)\n"
                )
            response += "\n"
        
        # Add best days
        if best_days:
            response += "*Best Trading Days:*\n"
            for day, data in best_days:
                response += (
                    f"• *{day}*: {data['avg_profit']:.4f} SOL avg profit "
                    f"({data['count']} trades)\n"
                )
            response += "\n"
        
        # Add best tokens
        if best_tokens:
            response += "*Most Profitable Tokens:*\n"
            for token, data in best_tokens:
                # Truncate token address for display
                display_token = f"{token[:6]}...{token[-4:]}" if len(token) > 10 else token
                
                response += (
                    f"• *{display_token}*: {data['profit']:.4f} SOL total profit "
                    f"({data['count']} trades)\n"
                )
            response += "\n"
        
        # Add profit trend
        if metrics.get("daily_profits"):
            # Get last 14 days sorted by date
            recent_days = sorted(metrics["daily_profits"].keys())[-14:]
            recent_profits = [metrics["daily_profits"][day] for day in recent_days]
            
            first_week = sum(recent_profits[:7])
            second_week = sum(recent_profits[7:])
            
            trend_text = "📈 *Improving*" if second_week > first_week else "📉 *Declining*"
            
            response += (
                "*Profit Trend:* " + trend_text + "\n"
                f"• Last 7 days: {second_week:.4f} SOL\n"
                f"• Previous 7 days: {first_week:.4f} SOL\n"
                f"• Change: {((second_week - first_week) / max(abs(first_week), 0.0001)) * 100:.1f}%\n\n"
            )
        
        # Add strategic recommendations
        response += (
            "*Strategic Recommendations:*\n"
            "1. Focus trading during your highest performing hours\n"
            "2. Concentrate on the days of the week with best results\n"
            "3. Consider developing a specialized strategy for your most profitable tokens\n"
            "4. Monitor changes in market conditions that may affect these patterns\n\n"
            "*Note:* This analysis is based on your historical trading data. "
            "Patterns may change as market conditions evolve."
        )
        
        # Update the message
        await message.edit_text(
            response,
            parse_mode="Markdown"
        )
        
    except Exception as e:
        logger.error(f"Error analyzing profit patterns: {str(e)}")
        await update.message.reply_text(f"❌ Error analyzing profit patterns: {str(e)}")

async def handle_profit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback queries for profit buttons.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    data = query.data
    
    # Answer the callback query to stop the loading indicator
    await query.answer()
    
    # Handle different callback data
    if data.startswith("profit_stats_"):
        # Extract the number of days
        days = int(data.split("_")[-1])
        await show_profit_stats(update, context, days)
    
    elif data.startswith("profit_groups_"):
        # Extract the limit
        limit = int(data.split("_")[-1])
        await show_top_groups(update, context, limit)
    
    elif data == "profit_optimize":
        # Create a fake update object to reuse the optimize function
        fake_update = update
        fake_update.message = update.effective_message
        await optimize_profits(fake_update, context)
    
    elif data == "profit_history":
        # Show profit history
        if os.path.exists(PROFIT_HISTORY_FILE):
            with open(PROFIT_HISTORY_FILE, "r") as f:
                history = json.load(f)
        else:
            history = []
        
        if not history:
            await query.edit_message_text("No profit history available.")
            return
        
        # Show last 10 entries
        response = "*📜 Recent Profit History*\n\n"
        
        for entry in sorted(history, key=lambda x: x.get("timestamp", ""), reverse=True)[:10]:
            timestamp = entry.get("timestamp", "Unknown")
            amount = entry.get("amount", 0)
            token = entry.get("token_address")
            group = entry.get("group")
            
            try:
                dt = datetime.fromisoformat(timestamp)
                timestamp = dt.strftime("%Y-%m-%d %H:%M")
            except (ValueError, TypeError):
                pass
            
            emoji = "📈" if amount > 0 else "📉"
            response += f"{timestamp} {emoji} *{amount:.4f} SOL*\n"
            
            if token:
                # Truncate token address for display
                display_token = f"{token[:6]}...{token[-4:]}" if len(token) > 10 else token
                response += f"Token: `{display_token}`\n"
            
            if group:
                response += f"Group: {group}\n"
            
            response += "\n"
        
        # Create keyboard
        keyboard = [
            [
                InlineKeyboardButton("📊 Profit Stats", callback_data="profit_stats_7"),
                InlineKeyboardButton("⚙️ Analyze", callback_data="profit_analyze")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    
    elif data == "profit_analyze":
        # Create a fake update object to reuse the analyze function
        fake_update = update
        fake_update.message = update.effective_message
        await analyze_profit_patterns(fake_update, context)

def get_profit_handlers():
    """
    Get the command handlers for profit-related commands.
    
    Returns:
        A list of handlers for profit commands
    """
    return [
        CommandHandler("profit", profit_command),
        CommandHandler("logprofit", direct_log_profit),
        CallbackQueryHandler(handle_profit_callback, pattern="^profit_stats_|^profit_groups_|^profit_history|^profit_optimize|^profit_analyze")
    ]

# For simplified bot
async def handle_profit_simple(bot, chat_id, params):
    """
    Handle the /profit command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: Command parameters
    """
    try:
        # Parse arguments
        if not params:
            # Show help message
            help_text = (
                "*💰 PROFIT - Profit Management System*\n\n"
                "Track and optimize your trading profits with advanced analytics.\n\n"
                "*Commands:*\n"
                "• `/profit log <amount> [token] [group]` - Log a new profit\n"
                "• `/profit loss <amount> [token] [group]` - Log a loss\n"
                "• `/profit stats [days]` - View profit statistics (default: 7 days)\n"
                "• `/profit groups [limit]` - View top-performing groups (default: 5)\n\n"
                "*Examples:*\n"
                "• `/profit log 0.5` - Log a 0.5 SOL profit\n"
                "• `/profit log 1.2 Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu Crypto Gems` - Log profit with token and group\n"
                "• `/profit stats 14` - View 14-day profit statistics"
            )
            
            await bot.send_message(chat_id=chat_id, text=help_text, parse_mode="Markdown")
            return
        
        subcommand = params[0].lower()
        
        if subcommand == "log":
            # Log a new profit
            if len(params) < 2:
                await bot.send_message(
                    chat_id=chat_id,
                    text="❌ Missing profit amount. Use: `/profit log <amount> [token_address] [group]`",
                    parse_mode="Markdown"
                )
                return
            
            try:
                amount = float(params[1])
            except ValueError:
                await bot.send_message(
                    chat_id=chat_id,
                    text="❌ Invalid profit amount. Please provide a number.",
                    parse_mode="Markdown"
                )
                return
            
            # Optional token address
            token_address = params[2] if len(params) > 2 else None
            
            # Optional group name
            group = " ".join(params[3:]) if len(params) > 3 else "Default Group"
            
            # Update reinvestment system
            result = update_profit(amount)
            
            # Add to trade history
            trade_type = "manual"
            if group and group != "Default Group":
                trade_type = "group"
            
            add_trade_history_entry(amount, token_address, trade_type)
            
            # Update group scores (simplified version)
            try:
                # Load existing scores
                if os.path.exists(GROUP_SCORES_FILE):
                    with open(GROUP_SCORES_FILE, "r") as f:
                        scores = json.load(f)
                else:
                    scores = {}
                
                # Initialize group entry if not exists
                if group not in scores:
                    scores[group] = {
                        "wins": 0,
                        "losses": 0,
                        "total_profit": 0.0,
                        "last_updated": datetime.now().isoformat()
                    }
                
                # Update scores
                if amount > 0:
                    scores[group]["wins"] += 1
                else:
                    scores[group]["losses"] += 1
                
                scores[group]["total_profit"] += amount
                scores[group]["last_updated"] = datetime.now().isoformat()
                
                # Save updated scores
                with open(GROUP_SCORES_FILE, "w") as f:
                    json.dump(scores, f, indent=2)
                
            except Exception as e:
                logger.error(f"Error updating group scores: {str(e)}")
            
            # Generate response message
            if amount > 0:
                emoji = "📈"
                action_text = "profit"
            else:
                emoji = "📉"
                action_text = "loss"
            
            response = (
                f"{emoji} *{action_text.capitalize()} Logged Successfully*\n\n"
                f"Amount: *{abs(amount):.4f} SOL* {'profit' if amount > 0 else 'loss'}\n"
            )
            
            if token_address:
                # Truncate token address for display
                display_token = f"{token_address[:6]}...{token_address[-4:]}" if len(token_address) > 10 else token_address
                response += f"Token: `{display_token}`\n"
            
            if group and group != "Default Group":
                response += f"Group: *{group}*\n"
            
            response += (
                f"\nCurrent Bag Size: *{result['current_bag']:.2f} SOL*\n"
                f"Progress to Next Reinvest: *{result['total_profit']:.2f}/100 SOL*"
            )
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        elif subcommand == "stats":
            # Show profit statistics
            days = 7  # Default
            if len(params) > 1:
                try:
                    days = int(params[1])
                    days = min(max(1, days), 30)  # Limit between 1 and 30
                except ValueError:
                    pass
            
            # Load reinvestment data
            summary = get_profit_summary()
            
            # Load profit metrics if available
            if os.path.exists(PROFIT_METRICS_FILE):
                with open(PROFIT_METRICS_FILE, "r") as f:
                    metrics = json.load(f)
            else:
                metrics = {
                    "total_profit": 0.0,
                    "daily_profits": {},
                    "win_rate": 0.0,
                    "avg_profit": 0.0,
                    "avg_loss": 0.0
                }
            
            # Calculate recent profit (last N days)
            recent_profit = 0.0
            if metrics.get("daily_profits"):
                cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
                recent_daily_profits = {
                    date: profit for date, profit in metrics.get("daily_profits", {}).items()
                    if date >= cutoff_date
                }
                recent_profit = sum(recent_daily_profits.values())
            
            # Format response
            response = (
                f"📊 *Profit Statistics ({days} Days)*\n\n"
                f"*Current Bag Size:* {summary.get('current_bag', 0):.2f} SOL\n"
                f"*Unreinvested Profit:* {summary.get('unreinvested_profit', 0):.2f} SOL\n"
                f"*Recent Profit:* {recent_profit:.4f} SOL\n\n"
                f"*Win Rate:* {metrics.get('win_rate', 0):.1f}%\n"
                f"*Avg Profit:* {metrics.get('avg_profit', 0):.4f} SOL\n"
                f"*Avg Loss:* {metrics.get('avg_loss', 0):.4f} SOL\n\n"
            )
            
            # Add daily breakdown
            if metrics.get("daily_profits"):
                response += "*Daily Breakdown:*\n"
                
                # Get recent days sorted by date (newest first)
                cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
                recent_days = sorted(
                    [(date, profit) for date, profit in metrics.get("daily_profits", {}).items() if date >= cutoff_date],
                    reverse=True
                )
                
                for date, profit in recent_days:
                    emoji = "📈" if profit > 0 else "📉"
                    response += f"{date}: {emoji} {profit:.4f} SOL\n"
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        elif subcommand == "groups":
            # Show top-performing groups
            limit = 5  # Default
            if len(params) > 1:
                try:
                    limit = int(params[1])
                    limit = min(max(1, limit), 20)  # Limit between 1 and 20
                except ValueError:
                    pass
            
            # Load from cache first
            if os.path.exists(TOP_PERFORMERS_CACHE_FILE):
                with open(TOP_PERFORMERS_CACHE_FILE, "r") as f:
                    cache = json.load(f)
                
                # Check if cache is fresh (less than 1 hour old)
                cache_time = datetime.fromisoformat(cache.get("timestamp", "2000-01-01T00:00:00"))
                if datetime.now() - cache_time < timedelta(hours=1):
                    top_groups = cache.get("groups", [])[:limit]
                    
                    # Format response
                    response = f"🏆 *Top {limit} Performing Groups*\n\n"
                    
                    for i, group in enumerate(top_groups, 1):
                        name = group.get("name", "Unknown Group")
                        total_profit = group.get("total_profit", 0)
                        wins = group.get("wins", 0)
                        losses = group.get("losses", 0)
                        
                        total_trades = wins + losses
                        if total_trades > 0:
                            win_rate = (wins / total_trades) * 100
                        else:
                            win_rate = 0
                        
                        response += (
                            f"{i}. *{name}*\n"
                            f"   Profit: {total_profit:.4f} SOL\n"
                            f"   Win Rate: {win_rate:.1f}%\n"
                            f"   Trades: {wins}/{total_trades}\n\n"
                        )
                    
                    await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
                    return
            
            # If cache is not available or stale, load from raw data
            if os.path.exists(GROUP_SCORES_FILE):
                with open(GROUP_SCORES_FILE, "r") as f:
                    scores = json.load(f)
            else:
                scores = {}
            
            # Calculate performance score for each group
            for group, data in scores.items():
                total_trades = data.get("wins", 0) + data.get("losses", 0)
                if total_trades > 0:
                    win_rate = data.get("wins", 0) / total_trades
                else:
                    win_rate = 0
                    
                avg_profit = data.get("avg_profit", 0)
                
                # Performance score = win rate * average profit
                performance_score = win_rate * max(0, avg_profit)
                data["performance_score"] = performance_score
            
            # Sort groups by performance score
            sorted_groups = sorted(
                scores.items(),
                key=lambda x: x[1].get("performance_score", 0),
                reverse=True
            )[:limit]
            
            # Format response
            response = f"🏆 *Top {limit} Performing Groups*\n\n"
            
            for i, (name, data) in enumerate(sorted_groups, 1):
                total_profit = data.get("total_profit", 0)
                wins = data.get("wins", 0)
                losses = data.get("losses", 0)
                
                total_trades = wins + losses
                if total_trades > 0:
                    win_rate = (wins / total_trades) * 100
                else:
                    win_rate = 0
                
                response += (
                    f"{i}. *{name}*\n"
                    f"   Profit: {total_profit:.4f} SOL\n"
                    f"   Win Rate: {win_rate:.1f}%\n"
                    f"   Trades: {wins}/{total_trades}\n\n"
                )
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        elif subcommand == "loss":
            # Log a loss (negative profit)
            if len(params) < 2:
                await bot.send_message(
                    chat_id=chat_id,
                    text="❌ Missing loss amount. Use: `/profit loss <amount> [token_address] [group]`",
                    parse_mode="Markdown"
                )
                return
            
            try:
                amount = -abs(float(params[1]))  # Make sure it's negative
            except ValueError:
                await bot.send_message(
                    chat_id=chat_id,
                    text="❌ Invalid loss amount. Please provide a number.",
                    parse_mode="Markdown"
                )
                return
            
            # Rest of the logic is the same as "log" so we reuse it with the negated amount
            await handle_profit_simple(bot, chat_id, ["log", str(amount)] + params[2:])
            
        else:
            # Unknown subcommand, show help
            help_text = (
                "*💰 PROFIT - Profit Management System*\n\n"
                "Track and optimize your trading profits with advanced analytics.\n\n"
                "*Commands:*\n"
                "• `/profit log <amount> [token] [group]` - Log a new profit\n"
                "• `/profit loss <amount> [token] [group]` - Log a loss\n"
                "• `/profit stats [days]` - View profit statistics (default: 7 days)\n"
                "• `/profit groups [limit]` - View top-performing groups (default: 5)\n\n"
                "*Examples:*\n"
                "• `/profit log 0.5` - Log a 0.5 SOL profit\n"
                "• `/profit log 1.2 Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu Crypto Gems` - Log profit with token and group\n"
                "• `/profit stats 14` - View 14-day profit statistics"
            )
            
            await bot.send_message(chat_id=chat_id, text=help_text, parse_mode="Markdown")
    
    except Exception as e:
        logger.error(f"Error in profit command (simple): {str(e)}")
        await bot.send_message(chat_id=chat_id, text=f"❌ An error occurred: {str(e)}")