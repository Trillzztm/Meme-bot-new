"""
Reinvestment command handler for SMART MEMES BOT.

This module handles the /reinvest command which allows users to view
and manage their profit tracking and reinvestment settings.
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional

# Setup logging
logger = logging.getLogger(__name__)

# Telegram imports - using try/except for compatibility with simplified bot
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
except ImportError:
    # For simplified bot mode
    Update = None
    InlineKeyboardButton = None
    InlineKeyboardMarkup = None
    ContextTypes = None

# Import profit tracking functionality
from utils.reinvest import (
    get_bag_size, get_profit_summary, update_profit, 
    set_manual_bag_size, load_trade_history
)

async def reinvest_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /reinvest command to view and manage profit reinvestment.
    
    Command format: /reinvest [view|set|summary]
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Parse arguments
        command = "view"  # Default subcommand
        args = context.args
        
        if args and len(args) > 0:
            command = args[0].lower()
        
        # Handle subcommands
        if command == "view":
            await show_reinvest_status(update, context)
        elif command == "set" and len(args) > 1:
            try:
                new_size = float(args[1])
                if new_size <= 0:
                    await update.message.reply_text("❌ Invalid bag size. Must be greater than 0.")
                    return
                
                set_manual_bag_size(new_size)
                await update.message.reply_text(
                    f"✅ Bag size manually set to {new_size} SOL.",
                    parse_mode="Markdown"
                )
            except ValueError:
                await update.message.reply_text("❌ Invalid value. Please provide a number.")
        elif command == "summary":
            await show_profit_summary(update, context)
        elif command == "history":
            limit = 5
            if len(args) > 1:
                try:
                    limit = int(args[1])
                    limit = min(max(1, limit), 20)  # Limit between 1 and 20
                except ValueError:
                    pass
            
            await show_trade_history(update, context, limit)
        else:
            # Show help for reinvest command
            help_text = (
                "*📈 Reinvestment System Help*\n\n"
                "The bot automatically reinvests profits to grow your trading capital.\n\n"
                "*Commands:*\n"
                "• `/reinvest` - Show current bag size and reinvestment status\n"
                "• `/reinvest summary` - View detailed profit statistics\n"
                "• `/reinvest history [limit]` - View recent trade history\n"
                "• `/reinvest set <amount>` - Manually set bag size (admin only)\n\n"
                "*Auto-Reinvestment Strategy:*\n"
                "Every 100 SOL in accumulated profit automatically increases your bag size by 50%.\n"
                "Example: at 100 SOL profit, a 5 SOL bag grows to 7.5 SOL."
            )
            
            await update.message.reply_text(help_text, parse_mode="Markdown")
    
    except Exception as e:
        logger.error(f"Error in reinvest command: {str(e)}")
        await update.message.reply_text(f"❌ An error occurred: {str(e)}")

async def show_reinvest_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show the current reinvestment status and bag size.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    summary = get_profit_summary()
    
    current_bag = summary.get("current_bag", 0)
    unreinvested_profit = summary.get("unreinvested_profit", 0)
    progress_to_next = (unreinvested_profit / 100) * 100  # Percentage to next reinvestment
    
    # Create a visual progress bar
    progress_bar = generate_progress_bar(progress_to_next)
    
    response = (
        "*💰 Reinvestment Status*\n\n"
        f"Current Bag Size: *{current_bag} SOL*\n"
        f"Unreinvested Profit: *{unreinvested_profit:.2f} SOL*\n\n"
        f"Progress to Next Reinvestment:\n"
        f"{progress_bar} {progress_to_next:.1f}%\n\n"
        f"Next reinvestment at 100 SOL profit will increase bag to *{current_bag * 1.5:.2f} SOL*"
    )
    
    # Add buttons for other reinvestment functions
    keyboard = [
        [
            InlineKeyboardButton("📊 Profit Summary", callback_data="reinvest_summary"),
            InlineKeyboardButton("📜 Trade History", callback_data="reinvest_history")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        response,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def show_profit_summary(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show a detailed profit summary.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    summary = get_profit_summary()
    
    # Format the last updated time
    last_updated = "Unknown"
    try:
        if "last_updated" in summary:
            dt = datetime.fromisoformat(summary["last_updated"])
            last_updated = dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        pass
    
    # Calculate additional statistics
    win_rate = summary.get("win_rate", 0)
    total_trades = summary.get("total_trades", 0)
    winning_trades = summary.get("winning_trades", 0)
    losing_trades = summary.get("losing_trades", 0)
    
    response = (
        "*📊 Profit Summary*\n\n"
        f"Current Bag Size: *{summary.get('current_bag', 0)} SOL*\n"
        f"Unreinvested Profit: *{summary.get('unreinvested_profit', 0):.2f} SOL*\n"
        f"Reinvested Capital: *{summary.get('reinvested_capital', 0):.2f} SOL*\n\n"
        f"Total Trades: *{total_trades}*\n"
        f"Winning Trades: *{winning_trades}* ✅\n"
        f"Losing Trades: *{losing_trades}* ❌\n"
        f"Win Rate: *{win_rate:.1f}%*\n\n"
        f"Last Updated: {last_updated}"
    )
    
    # Check if we're responding to a callback query or a direct command
    if update.callback_query:
        await update.callback_query.edit_message_text(
            response,
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            response,
            parse_mode="Markdown"
        )

async def show_trade_history(update: Update, context: ContextTypes.DEFAULT_TYPE, limit: int = 5) -> None:
    """
    Show recent trade history.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        limit: Maximum number of entries to show
    """
    history = load_trade_history()
    
    if not history:
        message = "No trade history available."
        
        # Check if we're responding to a callback query or a direct command
        if update.callback_query:
            await update.callback_query.edit_message_text(message)
        else:
            await update.message.reply_text(message)
        return
    
    # Sort by timestamp (newest first) and limit the number of entries
    sorted_history = sorted(history, key=lambda x: x.get("timestamp", ""), reverse=True)
    recent_trades = sorted_history[:limit]
    
    response = "*📜 Recent Trade History*\n\n"
    
    for i, trade in enumerate(recent_trades, 1):
        # Format the timestamp
        timestamp = "Unknown"
        try:
            dt = datetime.fromisoformat(trade.get("timestamp", ""))
            timestamp = dt.strftime("%Y-%m-%d %H:%M")
        except (ValueError, TypeError):
            pass
        
        profit = trade.get("profit", 0)
        token = trade.get("token_address", "Unknown")
        # Truncate token address for display
        if token and len(token) > 10:
            token = f"{token[:6]}...{token[-4:]}"
        
        trade_type = trade.get("trade_type", "auto")
        
        # Add emoji based on profit
        emoji = "✅" if profit > 0 else "❌"
        
        response += (
            f"{i}. {timestamp} {emoji}\n"
            f"   Profit: *{profit:.3f} SOL*\n"
            f"   Token: `{token}`\n"
            f"   Type: {trade_type}\n\n"
        )
    
    # Check if we're responding to a callback query or a direct command
    if update.callback_query:
        await update.callback_query.edit_message_text(
            response,
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            response,
            parse_mode="Markdown"
        )

def generate_progress_bar(percentage: float, length: int = 10) -> str:
    """
    Generate a visual progress bar.
    
    Args:
        percentage: Percentage completion (0-100)
        length: Length of the progress bar
        
    Returns:
        Text-based progress bar
    """
    filled = int((percentage / 100) * length)
    bar = "█" * filled + "░" * (length - filled)
    return bar

async def handle_reinvest_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback queries for reinvestment buttons.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    data = query.data
    
    # Answer the callback query to stop the loading indicator
    await query.answer()
    
    if data == "reinvest_summary":
        await show_profit_summary(update, context)
    elif data == "reinvest_history":
        await show_trade_history(update, context, limit=5)

def get_reinvest_handlers():
    """
    Get the command handler for the /reinvest command.
    
    Returns:
        A list of handlers for the reinvest command
    """
    return [
        CommandHandler("reinvest", reinvest_command),
        CallbackQueryHandler(handle_reinvest_callback, pattern="^reinvest_")
    ]

# Simplified bot implementation
async def handle_reinvest_simple(bot, chat_id, params):
    """
    Handle the /reinvest command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: Command parameters
    """
    try:
        # Parse arguments
        command = "view"  # Default subcommand
        
        if params and len(params) > 0:
            command = params[0].lower()
        
        # Handle subcommands
        if command == "view":
            summary = get_profit_summary()
            
            current_bag = summary.get("current_bag", 0)
            unreinvested_profit = summary.get("unreinvested_profit", 0)
            progress_to_next = (unreinvested_profit / 100) * 100  # Percentage to next reinvestment
            
            # Create a visual progress bar
            filled = int((progress_to_next / 100) * 10)
            progress_bar = "█" * filled + "░" * (10 - filled)
            
            response = (
                "*💰 Reinvestment Status*\n\n"
                f"Current Bag Size: *{current_bag} SOL*\n"
                f"Unreinvested Profit: *{unreinvested_profit:.2f} SOL*\n\n"
                f"Progress to Next Reinvestment:\n"
                f"{progress_bar} {progress_to_next:.1f}%\n\n"
                f"Next reinvestment at 100 SOL profit will increase bag to *{current_bag * 1.5:.2f} SOL*"
            )
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        elif command == "set" and len(params) > 1:
            try:
                new_size = float(params[1])
                if new_size <= 0:
                    await bot.send_message(chat_id=chat_id, text="❌ Invalid bag size. Must be greater than 0.")
                    return
                
                set_manual_bag_size(new_size)
                await bot.send_message(
                    chat_id=chat_id,
                    text=f"✅ Bag size manually set to {new_size} SOL.",
                    parse_mode="Markdown"
                )
            except ValueError:
                await bot.send_message(chat_id=chat_id, text="❌ Invalid value. Please provide a number.")
                
        elif command == "summary":
            summary = get_profit_summary()
            
            # Format the last updated time
            last_updated = "Unknown"
            try:
                if "last_updated" in summary:
                    dt = datetime.fromisoformat(summary["last_updated"])
                    last_updated = dt.strftime("%Y-%m-%d %H:%M:%S")
            except (ValueError, TypeError):
                pass
            
            win_rate = summary.get("win_rate", 0)
            total_trades = summary.get("total_trades", 0)
            winning_trades = summary.get("winning_trades", 0)
            losing_trades = summary.get("losing_trades", 0)
            
            response = (
                "*📊 Profit Summary*\n\n"
                f"Current Bag Size: *{summary.get('current_bag', 0)} SOL*\n"
                f"Unreinvested Profit: *{summary.get('unreinvested_profit', 0):.2f} SOL*\n"
                f"Reinvested Capital: *{summary.get('reinvested_capital', 0):.2f} SOL*\n\n"
                f"Total Trades: *{total_trades}*\n"
                f"Winning Trades: *{winning_trades}* ✅\n"
                f"Losing Trades: *{losing_trades}* ❌\n"
                f"Win Rate: *{win_rate:.1f}%*\n\n"
                f"Last Updated: {last_updated}"
            )
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        elif command == "history":
            limit = 5
            if len(params) > 1:
                try:
                    limit = int(params[1])
                    limit = min(max(1, limit), 20)  # Limit between 1 and 20
                except ValueError:
                    pass
            
            history = load_trade_history()
            
            if not history:
                await bot.send_message(chat_id=chat_id, text="No trade history available.")
                return
            
            # Sort by timestamp (newest first) and limit the number of entries
            sorted_history = sorted(history, key=lambda x: x.get("timestamp", ""), reverse=True)
            recent_trades = sorted_history[:limit]
            
            response = "*📜 Recent Trade History*\n\n"
            
            for i, trade in enumerate(recent_trades, 1):
                # Format the timestamp
                timestamp = "Unknown"
                try:
                    dt = datetime.fromisoformat(trade.get("timestamp", ""))
                    timestamp = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass
                
                profit = trade.get("profit", 0)
                token = trade.get("token_address", "Unknown")
                # Truncate token address for display
                if token and len(token) > 10:
                    token = f"{token[:6]}...{token[-4:]}"
                
                trade_type = trade.get("trade_type", "auto")
                
                # Add emoji based on profit
                emoji = "✅" if profit > 0 else "❌"
                
                response += (
                    f"{i}. {timestamp} {emoji}\n"
                    f"   Profit: *{profit:.3f} SOL*\n"
                    f"   Token: `{token}`\n"
                    f"   Type: {trade_type}\n\n"
                )
            
            await bot.send_message(chat_id=chat_id, text=response, parse_mode="Markdown")
            
        else:
            # Show help for reinvest command
            help_text = (
                "*📈 Reinvestment System Help*\n\n"
                "The bot automatically reinvests profits to grow your trading capital.\n\n"
                "*Commands:*\n"
                "• `/reinvest` - Show current bag size and reinvestment status\n"
                "• `/reinvest summary` - View detailed profit statistics\n"
                "• `/reinvest history [limit]` - View recent trade history\n"
                "• `/reinvest set <amount>` - Manually set bag size (admin only)\n\n"
                "*Auto-Reinvestment Strategy:*\n"
                "Every 100 SOL in accumulated profit automatically increases your bag size by 50%.\n"
                "Example: at 100 SOL profit, a 5 SOL bag grows to 7.5 SOL."
            )
            
            await bot.send_message(chat_id=chat_id, text=help_text, parse_mode="Markdown")
    
    except Exception as e:
        logger.error(f"Error in reinvest command (simple): {str(e)}")
        await bot.send_message(chat_id=chat_id, text=f"❌ An error occurred: {str(e)}")