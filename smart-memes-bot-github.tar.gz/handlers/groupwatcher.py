"""
Group message watcher for SMART MEMES BOT.

This handler monitors group messages to detect potential token mentions
and triggers processing through the auto-sniper system.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes

from utils.group_monitor_handler import process_group_message
from utils.autosniper import process_token_mention

# Configure logger
logger = logging.getLogger(__name__)

async def handle_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Process messages from Telegram groups to detect token mentions.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
    """
    if not update.message or not update.message.text:
        return

    text = update.message.text.lower()
    
    # Process the message through our group monitoring system
    await process_group_message(update, context)
    
    # Also process it through the auto-sniper if it contains relevant keywords
    if "solana" in text or "raydium.io" in text or "dexscreener.com" in text:
        try:
            await process_token_mention(text, update)
            logger.info(f"Auto-sniper processing triggered for message in {update.effective_chat.title}")
        except Exception as e:
            logger.error(f"Error processing token mention: {str(e)}")