"""
Command handlers for viewing ranked groups.

This module contains handlers for the /rankedgroups command, which displays
the top-performing Telegram groups based on profitability of their token mentions.
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler

from utils.group_ranker import get_ranked_groups, get_group_stats

# Configure logger
logger = logging.getLogger(__name__)

async def rankedgroups(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show the top performing Telegram groups based on profitability.
    
    Command format: /rankedgroups [limit=5]
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Parse arguments
        args = context.args
        limit = 5  # Default limit
        
        if args and len(args) > 0:
            try:
                limit = int(args[0])
                # Cap the limit to avoid excessively long messages
                limit = min(max(1, limit), 20)
            except ValueError:
                await update.message.reply_text(
                    "Invalid limit. Using default of 5 groups."
                )
        
        # Get the top groups
        ranked_groups = get_ranked_groups(limit=limit)
        
        if not ranked_groups:
            await update.message.reply_text(
                "No groups have been ranked yet. "
                "Groups are ranked after tokens from them are evaluated for profit."
            )
            return
        
        # Format the response
        response = "🏆 *Top Performing Groups* 🏆\n\n"
        
        for i, group in enumerate(ranked_groups, 1):
            success_rate = group.get("success_rate", 0) * 100
            avg_profit = group.get("avg_profit", 0) * 100  # Convert to percentage
            
            response += (
                f"{i}. *{group.get('name', 'Unknown Group')}*\n"
                f"   Success Rate: {success_rate:.1f}%\n"
                f"   Avg. Profit: {avg_profit:.1f}%\n"
                f"   Wins/Total: {group.get('wins', 0)}/{group.get('total_evals', 0)}\n\n"
            )
        
        # Add buttons for detailed view of each top group
        buttons = []
        for group in ranked_groups[:min(5, len(ranked_groups))]:
            group_id = group.get("id")
            group_name = group.get("name", "Unknown")
            # Truncate long group names
            display_name = (group_name[:15] + "...") if len(group_name) > 18 else group_name
            buttons.append([InlineKeyboardButton(
                f"📊 {display_name}", 
                callback_data=f"groupdetail_{group_id}"
            )])
        
        # Add view more button if there are more than 5 groups
        if len(ranked_groups) > 5:
            buttons.append([InlineKeyboardButton(
                "View More Groups", 
                callback_data=f"moregroups_10"  # Show 10 groups next time
            )])
        
        markup = InlineKeyboardMarkup(buttons)
        
        # Send the response
        await update.message.reply_text(
            response,
            parse_mode="Markdown",
            reply_markup=markup
        )
    
    except Exception as e:
        logger.error(f"Error in rankedgroups command: {str(e)}")
        await update.message.reply_text(
            f"An error occurred while getting ranked groups: {str(e)}"
        )

async def handle_group_detail_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for group detail button clicks.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback data
        query = update.callback_query
        data = query.data
        
        # Extract the group ID from the callback data
        # Format: groupdetail_<group_id>
        group_id = data.split("_")[1]
        
        # Get detailed stats for this group
        group_stats = get_group_stats(group_id)
        
        if not group_stats:
            await query.answer("No data available for this group")
            return
        
        # Format the response
        response = f"📊 *Group Analysis: {group_stats.get('name', 'Unknown Group')}* 📊\n\n"
        
        # Calculate success metrics
        wins = group_stats.get("wins", 0)
        losses = group_stats.get("losses", 0)
        total = wins + losses
        
        if total > 0:
            success_rate = (wins / total) * 100
            avg_profit = group_stats.get("avg_profit", 0) * 100  # To percentage
            
            response += (
                f"Success Rate: {success_rate:.1f}%\n"
                f"Average Profit: {avg_profit:.1f}%\n"
                f"Total Evaluations: {total}\n"
                f"Profitable Tokens: {wins}\n"
                f"Unprofitable Tokens: {losses}\n\n"
            )
            
            # Add best token info if available
            best_token = group_stats.get("best_token")
            best_profit = group_stats.get("best_profit", 0)
            
            if best_token:
                response += (
                    f"Best Token: `{best_token}`\n"
                    f"Best Profit: {(best_profit-1)*100:.1f}%\n\n"
                )
            
            # Add recent token history
            token_history = group_stats.get("token_history", [])
            
            if token_history:
                response += "*Recent Token Performance:*\n"
                
                for i, token in enumerate(token_history[:5], 1):
                    profit = token.get("profit", 1)
                    token_addr = token.get("token", "Unknown")
                    # Truncate the token address
                    short_addr = f"{token_addr[:6]}...{token_addr[-4:]}"
                    
                    response += (
                        f"{i}. `{short_addr}`: {(profit-1)*100:.1f}% "
                        f"({'✅' if profit >= 1.25 else '❌'})\n"
                    )
        else:
            response += "No token evaluations have been recorded for this group yet."
        
        # Add buttons
        buttons = [
            [InlineKeyboardButton("Auto-Snipe Settings", callback_data=f"groupsnipe_{group_id}")],
            [InlineKeyboardButton("« Back to Top Groups", callback_data="backtogroups")]
        ]
        
        markup = InlineKeyboardMarkup(buttons)
        
        # Answer the callback query
        await query.answer()
        
        # Edit the message
        await query.edit_message_text(
            response,
            parse_mode="Markdown",
            reply_markup=markup
        )
    
    except Exception as e:
        logger.error(f"Error handling group detail callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

async def handle_more_groups_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for viewing more groups.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback data
        query = update.callback_query
        data = query.data
        
        # Extract the limit from the callback data
        # Format: moregroups_<limit>
        limit = int(data.split("_")[1])
        
        # Get the ranked groups with the new limit
        ranked_groups = get_ranked_groups(limit=limit)
        
        if not ranked_groups:
            await query.answer("No groups have been ranked yet")
            return
        
        # Format the response
        response = f"🏆 *Top {limit} Performing Groups* 🏆\n\n"
        
        for i, group in enumerate(ranked_groups, 1):
            success_rate = group.get("success_rate", 0) * 100
            avg_profit = group.get("avg_profit", 0) * 100  # Convert to percentage
            
            response += (
                f"{i}. *{group.get('name', 'Unknown Group')}*\n"
                f"   Success Rate: {success_rate:.1f}%\n"
                f"   Avg. Profit: {avg_profit:.1f}%\n"
                f"   Wins/Total: {group.get('wins', 0)}/{group.get('total_evals', 0)}\n\n"
            )
        
        # Add buttons for detailed view of each top group
        buttons = []
        for group in ranked_groups[:min(5, len(ranked_groups))]:
            group_id = group.get("id")
            group_name = group.get("name", "Unknown")
            # Truncate long group names
            display_name = (group_name[:15] + "...") if len(group_name) > 18 else group_name
            buttons.append([InlineKeyboardButton(
                f"📊 {display_name}", 
                callback_data=f"groupdetail_{group_id}"
            )])
        
        # Add button to show more or fewer groups
        if limit < 15 and len(ranked_groups) >= limit:
            buttons.append([InlineKeyboardButton(
                "View More Groups", 
                callback_data=f"moregroups_{min(limit+5, 15)}"
            )])
        elif limit > 5:
            buttons.append([InlineKeyboardButton(
                "View Fewer Groups", 
                callback_data=f"moregroups_5"
            )])
        
        markup = InlineKeyboardMarkup(buttons)
        
        # Answer the callback query
        await query.answer()
        
        # Edit the message
        await query.edit_message_text(
            response,
            parse_mode="Markdown",
            reply_markup=markup
        )
    
    except Exception as e:
        logger.error(f"Error handling more groups callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

async def handle_back_to_groups_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for going back to the main groups list.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback query
        query = update.callback_query
        
        # Get the top 5 groups (default)
        ranked_groups = get_ranked_groups(limit=5)
        
        if not ranked_groups:
            await query.answer("No groups have been ranked yet")
            return
        
        # Format the response
        response = "🏆 *Top Performing Groups* 🏆\n\n"
        
        for i, group in enumerate(ranked_groups, 1):
            success_rate = group.get("success_rate", 0) * 100
            avg_profit = group.get("avg_profit", 0) * 100  # Convert to percentage
            
            response += (
                f"{i}. *{group.get('name', 'Unknown Group')}*\n"
                f"   Success Rate: {success_rate:.1f}%\n"
                f"   Avg. Profit: {avg_profit:.1f}%\n"
                f"   Wins/Total: {group.get('wins', 0)}/{group.get('total_evals', 0)}\n\n"
            )
        
        # Add buttons for detailed view of each top group
        buttons = []
        for group in ranked_groups[:min(5, len(ranked_groups))]:
            group_id = group.get("id")
            group_name = group.get("name", "Unknown")
            # Truncate long group names
            display_name = (group_name[:15] + "...") if len(group_name) > 18 else group_name
            buttons.append([InlineKeyboardButton(
                f"📊 {display_name}", 
                callback_data=f"groupdetail_{group_id}"
            )])
        
        # Add view more button if there are more than 5 groups
        if len(ranked_groups) > 5:
            buttons.append([InlineKeyboardButton(
                "View More Groups", 
                callback_data=f"moregroups_10"  # Show 10 groups next time
            )])
        
        markup = InlineKeyboardMarkup(buttons)
        
        # Answer the callback query
        await query.answer()
        
        # Edit the message
        await query.edit_message_text(
            response,
            parse_mode="Markdown",
            reply_markup=markup
        )
    
    except Exception as e:
        logger.error(f"Error handling back to groups callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

async def handle_group_snipe_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for group auto-snipe settings.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback data
        query = update.callback_query
        data = query.data
        
        # Extract the group ID from the callback data
        # Format: groupsnipe_<group_id>
        group_id = data.split("_")[1]
        
        # Get the current auto-snipe settings for this group
        group_settings = context.bot_data.get('group_settings', {}).get(group_id, {})
        enabled = group_settings.get('auto_snipe_enabled', True)
        amount = group_settings.get('auto_snipe_amount', 0.01)
        
        # Get group stats
        group_stats = get_group_stats(group_id)
        group_name = group_stats.get('name', 'Unknown Group')
        
        # Format the response
        response = f"⚙️ *Auto-Snipe Settings: {group_name}* ⚙️\n\n"
        response += f"Auto-Snipe: {'Enabled ✅' if enabled else 'Disabled ❌'}\n"
        response += f"Amount: {amount} SOL\n\n"
        
        response += "Use these settings to control whether tokens from this group are automatically sniped and with what amount."
        
        # Create buttons for changing settings
        buttons = []
        
        # Toggle enable/disable
        toggle_text = "Disable Auto-Snipe" if enabled else "Enable Auto-Snipe"
        toggle_data = f"toggle_snipe_{group_id}_{'off' if enabled else 'on'}"
        buttons.append([InlineKeyboardButton(toggle_text, callback_data=toggle_data)])
        
        # Amount adjustment buttons
        if enabled:
            amount_row = []
            
            # Decrease amount
            if amount > 0.01:
                decrease_data = f"adjust_amount_{group_id}_{amount-0.01:.2f}"
                amount_row.append(InlineKeyboardButton("- 0.01", callback_data=decrease_data))
            
            # Current amount display (non-functional button)
            amount_row.append(InlineKeyboardButton(f"{amount} SOL", callback_data="noop"))
            
            # Increase amount
            if amount < 0.2:  # Cap at 0.2 SOL for safety
                increase_data = f"adjust_amount_{group_id}_{amount+0.01:.2f}"
                amount_row.append(InlineKeyboardButton("+ 0.01", callback_data=increase_data))
            
            buttons.append(amount_row)
        
        # Back button
        buttons.append([InlineKeyboardButton("« Back to Group Details", callback_data=f"groupdetail_{group_id}")])
        
        markup = InlineKeyboardMarkup(buttons)
        
        # Answer the callback query
        await query.answer()
        
        # Edit the message
        await query.edit_message_text(
            response,
            parse_mode="Markdown",
            reply_markup=markup
        )
    
    except Exception as e:
        logger.error(f"Error handling group snipe callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

async def handle_toggle_snipe_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for toggling auto-snipe settings.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback data
        query = update.callback_query
        data = query.data
        
        # Extract the group ID and new state from the callback data
        # Format: toggle_snipe_<group_id>_<on|off>
        parts = data.split("_")
        group_id = parts[2]
        new_state = parts[3] == "on"
        
        # Initialize group settings if not already present
        if 'group_settings' not in context.bot_data:
            context.bot_data['group_settings'] = {}
        
        if group_id not in context.bot_data['group_settings']:
            context.bot_data['group_settings'][group_id] = {}
        
        # Update the auto-snipe setting
        context.bot_data['group_settings'][group_id]['auto_snipe_enabled'] = new_state
        
        # Get group stats
        group_stats = get_group_stats(group_id)
        group_name = group_stats.get('name', 'Unknown Group')
        
        # Answer the callback query
        await query.answer(f"Auto-snipe for {group_name} {'enabled' if new_state else 'disabled'}")
        
        # Redirect back to the group snipe settings
        await handle_group_snipe_callback(update, context)
    
    except Exception as e:
        logger.error(f"Error handling toggle snipe callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

async def handle_adjust_amount_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback for adjusting auto-snipe amount.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Get the callback data
        query = update.callback_query
        data = query.data
        
        # Extract the group ID and new amount from the callback data
        # Format: adjust_amount_<group_id>_<amount>
        parts = data.split("_")
        group_id = parts[2]
        new_amount = float(parts[3])
        
        # Check boundaries
        new_amount = max(0.01, min(new_amount, 0.2))
        
        # Initialize group settings if not already present
        if 'group_settings' not in context.bot_data:
            context.bot_data['group_settings'] = {}
        
        if group_id not in context.bot_data['group_settings']:
            context.bot_data['group_settings'][group_id] = {}
        
        # Update the auto-snipe amount
        context.bot_data['group_settings'][group_id]['auto_snipe_amount'] = new_amount
        
        # Get group stats
        group_stats = get_group_stats(group_id)
        group_name = group_stats.get('name', 'Unknown Group')
        
        # Answer the callback query
        await query.answer(f"Auto-snipe amount for {group_name} set to {new_amount} SOL")
        
        # Redirect back to the group snipe settings
        await handle_group_snipe_callback(update, context)
    
    except Exception as e:
        logger.error(f"Error handling adjust amount callback: {str(e)}")
        if update.callback_query:
            await update.callback_query.answer(f"Error: {str(e)}")

def get_rankedgroups_handler():
    """Get the command handler for /rankedgroups."""
    return CommandHandler("rankedgroups", rankedgroups)