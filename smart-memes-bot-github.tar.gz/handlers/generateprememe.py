"""
Meme generation command handler for SMART MEMES BOT.

This module handles the /generateprememe command to create viral-ready
crypto memes based on token performance and user inputs.
"""

import logging
import os
import random
import re
import base64
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import json

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update, InputFile, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_info import get_token_info, is_valid_token_address, get_token_price_history
from utils.solana_utils import check_wallet_balance

# Import configuration
from config import MEME_TEMPLATES

# For meme generation
try:
    import cairosvg
    from PIL import Image, ImageDraw, ImageFont
    CAIROSVG_AVAILABLE = True
except ImportError:
    logger.warning("cairosvg or PIL not available. Meme generation may not work correctly.")
    CAIROSVG_AVAILABLE = False

async def generateprememe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /generateprememe command - Create custom crypto memes.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_generateprememe(update, context)

async def handle_generateprememe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the generateprememe command - Generate and send a meme.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Extract token address and parameters from the command
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address to create a meme.\n"
            "Usage: /generateprememe <token_address> [options]\n"
            "Example: /generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu template=moon_lambo top=\"When your token\" bottom=\"goes 100x\""
        )
        return
    
    token_address = context.args[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        await update.message.reply_text(
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    template = None
    top_text = None
    bottom_text = None
    style = "bullish"  # default style
    share_platform = None
    
    for arg in context.args[1:]:
        if arg.lower().startswith("template="):
            template_value = arg.split("=", 1)[1] if "=" in arg else ""
            if template_value in MEME_TEMPLATES:
                template = template_value
            else:
                template_options = ", ".join(MEME_TEMPLATES)
                await update.message.reply_text(
                    f"⚠️ Invalid template: {template_value}. "
                    f"Available templates: {template_options}"
                )
        elif arg.lower().startswith("top="):
            top_text = arg.split("=", 1)[1] if "=" in arg else ""
        elif arg.lower().startswith("bottom="):
            bottom_text = arg.split("=", 1)[1] if "=" in arg else ""
        elif arg.lower().startswith("style="):
            style_value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if style_value in ["bullish", "bearish", "neutral"]:
                style = style_value
            else:
                await update.message.reply_text(
                    f"⚠️ Invalid style: {style_value}. "
                    "Available styles: bullish, bearish, neutral"
                )
        elif arg.lower().startswith("share="):
            share_value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if share_value in ["twitter", "telegram"]:
                share_platform = share_value
            else:
                await update.message.reply_text(
                    f"⚠️ Invalid share platform: {share_value}. "
                    "Available platforms: twitter, telegram"
                )
    
    # If no template specified, pick a random one
    if not template:
        template = random.choice(MEME_TEMPLATES)
    
    # Get token info
    await update.message.reply_text(
        f"🎨 Generating premium meme for {token_address}...\n"
        "This may take a moment to gather token data and create your meme."
    )
    
    try:
        # Get token data
        token_data = get_token_info(token_address)
        token_price_history = get_token_price_history(token_address)
        
        # Generate default text if not provided
        if not top_text or not bottom_text:
            meme_text = generate_meme_text(token_data, token_price_history, style)
            if not top_text:
                top_text = meme_text.get("top", "")
            if not bottom_text:
                bottom_text = meme_text.get("bottom", "")
        
        # Generate the meme
        meme_path = generate_meme_image(
            template, 
            token_address, 
            token_data, 
            top_text, 
            bottom_text, 
            style
        )
        
        if not meme_path or not os.path.exists(meme_path):
            await update.message.reply_text(
                "❌ Failed to generate meme. Please try again or use a different template."
            )
            return
        
        # Create inline keyboard for sharing options
        keyboard = [
            [
                InlineKeyboardButton("Share on Twitter", callback_data=f"share_twitter_{meme_path}"),
                InlineKeyboardButton("Share on Telegram", callback_data=f"share_tg_{meme_path}")
            ],
            [
                InlineKeyboardButton("Generate Another", callback_data=f"meme_new_{token_address}"),
                InlineKeyboardButton("Add Custom Text", callback_data=f"meme_edit_{meme_path}")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Send the meme
        with open(meme_path, "rb") as meme_file:
            await update.message.reply_photo(
                photo=meme_file,
                caption=(
                    f"🎨 *Premium Meme Generated*\n\n"
                    f"*Token:* `{token_address}`\n"
                    f"*Template:* {template}\n"
                    f"*Style:* {style.capitalize()}\n\n"
                    "Use the buttons below to share your meme or generate another one."
                ),
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        
        # Auto-share if requested
        if share_platform:
            # This would typically call a function to share the meme
            # For now, just notify that it would be shared
            await update.message.reply_text(
                f"🔄 Auto-sharing meme to {share_platform.capitalize()}..."
            )
    
    except Exception as e:
        logger.error(f"Error generating meme: {e}")
        await update.message.reply_text(
            f"❌ Error generating meme: {str(e)}"
        )

def handle_generateprememe_simple(bot, chat_id, params):
    """
    Process the generateprememe command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # Extract token address and parameters from the command
    if not params or len(params) < 1:
        bot.send_message(
            chat_id,
            "Please provide a token address to create a meme.\n"
            "Usage: /generateprememe <token_address> [options]\n"
            "Example: /generateprememe Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu template=moon_lambo top=\"When your token\" bottom=\"goes 100x\""
        )
        return
    
    token_address = params[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        bot.send_message(
            chat_id,
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    template = None
    top_text = None
    bottom_text = None
    style = "bullish"  # default style
    share_platform = None
    
    for arg in params[1:]:
        if arg.lower().startswith("template="):
            template_value = arg.split("=", 1)[1] if "=" in arg else ""
            if template_value in MEME_TEMPLATES:
                template = template_value
            else:
                template_options = ", ".join(MEME_TEMPLATES)
                bot.send_message(
                    chat_id,
                    f"⚠️ Invalid template: {template_value}. "
                    f"Available templates: {template_options}"
                )
        elif arg.lower().startswith("top="):
            top_text = arg.split("=", 1)[1] if "=" in arg else ""
        elif arg.lower().startswith("bottom="):
            bottom_text = arg.split("=", 1)[1] if "=" in arg else ""
        elif arg.lower().startswith("style="):
            style_value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if style_value in ["bullish", "bearish", "neutral"]:
                style = style_value
            else:
                bot.send_message(
                    chat_id,
                    f"⚠️ Invalid style: {style_value}. "
                    "Available styles: bullish, bearish, neutral"
                )
        elif arg.lower().startswith("share="):
            share_value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if share_value in ["twitter", "telegram"]:
                share_platform = share_value
            else:
                bot.send_message(
                    chat_id,
                    f"⚠️ Invalid share platform: {share_value}. "
                    "Available platforms: twitter, telegram"
                )
    
    # If no template specified, pick a random one
    if not template:
        template = random.choice(MEME_TEMPLATES)
    
    # Get token info
    bot.send_message(
        chat_id,
        f"🎨 Generating premium meme for {token_address}...\n"
        "This may take a moment to gather token data and create your meme."
    )
    
    try:
        # Get token data
        token_data = get_token_info(token_address)
        token_price_history = get_token_price_history(token_address)
        
        # Generate default text if not provided
        if not top_text or not bottom_text:
            meme_text = generate_meme_text(token_data, token_price_history, style)
            if not top_text:
                top_text = meme_text.get("top", "")
            if not bottom_text:
                bottom_text = meme_text.get("bottom", "")
        
        # Generate the meme
        meme_path = generate_meme_image(
            template, 
            token_address, 
            token_data, 
            top_text, 
            bottom_text, 
            style
        )
        
        if not meme_path or not os.path.exists(meme_path):
            bot.send_message(
                chat_id,
                "❌ Failed to generate meme. Please try again or use a different template."
            )
            return
        
        # Send the meme
        with open(meme_path, "rb") as meme_file:
            bot.send_photo(
                chat_id,
                photo=meme_file,
                caption=(
                    f"🎨 *Premium Meme Generated*\n\n"
                    f"*Token:* `{token_address}`\n"
                    f"*Template:* {template}\n"
                    f"*Style:* {style.capitalize()}\n\n"
                    "Use /generateprememe again to create another meme."
                ),
                parse_mode="Markdown"
            )
        
        # Auto-share if requested
        if share_platform:
            # This would typically call a function to share the meme
            # For now, just notify that it would be shared
            bot.send_message(
                chat_id,
                f"🔄 Auto-sharing meme to {share_platform.capitalize()}..."
            )
    
    except Exception as e:
        logger.error(f"Error generating meme: {e}")
        bot.send_message(
            chat_id,
            f"❌ Error generating meme: {str(e)}"
        )

def generate_meme_text(token_data: Dict[str, Any], price_history: List[Dict[str, Any]], style: str) -> Dict[str, str]:
    """
    Generate appropriate meme text based on token data and style.
    
    Args:
        token_data: Token information dictionary
        price_history: List of price points with timestamps
        style: The emotional style (bullish, bearish, neutral)
        
    Returns:
        Dictionary with top and bottom text
    """
    # Get price change
    price_change = 0
    if price_history and len(price_history) >= 2:
        latest_price = price_history[0].get("price", 0)
        oldest_price = price_history[-1].get("price", 0)
        if oldest_price > 0:
            price_change = ((latest_price - oldest_price) / oldest_price) * 100
    
    # Predefined templates based on style
    bullish_templates = [
        {"top": "When your token", "bottom": "goes to the moon"},
        {"top": "Diamond hands", "bottom": "lead to lambos"},
        {"top": "HODL tight", "bottom": "rocket launching"},
        {"top": "Buying the dip", "bottom": "before the pump"},
        {"top": "This token", "bottom": "only goes up"},
    ]
    
    bearish_templates = [
        {"top": "When you invest", "bottom": "but it keeps dipping"},
        {"top": "Bought at ATH", "bottom": "now down 80%"},
        {"top": "Waiting for recovery", "bottom": "but it keeps falling"},
        {"top": "The chart looked bullish", "bottom": "until it wasn't"},
        {"top": "My portfolio", "bottom": "after buying this token"},
    ]
    
    neutral_templates = [
        {"top": "Crypto trading", "bottom": "a rollercoaster ride"},
        {"top": "DYOR always", "bottom": "this is not financial advice"},
        {"top": "Paper hands vs", "bottom": "diamond hands"},
        {"top": "Market analysis", "bottom": "vs gut feeling"},
        {"top": "Trading strategy", "bottom": "vs market reality"},
    ]
    
    # Pick a template based on style and price change
    if style == "bullish" or (style == "neutral" and price_change > 10):
        template = random.choice(bullish_templates)
    elif style == "bearish" or (style == "neutral" and price_change < -10):
        template = random.choice(bearish_templates)
    else:
        template = random.choice(neutral_templates)
    
    return template

def generate_meme_image(
    template: str,
    token_address: str,
    token_data: Dict[str, Any],
    top_text: str,
    bottom_text: str,
    style: str
) -> Optional[str]:
    """
    Generate a meme image based on the template and text.
    
    Args:
        template: The template to use
        token_address: The token address (used in the filename)
        token_data: Token information dictionary
        top_text: Text to display at the top
        bottom_text: Text to display at the bottom
        style: The emotional style (bullish, bearish, neutral)
        
    Returns:
        Path to the generated meme image
    """
    if not CAIROSVG_AVAILABLE:
        return None
    
    try:
        # Ensure temp directory exists
        temp_dir = "temp"
        os.makedirs(temp_dir, exist_ok=True)
        
        # Template path
        template_path = os.path.join("assets", "meme_templates", f"{template}.svg")
        if not os.path.exists(template_path):
            template_path = os.path.join("assets", "meme_templates", "template1.svg")
        
        # Create a unique filename
        timestamp = int(datetime.now().timestamp())
        output_path = os.path.join(temp_dir, f"meme_{token_address[:8]}_{timestamp}.png")
        
        # Read SVG content
        with open(template_path, "r") as f:
            svg_content = f.read()
        
        # Replace placeholder text in SVG
        svg_content = svg_content.replace("{{TOP_TEXT}}", top_text)
        svg_content = svg_content.replace("{{BOTTOM_TEXT}}", bottom_text)
        
        # Add token info if available
        token_score = token_data.get("score", "")
        liquidity = token_data.get("liquidity", "")
        
        svg_content = svg_content.replace("{{TOKEN_SCORE}}", f"Score: {token_score}")
        svg_content = svg_content.replace("{{TOKEN_LIQUIDITY}}", f"Liquidity: {liquidity}")
        
        # Apply style-specific colors
        if style == "bullish":
            svg_content = svg_content.replace("{{STYLE_COLOR}}", "#00FF00")  # Green
        elif style == "bearish":
            svg_content = svg_content.replace("{{STYLE_COLOR}}", "#FF0000")  # Red
        else:
            svg_content = svg_content.replace("{{STYLE_COLOR}}", "#FFFF00")  # Yellow
        
        # Convert SVG to PNG
        cairosvg.svg2png(bytestring=svg_content.encode("utf-8"), write_to=output_path)
        
        # Add additional image processing if needed
        # For example, adding a token logo, charts, etc.
        
        # Process the final image with PIL if needed
        # (e.g., adding filters, overlays, etc.)
        
        return output_path
    except Exception as e:
        logger.error(f"Error generating meme image: {e}")
        return None

def share_meme(meme_path: str, platform: str, caption: Optional[str] = None) -> bool:
    """
    Share a meme on the specified platform.
    
    Args:
        meme_path: Path to the meme image
        platform: Platform to share on (twitter, telegram)
        caption: Optional caption for the meme
        
    Returns:
        True if shared successfully, False otherwise
    """
    # This would typically use the respective platform APIs
    # For Twitter: twitter API
    # For Telegram: telegram channels or groups
    
    # Placeholder implementation
    logger.info(f"Sharing meme {meme_path} on {platform} with caption: {caption}")
    return True