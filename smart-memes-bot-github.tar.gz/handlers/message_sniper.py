"""
Message-based token sniper for SMART MEMES BOT.

This handler monitors messages in Telegram groups for token launch announcements
and executes trades based on comprehensive safety analysis with multiple fallback mechanisms.
The system uses enhanced API resilience features to maintain functionality even when external
services are experiencing outages.
"""

import logging
import re
import asyncio
import time
from typing import List, Optional, Dict, Any, Tuple
from telegram import Update
from telegram.ext import ContextTypes

# Import enhanced analysis tools with resilience features
from handlers.advanced_safety import analyze_token
from utils.solana_utils import is_valid_solana_address
from utils.trading import execute_trade
from utils.profit_tracker import schedule_price_check
from utils.group_ranker import log_group_performance, get_group_performance
from utils.enhanced_solana_trade import calculate_adjusted_investment
from utils.token_scanner import extract_token_address, detect_token_launch, extract_token_info_from_message, is_potential_rug_pull
from database import create_snipe_transaction, update_snipe_status

# Configure logger
logger = logging.getLogger(__name__)

# Import advanced token scanner
# Enhanced features with auto-detection and safety checks

# Token launch signal keywords (additional keywords defined in token_scanner.py)
LAUNCH_KEYWORDS = [
    "live now", "launching", "just launched", "stealth launch", 
    "chart", "ca:", "contract:", "buy now", "airdrop",
    "is live", "launched on", "fair launch", "dexscreener",
    "birdeye", "raydium", "buy link", "dextools", "address:",
    "dex:", "swap now", "fresh launch", "gem"
]

# Cache for recently processed messages to avoid duplicates
PROCESSED_MESSAGES = {}
MAX_CACHE_SIZE = 100
CACHE_EXPIRY = 3600  # 1 hour

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process incoming messages for potential token launch signals with enhanced resilience.
    
    This improved handler uses the enhanced token scanner to detect token launches
    and has multiple fallback mechanisms to continue functioning even when external
    APIs are experiencing outages.
    
    Args:
        update: Telegram update object
        context: Telegram context
    """
    # Skip if no message or text
    if not update.effective_message or not update.effective_message.text:
        return
        
    # Get message and context details
    message = update.effective_message.text
    message_lower = message.lower()
    group_id = update.effective_chat.id
    group_name = update.effective_chat.title or str(group_id)
    user_id = update.effective_user.id
    
    # Skip processing if message has no keywords (fast pre-check)
    if not any(keyword in message_lower for keyword in LAUNCH_KEYWORDS):
        return
    
    # Check if we've already processed this message recently to avoid duplicates
    if is_already_processed(message):
        logger.debug(f"Skipping already processed message from group '{group_name}'")
        return
    
    logger.info(f"Detected potential launch signal in group '{group_name}' ({group_id})")
    
    # Perform advanced analysis on the message
    try:
        # Use our enhanced analysis for more accurate detection
        message_analysis = await analyze_message_for_tokens(message)
        
        # If not a high-confidence token launch, skip
        if not message_analysis.get("is_token_launch", False) or message_analysis.get("confidence", 0) < 0.5:
            logger.debug(f"Message not identified as high-confidence token launch (confidence: {message_analysis.get('confidence', 0):.2f})")
            return
            
        # Get token details from analysis
        token_address = message_analysis.get("token_address")
        token_symbol = message_analysis.get("token_symbol")
        token_name = message_analysis.get("token_name")
        
        # If we couldn't extract an address, fall back to basic extraction
        if not token_address:
            token_address = extract_token_address(message)
            
        # If still no address, give up
        if not token_address:
            logger.info(f"No valid token address found in message from group {group_name}")
            return
            
        # Check if this might be a rug pull attempt
        if message_analysis.get("is_potential_rug", False):
            rug_warnings = message_analysis.get("rug_warnings", [])
            logger.warning(f"Potential rug pull detected for {token_address}. Warnings: {rug_warnings}")
            # We still proceed but will apply stricter safety checks
            
    except Exception as e:
        # If advanced analysis fails, fall back to simple token extraction
        logger.error(f"Error in advanced message analysis: {str(e)}. Falling back to simple extraction.")
        token_address = extract_token_address(message)
        token_symbol = None
        token_name = None
        
        if not token_address:
            logger.info(f"No valid token address found in message from group {group_name}")
            return
    
    logger.info(f"Extracted token address: {token_address} from group {group_name}")
    
    # Check group performance to adjust investment amount
    try:
        group_performance = await get_group_performance(group_id)
        base_investment = 0.2  # Base investment in SOL (≈ £20)
        adjusted_investment = calculate_adjusted_investment(base_investment, group_name=group_name)
    except Exception as e:
        logger.warning(f"Error getting group performance: {str(e)}. Using default investment.")
        adjusted_investment = 0.2  # Default to base investment if performance data unavailable
    
    # Analyze token with enhanced safety checks and API fallback mechanisms
    await context.bot.send_message(
        chat_id=user_id, 
        text=f"🔍 Analyzing token: `{token_address}`\nFrom group: {group_name}\n\nRunning safety checks...",
        parse_mode="Markdown"
    )
    
    safety_score, safety_summary, token_data = await analyze_token(token_address)
    
    # Check if token passed minimum safety threshold
    if safety_score < 50:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"❌ Token failed safety checks.\n\n{safety_summary}\n\nSkipping this token for your safety.",
            parse_mode="Markdown"
        )
        return
    
    # Determine token name for display
    token_name = token_data.get("market_data", {}).get("token_name", "Unknown Token")
    token_symbol = token_data.get("market_data", {}).get("token_symbol", "???")
    if not token_name or token_name == "Unknown Token" and token_symbol != "???":
        token_name = token_symbol
        
    # Show API status in case of partial data
    api_status = ""
    if "api_status" in token_data:
        successful_apis = sum(1 for status in token_data["api_status"].values() if status == "success")
        total_apis = len(token_data["api_status"])
        api_status = f"\nAPI Status: {successful_apis}/{total_apis} services available"
    
    # Record transaction in database before execution
    transaction_id = create_snipe_transaction(
        token_address=token_address,
        token_name=token_name, 
        group_id=group_id,
        group_name=group_name,
        amount_spent=adjusted_investment,
        status="initiating"
    )
    
    # Execute the trade with resilient error handling
    await context.bot.send_message(
        chat_id=user_id,
        text=(
            f"🚀 *SNIPER ACTIVATED* 🚀\n\n"
            f"*Token:* `{token_name}`\n"
            f"*Address:* `{token_address}`\n"
            f"*Safety Score:* {safety_score}/100\n"
            f"*Group:* {group_name}\n"
            f"*Investment:* {adjusted_investment} SOL\n\n"
            f"Executing transaction..."
        ),
        parse_mode="Markdown"
    )
    
    try:
        # Execute trade with enhanced error handling
        trade_result = await execute_trade(
            token_address=token_address,
            amount_sol=adjusted_investment,
            slippage=2.5  # 2.5% slippage tolerance
        )
        
        if trade_result and trade_result.get("success", False):
            # Extract trade details
            tx_hash = trade_result.get("transaction_hash", "unknown")
            tokens_received = trade_result.get("tokens_received", 0)
            entry_price = trade_result.get("entry_price", 0)
            
            # Update transaction in database
            update_snipe_status(
                snipe_id=transaction_id,
                status="executed",
                transaction_hash=tx_hash,
                tokens_received=tokens_received,
                entry_price=entry_price
            )
            
            # Schedule price tracking for this token
            await schedule_price_check(token_address, transaction_id, entry_price, tokens_received)
            
            # Log group performance for future investment adjustments
            await log_group_performance(group_id, token_address, adjusted_investment)
            
            # Send success message with trade details
            await context.bot.send_message(
                chat_id=user_id,
                text=(
                    f"✅ *SNIPE SUCCESSFUL* ✅\n\n"
                    f"*Token:* `{token_name}`\n"
                    f"*Address:* `{token_address}`\n"
                    f"*Investment:* {adjusted_investment} SOL\n"
                    f"*Tokens Received:* {tokens_received:,.0f}\n"
                    f"*Entry Price:* ${entry_price:.10f}\n"
                    f"*Transaction:* [View Explorer](https://solscan.io/tx/{tx_hash})\n\n"
                    f"Now tracking price performance..."
                ),
                parse_mode="Markdown"
            )
            
        else:
            # Handle trade execution failure
            error = trade_result.get("error", "Unknown error") if trade_result else "Transaction failed"
            
            # Update transaction status
            update_snipe_status(
                snipe_id=transaction_id,
                status="failed",
                error_message=error
            )
            
            # Send failure notification
            await context.bot.send_message(
                chat_id=user_id,
                text=(
                    f"❌ *SNIPE FAILED* ❌\n\n"
                    f"*Token:* `{token_name}`\n"
                    f"*Address:* `{token_address}`\n"
                    f"*Error:* {error}\n\n"
                    f"Please check your wallet balance or try again later."
                ),
                parse_mode="Markdown"
            )
            
    except Exception as e:
        logger.error(f"Error executing snipe for {token_address}: {str(e)}")
        
        # Update transaction with error
        update_snipe_status(
            snipe_id=transaction_id,
            status="error",
            error_message=str(e)
        )
        
        # Send error notification
        await context.bot.send_message(
            chat_id=user_id,
            text=(
                f"❌ *SNIPE ERROR* ❌\n\n"
                f"*Token:* `{token_name}`\n"
                f"*Address:* `{token_address}`\n"
                f"*Error:* {str(e)}\n\n"
                f"The system encountered an error during execution."
            ),
            parse_mode="Markdown"
        )

# Variable definitions for backwards compatibility
SOLANA_ADDRESS_PATTERN = r'\b[1-9A-HJ-NP-Za-km-z]{32,44}\b'
TOKEN_CONTEXT_PATTERN = r'(ca|address|contract)[:\s]*([1-9A-HJ-NP-Za-km-z]{32,44})'

def add_to_processed_cache(message_hash: str) -> None:
    """
    Add a message hash to the processed cache with expiry.
    
    Args:
        message_hash: Hash of the processed message
    """
    current_time = time.time()
    PROCESSED_MESSAGES[message_hash] = current_time
    
    # Clean up expired entries if cache is too large
    if len(PROCESSED_MESSAGES) > MAX_CACHE_SIZE:
        # Remove expired entries
        expired_keys = [k for k, v in PROCESSED_MESSAGES.items() 
                       if current_time - v > CACHE_EXPIRY]
        for key in expired_keys:
            del PROCESSED_MESSAGES[key]
        
        # If still too many, remove oldest
        if len(PROCESSED_MESSAGES) > MAX_CACHE_SIZE:
            # Find oldest entry (with smallest timestamp)
            oldest_timestamp = float('inf')
            oldest_key = None
            for key, timestamp in PROCESSED_MESSAGES.items():
                if timestamp < oldest_timestamp:
                    oldest_timestamp = timestamp
                    oldest_key = key
                    
            # Remove the oldest entry
            if oldest_key:
                del PROCESSED_MESSAGES[oldest_key]

def is_already_processed(message: str) -> bool:
    """
    Check if a message was recently processed.
    
    Args:
        message: Message text
        
    Returns:
        Whether the message was recently processed
    """
    # Create a simple hash of the message
    message_hash = str(hash(message))
    
    # Check if in cache and not expired
    if message_hash in PROCESSED_MESSAGES:
        timestamp = PROCESSED_MESSAGES[message_hash]
        if time.time() - timestamp < CACHE_EXPIRY:
            return True
        
    # Add to cache
    add_to_processed_cache(message_hash)
    return False

async def analyze_message_for_tokens(message: str) -> Dict[str, Any]:
    """
    Perform advanced analysis on a message to extract token information.
    
    Args:
        message: Message text
        
    Returns:
        Dictionary with analysis results
    """
    # Check if this message may be a token launch announcement
    is_launch, confidence, details = detect_token_launch(message)
    
    # Extract comprehensive token information
    token_info = extract_token_info_from_message(message)
    
    # Check for potential rug pull indicators
    is_rug, rug_warnings = is_potential_rug_pull(message)
    
    return {
        "is_token_launch": is_launch,
        "confidence": confidence,
        "token_address": token_info["token_address"],
        "token_symbol": token_info["symbol"],
        "token_name": token_info["name"],
        "network": token_info["network"],
        "addresses_found": token_info["addresses"],
        "is_potential_rug": is_rug,
        "rug_warnings": rug_warnings,
        "keywords_matched": details.get("keyword_matches", [])
    }

def extract_token_address(message: str) -> Optional[str]:
    """
    Extract Solana token address from message text using enhanced token scanner.
    
    This version uses the improved token_scanner utility, but maintains
    backward compatibility with the original function.
    
    Args:
        message: Message text
        
    Returns:
        Token address if found and valid, None otherwise
    """
    # Use enhanced token scanner with improved address detection
    address = None
    
    try:
        # First try to use our enhanced token scanner utility
        token_info = extract_token_info_from_message(message)
        address = token_info.get("token_address")
        
        # Verify it's a valid Solana address
        if address and is_valid_solana_address(address):
            return address
            
    except Exception as e:
        logger.warning(f"Error using enhanced token scanner: {e}. Falling back to regex.")
    
    # If enhanced scanner failed or didn't find a valid address, fall back to regex
    # Try pattern with context (more accurate)
    context_matches = re.findall(TOKEN_CONTEXT_PATTERN, message, re.IGNORECASE)
    if context_matches:
        for _, address in context_matches:
            if is_valid_solana_address(address):
                return address
    
    # Try finding any Solana address pattern
    address_matches = re.findall(SOLANA_ADDRESS_PATTERN, message)
    for address in address_matches:
        if is_valid_solana_address(address):
            return address
            
    return None