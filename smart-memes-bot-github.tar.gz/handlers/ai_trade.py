"""
AI-powered trade handler for SMART MEMES BOT.

This module handles automated token trading based on AI analysis,
with automatic trading decisions and risk management.
"""

import logging
import os
import asyncio
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logger = logging.getLogger(__name__)

# Try importing AI integration
try:
    from ai_integration import get_ai_token_analysis, get_ai_safety_report
    HAS_AI = True
    logger.info("AI integration available for trading")
except ImportError:
    HAS_AI = False
    logger.warning("AI integration not available for trading, using fallbacks")

# Import trading utilities
from utils.trading import calculate_position_size, calculate_exit_strategy
from utils.token_scanner import extract_token_address, is_valid_token_address
from utils.solana_trade import execute_trade, get_wallet_info

# Import database
from database import create_snipe_transaction
from utils.price_tracker import schedule_price_check

# Base investment amount for AI trades (in SOL)
AI_BASE_INVESTMENT_SOL = 0.2

# Safety thresholds for AI trading
MIN_SAFETY_SCORE = 60  # Minimum safety score to allow trading
MIN_POTENTIAL_SCORE = 70  # Minimum potential score to allow trading

async def handle_ai_trade_command(update: Any, context: Any) -> None:
    """
    Handle the /aitrade command with a token address.
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    try:
        # Extract user message
        message_text = update.message.text
        user_id = update.message.from_user.id
        chat_id = update.message.chat_id
        
        # Check if AI is available
        if not HAS_AI:
            await update.message.reply_text(
                "⚠️ AI trading system is currently unavailable. Please try again later."
            )
            return
        
        # Extract token address from message
        token_parts = message_text.split(" ")
        if len(token_parts) < 2:
            await update.message.reply_text(
                "Please provide a token address: /aitrade <token_address>"
            )
            return
        
        # Use token scanner to extract address
        token_address = token_parts[1].strip()
        if not is_valid_token_address(token_address):
            # Try to extract from full message
            extracted_addresses = extract_token_address(message_text)
            if extracted_addresses:
                token_address = extracted_addresses[0]
            else:
                await update.message.reply_text(
                    "Sorry, I couldn't identify a valid token address in your message. "
                    "Please use format: /aitrade <token_address>"
                )
                return
        
        # Send initial response
        processing_message = await update.message.reply_text(
            "🔍 Analyzing token and preparing AI-powered trade recommendation..."
        )
        
        # Get wallet info first to check available balance
        wallet_info = await get_wallet_info()
        available_sol = wallet_info.get("sol_balance", 0)
        
        if available_sol < 0.05:  # Minimum SOL required
            await update.message.reply_text(
                f"⚠️ Insufficient SOL balance for trading. Available: {available_sol:.3f} SOL. "
                f"Minimum required: 0.05 SOL."
            )
            return
        
        # Analyze token with AI
        analysis_result = await get_ai_token_analysis(token_address)
        safety_result = await get_ai_safety_report(token_address)
        
        # Create a combined analysis
        combined_analysis = {
            **analysis_result,
            "safety_score": safety_result.get("safety_score", 0),
            "risks": safety_result.get("risks", []),
            "risk_level": safety_result.get("risk_level", "high")
        }
        
        # Format response message
        response = format_ai_analysis(combined_analysis)
        
        # Send analysis result
        await update.message.reply_text(response)
        
        # Check if this is a safe investment
        safety_score = safety_result.get("safety_score", 0)
        potential_score = analysis_result.get("score", 0)
        recommendation = analysis_result.get("recommendation", "avoid")
        
        if safety_score < MIN_SAFETY_SCORE:
            await update.message.reply_text(
                f"⛔ Safety score too low ({safety_score}/100). "
                f"AI trade has been blocked for your protection."
            )
            return
            
        if potential_score < MIN_POTENTIAL_SCORE:
            await update.message.reply_text(
                f"⚠️ Potential score insufficient ({potential_score}/100). "
                f"AI recommends not trading this token."
            )
            return
            
        # If recommendation is not to buy, don't trade automatically
        if recommendation != "buy":
            await update.message.reply_text(
                f"🔍 AI recommends to {recommendation} this token rather than buy. "
                f"No automatic trade will be executed."
            )
            return
            
        # Calculate position size based on analysis
        position_size = calculate_position_size(combined_analysis, AI_BASE_INVESTMENT_SOL)
        
        # Ensure we have enough balance
        if position_size > available_sol:
            position_size = available_sol * 0.9  # Use 90% of available to leave room for gas
            
        # Double check position size is reasonable
        if position_size < 0.02:  # Minimum viable trade
            await update.message.reply_text(
                f"⚠️ Calculated position size too small: {position_size:.3f} SOL. "
                f"Minimum required: 0.02 SOL."
            )
            return
            
        # Confirm trade with user
        confirmation_message = (
            f"🚀 AI recommends trading this token!\n\n"
            f"• Token: {token_address}\n"
            f"• Position size: {position_size:.3f} SOL\n"
            f"• Safety score: {safety_score}/100\n"
            f"• Potential score: {potential_score}/100\n\n"
            f"Do you want to proceed with this trade?"
        )
        
        # Send confirmation message
        await update.message.reply_text(confirmation_message)
        
        # Store state for follow-up responses
        if not hasattr(context, 'user_data'):
            context.user_data = {}
            
        context.user_data[f'pending_trade_{user_id}'] = {
            'token_address': token_address,
            'position_size': position_size,
            'analysis': combined_analysis
        }
        
    except Exception as e:
        logger.error(f"Error in AI trade handler: {e}")
        await update.message.reply_text(
            "Sorry, there was an error processing your AI trade request. Please try again later."
        )

async def handle_trade_confirmation(update: Any, context: Any) -> None:
    """
    Handle user confirmation for AI trade.
    
    Args:
        update: Telegram update object
        context: Telegram context object
    """
    try:
        message_text = update.message.text.lower()
        user_id = update.message.from_user.id
        
        # Check if there's a pending trade for this user
        pending_key = f'pending_trade_{user_id}'
        if not hasattr(context, 'user_data') or pending_key not in context.user_data:
            await update.message.reply_text(
                "No pending AI trade found. Please use /aitrade <token_address> to start."
            )
            return
            
        # Check if this is a confirmation message
        if 'yes' in message_text or 'confirm' in message_text or 'proceed' in message_text:
            # Get the stored trade data
            trade_data = context.user_data[pending_key]
            token_address = trade_data['token_address']
            position_size = trade_data['position_size']
            analysis = trade_data['analysis']
            
            # Send processing message
            processing_message = await update.message.reply_text(
                f"🔄 Processing AI-powered trade for {position_size:.3f} SOL..."
            )
            
            # Execute the trade
            trade_result = await execute_trade(
                token_address=token_address,
                amount=position_size,
                is_buy=True,
                slippage=0.02  # 2% slippage allowed for AI trades
            )
            
            if not trade_result or not trade_result.get('success'):
                error_message = trade_result.get('error', 'Unknown error')
                await update.message.reply_text(
                    f"❌ Trade failed: {error_message}"
                )
                return
                
            # Trade was successful
            tx_hash = trade_result.get('transaction_hash', 'unknown')
            entry_price = trade_result.get('entry_price', 0)
            tokens_received = trade_result.get('tokens_received', 0)
            
            # Store transaction in database
            transaction_id = await create_snipe_transaction(
                token_address=token_address,
                transaction_hash=tx_hash,
                user_id=user_id,
                amount=position_size,
                entry_price=entry_price
            )
            
            # Schedule price tracking
            if transaction_id:
                schedule_price_check(
                    token_address=token_address,
                    transaction_id=transaction_id,
                    entry_price=entry_price,
                    tokens_received=tokens_received
                )
            
            # Calculate exit strategy
            exit_strategy = calculate_exit_strategy(entry_price, analysis)
            
            # Format success message
            success_message = (
                f"✅ AI-powered trade executed successfully!\n\n"
                f"• Token: {token_address}\n"
                f"• Amount: {position_size:.3f} SOL\n"
                f"• Entry price: {entry_price:.10f}\n"
                f"• Tokens received: {tokens_received:.2f}\n"
                f"• Transaction: {tx_hash}\n\n"
                f"📈 Exit Strategy:\n"
                f"• Stop loss: {exit_strategy['stop_loss']:.10f}\n"
                f"• Take profit 1: {exit_strategy['take_profit_1']:.10f} (30% position)\n"
                f"• Take profit 2: {exit_strategy['take_profit_2']:.10f} (30% position)\n"
                f"• Take profit 3: {exit_strategy['take_profit_3']:.10f} (40% position)\n\n"
                f"🔄 Automated price tracking has been set up."
            )
            
            await update.message.reply_text(success_message)
            
            # Clear the pending trade
            del context.user_data[pending_key]
            
        elif 'no' in message_text or 'cancel' in message_text:
            # User declined the trade
            await update.message.reply_text(
                "AI trade cancelled. Use /aitrade <token_address> to start a new analysis."
            )
            
            # Clear the pending trade
            del context.user_data[pending_key]
            
        else:
            # Not a recognized response
            await update.message.reply_text(
                "Please reply with 'yes' to confirm or 'no' to cancel the trade."
            )
            
    except Exception as e:
        logger.error(f"Error in trade confirmation handler: {e}")
        await update.message.reply_text(
            "Sorry, there was an error processing your trade confirmation. Please try again."
        )

def format_ai_analysis(analysis: Dict[str, Any]) -> str:
    """
    Format AI analysis for display in Telegram.
    
    Args:
        analysis: The token analysis data
        
    Returns:
        Formatted message string
    """
    # Extract important values
    token_address = analysis.get('token_address', 'Unknown')
    score = analysis.get('score', 0)
    verdict = analysis.get('verdict', 'Analysis unavailable')
    recommendation = analysis.get('recommendation', 'avoid')
    safety_score = analysis.get('safety_score', 0)
    risk_level = analysis.get('risk_level', 'unknown')
    risks = analysis.get('risks', [])
    used_ai = analysis.get('used_ai', False)
    
    # Format recommendation emoji
    if recommendation == 'buy':
        rec_emoji = "🟢 BUY"
    elif recommendation == 'watch':
        rec_emoji = "🟡 WATCH"
    elif recommendation == 'caution':
        rec_emoji = "🟠 CAUTION"
    else:
        rec_emoji = "🔴 AVOID"
        
    # Format risk level emoji
    if risk_level == 'low':
        risk_emoji = "🟢 Low"
    elif risk_level == 'medium':
        risk_emoji = "🟡 Medium"
    else:
        risk_emoji = "🔴 High"
        
    # Format AI status
    ai_status = "🧠 AI-Powered Analysis" if used_ai else "📊 Traditional Analysis"
    
    # Create formatted message
    message = (
        f"{ai_status}\n\n"
        f"🪙 Token: {token_address}\n"
        f"🎯 Potential Score: {score}/100\n"
        f"🔒 Safety Score: {safety_score}/100\n"
        f"⚠️ Risk Level: {risk_emoji}\n"
        f"📝 Verdict: {verdict}\n"
        f"🚨 Recommendation: {rec_emoji}\n\n"
    )
    
    # Add risks if any
    if risks:
        message += "🚫 Risk Factors:\n"
        for risk in risks[:5]:  # Show max 5 risks
            message += f"• {risk}\n"
        
        if len(risks) > 5:
            message += f"• ...and {len(risks) - 5} more risks\n"
            
    return message

def register_handlers(dispatcher) -> None:
    """
    Register AI trade handlers with the dispatcher.
    
    Args:
        dispatcher: The bot dispatcher
    """
    try:
        # Import required components
        from telegram.ext import CommandHandler, MessageHandler, filters
        
        # Register command handler
        dispatcher.add_handler(CommandHandler("aitrade", handle_ai_trade_command))
        
        # Register confirmation handler - will pick up messages after an AI trade request
        # This needs to be ordered properly in the dispatcher chain with a higher priority
        # than the default message handler
        dispatcher.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & 
            (filters.Regex(r'(?i)(yes|confirm|proceed|no|cancel).*')),
            handle_trade_confirmation
        ))
        
        logger.info("AI trade handlers registered successfully")
        
    except Exception as e:
        logger.error(f"Error registering AI trade handlers: {e}")

# Handle module initialization
def init_module():
    """Initialize the AI trade module."""
    logger.info("Initializing AI trade module")
    
    # Pre-check the AI system
    if HAS_AI:
        logger.info("AI trading system is available")
    else:
        logger.warning("AI trading system is in limited mode (AI unavailable)")
        
    return True

# Initialize on import
init_module()