"""
Market prediction command handler for SMART MEMES BOT.

This module handles the /marketpredict command to provide AI-powered
price predictions and market sentiment analysis for tokens.
"""

import logging
from typing import Dict, Any, Optional, List

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_info import is_valid_token_address, get_token_info
from utils.market_prediction import (
    predict_token_price, 
    get_market_sentiment,
    format_price_prediction,
    format_sentiment_analysis
)

async def marketpredict(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /marketpredict command - Provide AI-powered market predictions.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_marketpredict(update, context)

async def handle_marketpredict(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the marketpredict command - Generate and send prediction.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Extract token address and parameters from the command
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address to analyze.\n"
            "Usage: /marketpredict <token_address> [options]\n"
            "Options: timeframe=24h/7d/30d, hours=24/48/72, sentiment=yes/no\n"
            "Example: /marketpredict Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu timeframe=7d hours=48 sentiment=yes"
        )
        return
    
    token_address = context.args[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        await update.message.reply_text(
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    time_frame = "24h"
    prediction_hours = 24
    include_sentiment = False
    
    for arg in context.args[1:]:
        if arg.lower().startswith("timeframe="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if value in ["1h", "24h", "7d", "30d"]:
                time_frame = value
            else:
                await update.message.reply_text(
                    f"⚠️ Invalid time frame: {value}. Using default: 24h"
                )
        elif arg.lower().startswith("hours="):
            try:
                value = int(arg.split("=", 1)[1]) if "=" in arg else 24
                if 1 <= value <= 168:
                    prediction_hours = value
                else:
                    await update.message.reply_text(
                        f"⚠️ Hours must be between 1 and 168. Using default: 24"
                    )
            except ValueError:
                await update.message.reply_text(
                    f"⚠️ Invalid hours value: {arg}. Using default: 24"
                )
        elif arg.lower().startswith("sentiment="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            include_sentiment = value in ["yes", "true", "y", "1"]
    
    # Send "analyzing" message
    progress_message = await update.message.reply_text(
        f"🧠 Performing AI market analysis for {token_address}...\n"
        f"Time frame: {time_frame}, Prediction window: {prediction_hours} hours\n"
        "This may take a moment as our neural networks process the data."
    )
    
    try:
        # Get token info for the name/symbol
        token_info = get_token_info(token_address)
        token_name = token_info.get("name", "Unknown")
        token_symbol = token_info.get("symbol", "Unknown")
        
        # Generate price prediction
        prediction_data = predict_token_price(
            token_address,
            time_frame=time_frame,
            prediction_hours=prediction_hours
        )
        
        # Format the prediction
        prediction_text = format_price_prediction(prediction_data)
        
        # Create inline keyboard for additional actions
        keyboard = [
            [
                InlineKeyboardButton("24h Prediction", callback_data=f"predict_24h_{token_address}"),
                InlineKeyboardButton("7d Prediction", callback_data=f"predict_7d_{token_address}")
            ]
        ]
        
        # Add sentiment analysis if requested
        sentiment_text = ""
        if include_sentiment:
            sentiment_data = get_market_sentiment(token_address)
            sentiment_text = "\n\n" + format_sentiment_analysis(sentiment_data)
            
            # Add sentiment button
            keyboard.append([
                InlineKeyboardButton("Full Sentiment Analysis", callback_data=f"sentiment_{token_address}")
            ])
        
        # Add trade buttons
        keyboard.append([
            InlineKeyboardButton("Buy Now", callback_data=f"buy_{token_address}"),
            InlineKeyboardButton("Set Alert", callback_data=f"alert_{token_address}")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Send the prediction
        await progress_message.delete()
        await update.message.reply_text(
            f"{prediction_text}{sentiment_text}",
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    
    except Exception as e:
        logger.error(f"Error generating market prediction: {e}")
        await progress_message.delete()
        await update.message.reply_text(
            f"❌ Error generating market prediction: {str(e)}"
        )

def handle_marketpredict_simple(bot, chat_id, params):
    """
    Process the marketpredict command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # Extract token address and parameters from the command
    if not params or len(params) < 1:
        bot.send_message(
            chat_id,
            "Please provide a token address to analyze.\n"
            "Usage: /marketpredict <token_address> [options]\n"
            "Options: timeframe=24h/7d/30d, hours=24/48/72, sentiment=yes/no\n"
            "Example: /marketpredict Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu timeframe=7d hours=48 sentiment=yes"
        )
        return
    
    token_address = params[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        bot.send_message(
            chat_id,
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    time_frame = "24h"
    prediction_hours = 24
    include_sentiment = False
    
    for arg in params[1:]:
        if arg.lower().startswith("timeframe="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            if value in ["1h", "24h", "7d", "30d"]:
                time_frame = value
            else:
                bot.send_message(
                    chat_id,
                    f"⚠️ Invalid time frame: {value}. Using default: 24h"
                )
        elif arg.lower().startswith("hours="):
            try:
                value = int(arg.split("=", 1)[1]) if "=" in arg else 24
                if 1 <= value <= 168:
                    prediction_hours = value
                else:
                    bot.send_message(
                        chat_id,
                        f"⚠️ Hours must be between 1 and 168. Using default: 24"
                    )
            except ValueError:
                bot.send_message(
                    chat_id,
                    f"⚠️ Invalid hours value: {arg}. Using default: 24"
                )
        elif arg.lower().startswith("sentiment="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            include_sentiment = value in ["yes", "true", "y", "1"]
    
    # Send "analyzing" message
    bot.send_message(
        chat_id,
        f"🧠 Performing AI market analysis for {token_address}...\n"
        f"Time frame: {time_frame}, Prediction window: {prediction_hours} hours\n"
        "This may take a moment as our neural networks process the data."
    )
    
    try:
        # Generate price prediction
        prediction_data = predict_token_price(
            token_address,
            time_frame=time_frame,
            prediction_hours=prediction_hours
        )
        
        # Format the prediction
        prediction_text = format_price_prediction(prediction_data)
        
        # Add sentiment analysis if requested
        sentiment_text = ""
        if include_sentiment:
            sentiment_data = get_market_sentiment(token_address)
            sentiment_text = "\n\n" + format_sentiment_analysis(sentiment_data)
        
        # Send the prediction
        bot.send_message(
            chat_id,
            f"{prediction_text}{sentiment_text}",
            parse_mode="Markdown"
        )
    
    except Exception as e:
        logger.error(f"Error generating market prediction: {e}")
        bot.send_message(
            chat_id,
            f"❌ Error generating market prediction: {str(e)}"
        )