"""
Token safety check command handler for SMART MEMES BOT.

This module handles the /tokensafety command to analyze tokens for security risks.
"""

import logging
import time
from typing import Dict, Any, Optional, List

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_info import is_valid_token_address, get_token_info
from utils.token_safety import check_token_safety, format_safety_report

async def tokensafety(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /tokensafety command - Perform comprehensive token security analysis.
    Works with Telegram's python-telegram-bot library.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    await handle_tokensafety(update, context)

async def handle_tokensafety(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the tokensafety command - Analyze token security.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Extract token address and parameters from the command
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "Please provide a token address to analyze.\n"
            "Usage: /tokensafety <token_address> [options]\n"
            "Options: detailed=yes/no\n"
            "Example: /tokensafety Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu detailed=yes"
        )
        return
    
    token_address = context.args[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        await update.message.reply_text(
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    detailed = False
    
    for arg in context.args[1:]:
        if arg.lower().startswith("detailed="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            detailed = value in ["yes", "true", "y", "1"]
    
    # Send "analyzing" message
    progress_message = await update.message.reply_text(
        f"🔍 Performing comprehensive security analysis for {token_address}...\n"
        "This may take a moment as we check multiple security factors."
    )
    
    try:
        # Start with basic token info
        token_info = get_token_info(token_address)
        
        # Run safety analysis
        start_time = time.time()
        safety_data = check_token_safety(token_address, detailed=detailed)
        analysis_time = time.time() - start_time
        
        # Format safety report
        report = format_safety_report(safety_data, compact=False)
        
        # Create inline keyboard for additional actions
        keyboard = [
            [
                InlineKeyboardButton("Detailed Analysis", callback_data=f"safety_detailed_{token_address}"),
                InlineKeyboardButton("View on Explorer", url=token_info.get("url", ""))
            ],
            [
                InlineKeyboardButton("Buy Token", callback_data=f"safety_buy_{token_address}"),
                InlineKeyboardButton("Monitor Token", callback_data=f"safety_monitor_{token_address}")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Send full report
        await progress_message.delete()
        await update.message.reply_text(
            f"{report}\n\n"
            f"Analysis completed in {analysis_time:.2f} seconds.",
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
        # If very high risk, send additional warning
        safety_score = safety_data.get("safety_score", 0)
        if safety_score < 3:
            await update.message.reply_text(
                "🚨 *CRITICAL SECURITY ALERT* 🚨\n\n"
                "This token has been flagged as extremely high risk by our security system.\n"
                "Trading is strongly discouraged due to multiple severe security concerns.\n\n"
                "If you still wish to proceed, use extreme caution and never invest more than you can afford to lose.",
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Error analyzing token safety: {e}")
        await progress_message.delete()
        await update.message.reply_text(
            f"❌ Error analyzing token safety: {str(e)}"
        )

def handle_tokensafety_simple(bot, chat_id, params):
    """
    Process the tokensafety command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    # Extract token address and parameters from the command
    if not params or len(params) < 1:
        bot.send_message(
            chat_id,
            "Please provide a token address to analyze.\n"
            "Usage: /tokensafety <token_address> [options]\n"
            "Options: detailed=yes/no\n"
            "Example: /tokensafety Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu detailed=yes"
        )
        return
    
    token_address = params[0]
    
    # Validate the token address
    if not is_valid_token_address(token_address):
        bot.send_message(
            chat_id,
            f"❌ Invalid token address format: {token_address}\n"
            "Please provide a valid Solana token address."
        )
        return
    
    # Parse optional parameters
    detailed = False
    
    for arg in params[1:]:
        if arg.lower().startswith("detailed="):
            value = arg.split("=", 1)[1].lower() if "=" in arg else ""
            detailed = value in ["yes", "true", "y", "1"]
    
    # Send "analyzing" message
    bot.send_message(
        chat_id,
        f"🔍 Performing comprehensive security analysis for {token_address}...\n"
        "This may take a moment as we check multiple security factors."
    )
    
    try:
        # Run safety analysis
        start_time = time.time()
        safety_data = check_token_safety(token_address, detailed=detailed)
        analysis_time = time.time() - start_time
        
        # Format safety report
        report = format_safety_report(safety_data, compact=False)
        
        # Send full report
        bot.send_message(
            chat_id,
            f"{report}\n\n"
            f"Analysis completed in {analysis_time:.2f} seconds.",
            parse_mode="Markdown"
        )
        
        # If very high risk, send additional warning
        safety_score = safety_data.get("safety_score", 0)
        if safety_score < 3:
            bot.send_message(
                chat_id,
                "🚨 *CRITICAL SECURITY ALERT* 🚨\n\n"
                "This token has been flagged as extremely high risk by our security system.\n"
                "Trading is strongly discouraged due to multiple severe security concerns.\n\n"
                "If you still wish to proceed, use extreme caution and never invest more than you can afford to lose.",
                parse_mode="Markdown"
            )
    
    except Exception as e:
        logger.error(f"Error analyzing token safety: {e}")
        bot.send_message(
            chat_id,
            f"❌ Error analyzing token safety: {str(e)}"
        )