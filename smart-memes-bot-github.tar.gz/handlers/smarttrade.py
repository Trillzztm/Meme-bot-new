"""
Smart Trade handler for SMART MEMES BOT.

This module provides advanced trading capabilities with AI insights,
profit protection, and trend analysis all in a single command.
"""

import logging
import asyncio
from typing import Dict, Any, List, Optional, Tuple
import time

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram imports
from telegram import Update
from telegram.ext import ContextTypes

# Import our utilities
from utils.token_analyzer import analyze_token, is_valid_token_address
from utils.advanced_trading_core import execute_smart_trade
from utils.market_ai_predictor import predict_token_movement
from database import record_snipe_transaction, update_snipe_status
from config import (
    DEFAULT_SLIPPAGE, MAX_SPEND, DEFAULT_TAKE_PROFIT, 
    DEFAULT_STOP_LOSS, TRAILING_STOP_ENABLED
)

async def smarttrade(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /smarttrade command - AI-enhanced token purchasing with automatic profit taking
    and loss prevention.
    
    Command format:
    /smarttrade <token_address> <amount_in_sol> [options]
    
    Available options:
    • tp=X - Take profit percentage (default: 200%)
    • sl=Y - Stop loss percentage (default: 50%)
    • trail=yes/no - Enable trailing stop loss (default: yes)
    • slippage=Z - Slippage tolerance percentage (default: 0.5%)
    
    Examples:
    /smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.2
    /smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 tp=300 sl=40 trail=yes
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    # Call the handler
    await handle_smarttrade(update, context)

async def handle_smarttrade(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Process the smarttrade command logic.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    try:
        # Check for arguments
        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "🧠 *SMART TRADE Command Usage*\n\n"
                "The smarttrade command combines AI analysis, token safety checks, and profit protection in one command.\n\n"
                "*Required parameters:*\n"
                "• `token_address` - The token's address\n"
                "• `amount` - Amount in SOL to spend\n\n"
                "*Optional parameters:*\n"
                "• `tp=X` - Take profit percentage (default: 200%)\n"
                "• `sl=Y` - Stop loss percentage (default: 50%)\n"
                "• `trail=yes/no` - Enable trailing stop loss (default: yes)\n"
                "• `slippage=Z` - Slippage tolerance percentage (default: 0.5%)\n\n"
                "*Examples:*\n"
                "/smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.2\n"
                "/smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 tp=300 sl=40 trail=yes",
                parse_mode="Markdown"
            )
            return
        
        # Get token address and amount
        token_address = context.args[0]
        
        # Validate token address
        if not is_valid_token_address(token_address):
            await update.message.reply_text(
                "❌ Invalid token address format. Please provide a valid Solana token address."
            )
            return
            
        # Parse amount
        try:
            amount = float(context.args[1])
            if amount <= 0:
                raise ValueError("Amount must be positive")
                
            if amount > MAX_SPEND:
                await update.message.reply_text(
                    f"⚠️ Amount {amount} SOL exceeds maximum ({MAX_SPEND} SOL). "
                    f"Setting to {MAX_SPEND} SOL."
                )
                amount = MAX_SPEND
                
        except ValueError as e:
            await update.message.reply_text(
                f"❌ Invalid amount: {context.args[1]}. Please provide a valid number."
            )
            return
            
        # Parse optional parameters
        take_profit = DEFAULT_TAKE_PROFIT  # Default: 200%
        stop_loss = DEFAULT_STOP_LOSS  # Default: 50%
        trailing_stop = TRAILING_STOP_ENABLED  # Default: True
        slippage = DEFAULT_SLIPPAGE  # Default: 0.5%
        
        for arg in context.args[2:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                key = key.lower()
                
                if key == "tp":
                    try:
                        take_profit = float(value)
                        if take_profit <= 100:
                            await update.message.reply_text(
                                f"⚠️ Take profit value {take_profit}% is below 100% (break-even). "
                                "You might want to increase this value."
                            )
                    except ValueError:
                        await update.message.reply_text(f"Invalid take profit value: {value}. Using default {DEFAULT_TAKE_PROFIT}%.")
                        
                elif key == "sl":
                    try:
                        stop_loss = float(value)
                        if stop_loss < 1 or stop_loss > 99:
                            await update.message.reply_text(
                                f"⚠️ Stop loss value {stop_loss}% is outside the recommended range (1-99%). "
                                f"Setting to {DEFAULT_STOP_LOSS}%."
                            )
                            stop_loss = DEFAULT_STOP_LOSS
                    except ValueError:
                        await update.message.reply_text(f"Invalid stop loss value: {value}. Using default {DEFAULT_STOP_LOSS}%.")
                        
                elif key == "trail":
                    trailing_stop = value.lower() in ["yes", "true", "y", "1"]
                    
                elif key == "slippage":
                    try:
                        slippage = float(value)
                        if slippage < 0.1 or slippage > 50:
                            await update.message.reply_text(
                                f"⚠️ Slippage value {slippage}% is outside the recommended range (0.1-50%). "
                                f"Setting to {DEFAULT_SLIPPAGE}%."
                            )
                            slippage = DEFAULT_SLIPPAGE
                    except ValueError:
                        await update.message.reply_text(f"Invalid slippage value: {value}. Using default {DEFAULT_SLIPPAGE}%.")
        
        # Get user ID for database tracking
        user_id = update.effective_user.id
        
        # Inform user we're proceeding
        progress_message = await update.message.reply_text(
            f"🧠 *AI ANALYSIS IN PROGRESS*\n\n"
            f"Analyzing token {token_address}...\n"
            f"• Running safety checks\n"
            f"• Analyzing market conditions\n"
            f"• Checking liquidity and trading activity\n"
            f"• Generating price prediction",
            parse_mode="Markdown"
        )
        
        try:
            # First, get AI market prediction (don't wait for this to complete the trade)
            prediction_task = asyncio.create_task(
                predict_token_movement(token_address, "24h")
            )
            
            # Execute the trade with profit protection
            trade_result = await execute_smart_trade(
                token_address=token_address,
                amount=amount,
                user_id=user_id,
                slippage=slippage,
                auto_sell=take_profit,
                stop_loss=stop_loss,
                transaction_type="smart"
            )
            
            # Get prediction result (with timeout to prevent hanging)
            try:
                prediction = await asyncio.wait_for(prediction_task, timeout=10)
            except asyncio.TimeoutError:
                prediction = None
                logger.warning(f"AI prediction timed out for {token_address}")
            
            # Check if the trade was successful
            if trade_result.get("success"):
                # Extract information from the result
                token_name = trade_result.get("token_name", "Unknown Token")
                tokens_received = trade_result.get("tokens_received", 0)
                entry_price = trade_result.get("entry_price", 0)
                tx_hash = trade_result.get("transaction_hash", "Unknown")
                safety_score = trade_result.get("safety_score", 0)
                
                # Format explorer URL
                explorer_url = f"https://solscan.io/tx/{tx_hash}"
                
                # Format success message with AI insights
                success_message = (
                    f"✅ *SMART TRADE SUCCESSFUL!*\n\n"
                    f"*Token:* `{token_name}`\n"
                    f"*Amount Spent:* {amount} SOL\n"
                    f"*Tokens Received:* {tokens_received:,.0f}\n"
                    f"*Entry Price:* ${entry_price:.10f}\n"
                    f"*Safety Score:* {safety_score}/10\n"
                    f"*Transaction:* [View on Explorer]({explorer_url})\n\n"
                )
                
                # Add profit protection information
                success_message += (
                    f"*📈 PROFIT PROTECTION:*\n"
                    f"• Take Profit: {take_profit}% (${entry_price * (take_profit/100):.10f})\n"
                    f"• Stop Loss: {stop_loss}% (${entry_price * (1-stop_loss/100):.10f})\n"
                    f"• Trailing Stop: {'Enabled' if trailing_stop else 'Disabled'}\n\n"
                )
                
                # Add AI prediction if available
                if prediction and prediction.get("success"):
                    direction = prediction.get("direction", "neutral")
                    change_percent = prediction.get("predicted_change_percent", 0)
                    confidence = prediction.get("confidence", 0)
                    
                    # Format direction emoji
                    direction_emoji = "🚀" if direction == "bullish" else ("🔴" if direction == "bearish" else "➡️")
                    
                    success_message += (
                        f"*🧠 AI PREDICTION (24h):*\n"
                        f"• Direction: {direction_emoji} {direction.capitalize()}\n"
                        f"• Expected Change: {change_percent:+.2f}%\n"
                        f"• Confidence: {confidence*100:.1f}%\n\n"
                    )
                    
                    # Add recommendation based on prediction
                    if direction == "bullish" and confidence > 0.65:
                        success_message += "💡 *AI Recommendation:* Consider increasing position size\n\n"
                    elif direction == "bearish" and confidence > 0.65:
                        success_message += "💡 *AI Recommendation:* Set tighter stop loss (25%)\n\n"
                
                # Add warnings if any
                warnings = trade_result.get("warnings", [])
                if warnings:
                    warning_text = "\n".join([f"• {w}" for w in warnings[:3]])
                    success_message += (
                        f"*⚠️ RISK FACTORS:*\n{warning_text}\n\n"
                    )
                
                # Send the success message
                await update.message.reply_text(
                    success_message,
                    parse_mode="Markdown",
                    disable_web_page_preview=True
                )
                
                # Clean up progress message
                await progress_message.delete()
                
                # Start price tracking with profit protection
                # This is handled by the core trading system
                
            else:
                # Trade failed
                error_message = trade_result.get("error", "Unknown error")
                
                # Format error message
                failure_message = (
                    f"❌ *SMART TRADE FAILED*\n\n"
                    f"Error: {error_message}\n\n"
                )
                
                # Add AI prediction if available, could still be useful
                if prediction and prediction.get("success"):
                    direction = prediction.get("direction", "neutral")
                    change_percent = prediction.get("predicted_change_percent", 0)
                    confidence = prediction.get("confidence", 0)
                    
                    # Format direction emoji
                    direction_emoji = "🚀" if direction == "bullish" else ("🔴" if direction == "bearish" else "➡️")
                    
                    failure_message += (
                        f"*🧠 AI PREDICTION (24h):*\n"
                        f"• Direction: {direction_emoji} {direction.capitalize()}\n"
                        f"• Expected Change: {change_percent:+.2f}%\n"
                        f"• Confidence: {confidence*100:.1f}%\n\n"
                    )
                
                # Send the failure message
                await update.message.reply_text(
                    failure_message,
                    parse_mode="Markdown"
                )
                
                # Clean up progress message
                await progress_message.delete()
                
        except Exception as e:
            logger.error(f"Error in smarttrade handler: {e}")
            
            # Send error message
            await update.message.reply_text(
                f"❌ An error occurred: {str(e)}\n\n"
                "Please try again with a different token or amount."
            )
            
            # Clean up progress message if it exists
            try:
                await progress_message.delete()
            except:
                pass
            
    except Exception as e:
        logger.error(f"Unexpected error in smarttrade handler: {e}")
        await update.message.reply_text(
            f"❌ An unexpected error occurred: {str(e)}"
        )

async def handle_smarttrade_simple(bot, chat_id, params):
    """
    Process the smarttrade command for the simplified bot implementation.
    
    Args:
        bot: The bot instance
        chat_id: The chat ID to send the response to
        params: The command parameters
    """
    try:
        # Check for arguments
        if not params or len(params) < 2:
            bot.send_message(
                chat_id,
                "🧠 *SMART TRADE Command Usage*\n\n"
                "The smarttrade command combines AI analysis, token safety checks, and profit protection in one command.\n\n"
                "*Required parameters:*\n"
                "• `token_address` - The token's address\n"
                "• `amount` - Amount in SOL to spend\n\n"
                "*Optional parameters:*\n"
                "• `tp=X` - Take profit percentage (default: 200%)\n"
                "• `sl=Y` - Stop loss percentage (default: 50%)\n"
                "• `trail=yes/no` - Enable trailing stop loss (default: yes)\n"
                "• `slippage=Z` - Slippage tolerance percentage (default: 0.5%)\n\n"
                "*Examples:*\n"
                "/smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.2\n"
                "/smarttrade Dn8yfjRKfA4vGdj6xuc8HcM8kn2CHMRPFQJjPBrFZ8Xu 0.5 tp=300 sl=40 trail=yes",
                parse_mode="Markdown"
            )
            return
        
        # Get token address and amount
        token_address = params[0]
        
        # Validate token address
        if not is_valid_token_address(token_address):
            bot.send_message(
                chat_id,
                "❌ Invalid token address format. Please provide a valid Solana token address."
            )
            return
            
        # Parse amount
        try:
            amount = float(params[1])
            if amount <= 0:
                raise ValueError("Amount must be positive")
                
            if amount > MAX_SPEND:
                bot.send_message(
                    chat_id,
                    f"⚠️ Amount {amount} SOL exceeds maximum ({MAX_SPEND} SOL). "
                    f"Setting to {MAX_SPEND} SOL."
                )
                amount = MAX_SPEND
                
        except ValueError as e:
            bot.send_message(
                chat_id,
                f"❌ Invalid amount: {params[1]}. Please provide a valid number."
            )
            return
            
        # Parse optional parameters
        take_profit = DEFAULT_TAKE_PROFIT  # Default: 200%
        stop_loss = DEFAULT_STOP_LOSS  # Default: 50%
        trailing_stop = TRAILING_STOP_ENABLED  # Default: True
        slippage = DEFAULT_SLIPPAGE  # Default: 0.5%
        
        for arg in params[2:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                key = key.lower()
                
                if key == "tp":
                    try:
                        take_profit = float(value)
                        if take_profit <= 100:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Take profit value {take_profit}% is below 100% (break-even). "
                                "You might want to increase this value."
                            )
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid take profit value: {value}. Using default {DEFAULT_TAKE_PROFIT}%.")
                        
                elif key == "sl":
                    try:
                        stop_loss = float(value)
                        if stop_loss < 1 or stop_loss > 99:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Stop loss value {stop_loss}% is outside the recommended range (1-99%). "
                                f"Setting to {DEFAULT_STOP_LOSS}%."
                            )
                            stop_loss = DEFAULT_STOP_LOSS
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid stop loss value: {value}. Using default {DEFAULT_STOP_LOSS}%.")
                        
                elif key == "trail":
                    trailing_stop = value.lower() in ["yes", "true", "y", "1"]
                    
                elif key == "slippage":
                    try:
                        slippage = float(value)
                        if slippage < 0.1 or slippage > 50:
                            bot.send_message(
                                chat_id,
                                f"⚠️ Slippage value {slippage}% is outside the recommended range (0.1-50%). "
                                f"Setting to {DEFAULT_SLIPPAGE}%."
                            )
                            slippage = DEFAULT_SLIPPAGE
                    except ValueError:
                        bot.send_message(chat_id, f"Invalid slippage value: {value}. Using default {DEFAULT_SLIPPAGE}%.")
        
        # Inform user we're proceeding
        progress_message = bot.send_message(
            chat_id,
            f"🧠 *AI ANALYSIS IN PROGRESS*\n\n"
            f"Analyzing token {token_address}...\n"
            f"• Running safety checks\n"
            f"• Analyzing market conditions\n"
            f"• Checking liquidity and trading activity\n"
            f"• Generating price prediction",
            parse_mode="Markdown"
        )
        progress_message_id = progress_message["message_id"]
        
        # Execute this in a background task
        asyncio.create_task(
            execute_smarttrade_simple_background(
                bot=bot,
                chat_id=chat_id,
                token_address=token_address,
                amount=amount,
                slippage=slippage,
                take_profit=take_profit,
                stop_loss=stop_loss,
                trailing_stop=trailing_stop,
                progress_message_id=progress_message_id
            )
        )
        
    except Exception as e:
        logger.error(f"Error in smarttrade simple handler: {e}")
        bot.send_message(
            chat_id,
            f"❌ An unexpected error occurred: {str(e)}"
        )

async def execute_smarttrade_simple_background(
    bot, chat_id, token_address, amount, slippage,
    take_profit, stop_loss, trailing_stop, progress_message_id
):
    """
    Execute the smarttrade operation in a background task for the simplified bot.
    
    This handles the asynchronous parts of the smarttrade command for the simplified bot implementation.
    """
    try:
        # First, get AI market prediction (don't wait for this to complete the trade)
        prediction_task = asyncio.create_task(
            predict_token_movement(token_address, "24h")
        )
        
        # Execute the trade with profit protection
        trade_result = await execute_smart_trade(
            token_address=token_address,
            amount=amount,
            user_id=chat_id,
            slippage=slippage,
            auto_sell=take_profit,
            stop_loss=stop_loss,
            transaction_type="smart"
        )
        
        # Get prediction result (with timeout to prevent hanging)
        try:
            prediction = await asyncio.wait_for(prediction_task, timeout=10)
        except asyncio.TimeoutError:
            prediction = None
            logger.warning(f"AI prediction timed out for {token_address}")
        
        # Check if the trade was successful
        if trade_result.get("success"):
            # Extract information from the result
            token_name = trade_result.get("token_name", "Unknown Token")
            tokens_received = trade_result.get("tokens_received", 0)
            entry_price = trade_result.get("entry_price", 0)
            tx_hash = trade_result.get("transaction_hash", "Unknown")
            safety_score = trade_result.get("safety_score", 0)
            
            # Format explorer URL
            explorer_url = f"https://solscan.io/tx/{tx_hash}"
            
            # Format success message with AI insights
            success_message = (
                f"✅ *SMART TRADE SUCCESSFUL!*\n\n"
                f"*Token:* `{token_name}`\n"
                f"*Amount Spent:* {amount} SOL\n"
                f"*Tokens Received:* {tokens_received:,.0f}\n"
                f"*Entry Price:* ${entry_price:.10f}\n"
                f"*Safety Score:* {safety_score}/10\n"
                f"*Transaction:* [View on Explorer]({explorer_url})\n\n"
            )
            
            # Add profit protection information
            success_message += (
                f"*📈 PROFIT PROTECTION:*\n"
                f"• Take Profit: {take_profit}% (${entry_price * (take_profit/100):.10f})\n"
                f"• Stop Loss: {stop_loss}% (${entry_price * (1-stop_loss/100):.10f})\n"
                f"• Trailing Stop: {'Enabled' if trailing_stop else 'Disabled'}\n\n"
            )
            
            # Add AI prediction if available
            if prediction and prediction.get("success"):
                direction = prediction.get("direction", "neutral")
                change_percent = prediction.get("predicted_change_percent", 0)
                confidence = prediction.get("confidence", 0)
                
                # Format direction emoji
                direction_emoji = "🚀" if direction == "bullish" else ("🔴" if direction == "bearish" else "➡️")
                
                success_message += (
                    f"*🧠 AI PREDICTION (24h):*\n"
                    f"• Direction: {direction_emoji} {direction.capitalize()}\n"
                    f"• Expected Change: {change_percent:+.2f}%\n"
                    f"• Confidence: {confidence*100:.1f}%\n\n"
                )
                
                # Add recommendation based on prediction
                if direction == "bullish" and confidence > 0.65:
                    success_message += "💡 *AI Recommendation:* Consider increasing position size\n\n"
                elif direction == "bearish" and confidence > 0.65:
                    success_message += "💡 *AI Recommendation:* Set tighter stop loss (25%)\n\n"
            
            # Add warnings if any
            warnings = trade_result.get("warnings", [])
            if warnings:
                warning_text = "\n".join([f"• {w}" for w in warnings[:3]])
                success_message += (
                    f"*⚠️ RISK FACTORS:*\n{warning_text}\n\n"
                )
            
            # Send the success message
            bot.send_message(
                chat_id=chat_id,
                text=success_message,
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
            
            # Delete the progress message
            try:
                bot.delete_message(
                    chat_id=chat_id,
                    message_id=progress_message_id
                )
            except:
                pass
            
            # Start price tracking with profit protection
            # This is handled by the core trading system
            
        else:
            # Trade failed
            error_message = trade_result.get("error", "Unknown error")
            
            # Format error message
            failure_message = (
                f"❌ *SMART TRADE FAILED*\n\n"
                f"Error: {error_message}\n\n"
            )
            
            # Add AI prediction if available, could still be useful
            if prediction and prediction.get("success"):
                direction = prediction.get("direction", "neutral")
                change_percent = prediction.get("predicted_change_percent", 0)
                confidence = prediction.get("confidence", 0)
                
                # Format direction emoji
                direction_emoji = "🚀" if direction == "bullish" else ("🔴" if direction == "bearish" else "➡️")
                
                failure_message += (
                    f"*🧠 AI PREDICTION (24h):*\n"
                    f"• Direction: {direction_emoji} {direction.capitalize()}\n"
                    f"• Expected Change: {change_percent:+.2f}%\n"
                    f"• Confidence: {confidence*100:.1f}%\n\n"
                )
            
            # Send the failure message
            bot.send_message(
                chat_id=chat_id,
                text=failure_message,
                parse_mode="Markdown"
            )
            
            # Delete the progress message
            try:
                bot.delete_message(
                    chat_id=chat_id,
                    message_id=progress_message_id
                )
            except:
                pass
            
    except Exception as e:
        logger.error(f"Error in smarttrade background task: {e}")
        
        # Send error message
        bot.send_message(
            chat_id=chat_id,
            text=f"❌ An error occurred: {str(e)}\n\n"
                 "Please try again with a different token or amount."
        )
        
        # Delete the progress message
        try:
            bot.delete_message(
                chat_id=chat_id,
                message_id=progress_message_id
            )
        except:
            pass