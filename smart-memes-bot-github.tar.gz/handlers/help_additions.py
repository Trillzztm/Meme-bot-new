"""
Additional help content for the SMART MEMES BOT.

This module contains help text for complex commands that would make
the main help.py file too large.
"""

# Help content for /topgroups command
topgroups_help = (
    "*📊 TOPGROUPS - Group Performance Tracking*\n\n"
    "View the most profitable Telegram groups based on tracked token performance.\n\n"
    "*Usage:* `/topgroups [limit]`\n\n"
    "*Parameters:*\n"
    "• `limit` - Maximum number of groups to show (default: 5)\n\n"
    "*Features:*\n"
    "• Tracks win/loss ratio of tokens mentioned in groups\n"
    "• Calculates average profit percentage across all tokens\n"
    "• Sorts groups by success rate and profitability\n"
    "• Shows latest token performance for each group\n\n"
    "*Examples:*\n"
    "• `/topgroups` - Shows top 5 most profitable groups\n"
    "• `/topgroups 10` - Shows top 10 most profitable groups\n\n"
    "This command helps you identify which groups consistently share profitable tokens, "
    "allowing you to focus your attention on the most reliable sources."
)

# Help content for /rankedgroups command
rankedgroups_help = (
    "*📈 RANKEDGROUPS - Profit-Optimized Group Ranking*\n\n"
    "Advanced analytics showing the groups with the highest profit potential for auto-sniping.\n\n"
    "*Usage:* `/rankedgroups [limit]`\n\n"
    "*Parameters:*\n"
    "• `limit` - Maximum number of groups to display (default: 5)\n\n"
    "*Features:*\n"
    "• AI-powered ranking algorithm based on profit metrics\n"
    "• Interactive dashboard for group performance analysis\n"
    "• Auto-snipe configuration for each group\n"
    "• Detailed token history with profit/loss tracking\n"
    "• Dynamic investment sizing based on group performance\n\n"
    "*Examples:*\n"
    "• `/rankedgroups` - Shows top 5 ranked groups\n"
    "• `/rankedgroups 10` - Shows top 10 ranked groups\n\n"
    "The ranking system continuously analyzes group performance and automatically adjusts "
    "auto-snipe parameters to optimize your trading. Groups with consistent profitability "
    "receive higher auto-snipe amounts, while poorly performing groups are deprioritized."
)

# Help content for /groupstats command
groupstats_help = (
    "*📈 GROUPSTATS - Group Performance Analysis*\n\n"
    "Detailed statistics and performance metrics for tracked Telegram groups.\n\n"
    "*Usage:* `/groupstats [group_link]`\n\n"
    "*Parameters:*\n"
    "• `group_link` - Optional link to specific group (e.g., t.me/cryptogems)\n\n"
    "*Features:*\n"
    "• Success rate of tokens mentioned in the group\n"
    "• Average profit/loss metrics\n"
    "• Token mention frequency analysis\n"
    "• Performance trends over time\n"
    "• Top-performing tokens from each group\n\n"
    "*Examples:*\n"
    "• `/groupstats` - Shows statistics for all tracked groups\n"
    "• `/groupstats t.me/cryptogems` - Shows statistics for a specific group\n\n"
    "Group statistics help you identify which groups are worth monitoring and which ones "
    "consistently share profitable opportunities. The system analyzes every token mention "
    "and tracks performance over time to build a comprehensive profile of each group."
)

# Help content for /ultimate command
ultimate_help = (
    "*🌟 ULTIMATE - Complete Profit Maximization System*\n\n"
    "The ultimate all-in-one profit generation system that combines all bot capabilities.\n\n"
    "*Usage:* `/ultimate <command> [options]`\n\n"
    "*Commands:*\n"
    "• `start` - Activate the complete Ultimate system\n"
    "• `stop` - Deactivate the Ultimate system\n"
    "• `status` - View current performance and metrics\n"
    "• `mode <profile>` - Set risk tolerance profile\n\n"
    "*Risk Profiles:*\n"
    "• `conservative` - Lower risk, moderate returns\n"
    "• `balanced` - Medium risk, higher returns\n"
    "• `aggressive` - Higher risk, maximum returns\n\n"
    "*Examples:*\n"
    "• `/ultimate start` - Activate the Ultimate system\n"
    "• `/ultimate mode aggressive` - Set to aggressive mode\n"
    "• `/ultimate status` - Check performance statistics\n\n"
    "The Ultimate system combines early token detection, mempool sniping, group monitoring, "
    "momentum trading, and profit optimization into a fully automated profit machine. "
    "Once activated, it continuously hunts for profitable opportunities 24/7 across multiple "
    "Telegram groups, DEXs, and blockchains, managing the entire lifecycle from token detection "
    "to profit taking."
)

# Help content for /reinvest command
reinvest_help = (
    "*📈 REINVEST - Profit Compounding System*\n\n"
    "Track profits and automatically grow your trading capital with the smart reinvestment system.\n\n"
    "*Usage:* `/reinvest <command> [options]`\n\n"
    "*Commands:*\n"
    "• `view` - Show current bag size and reinvestment status (default)\n"
    "• `summary` - View detailed profit statistics and metrics\n"
    "• `history [limit]` - View recent trade history with profits/losses\n"
    "• `set <amount>` - Manually set bag size (admin only)\n\n"
    "*Examples:*\n"
    "• `/reinvest` - Check current reinvestment status\n"
    "• `/reinvest summary` - View comprehensive profit statistics\n"
    "• `/reinvest history 10` - Show last 10 trades\n\n"
    "*Auto-Reinvestment Strategy:*\n"
    "For every 100 SOL in accumulated profits, the system automatically increases your trading "
    "capital (bag size) by 50%. This powerful compounding effect accelerates your profit growth "
    "over time while maintaining disciplined risk management.\n\n"
    "The reinvestment system tracks all your trades, calculates profits, and provides detailed "
    "analytics including win rates and performance metrics."
)