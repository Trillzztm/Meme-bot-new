"""
Command handler for displaying top performing groups.

This command allows users to view a list of the most profitable groups
based on win rate and token mentions.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes

from utils.group_tracker import get_top_groups, get_group_stats_summary

# Configure logger
logger = logging.getLogger(__name__)

async def cmd_topgroups(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show the top performing groups based on profitable token mentions.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
    """
    try:
        # Get summary of group stats
        summary = get_group_stats_summary()
        
        # Get top groups with at least 2 profitable calls
        top_groups = get_top_groups(threshold=2)
        
        # Format message
        if not top_groups:
            message = "📊 *Group Performance*\n\n"
            message += "No groups have reached the minimum threshold of profitable calls yet.\n"
            message += "Groups will appear here once they have had at least 2 profitable token mentions."
        else:
            message = "📊 *Top Performing Groups*\n\n"
            
            for i, (group_name, stats) in enumerate(top_groups[:10]):
                win_rate = (stats["wins"] / stats["mentions"]) * 100 if stats["mentions"] > 0 else 0
                message += f"{i+1}. *{group_name}*\n"
                message += f"   Profitable calls: {stats['wins']}\n"
                message += f"   Total mentions: {stats['mentions']}\n"
                message += f"   Win rate: {win_rate:.1f}%\n\n"
        
        # Send the message
        await update.message.reply_text(
            message,
            parse_mode="Markdown"
        )
        
        logger.info(f"Sent top groups report to user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in cmd_topgroups: {str(e)}")
        await update.message.reply_text(
            "❌ An error occurred while retrieving group performance data."
        )