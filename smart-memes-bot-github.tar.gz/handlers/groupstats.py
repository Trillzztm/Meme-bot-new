"""
Command handler for displaying specific group statistics.

This command allows users to check detailed statistics for a specific Telegram group.
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from utils.group_tracker import group_scores, get_group_win_rate
from utils.group_monitor_handler import GROUP_MONITORS

# Configure logger
logger = logging.getLogger(__name__)

async def cmd_groupstats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show detailed statistics for a specific Telegram group.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
    """
    try:
        # Get the group name from command arguments
        if not context.args or len(context.args) == 0:
            # No group specified, show a list of tracked groups as buttons
            await show_group_selection(update, context)
            return
        
        # Group name is provided, get stats for this group
        group_name = " ".join(context.args)
        await show_group_stats(update, context, group_name)
        
    except Exception as e:
        logger.error(f"Error in cmd_groupstats: {str(e)}")
        await update.message.reply_text(
            "❌ An error occurred while retrieving group statistics."
        )

async def show_group_selection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show a list of tracked groups as buttons.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
    """
    # Get list of all tracked groups
    tracked_groups = []
    
    # From GROUP_MONITORS
    for chat_id, monitor in GROUP_MONITORS.items():
        if monitor and monitor.group_name:
            tracked_groups.append(monitor.group_name)
    
    # From group_scores
    for group_name in group_scores.keys():
        if group_name not in tracked_groups:
            tracked_groups.append(group_name)
    
    if not tracked_groups:
        await update.message.reply_text(
            "No groups are currently being tracked. Use /watchgroup to start monitoring a group."
        )
        return
    
    # Create a keyboard with buttons for each group
    keyboard = []
    row = []
    for i, group_name in enumerate(tracked_groups):
        # Create rows with 2 buttons each
        row.append(InlineKeyboardButton(group_name, callback_data=f"groupstats_{i}"))
        if len(row) == 2 or i == len(tracked_groups) - 1:
            keyboard.append(row)
            row = []
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "Select a group to view detailed statistics:",
        reply_markup=reply_markup
    )
    
    # Store the list of groups in context.user_data for later reference
    if not context.user_data:
        context.user_data = {}
    context.user_data["tracked_groups"] = tracked_groups

async def handle_groupstats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback when a user selects a group from the list.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
    """
    query = update.callback_query
    await query.answer()
    
    # Extract group index from callback data
    if not query.data or not query.data.startswith("groupstats_"):
        return
    
    try:
        group_index = int(query.data[11:])  # Remove "groupstats_" prefix
        
        # Get the tracked groups list from user_data
        tracked_groups = context.user_data.get("tracked_groups", [])
        
        # Validate group index
        if group_index < 0 or group_index >= len(tracked_groups):
            await query.edit_message_text("Invalid group selection.")
            return
        
        # Get selected group name
        group_name = tracked_groups[group_index]
        
        # Show stats for this group
        await show_group_stats(update, context, group_name, query=query)
        
    except Exception as e:
        logger.error(f"Error in handle_groupstats_callback: {str(e)}")
        await query.edit_message_text("An error occurred while retrieving group statistics.")

async def show_group_stats(update: Update, context: ContextTypes.DEFAULT_TYPE, group_name: str, query=None) -> None:
    """
    Show detailed statistics for a specific group.
    
    Args:
        update: The Telegram update object
        context: The Telegram context object
        group_name: The name of the group to show stats for
        query: Optional callback query object if this was triggered by a button press
    """
    # Get stats for this group
    stats = group_scores.get(group_name, {"mentions": 0, "wins": 0, "last_active": None})
    
    # Calculate win rate
    win_rate = get_group_win_rate(group_name)
    
    # Format message
    message = f"📊 *Group Statistics: {group_name}*\n\n"
    message += f"Total token mentions: {stats['mentions']}\n"
    message += f"Profitable calls: {stats['wins']}\n"
    message += f"Win rate: {win_rate:.1f}%\n"
    
    if stats["last_active"]:
        message += f"Last active: {stats['last_active']}\n"
    
    # Add trading advice based on win rate
    if win_rate >= 50:
        message += "\n✅ *Trading Advice*: This group has a high win rate. Consider monitoring it closely for token mentions."
    elif win_rate >= 30:
        message += "\n⚠️ *Trading Advice*: This group has a moderate win rate. Use caution and do your own research."
    elif stats["mentions"] > 0:
        message += "\n❌ *Trading Advice*: This group has a low win rate. Not recommended for token mentions."
    
    # Send or edit the message
    if query:
        await query.edit_message_text(
            message,
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            message,
            parse_mode="Markdown"
        )
    
    logger.info(f"Showed stats for group {group_name} to user {update.effective_user.id}")