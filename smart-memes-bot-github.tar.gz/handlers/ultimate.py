"""
Ultimate Command Handler for SMART MEMES BOT.

This module integrates all profit-making systems into a single command,
transforming the bot into a fully automated money-making machine.

Usage:
/ultimate start - Start all profit systems
/ultimate status - View all systems' statuses and profits
/ultimate mode [conservative/balanced/aggressive] - Set risk profile
"""

import logging
import asyncio
import time
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes, CommandHandler

# Import our advanced profit systems
from utils.early_token_detector import start_monitoring
from utils.mempool_sniper import start_mempool_sniper
from utils.profit_maximizer import start_profit_maximizer, ProfitMaximizer

# Import database utilities for tracking profits
from database import get_user, update_user_settings

# Configure logger
logger = logging.getLogger(__name__)

# Global instance of profit maximizer for stats
profit_maximizer = ProfitMaximizer()

# Tracking for active users
active_users = {}

# Risk profiles with corresponding settings
RISK_PROFILES = {
    "conservative": {
        "max_investment_per_token": 0.05,  # SOL
        "max_active_positions": 3,
        "take_profit_multiplier": 1.5,  # 50% profit target
        "stop_loss_percentage": 0.9,  # 10% stop loss
        "auto_snipe": False,
        "description": "Conservative mode prioritizes capital preservation with small positions, tight stop losses, and conservative profit targets."
    },
    "balanced": {
        "max_investment_per_token": 0.1,  # SOL
        "max_active_positions": 5,
        "take_profit_multiplier": 2.0,  # 100% profit target
        "stop_loss_percentage": 0.8,  # 20% stop loss
        "auto_snipe": True,
        "description": "Balanced mode combines reasonable risk management with good profit potential."
    },
    "aggressive": {
        "max_investment_per_token": 0.3,  # SOL
        "max_active_positions": 10,
        "take_profit_multiplier": 3.0,  # 200% profit target
        "stop_loss_percentage": 0.7,  # 30% stop loss
        "auto_snipe": True,
        "description": "Aggressive mode maximizes profit potential with larger positions and higher risk tolerance."
    }
}

async def ultimate_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /ultimate command.
    
    This command activates the full suite of profit-making capabilities,
    turning the bot into an automated money machine.
    
    Args:
        update: Update object from Telegram
        context: CallbackContext object from Telegram
    """
    try:
        user = update.effective_user
        chat_id = update.effective_chat.id
        
        # Parse arguments
        args = context.args
        
        if not args:
            # No arguments, show usage
            await update.message.reply_text(
                "🚀 *ULTIMATE WEAPON SYSTEM* 🚀\n\n"
                "Unlock the full potential of SMART MEMES BOT's profit-making capabilities:\n\n"
                "📊 */ultimate start* - Activate all profit systems\n"
                "🔍 */ultimate status* - Check system status and profits\n"
                "⚙️ */ultimate mode [conservative/balanced/aggressive]* - Set risk profile\n"
                "❌ */ultimate stop* - Stop all profit systems\n\n"
                "The Ultimate system includes:\n"
                "• Early token detection\n"
                "• Mempool sniping\n"
                "• Profit maximization\n"
                "• Intelligent trailing stops\n"
                "• Multi-layered safety checks\n"
                "• Dynamic position sizing\n",
                parse_mode="Markdown"
            )
            return
        
        command = args[0].lower()
        
        if command == "start":
            # Start all profit systems
            if user.id in active_users:
                await update.message.reply_text("Ultimate systems already running! Use /ultimate status to check progress.")
                return
            
            # Get user settings from the database
            db_user = get_user(user.id)
            if not db_user:
                await update.message.reply_text("Please use /start first to set up your account.")
                return
            
            # Get user's risk profile (default to balanced)
            user_settings = db_user.settings if hasattr(db_user, 'settings') else None
            risk_profile = "balanced"
            
            if user_settings and hasattr(user_settings, 'risk_profile'):
                risk_profile = user_settings.risk_profile
            
            # Activate the systems
            active_users[user.id] = {
                "started_at": datetime.now(),
                "risk_profile": risk_profile,
                "profits": 0.0,
                "trades_executed": 0,
                "active_positions": 0
            }
            
            profile_settings = RISK_PROFILES[risk_profile]
            
            await update.message.reply_text(
                f"🚀 *ULTIMATE WEAPON ACTIVATED* 🚀\n\n"
                f"All profit systems are now running with *{risk_profile}* risk profile:\n\n"
                f"• Max investment per token: {profile_settings['max_investment_per_token']} SOL\n"
                f"• Max active positions: {profile_settings['max_active_positions']}\n"
                f"• Take profit target: {(profile_settings['take_profit_multiplier']-1)*100}%\n"
                f"• Stop loss: {(1-profile_settings['stop_loss_percentage'])*100}%\n"
                f"• Auto-sniping: {'Enabled' if profile_settings['auto_snipe'] else 'Disabled'}\n\n"
                f"The profit machine is now hunting for opportunities 24/7!\n"
                f"Use */ultimate status* to check progress.",
                parse_mode="Markdown"
            )
            
        elif command == "status":
            # Show status of all profit systems
            if user.id not in active_users:
                await update.message.reply_text(
                    "Ultimate profit systems are not running.\n"
                    "Use */ultimate start* to activate them!",
                    parse_mode="Markdown"
                )
                return
            
            user_data = active_users[user.id]
            
            # Get system statistics
            stats = profit_maximizer.get_trade_statistics()
            
            # Calculate runtime
            runtime = datetime.now() - user_data["started_at"]
            hours, remainder = divmod(runtime.total_seconds(), 3600)
            minutes, seconds = divmod(remainder, 60)
            
            # Format the stats message
            await update.message.reply_text(
                f"📊 *ULTIMATE WEAPON STATUS* 📊\n\n"
                f"*Runtime:* {int(hours)}h {int(minutes)}m\n"
                f"*Risk Profile:* {user_data['risk_profile']}\n\n"
                f"*Performance Metrics:*\n"
                f"• Active positions: {stats['active_positions']}\n"
                f"• Completed trades: {stats['total_trades']}\n"
                f"• Win rate: {stats['win_rate']*100:.1f}%\n"
                f"• Total profit: ${stats['total_profit_loss']:.2f}\n\n"
                f"*System Status:*\n"
                f"• Early Token Detector: ✅ Active\n"
                f"• Mempool Sniper: ✅ Active\n"
                f"• Profit Maximizer: ✅ Active\n"
                f"• Safety Checks: ✅ Active\n\n"
                f"Hunting for million-dollar opportunities 24/7!",
                parse_mode="Markdown"
            )
            
        elif command == "mode":
            # Set risk profile
            if len(args) < 2:
                await update.message.reply_text(
                    "Please specify a risk profile:\n"
                    "*/ultimate mode conservative* - Low risk, low reward\n"
                    "*/ultimate mode balanced* - Balanced risk and reward\n"
                    "*/ultimate mode aggressive* - High risk, high reward",
                    parse_mode="Markdown"
                )
                return
            
            risk_profile = args[1].lower()
            
            if risk_profile not in RISK_PROFILES:
                await update.message.reply_text(
                    "Invalid risk profile. Choose from:\n"
                    "*conservative*, *balanced*, or *aggressive*",
                    parse_mode="Markdown"
                )
                return
            
            # Update user settings in database
            update_user_settings(user.id, {"risk_profile": risk_profile})
            
            # Update active user data if systems are running
            if user.id in active_users:
                active_users[user.id]["risk_profile"] = risk_profile
            
            profile_settings = RISK_PROFILES[risk_profile]
            
            await update.message.reply_text(
                f"⚙️ *Risk Profile Updated* ⚙️\n\n"
                f"Risk profile set to *{risk_profile}*\n\n"
                f"*Profile Details:*\n"
                f"• {profile_settings['description']}\n\n"
                f"*Technical Settings:*\n"
                f"• Max investment per token: {profile_settings['max_investment_per_token']} SOL\n"
                f"• Max active positions: {profile_settings['max_active_positions']}\n"
                f"• Take profit target: {(profile_settings['take_profit_multiplier']-1)*100}%\n"
                f"• Stop loss: {(1-profile_settings['stop_loss_percentage'])*100}%\n"
                f"• Auto-sniping: {'Enabled' if profile_settings['auto_snipe'] else 'Disabled'}\n\n"
                f"These settings will be applied to all new trades.",
                parse_mode="Markdown"
            )
            
        elif command == "stop":
            # Stop all profit systems
            if user.id not in active_users:
                await update.message.reply_text("Ultimate profit systems are not running.")
                return
            
            # Remove user from active users
            del active_users[user.id]
            
            await update.message.reply_text(
                "🛑 *ULTIMATE WEAPON DEACTIVATED* 🛑\n\n"
                "All profit systems have been stopped.\n"
                "Use */ultimate start* to reactivate them.",
                parse_mode="Markdown"
            )
        
        else:
            # Unknown command
            await update.message.reply_text(
                "Unknown command. Available commands:\n"
                "*/ultimate start* - Start all profit systems\n"
                "*/ultimate status* - Check system status\n"
                "*/ultimate mode [profile]* - Set risk profile\n"
                "*/ultimate stop* - Stop all profit systems",
                parse_mode="Markdown"
            )
            
    except Exception as e:
        logger.error(f"Error in ultimate command: {str(e)}")
        await update.message.reply_text(f"Error processing command: {str(e)}")

def get_ultimate_handler():
    """Get the CommandHandler for the ultimate command."""
    return CommandHandler("ultimate", ultimate_command)