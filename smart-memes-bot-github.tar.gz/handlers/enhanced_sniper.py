"""
Enhanced Sniper Command Handler for SMART MEMES BOT.

This module provides a command handler for the /enhancedsnipe command,
which allows users to configure and use the enhanced smart sniper with
integrated profit-making systems.
"""

import logging
import json
import asyncio
from typing import Dict, Any, List, Optional

# Telegram imports - using try/except for compatibility with simplified bot
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
    STANDARD_BOT = True
except ImportError:
    # For simplified bot mode
    STANDARD_BOT = False
    Update = None
    InlineKeyboardButton = None
    InlineKeyboardMarkup = None
    ContextTypes = None

# Import enhanced sniper
try:
    from utils.enhanced_smart_sniper import (
        get_smart_sniper, smart_snipe, EnhancedSmartSniper
    )
    SNIPER_AVAILABLE = True
except ImportError:
    SNIPER_AVAILABLE = False
    logging.warning("Enhanced Smart Sniper not available")

# Configure logging
logger = logging.getLogger(__name__)

# Default settings
DEFAULT_SETTINGS = {
    "risk_profile": "balanced",  # conservative, balanced, aggressive
    "enabled": True,
    "auto_snipe": False,  # Auto-snipe without confirmation
    "min_confidence": 0.7,  # Minimum confidence to auto-snipe
    "max_daily_snipes": 10,  # Maximum daily snipes
    "max_position_size": 1.0,  # Maximum position size in SOL
    "notification_level": "all"  # all, successes, failures, none
}

# User settings storage
user_settings = {}

async def enhanced_snipe_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /enhancedsnipe command.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    if not SNIPER_AVAILABLE:
        await update.message.reply_text(
            "❌ Enhanced Smart Sniper is not available on this bot instance.\n"
            "Please contact the bot administrator for assistance.",
            parse_mode="Markdown"
        )
        return
    
    # Get user ID
    user_id = update.effective_user.id
    
    # Get or create user settings
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    user_settings[user_id] = settings
    
    # Check for subcommand
    args = context.args
    subcommand = args[0].lower() if args else "help"
    
    # Handle subcommands
    if subcommand == "status":
        await show_sniper_status(update, context)
    
    elif subcommand == "profile":
        if len(args) > 1:
            profile = args[1].lower()
            if profile in ["conservative", "balanced", "aggressive"]:
                settings["risk_profile"] = profile
                await update.message.reply_text(
                    f"✅ Risk profile set to *{profile}*.",
                    parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    "❌ Invalid risk profile. Valid options are: `conservative`, `balanced`, `aggressive`.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Current risk profile is *{settings['risk_profile']}*.\n"
                "Use `/enhancedsnipe profile [conservative|balanced|aggressive]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "enable" or subcommand == "on":
        settings["enabled"] = True
        await update.message.reply_text(
            "✅ Enhanced Smart Sniper *enabled*.",
            parse_mode="Markdown"
        )
    
    elif subcommand == "disable" or subcommand == "off":
        settings["enabled"] = False
        await update.message.reply_text(
            "✅ Enhanced Smart Sniper *disabled*.",
            parse_mode="Markdown"
        )
    
    elif subcommand == "auto":
        if len(args) > 1:
            auto_setting = args[1].lower()
            if auto_setting in ["on", "true", "yes", "1"]:
                settings["auto_snipe"] = True
                await update.message.reply_text(
                    "✅ Auto-sniping *enabled*. Tokens will be sniped automatically when confidence is above threshold.",
                    parse_mode="Markdown"
                )
            elif auto_setting in ["off", "false", "no", "0"]:
                settings["auto_snipe"] = False
                await update.message.reply_text(
                    "✅ Auto-sniping *disabled*. You'll receive snipe opportunities for manual confirmation.",
                    parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    "❌ Invalid auto-snipe setting. Use `on` or `off`.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Auto-sniping is currently *{'enabled' if settings['auto_snipe'] else 'disabled'}*.\n"
                "Use `/enhancedsnipe auto [on|off]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "confidence":
        if len(args) > 1:
            try:
                confidence = float(args[1])
                if 0 <= confidence <= 1:
                    settings["min_confidence"] = confidence
                    await update.message.reply_text(
                        f"✅ Minimum confidence threshold set to *{confidence:.2f}*.",
                        parse_mode="Markdown"
                    )
                else:
                    await update.message.reply_text(
                        "❌ Confidence must be between 0 and 1.",
                        parse_mode="Markdown"
                    )
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid confidence value. Must be a number between 0 and 1.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Current minimum confidence threshold is *{settings['min_confidence']:.2f}*.\n"
                "Use `/enhancedsnipe confidence [0-1]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "maxsize" or subcommand == "size":
        if len(args) > 1:
            try:
                max_size = float(args[1])
                if max_size > 0:
                    settings["max_position_size"] = max_size
                    await update.message.reply_text(
                        f"✅ Maximum position size set to *{max_size:.2f} SOL*.",
                        parse_mode="Markdown"
                    )
                else:
                    await update.message.reply_text(
                        "❌ Maximum position size must be greater than 0.",
                        parse_mode="Markdown"
                    )
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid position size. Must be a positive number.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Current maximum position size is *{settings['max_position_size']:.2f} SOL*.\n"
                "Use `/enhancedsnipe maxsize [amount]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "maxdaily" or subcommand == "limit":
        if len(args) > 1:
            try:
                max_daily = int(args[1])
                if max_daily > 0:
                    settings["max_daily_snipes"] = max_daily
                    await update.message.reply_text(
                        f"✅ Maximum daily snipes set to *{max_daily}*.",
                        parse_mode="Markdown"
                    )
                else:
                    await update.message.reply_text(
                        "❌ Maximum daily snipes must be greater than 0.",
                        parse_mode="Markdown"
                    )
            except ValueError:
                await update.message.reply_text(
                    "❌ Invalid number. Must be a positive integer.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Current maximum daily snipes is *{settings['max_daily_snipes']}*.\n"
                "Use `/enhancedsnipe maxdaily [number]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "notify":
        if len(args) > 1:
            notify_level = args[1].lower()
            if notify_level in ["all", "successes", "failures", "none"]:
                settings["notification_level"] = notify_level
                await update.message.reply_text(
                    f"✅ Notification level set to *{notify_level}*.",
                    parse_mode="Markdown"
                )
            else:
                await update.message.reply_text(
                    "❌ Invalid notification level. Valid options are: `all`, `successes`, `failures`, `none`.",
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(
                f"Current notification level is *{settings['notification_level']}*.\n"
                "Use `/enhancedsnipe notify [all|successes|failures|none]` to change.",
                parse_mode="Markdown"
            )
    
    elif subcommand == "settings":
        await show_settings(update, context)
    
    elif subcommand == "reset":
        user_settings[user_id] = DEFAULT_SETTINGS.copy()
        await update.message.reply_text(
            "✅ Settings reset to defaults.",
            parse_mode="Markdown"
        )
    
    elif subcommand == "history":
        await show_snipe_history(update, context)
    
    elif subcommand == "help" or subcommand == "?":
        await show_help(update, context)
    
    else:
        # Check if it's a token address
        if len(subcommand) >= 40:  # Likely a token address
            await manual_snipe(update, context, subcommand)
        else:
            await show_help(update, context)

async def show_sniper_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show the current status of the sniper.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    # Get the sniper instance
    try:
        sniper = await get_smart_sniper(settings["risk_profile"])
        
        # Get pending and recent snipes
        pending_snipes = sniper.get_pending_snipes()
        successful_snipes = sniper.get_successful_snipes(5)
        failed_snipes = sniper.get_failed_snipes(5)
        
        # Create status message
        status_message = (
            "🔫 *Enhanced Smart Sniper Status*\n\n"
            f"Status: *{'Enabled' if settings['enabled'] else 'Disabled'}*\n"
            f"Risk Profile: *{settings['risk_profile'].capitalize()}*\n"
            f"Auto-Snipe: *{'Enabled' if settings['auto_snipe'] else 'Disabled'}*\n"
            f"Min Confidence: *{settings['min_confidence']:.2f}*\n"
            f"Max Position: *{settings['max_position_size']:.2f} SOL*\n"
            f"Max Daily Snipes: *{settings['max_daily_snipes']}*\n\n"
            f"Pending Snipes: *{len(pending_snipes)}*\n"
            f"Recent Successful Snipes: *{len(successful_snipes)}*\n"
            f"Recent Failed Snipes: *{len(failed_snipes)}*\n\n"
        )
        
        # Add recent successful snipes
        if successful_snipes:
            status_message += "*Recent Successful Snipes:*\n"
            for snipe in successful_snipes[:3]:  # Show top 3
                token_symbol = snipe.get("token_symbol", "UNKNOWN")
                position_size = snipe.get("position_size", 0)
                executed_at = snipe.get("executed_at", 0)
                status_message += f"• {token_symbol}: {position_size:.2f} SOL\n"
        
        # Create keyboard for other actions
        keyboard = [
            [
                InlineKeyboardButton("📊 History", callback_data="sniper_history"),
                InlineKeyboardButton("⚙️ Settings", callback_data="sniper_settings")
            ],
            [
                InlineKeyboardButton("🔄 Refresh", callback_data="sniper_status"),
                InlineKeyboardButton("❓ Help", callback_data="sniper_help")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            status_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error showing sniper status: {str(e)}")
        await update.message.reply_text(
            f"❌ Error showing sniper status: {str(e)}",
            parse_mode="Markdown"
        )

async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show current settings with buttons to modify.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    settings_message = (
        "⚙️ *Enhanced Smart Sniper Settings*\n\n"
        f"Status: *{'Enabled' if settings['enabled'] else 'Disabled'}*\n"
        f"Risk Profile: *{settings['risk_profile'].capitalize()}*\n"
        f"Auto-Snipe: *{'Enabled' if settings['auto_snipe'] else 'Disabled'}*\n"
        f"Min Confidence: *{settings['min_confidence']:.2f}*\n"
        f"Max Position: *{settings['max_position_size']:.2f} SOL*\n"
        f"Max Daily Snipes: *{settings['max_daily_snipes']}*\n"
        f"Notification Level: *{settings['notification_level'].capitalize()}*\n\n"
        "Use the buttons below to modify settings or `/enhancedsnipe help` for command details."
    )
    
    # Create keyboard for modifying settings
    keyboard = [
        [
            InlineKeyboardButton("🔄 Toggle Status", callback_data="sniper_toggle_status"),
            InlineKeyboardButton("🤖 Toggle Auto", callback_data="sniper_toggle_auto")
        ],
        [
            InlineKeyboardButton("🛡️ Conservative", callback_data="sniper_profile_conservative"),
            InlineKeyboardButton("⚖️ Balanced", callback_data="sniper_profile_balanced"),
            InlineKeyboardButton("🔥 Aggressive", callback_data="sniper_profile_aggressive")
        ],
        [
            InlineKeyboardButton("📊 Status", callback_data="sniper_status"),
            InlineKeyboardButton("🔄 Reset", callback_data="sniper_reset")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            settings_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            settings_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )

async def show_snipe_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show recent snipe history.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    try:
        # Get the sniper instance
        sniper = await get_smart_sniper(settings["risk_profile"])
        
        # Get recent snipes
        successful_snipes = sniper.get_successful_snipes(10)
        failed_snipes = sniper.get_failed_snipes(10)
        
        # Create history message
        history_message = "📜 *Enhanced Smart Sniper History*\n\n"
        
        # Add successful snipes
        if successful_snipes:
            history_message += "*Successful Snipes:*\n"
            for i, snipe in enumerate(successful_snipes):
                token_symbol = snipe.get("token_symbol", "UNKNOWN")
                position_size = snipe.get("position_size", 0)
                result = snipe.get("result", {})
                executed_price = result.get("executed_price", 0)
                executed_amount = result.get("executed_amount", 0)
                
                history_message += f"{i+1}. {token_symbol}: {position_size:.2f} SOL @ {executed_price:.8f}\n"
        else:
            history_message += "*No successful snipes yet.*\n"
        
        history_message += "\n"
        
        # Add failed snipes
        if failed_snipes:
            history_message += "*Failed Snipes:*\n"
            for i, snipe in enumerate(failed_snipes):
                token_symbol = snipe.get("token_symbol", "UNKNOWN")
                error = snipe.get("error", "Unknown error")
                
                history_message += f"{i+1}. {token_symbol}: {error}\n"
        else:
            history_message += "*No failed snipes yet.*\n"
        
        # Create keyboard
        keyboard = [
            [
                InlineKeyboardButton("📊 Status", callback_data="sniper_status"),
                InlineKeyboardButton("⚙️ Settings", callback_data="sniper_settings")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                history_message,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text(
                history_message,
                parse_mode="Markdown",
                reply_markup=reply_markup
            )
        
    except Exception as e:
        logger.error(f"Error showing snipe history: {str(e)}")
        error_message = f"❌ Error showing snipe history: {str(e)}"
        
        if update.callback_query:
            await update.callback_query.edit_message_text(
                error_message,
                parse_mode="Markdown"
            )
        else:
            await update.message.reply_text(
                error_message,
                parse_mode="Markdown"
            )

async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Show help for the enhanced sniper command.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    help_message = (
        "🔫 *Enhanced Smart Sniper Help*\n\n"
        "The Enhanced Smart Sniper integrates all profit-making systems to make intelligent sniping decisions:\n"
        "• AI-powered safety analysis\n"
        "• Twitter signal enhancement\n"
        "• Advanced slippage management\n"
        "• MEV protection\n"
        "• Transaction speed enhancement\n"
        "• Cross-chain arbitrage\n"
        "• AI trade fallback\n\n"
        "*Available Commands:*\n"
        "• `/enhancedsnipe status` - Show current status\n"
        "• `/enhancedsnipe profile [conservative|balanced|aggressive]` - Set risk profile\n"
        "• `/enhancedsnipe enable|disable` - Enable or disable sniper\n"
        "• `/enhancedsnipe auto [on|off]` - Set auto-sniping\n"
        "• `/enhancedsnipe confidence [0-1]` - Set minimum confidence\n"
        "• `/enhancedsnipe maxsize [amount]` - Set maximum position size\n"
        "• `/enhancedsnipe maxdaily [number]` - Set maximum daily snipes\n"
        "• `/enhancedsnipe notify [all|successes|failures|none]` - Set notification level\n"
        "• `/enhancedsnipe settings` - View and modify settings\n"
        "• `/enhancedsnipe history` - Show recent snipe history\n"
        "• `/enhancedsnipe reset` - Reset to default settings\n"
        "• `/enhancedsnipe [token_address]` - Manually snipe a token\n\n"
        "*Risk Profiles:*\n"
        "• *Conservative* - Higher safety thresholds, smaller positions\n"
        "• *Balanced* - Moderate thresholds and position sizes\n"
        "• *Aggressive* - Lower thresholds, larger positions\n\n"
        "Configure your sniper, then sit back and let it find opportunities!"
    )
    
    # Create keyboard
    keyboard = [
        [
            InlineKeyboardButton("📊 Status", callback_data="sniper_status"),
            InlineKeyboardButton("⚙️ Settings", callback_data="sniper_settings")
        ]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(
            help_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            help_message,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )

async def manual_snipe(update: Update, context: ContextTypes.DEFAULT_TYPE, token_address: str) -> None:
    """
    Manually snipe a token.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        token_address: Token address to snipe
    """
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    if not settings["enabled"]:
        await update.message.reply_text(
            "❌ Enhanced Smart Sniper is currently *disabled*.\n"
            "Enable it first with `/enhancedsnipe enable`.",
            parse_mode="Markdown"
        )
        return
    
    try:
        # Inform user that we're analyzing
        processing_message = await update.message.reply_text(
            f"🔍 Analyzing token {token_address}...\n"
            "Please wait while our AI systems evaluate this opportunity.",
            parse_mode="Markdown"
        )
        
        # Perform token analysis
        result = await smart_snipe(
            token_address=token_address,
            risk_profile=settings["risk_profile"]
        )
        
        if result["snipe_scheduled"]:
            # Token passed checks and was scheduled for sniping
            confidence = result.get("confidence", 0)
            position_size = result.get("position_size", 0)
            
            # Apply user's max position size limit
            if position_size > settings["max_position_size"]:
                position_size = settings["max_position_size"]
            
            response = (
                f"✅ *Token Approved for Sniping*\n\n"
                f"Token: `{token_address}`\n"
                f"Confidence: *{confidence:.2f}*\n"
                f"Position Size: *{position_size:.4f} SOL*\n\n"
            )
            
            # Add evaluation details
            if "evaluation" in result:
                eval_data = result["evaluation"]
                
                if "safety_score" in eval_data:
                    response += f"Safety Score: *{eval_data['safety_score']:.2f}*\n"
                
                if "reasons" in eval_data and eval_data["reasons"]:
                    response += f"Reasons: *{', '.join(eval_data['reasons'])}*\n"
                
                if "exit_strategy" in eval_data:
                    strategy = eval_data["exit_strategy"]
                    response += (
                        f"Exit Strategy: *Take Profit {strategy['take_profit']*100}%, "
                        f"Stop Loss {strategy['stop_loss']*100}%, "
                        f"Trailing Stop {strategy['trailing_stop']*100}%*\n"
                    )
            
            response += (
                f"\nThe sniper is now *monitoring* this token and will execute the trade "
                f"based on your settings."
            )
            
            # Update the processing message
            await processing_message.edit_text(
                response,
                parse_mode="Markdown"
            )
            
        else:
            # Token failed checks
            reasons = result.get("reasons", ["Unknown reason"])
            
            response = (
                f"❌ *Token Rejected for Sniping*\n\n"
                f"Token: `{token_address}`\n"
                f"Rejection Reasons:\n"
            )
            
            for reason in reasons:
                response += f"• {reason}\n"
            
            response += (
                f"\nThis token did not meet the criteria for the *{settings['risk_profile']}* risk profile. "
                f"You can try again with a different risk profile or another token."
            )
            
            # Update the processing message
            await processing_message.edit_text(
                response,
                parse_mode="Markdown"
            )
        
    except Exception as e:
        logger.error(f"Error in manual snipe: {str(e)}")
        await update.message.reply_text(
            f"❌ Error analyzing token: {str(e)}",
            parse_mode="Markdown"
        )

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle callback queries from inline keyboards.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
    """
    query = update.callback_query
    await query.answer()
    
    # Get user ID and settings
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    # Handle different callback data
    if query.data == "sniper_status":
        await show_sniper_status(update, context)
    
    elif query.data == "sniper_settings":
        await show_settings(update, context)
    
    elif query.data == "sniper_history":
        await show_snipe_history(update, context)
    
    elif query.data == "sniper_help":
        await show_help(update, context)
    
    elif query.data == "sniper_toggle_status":
        # Toggle enabled status
        settings["enabled"] = not settings["enabled"]
        await show_settings(update, context)
    
    elif query.data == "sniper_toggle_auto":
        # Toggle auto-snipe
        settings["auto_snipe"] = not settings["auto_snipe"]
        await show_settings(update, context)
    
    elif query.data.startswith("sniper_profile_"):
        # Set risk profile
        profile = query.data.split("_")[2]
        if profile in ["conservative", "balanced", "aggressive"]:
            settings["risk_profile"] = profile
            
            # Update the sniper instance
            if SNIPER_AVAILABLE:
                sniper = await get_smart_sniper(profile)
            
            await show_settings(update, context)
    
    elif query.data == "sniper_reset":
        # Reset settings to defaults
        user_settings[user_id] = DEFAULT_SETTINGS.copy()
        await show_settings(update, context)
    
    else:
        logger.warning(f"Unknown callback query: {query.data}")

def register_handlers(dispatcher) -> None:
    """
    Register handlers for the enhanced sniper command.
    
    Args:
        dispatcher: The dispatcher to register handlers with
    """
    if not STANDARD_BOT:
        logger.warning("Standard bot not available, skipping handler registration")
        return
    
    dispatcher.add_handler(CommandHandler("enhancedsnipe", enhanced_snipe_command))
    dispatcher.add_handler(CallbackQueryHandler(handle_callback_query, pattern="^sniper_"))
    
    logger.info("Enhanced sniper handlers registered")

# For simplified bot compatibility
def handle_enhanced_snipe_command(bot, update) -> None:
    """
    Handle the /enhancedsnipe command for simplified bot.
    
    Args:
        bot: The bot instance
        update: The update object
    """
    if not SNIPER_AVAILABLE:
        bot.send_message(
            update.chat.id,
            "❌ Enhanced Smart Sniper is not available on this bot instance.\n"
            "Please contact the bot administrator for assistance."
        )
        return
    
    # Get user ID
    user_id = update.from_user.id
    
    # Get or create user settings
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    user_settings[user_id] = settings
    
    # Check for subcommand
    text = update.text.split()
    subcommand = text[1].lower() if len(text) > 1 else "help"
    
    # Define response based on subcommand
    if subcommand == "status":
        response = (
            "🔫 *Enhanced Smart Sniper Status*\n\n"
            f"Status: *{'Enabled' if settings['enabled'] else 'Disabled'}*\n"
            f"Risk Profile: *{settings['risk_profile'].capitalize()}*\n"
            f"Auto-Snipe: *{'Enabled' if settings['auto_snipe'] else 'Disabled'}*\n"
            f"Min Confidence: *{settings['min_confidence']:.2f}*\n"
            f"Max Position: *{settings['max_position_size']:.2f} SOL*\n"
            f"Max Daily Snipes: *{settings['max_daily_snipes']}*\n"
        )
    
    elif subcommand == "help":
        response = (
            "🔫 *Enhanced Smart Sniper Help*\n\n"
            "The Enhanced Smart Sniper integrates all profit-making systems for intelligent sniping.\n\n"
            "*Available Commands:*\n"
            "• `/enhancedsnipe status` - Show current status\n"
            "• `/enhancedsnipe profile [conservative|balanced|aggressive]` - Set risk profile\n"
            "• `/enhancedsnipe enable|disable` - Enable or disable sniper\n"
            "• `/enhancedsnipe auto [on|off]` - Set auto-sniping\n"
            "• `/enhancedsnipe settings` - View settings\n"
        )
    
    else:
        response = "Use `/enhancedsnipe help` to see available commands."
    
    bot.send_message(update.chat.id, response, parse_mode="Markdown")

# Example of how to handle token mention with the enhanced sniper
async def process_token_mention(update: Update, context: ContextTypes.DEFAULT_TYPE, 
                               token_address: str, token_symbol: str, 
                               group_score: float, message_text: str) -> None:
    """
    Process a token mention and evaluate it for potential sniping.
    
    Args:
        update: The update object from Telegram
        context: The context object from Telegram
        token_address: Token address
        token_symbol: Token symbol
        group_score: Score for the group where token was mentioned
        message_text: The message text that mentioned the token
    """
    # Skip if sniper not available
    if not SNIPER_AVAILABLE:
        return
    
    # Get user ID and settings
    user_id = update.effective_user.id
    settings = user_settings.get(user_id, DEFAULT_SETTINGS.copy())
    
    # Skip if disabled
    if not settings["enabled"]:
        return
    
    # Perform analysis
    try:
        result = await smart_snipe(
            token_address=token_address,
            token_symbol=token_symbol,
            group_score=group_score,
            message_text=message_text,
            risk_profile=settings["risk_profile"]
        )
        
        # If token passed checks and meets the confidence threshold
        if result["snipe_scheduled"] and result.get("confidence", 0) >= settings["min_confidence"]:
            position_size = min(result["position_size"], settings["max_position_size"])
            
            # If auto-snipe is enabled, no need to notify the user
            if settings["auto_snipe"]:
                # Only notify based on notification settings
                if settings["notification_level"] in ["all", "successes"]:
                    await update.message.reply_text(
                        f"🚨 *Auto-Sniping Token*\n\n"
                        f"Token: `{token_address}`\n"
                        f"Symbol: {token_symbol}\n"
                        f"Confidence: {result['confidence']:.2f}\n"
                        f"Position Size: {position_size:.4f} SOL\n\n"
                        f"Auto-sniping is executing this trade automatically.",
                        parse_mode="Markdown"
                    )
            else:
                # Create notification with buttons for user to confirm or reject
                keyboard = [
                    [
                        InlineKeyboardButton("✅ Snipe Now", callback_data=f"snipe_confirm_{token_address}"),
                        InlineKeyboardButton("❌ Reject", callback_data=f"snipe_reject_{token_address}")
                    ],
                    [
                        InlineKeyboardButton("📊 View Analysis", callback_data=f"snipe_analysis_{token_address}")
                    ]
                ]
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.message.reply_text(
                    f"🚨 *New Snipe Opportunity Detected*\n\n"
                    f"Token: `{token_address}`\n"
                    f"Symbol: {token_symbol}\n"
                    f"Confidence: {result['confidence']:.2f}\n"
                    f"Position Size: {position_size:.4f} SOL\n\n"
                    f"This token matches your snipe criteria with {result['confidence']*100:.0f}% confidence.\n"
                    f"Do you want to snipe it?",
                    parse_mode="Markdown",
                    reply_markup=reply_markup
                )
    
    except Exception as e:
        logger.error(f"Error processing token mention: {str(e)}")
        # No need to notify the user about background processing errors