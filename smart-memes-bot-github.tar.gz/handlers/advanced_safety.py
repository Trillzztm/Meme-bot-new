"""
Advanced token safety handler for SMART MEMES BOT.

This module provides comprehensive API-based token safety checks,
integrated with our enhanced blockchain-based analysis.
"""

import logging
import asyncio
from typing import Dict, Any, Tuple, List

# Import real blockchain integration
from utils.enhanced_token_safety import check_token_safety as blockchain_safety_check
from utils.token_safety import check_birdeye_liquidity
from utils.pricing import get_token_metrics

# Configure logger
logger = logging.getLogger(__name__)

async def analyze_token(token_address: str) -> Tuple[int, str, Dict[str, Any]]:
    """
    Comprehensive token analysis integrating multiple sources with robust error handling.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Tuple containing:
        - Safety score (0-100)
        - Summary message 
        - Detailed token data with API status
    """
    # Initialize token data with API status tracking
    token_data = {
        "address": token_address,
        "safety_score": 0,
        "blockchain_safe": False,
        "warnings": [],
        "api_status": {
            "blockchain_api": "pending",
            "liquidity_api": "pending",
            "metrics_api": "pending"
        },
        "market_data": {
            "price": 0,
            "liquidity": 0,
            "volume_24h": 0,
            "market_cap": 0,
            "holders": 0,
            "token_symbol": "",
            "token_name": ""
        },
        "blockchain_details": {},
        "metrics": {}
    }
    
    try:
        # Start parallel API and blockchain checks
        safety_tasks = [
            blockchain_safety_check(token_address),
            check_birdeye_liquidity(token_address),
            get_token_metrics(token_address)
        ]
        
        # Wait for all checks to complete
        results = await asyncio.gather(*safety_tasks, return_exceptions=True)
        
        # Process blockchain safety check
        blockchain_safe = False
        blockchain_details = {}
        if isinstance(results[0], Exception):
            logger.error(f"Blockchain safety check error: {str(results[0])}")
            token_data["api_status"]["blockchain_api"] = f"error: {str(results[0])}"
            token_data["warnings"].append("Blockchain API error")
        elif isinstance(results[0], tuple) and len(results[0]) == 2:
            blockchain_safe, blockchain_details = results[0]
            token_data["api_status"]["blockchain_api"] = "success"
            token_data["blockchain_safe"] = blockchain_safe
            token_data["blockchain_details"] = blockchain_details
        else:
            logger.warning(f"Unexpected blockchain safety check result: {results[0]}")
            token_data["api_status"]["blockchain_api"] = "error: unexpected result format"
            
        # Process Birdeye liquidity check
        birdeye_score = 0
        birdeye_warnings = []
        if isinstance(results[1], Exception):
            logger.error(f"Liquidity check error: {str(results[1])}")
            token_data["api_status"]["liquidity_api"] = f"error: {str(results[1])}"
            token_data["warnings"].append("Liquidity API error")
        elif isinstance(results[1], dict):
            birdeye_data = results[1]
            birdeye_score = birdeye_data.get("score", 0)
            birdeye_warnings = birdeye_data.get("warnings", [])
            token_data["api_status"]["liquidity_api"] = "success"
            token_data["liquidity_score"] = birdeye_score
        else:
            logger.warning(f"Unexpected liquidity check result: {results[1]}")
            token_data["api_status"]["liquidity_api"] = "error: unexpected result format"
            
        # Process token metrics
        metrics = {}
        if isinstance(results[2], Exception):
            logger.error(f"Token metrics error: {str(results[2])}")
            token_data["api_status"]["metrics_api"] = f"error: {str(results[2])}"
            token_data["warnings"].append("Token metrics API error")
        elif isinstance(results[2], dict):
            metrics = results[2]
            token_data["metrics"] = metrics
            if metrics.get("success", False):
                token_data["api_status"]["metrics_api"] = "success"
                # Update market data
                token_data["market_data"]["price"] = metrics.get("price", 0)
                token_data["market_data"]["liquidity"] = metrics.get("liquidity", 0)
                token_data["market_data"]["volume_24h"] = metrics.get("volume_24h", 0)
                token_data["market_data"]["market_cap"] = metrics.get("market_cap", 0)
                token_data["market_data"]["holders"] = metrics.get("holders_count", 0)
                token_data["market_data"]["token_symbol"] = metrics.get("token_symbol", "")
                token_data["market_data"]["token_name"] = metrics.get("token_name", "")
            else:
                token_data["api_status"]["metrics_api"] = f"error: {metrics.get('error', 'unknown error')}"
        else:
            logger.warning(f"Unexpected metrics result: {results[2]}")
            token_data["api_status"]["metrics_api"] = "error: unexpected result format"
            
        # Compile warnings from all sources
        if "warnings" in blockchain_details:
            token_data["warnings"].extend(blockchain_details.get("warnings", []))
        token_data["warnings"].extend(birdeye_warnings)
        
        # Calculate combined safety score (weighted)
        # 50% weight to blockchain analysis, 30% to liquidity, 20% to metrics
        combined_score = 0
        weight_total = 0
        
        if blockchain_safe:
            blockchain_score = blockchain_details.get("safety_score", 70)
            combined_score += blockchain_score * 0.5
            weight_total += 0.5
            
        if birdeye_score > 0:
            combined_score += birdeye_score * 0.3
            weight_total += 0.3
            
        if metrics and metrics.get("success", False):
            # Derive score from metrics
            metrics_score = 70  # Default moderate score
            # Adjust based on liquidity
            if metrics.get("liquidity", 0) > 100000:
                metrics_score = 90
            elif metrics.get("liquidity", 0) > 50000:
                metrics_score = 80
            elif metrics.get("liquidity", 0) < 10000:
                metrics_score = 60
                if "Low liquidity token" not in token_data["warnings"]:
                    token_data["warnings"].append("Low liquidity token")
                
            combined_score += metrics_score * 0.2
            weight_total += 0.2
        
        # Normalize score based on available data
        final_score = 0
        if weight_total > 0:
            final_score = int(combined_score / weight_total)
        else:
            # If we have no data at all, make it clear this is a fallback score
            token_data["warnings"].append("Score based on limited data")
            final_score = 30  # Very conservative score when no data is available
        
        # Update the token data with the final safety score
        token_data["safety_score"] = final_score
        
        # Generate summary based on score
        summary = ""
        if final_score >= 80:
            summary = "✅ Token appears safe with good liquidity."
        elif final_score >= 60:
            summary = "⚠️ Token has passed basic safety checks."
        else:
            summary = "❌ Token failed safety checks - high risk."
            
        # Add warnings to summary if present
        if token_data["warnings"]:
            summary += "\nWarnings:\n• " + "\n• ".join(token_data["warnings"][:3])
            if len(token_data["warnings"]) > 3:
                summary += f"\n• ...and {len(token_data['warnings']) - 3} more issues"
        
        # Add API status summary
        successful_apis = sum(1 for status in token_data["api_status"].values() if status == "success")
        total_apis = len(token_data["api_status"])
        summary += f"\n\nAPI Status: {successful_apis}/{total_apis} services available"
        
        return final_score, summary, token_data
        
    except Exception as e:
        logger.error(f"Error analyzing token: {str(e)}")
        token_data["warnings"].append(f"Analysis error: {str(e)}")
        return 0, f"❌ Error analyzing token: {str(e)}", token_data