"""
Quick Connect for SMART MEMES BOT

This simplified web interface allows quick connection to your Phantom wallet
and starts the money-making system with minimal setup.
"""

import os
from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
import logging
import json
import time
from datetime import datetime, timedelta

# Import our modules
import phantom_direct_connector as phantom
import jupiter_trading as jupiter

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("QuickConnect")

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET") or "smart_memes_secret_key"

# Global variables to track system status
system_status = {
    "wallet_connected": False,
    "trading_active": False,
    "last_status_update": datetime.now().isoformat(),
    "profits": {"total_usd": 0, "last_24h": 0, "trades_count": 0}
}

@app.route('/')
def home():
    """Home page with quick connect interface"""
    # Get wallet status
    wallet_connected = phantom.is_wallet_connected()
    if wallet_connected:
        wallet_balance = phantom.get_wallet_balance()
        if "error" in wallet_balance:
            wallet_connected = False
    else:
        wallet_balance = None
    
    # Update system status
    system_status["wallet_connected"] = wallet_connected
    
    # Get profit stats if wallet is connected
    if wallet_connected:
        profit_stats = jupiter.get_profit_stats()
        system_status["profits"] = {
            "total_usd": profit_stats["total_profit_usd"],
            "trades_count": profit_stats["trades_count"],
            "avg_profit_per_trade": profit_stats["avg_profit_per_trade"]
        }
    
    return render_template('quick_connect.html', 
                          wallet_connected=wallet_connected,
                          wallet_balance=wallet_balance,
                          system_status=system_status)

@app.route('/connect', methods=['POST'])
def connect_wallet():
    """Connect to Phantom wallet"""
    try:
        wallet_address = request.form.get('wallet_address')
        if not wallet_address:
            flash("Please enter a wallet address", "error")
            return redirect(url_for('home'))
        
        # Store the private key securely in environment variables
        private_key = request.form.get('private_key')
        if private_key:
            os.environ["SOLANA_PRIVATE_KEY"] = private_key
        
        connect_result = phantom.connect_phantom_wallet(wallet_address)
        
        if connect_result:
            flash("Successfully connected to Phantom wallet!", "success")
            system_status["wallet_connected"] = True
            system_status["last_status_update"] = datetime.now().isoformat()
        else:
            flash("Failed to connect to Phantom wallet. Please try again.", "error")
        
        return redirect(url_for('home'))
    except Exception as e:
        logger.error(f"Error connecting wallet: {e}")
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('home'))

@app.route('/disconnect', methods=['POST'])
def disconnect_wallet():
    """Disconnect from Phantom wallet"""
    try:
        disconnect_result = phantom.disconnect_phantom_wallet()
        
        if disconnect_result:
            flash("Successfully disconnected from Phantom wallet!", "success")
            system_status["wallet_connected"] = False
            system_status["last_status_update"] = datetime.now().isoformat()
        else:
            flash("Failed to disconnect from Phantom wallet. Please try again.", "error")
        
        return redirect(url_for('home'))
    except Exception as e:
        logger.error(f"Error disconnecting wallet: {e}")
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('home'))

@app.route('/start_trading', methods=['POST'])
def start_trading():
    """Start the money-making system"""
    if not phantom.is_wallet_connected():
        flash("Please connect your wallet first", "error")
        return redirect(url_for('home'))
    
    try:
        # Here you would start your trading system
        # For now, we'll just update the status
        system_status["trading_active"] = True
        system_status["last_status_update"] = datetime.now().isoformat()
        flash("Money-making system started successfully!", "success")
        
        # You'd call your actual trading system startup here
        # Example: trade_system.start()
        
        return redirect(url_for('home'))
    except Exception as e:
        logger.error(f"Error starting trading: {e}")
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('home'))

@app.route('/stop_trading', methods=['POST'])
def stop_trading():
    """Stop the money-making system"""
    try:
        # Here you would stop your trading system
        # For now, we'll just update the status
        system_status["trading_active"] = False
        system_status["last_status_update"] = datetime.now().isoformat()
        flash("Money-making system stopped", "info")
        
        # You'd call your actual trading system shutdown here
        # Example: trade_system.stop()
        
        return redirect(url_for('home'))
    except Exception as e:
        logger.error(f"Error stopping trading: {e}")
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('home'))

@app.route('/system_status', methods=['GET'])
def get_system_status():
    """Get the current system status as JSON"""
    # Update the wallet connection status
    system_status["wallet_connected"] = phantom.is_wallet_connected()
    
    # If wallet is connected, update profit stats
    if system_status["wallet_connected"]:
        profit_stats = jupiter.get_profit_stats()
        system_status["profits"] = {
            "total_usd": profit_stats["total_profit_usd"],
            "trades_count": profit_stats["trades_count"],
            "avg_profit_per_trade": profit_stats["avg_profit_per_trade"]
        }
    
    return jsonify(system_status)

@app.route('/test_trade', methods=['POST'])
def test_trade():
    """Execute a test trade"""
    if not phantom.is_wallet_connected():
        flash("Please connect your wallet first", "error")
        return redirect(url_for('home'))
    
    try:
        # Execute a small test trade
        # For demonstration, we'll buy a small amount of a token
        token_mint = "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU"  # SAMO token
        sol_amount = 0.01  # Very small amount for testing
        
        result = jupiter.buy_token_with_sol(token_mint, sol_amount)
        
        if result and result.get("success"):
            flash(f"Test trade successful! Bought token with {sol_amount} SOL", "success")
        else:
            error_msg = result.get("error") or "Unknown error"
            flash(f"Test trade failed: {error_msg}", "error")
        
        return redirect(url_for('home'))
    except Exception as e:
        logger.error(f"Error executing test trade: {e}")
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('home'))

if __name__ == "__main__":
    # Create template directory if it doesn't exist
    os.makedirs("templates", exist_ok=True)
    
    # Create the template file
    template_path = os.path.join("templates", "quick_connect.html")
    if not os.path.exists(template_path):
        with open(template_path, "w") as f:
            f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART MEMES BOT - Quick Connect</title>
    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
    <style>
        .profit-card {
            background-color: rgba(40, 167, 69, 0.2);
            border-left: 4px solid #28a745;
        }
        .wallet-card {
            background-color: rgba(0, 123, 255, 0.2);
            border-left: 4px solid #007bff;
        }
        .system-card {
            background-color: rgba(255, 193, 7, 0.2);
            border-left: 4px solid #ffc107;
        }
    </style>
</head>
<body>
    <div class="container my-4">
        <div class="row">
            <div class="col-12">
                <h1 class="display-4 text-center mb-4">SMART MEMES BOT</h1>
                <h3 class="text-center mb-5">Quick Connect & Money-Maker</h3>
                
                {% with messages = get_flashed_messages(with_categories=true) %}
                    {% if messages %}
                        {% for category, message in messages %}
                            <div class="alert alert-{{ category if category != 'error' else 'danger' }} alert-dismissible fade show" role="alert">
                                {{ message }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        {% endfor %}
                    {% endif %}
                {% endwith %}
                
                <div class="row">
                    <!-- Wallet Connection -->
                    <div class="col-md-6 mb-4">
                        <div class="card wallet-card h-100">
                            <div class="card-body">
                                <h4 class="card-title">Phantom Wallet Connection</h4>
                                {% if wallet_connected %}
                                    <div class="alert alert-success">
                                        <strong>Connected to wallet:</strong> {{ wallet_balance.address }}
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Balance:</span>
                                        <strong>{{ wallet_balance.balance_sol }} SOL (≈ ${{ wallet_balance.balance_usd|round(2) }})</strong>
                                    </div>
                                    <form action="{{ url_for('disconnect_wallet') }}" method="post">
                                        <button type="submit" class="btn btn-outline-danger btn-sm">Disconnect Wallet</button>
                                    </form>
                                {% else %}
                                    <form action="{{ url_for('connect_wallet') }}" method="post">
                                        <div class="mb-3">
                                            <label for="wallet_address" class="form-label">Phantom Wallet Address</label>
                                            <input type="text" class="form-control" id="wallet_address" name="wallet_address" required>
                                            <div class="form-text">Enter your Phantom wallet address</div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="private_key" class="form-label">Private Key (optional)</label>
                                            <input type="password" class="form-control" id="private_key" name="private_key">
                                            <div class="form-text text-warning">Only needed for executing real trades. Never share your private key!</div>
                                        </div>
                                        <button type="submit" class="btn btn-primary">Connect Wallet</button>
                                    </form>
                                {% endif %}
                            </div>
                        </div>
                    </div>
                    
                    <!-- System Status -->
                    <div class="col-md-6 mb-4">
                        <div class="card system-card h-100">
                            <div class="card-body">
                                <h4 class="card-title">System Status</h4>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Wallet Connected:</span>
                                    <strong class="{{ 'text-success' if system_status.wallet_connected else 'text-danger' }}">
                                        {{ 'Yes' if system_status.wallet_connected else 'No' }}
                                    </strong>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Trading Active:</span>
                                    <strong class="{{ 'text-success' if system_status.trading_active else 'text-danger' }}">
                                        {{ 'Yes' if system_status.trading_active else 'No' }}
                                    </strong>
                                </div>
                                <div class="d-flex justify-content-between mb-4">
                                    <span>Last Updated:</span>
                                    <span>{{ system_status.last_status_update }}</span>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    {% if system_status.trading_active %}
                                        <form action="{{ url_for('stop_trading') }}" method="post">
                                            <button type="submit" class="btn btn-warning w-100">Stop Money-Maker</button>
                                        </form>
                                    {% else %}
                                        <form action="{{ url_for('start_trading') }}" method="post" class="mb-2">
                                            <button type="submit" class="btn btn-success w-100" {{ 'disabled' if not system_status.wallet_connected }}>
                                                Start Money-Maker
                                            </button>
                                        </form>
                                    {% endif %}
                                    
                                    <form action="{{ url_for('test_trade') }}" method="post">
                                        <button type="submit" class="btn btn-outline-info w-100" {{ 'disabled' if not system_status.wallet_connected }}>
                                            Execute Test Trade (0.01 SOL)
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Profit Display -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card profit-card">
                            <div class="card-body">
                                <h4 class="card-title">Profit Dashboard</h4>
                                <div class="row text-center">
                                    <div class="col-md-4 mb-3">
                                        <h5>Total Profit</h5>
                                        <h3 class="text-success">${{ system_status.profits.total_usd|round(2) }}</h3>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <h5>Total Trades</h5>
                                        <h3>{{ system_status.profits.trades_count }}</h3>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <h5>Average Profit Per Trade</h5>
                                        <h3 class="text-success">${{ system_status.profits.avg_profit_per_trade|round(2) }}</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Instructions -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Quick Start Guide</h4>
                                <ol>
                                    <li>Connect your Phantom wallet by entering your wallet address</li>
                                    <li>For real trading, enter your private key (never share this with anyone!)</li>
                                    <li>Click "Start Money-Maker" to begin automated trading</li>
                                    <li>Monitor your profits in the dashboard above</li>
                                    <li>Stop the system at any time by clicking "Stop Money-Maker"</li>
                                </ol>
                                <div class="alert alert-warning">
                                    <strong>Important:</strong> This system uses real funds from your wallet. Start with small amounts until you're comfortable with the performance.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh system status every 10 seconds
        setInterval(function() {
            fetch('/system_status')
                .then(response => response.json())
                .then(data => {
                    document.querySelector('.wallet-connected-status').textContent = data.wallet_connected ? 'Yes' : 'No';
                    document.querySelector('.trading-active-status').textContent = data.trading_active ? 'Yes' : 'No';
                    document.querySelector('.total-profit').textContent = '$' + data.profits.total_usd.toFixed(2);
                    document.querySelector('.trades-count').textContent = data.profits.trades_count;
                    document.querySelector('.avg-profit').textContent = '$' + data.profits.avg_profit_per_trade.toFixed(2);
                })
                .catch(error => console.error('Error fetching status:', error));
        }, 10000);
    </script>
</body>
</html>""")
    
    app.run(host="0.0.0.0", port=8080, debug=True)