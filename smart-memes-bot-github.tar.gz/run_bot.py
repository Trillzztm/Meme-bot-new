"""
SMART MEMES BOT - Bot Runner

This script runs the Telegram bot and keeps it running.
"""

import os
import time
import logging
import threading
from direct_bot import DirectBot

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - BotRunner - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("bot_runner.log"),
    ]
)
logger = logging.getLogger("BotRunner")

def main():
    """Start the bot and keep it running."""
    try:
        # Create and start the bot
        logger.info("Starting Telegram bot...")
        bot = DirectBot()
        bot.start()
        logger.info("Bot started successfully!")
        
        # Keep checking that the bot is still running
        status_thread = threading.Thread(target=bot.update_thread.is_alive)
        
        # Log status every 5 minutes
        last_log_time = time.time()
        while True:
            current_time = time.time()
            if current_time - last_log_time >= 300:  # 5 minutes in seconds
                logger.info("Bot is still running")
                last_log_time = current_time
                
            # Check if bot is still running
            if not bot.running or not bot.update_thread.is_alive():
                logger.warning("Bot stopped unexpectedly, restarting...")
                bot.stop()
                bot = DirectBot()
                bot.start()
                logger.info("Bot restarted successfully!")
            
            # Sleep for a bit
            time.sleep(10)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down bot...")
        if 'bot' in locals():
            bot.stop()
        logger.info("Bot shutdown complete")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        if 'bot' in locals():
            bot.stop()

if __name__ == "__main__":
    main()