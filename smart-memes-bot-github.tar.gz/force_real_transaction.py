"""
Force Real Transaction Execution Script for SMART MEMES BOT

This script bypasses all simulations and executes a real token swap
directly through Jupiter Exchange API.
"""

import os
import sys
import time
import logging
import phantom_direct_connector

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ForceRealTransaction")

def force_real_transaction(token_symbol="BONK", amount_sol=0.01):
    """
    Force a real transaction execution with no simulations
    
    Args:
        token_symbol: Token to buy
        amount_sol: Amount of SOL to use
    """
    logger.info(f"🔥 FORCING REAL TRANSACTION: {amount_sol} SOL to {token_symbol} 🔥")
    
    # Import directly to avoid circular imports
    from enhanced_jupiter_trader import execute_real_trade
    
    # Execute the trade with force flag
    result = execute_real_trade(token_symbol, amount_sol=amount_sol, slippage_bps=50)
    
    if result.get("success"):
        logger.info(f"✅ REAL TRANSACTION EXECUTED SUCCESSFULLY!")
        logger.info(f"Transaction hash: {result.get('tx_hash')}")
        
        # Record to a special file for tracking forced trades
        with open("forced_real_trades.json", "a") as f:
            import json
            from datetime import datetime
            
            record = {
                "timestamp": datetime.now().isoformat(),
                "token": token_symbol,
                "amount_sol": amount_sol,
                "tx_hash": result.get("tx_hash"),
                "status": "SUCCESS"
            }
            f.write(json.dumps(record) + "\n")
            
        return True
    else:
        logger.error(f"❌ TRANSACTION FAILED: {result.get('error')}")
        return False

if __name__ == "__main__":
    # Parse command line arguments
    token = "BONK"  # Default token
    amount = 0.01   # Default amount
    
    if len(sys.argv) >= 2:
        token = sys.argv[1]
    if len(sys.argv) >= 3:
        try:
            amount = float(sys.argv[2])
        except:
            logger.error(f"Invalid amount: {sys.argv[2]}")
            amount = 0.01
    
    # Execute the forced trade
    logger.info(f"Starting forced transaction with: {amount} SOL to {token}")
    success = force_real_transaction(token, amount)
    
    if success:
        logger.info("✅ Forced transaction completed successfully")
    else:
        logger.error("❌ Forced transaction failed")
