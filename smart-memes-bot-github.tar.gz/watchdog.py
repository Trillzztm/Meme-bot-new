#!/usr/bin/env python3
"""
Watchdog script for SMART MEMES BOT.

This script monitors the auto_trader_simple.py process and restarts it if it stops.
It also sends Telegram notifications about its status.
"""

import os
import time
import logging
import datetime
import subprocess
import requests
import json
import signal
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - Watchdog - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("watchdog.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("Watchdog")

# Constants
CHECK_INTERVAL = 60  # seconds between checks
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
AUTO_TRADER_CMD = ["python", "auto_trader_simple.py"]
PID_FILE = "auto_trader.pid"
PROFITS_FILE = "auto_trader_profits.json"

# Telegram chat ID for notifications
TELEGRAM_CHAT_IDS = ["6915721378"]  # Replace with your actual chat ID


def send_telegram_notification(message):
    """Send a notification to Telegram"""
    if not TELEGRAM_BOT_TOKEN:
        logger.warning("No Telegram bot token found, skipping notification")
        return False
    
    try:
        for chat_id in TELEGRAM_CHAT_IDS:
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": "HTML"
            }
            
            # Add retry logic for Telegram API
            max_retries = 3
            retry_delay = 2
            success = False
            response = None
            
            for retry in range(max_retries):
                try:
                    response = requests.post(url, json=payload, timeout=10)
                    if response.status_code == 200:
                        logger.info(f"Telegram notification sent successfully to {chat_id}")
                        success = True
                        break
                    else:
                        logger.warning(f"Failed to send Telegram notification (attempt {retry+1}/{max_retries}): {response.text}")
                        if retry < max_retries - 1:
                            time.sleep(retry_delay)
                            retry_delay *= 2  # Exponential backoff
                except requests.exceptions.RequestException as req_err:
                    logger.warning(f"Request error sending Telegram notification (attempt {retry+1}/{max_retries}): {req_err}")
                    if retry < max_retries - 1:
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
            
            if not success:
                error_msg = response.text if response else "No response received"
                logger.error(f"Failed to send Telegram notification after {max_retries} attempts: {error_msg}")
                return False
        
        return True
    except Exception as e:
        logger.error(f"Error sending Telegram notification: {e}")
        return False


def get_total_profit():
    """Get total profit in USD"""
    try:
        with open(PROFITS_FILE, "r") as f:
            data = json.load(f)
        return data.get("total_profit_usd", 0)
    except Exception as e:
        logger.error(f"Error getting total profit: {e}")
        return 0


def is_process_running(pid):
    """Check if a process with the given PID is running"""
    try:
        # Send signal 0 to the process to check if it exists
        os.kill(pid, 0)
        return True
    except OSError:
        return False
    except Exception as e:
        logger.error(f"Error checking process: {e}")
        return False


def read_pid_file():
    """Read PID from file"""
    try:
        if os.path.exists(PID_FILE):
            with open(PID_FILE, "r") as f:
                pid = int(f.read().strip())
            return pid
        return None
    except Exception as e:
        logger.error(f"Error reading PID file: {e}")
        return None


def write_pid_file(pid):
    """Write PID to file"""
    try:
        with open(PID_FILE, "w") as f:
            f.write(str(pid))
        logger.info(f"Wrote PID {pid} to {PID_FILE}")
        return True
    except Exception as e:
        logger.error(f"Error writing PID file: {e}")
        return False


def start_auto_trader():
    """Start the auto trader process"""
    try:
        # Start the process
        process = subprocess.Popen(
            AUTO_TRADER_CMD,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True  # Detach from parent process
        )
        
        # Write PID to file
        write_pid_file(process.pid)
        
        logger.info(f"Started Auto Trader with PID {process.pid}")
        
        # Send notification
        send_telegram_notification(
            "🔄 <b>AUTO TRADER RESTARTED</b>\n\n"
            f"New process started with PID: {process.pid}\n"
            f"Current total profit: ${get_total_profit():.2f}\n\n"
            "The trading bot will continue making profits automatically."
        )
        
        return process.pid
    except Exception as e:
        logger.error(f"Error starting Auto Trader: {e}")
        
        # Send notification
        send_telegram_notification(
            "❌ <b>ERROR STARTING AUTO TRADER</b>\n\n"
            f"Error: {str(e)}\n\n"
            "The watchdog will continue trying to restart the trading bot."
        )
        
        return None


def stop_auto_trader(pid):
    """Stop the auto trader process"""
    try:
        if pid and is_process_running(pid):
            os.kill(pid, signal.SIGTERM)
            logger.info(f"Stopped Auto Trader with PID {pid}")
            return True
        return False
    except Exception as e:
        logger.error(f"Error stopping Auto Trader: {e}")
        return False


def main():
    """Main watchdog loop"""
    logger.info("Starting Watchdog for Auto Trader")
    
    # Send startup notification
    send_telegram_notification(
        "🔍 <b>SMART MEMES BOT WATCHDOG STARTED</b>\n\n"
        "The watchdog will monitor the Auto Trader and restart it if it stops.\n"
        f"Current total profit: ${get_total_profit():.2f}"
    )
    
    # Initial PID check
    pid = read_pid_file()
    if pid and is_process_running(pid):
        logger.info(f"Found existing Auto Trader process with PID {pid}")
    else:
        logger.info("No running Auto Trader process found, starting new one")
        pid = start_auto_trader()
    
    # Main monitoring loop
    try:
        consecutive_failures = 0
        while True:
            try:
                # Check if the process is running
                if pid and is_process_running(pid):
                    logger.info(f"Auto Trader process with PID {pid} is running")
                    consecutive_failures = 0
                else:
                    logger.warning(f"Auto Trader process with PID {pid} is not running")
                    
                    # Restart the process
                    logger.info("Restarting Auto Trader")
                    pid = start_auto_trader()
                    
                    if pid:
                        consecutive_failures = 0
                    else:
                        consecutive_failures += 1
                
                # If we've failed to start the process multiple times, notify but keep trying
                if consecutive_failures >= 3:
                    send_telegram_notification(
                        "⚠️ <b>PERSISTENT AUTO TRADER FAILURE</b>\n\n"
                        f"Failed to start Auto Trader {consecutive_failures} times in a row.\n"
                        "The watchdog will continue trying to restart it.\n\n"
                        f"Current total profit: ${get_total_profit():.2f}"
                    )
                    # Reset counter to avoid spamming
                    consecutive_failures = 0
                
                # Sleep before next check
                time.sleep(CHECK_INTERVAL)
            
            except Exception as e:
                logger.error(f"Error in watchdog loop: {e}")
                time.sleep(CHECK_INTERVAL)
    
    except KeyboardInterrupt:
        logger.info("Watchdog stopped by user")
        
        # Send shutdown notification
        send_telegram_notification(
            "🛑 <b>WATCHDOG STOPPED</b>\n\n"
            "The Auto Trader watchdog has been stopped.\n"
            f"Current total profit: ${get_total_profit():.2f}"
        )
        
        # Stop the auto trader
        if pid:
            stop_auto_trader(pid)
        
        sys.exit(0)


if __name__ == "__main__":
    main()