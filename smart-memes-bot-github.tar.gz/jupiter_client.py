#!/usr/bin/env python3
"""
SMART MEMES BOT - Jupiter API Client

This module provides utilities for interacting with the Jupiter API for Solana DEX aggregation.
It supports real blockchain trades using Jupiter's API.
"""

import os
import base64
import json
import logging
import aiohttp
import asyncio
import time
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("jupiter_client.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("JupiterClient")

# Constants
JUPITER_API_BASE = "https://quote-api.jup.ag/v6"
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" 
SOLANA_RPC = "https://api.mainnet-beta.solana.com"

class JupiterClient:
    """Client for interacting with Jupiter DEX API"""
    
    def __init__(self):
        """Initialize the Jupiter client"""
        self.session = None
        self.wallet_address = None
        self.keypair = None
    
    async def setup(self):
        """Set up the client with HTTP session"""
        self.session = aiohttp.ClientSession()
        
        # Set up wallet if private key is provided
        if "SOLANA_PRIVATE_KEY" in os.environ:
            if not await self.setup_wallet():
                logger.error("Failed to set up wallet")
                return False
        
        return True
    
    async def setup_wallet(self) -> bool:
        """Set up the Solana wallet using private key"""
        try:
            # These imports are done locally to avoid dependencies if not using wallet features
            import base58
            from solana.keypair import Keypair
            
            # Get private key from environment
            private_key = os.environ.get("SOLANA_PRIVATE_KEY")
            if not private_key:
                logger.error("SOLANA_PRIVATE_KEY environment variable not set")
                return False
            
            # Parse private key
            try:
                if private_key.startswith("["):
                    # Handle array format
                    private_key_bytes = bytes(json.loads(private_key))
                else:
                    # Handle base58 format
                    private_key_bytes = base58.b58decode(private_key)
                
                # Create keypair
                self.keypair = Keypair.from_secret_key(private_key_bytes)
                self.wallet_address = str(self.keypair.public_key)
                logger.info(f"Wallet setup successful. Address: {self.wallet_address}")
                return True
            except Exception as e:
                logger.error(f"Error parsing private key: {e}")
                return False
            
        except ImportError:
            logger.error("Required libraries not installed: solana-py, base58")
            logger.error("Run: pip install solana-py base58")
            return False
    
    async def close(self):
        """Close the client session"""
        if self.session:
            await self.session.close()
    
    async def get_token_price(self, token_mint: str, vs_token: str = USDC_MINT) -> float:
        """
        Get token price in USD or another token
        
        Args:
            token_mint: The token mint address
            vs_token: The token to compare against (default: USDC)
            
        Returns:
            Token price
        """
        try:
            if not self.session:
                await self.setup()
            
            url = f"{JUPITER_API_BASE}/price?ids={token_mint}&vsToken={vs_token}"
            
            async with self.session.get(url) as response:
                if response.status != 200:
                    logger.error(f"Error getting token price: {response.status}")
                    return 0
                
                data = await response.json()
                price = float(data["data"][token_mint]["price"])
                return price
                
        except Exception as e:
            logger.error(f"Error getting token price: {e}")
            return 0
    
    async def get_quote(
        self, 
        input_mint: str, 
        output_mint: str, 
        amount: int,
        slippage_bps: int = 100
    ) -> Optional[Dict[str, Any]]:
        """
        Get a quote for swapping tokens
        
        Args:
            input_mint: Input token mint address
            output_mint: Output token mint address
            amount: Amount in smallest units (lamports for SOL)
            slippage_bps: Slippage in basis points (1% = 100 bps)
            
        Returns:
            Quote data or None if failed
        """
        try:
            if not self.session:
                await self.setup()
                
            params = {
                "inputMint": input_mint,
                "outputMint": output_mint,
                "amount": str(amount),
                "slippageBps": slippage_bps
            }
            
            url = f"{JUPITER_API_BASE}/quote"
            
            async with self.session.get(url, params=params) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Error getting quote: {response.status}, {error_text}")
                    return None
                
                quote = await response.json()
                
                # Log quote details
                out_amount = int(quote["outAmount"])
                price_impact = float(quote.get("priceImpactPct", 0)) * 100
                
                logger.info(f"Quote: {amount} -> {out_amount} ({price_impact:.2f}% impact)")
                
                return quote
        
        except Exception as e:
            logger.error(f"Error getting quote: {e}")
            return None
    
    async def get_swap_instructions(
        self, 
        quote: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Get swap instructions for a quote
        
        Args:
            quote: Quote from get_quote
            
        Returns:
            Swap instructions or None if failed
        """
        try:
            if not self.session:
                await self.setup()
            
            if not self.wallet_address:
                logger.error("Wallet not set up. Call setup_wallet first.")
                return None
            
            url = f"{JUPITER_API_BASE}/swap-instructions"
            
            payload = {
                "quoteResponse": quote,
                "userPublicKey": self.wallet_address,
                "wrapAndUnwrapSol": True
            }
            
            async with self.session.post(url, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Error getting swap instructions: {response.status}, {error_text}")
                    return None
                
                swap_data = await response.json()
                return swap_data
        
        except Exception as e:
            logger.error(f"Error getting swap instructions: {e}")
            return None
    
    async def execute_swap(
        self, 
        input_mint: str, 
        output_mint: str, 
        amount: int,
        slippage_bps: int = 100
    ) -> Optional[str]:
        """
        Execute a token swap
        
        Args:
            input_mint: Input token mint address
            output_mint: Output token mint address
            amount: Amount in smallest units (lamports for SOL)
            slippage_bps: Slippage in basis points (1% = 100 bps)
            
        Returns:
            Transaction signature or None if failed
        """
        if not self.keypair:
            logger.error("Keypair not set up. Call setup_wallet first.")
            return None
        
        try:
            # Import Solana libraries
            from solana.transaction import Transaction
            from solana.rpc.api import Client
            from solana.rpc.types import TxOpts
            
            # Get quote
            quote = await self.get_quote(input_mint, output_mint, amount, slippage_bps)
            if not quote:
                return None
            
            # Get swap instructions
            swap_data = await self.get_swap_instructions(quote)
            if not swap_data:
                return None
            
            # Extract and deserialize transaction
            serialized_tx = swap_data["swapTransaction"]
            transaction_bytes = base64.b64decode(serialized_tx)
            
            # Create Solana client
            client = Client(SOLANA_RPC)
            
            # Deserialize and sign transaction
            transaction = Transaction.deserialize(transaction_bytes)
            transaction.sign([self.keypair])
            
            # Send transaction
            tx_opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
            result = client.send_transaction(transaction, self.keypair, opts=tx_opts)
            
            # Get transaction signature
            tx_hash = result["result"]
            logger.info(f"Transaction sent: {tx_hash}")
            logger.info(f"Check transaction: https://explorer.solana.com/tx/{tx_hash}")
            
            return tx_hash
        
        except Exception as e:
            logger.error(f"Error executing swap: {e}")
            logger.exception(e)
            return None

async def test_jupiter_client():
    """Test the Jupiter client"""
    client = JupiterClient()
    await client.setup()
    
    # Get SOL price
    sol_price = await client.get_token_price(SOL_MINT)
    print(f"SOL price: ${sol_price:.2f}")
    
    # Close the client
    await client.close()

if __name__ == "__main__":
    asyncio.run(test_jupiter_client())