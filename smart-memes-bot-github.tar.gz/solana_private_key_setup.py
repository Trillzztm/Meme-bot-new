"""
Solana Private Key Setup Script

This script helps securely set up your Solana private key
for use with the SMART MEMES BOT. It handles the secure
storage and usage of your private key for trading.

IMPORTANT: Your private key is extremely sensitive information.
Never share it with anyone or expose it in logs/code.
"""

import os
import sys
import json
import base58
import getpass
import logging
from typing import Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SolanaKeySetup")

# Constants
SOLANA_KEY_FILE = "solana_key.txt"  # File to store encrypted key

def check_private_key_env() -> bool:
    """
    Check if the SOLANA_PRIVATE_KEY environment variable is set
    
    Returns:
        bool: Whether the environment variable is set
    """
    return os.environ.get("SOLANA_PRIVATE_KEY") is not None

def validate_private_key(private_key: str) -> bool:
    """
    Validate that a string is a valid Solana private key
    
    Args:
        private_key: Private key to validate
        
    Returns:
        bool: Whether the private key is valid
    """
    try:
        # Check if it's a valid base58 string
        if len(private_key) < 32:
            return False
        
        # Try to decode it
        decoded = base58.b58decode(private_key)
        
        # Private key should be 64 bytes (ed25519)
        return len(decoded) == 64
    except Exception as e:
        logger.error(f"Error validating private key: {e}")
        return False

def get_public_key(private_key: str) -> Optional[str]:
    """
    Get the public key from a private key
    
    Args:
        private_key: Private key to use
        
    Returns:
        str: Public key or None if error
    """
    try:
        # Import here to avoid dependencies if the user doesn't have solana packages
        from solana.keypair import Keypair
        
        # Decode the private key
        private_key_bytes = base58.b58decode(private_key)
        
        # Create a keypair
        keypair = Keypair.from_secret_key(private_key_bytes)
        
        # Return the public key
        return str(keypair.public_key)
    except Exception as e:
        logger.error(f"Error getting public key: {e}")
        return None

def save_private_key(private_key: str) -> bool:
    """
    Save the private key to the file
    
    Args:
        private_key: Private key to save
        
    Returns:
        bool: Whether the save was successful
    """
    try:
        # For simplicity, we'll save it as plaintext
        # In a real implementation, you'd want to encrypt it
        with open(SOLANA_KEY_FILE, "w") as f:
            f.write(private_key)
        
        # Make the file readable only by the owner
        os.chmod(SOLANA_KEY_FILE, 0o600)
        
        return True
    except Exception as e:
        logger.error(f"Error saving private key: {e}")
        return False

def load_private_key() -> Optional[str]:
    """
    Load the private key from the file
    
    Returns:
        str: Private key or None if not found/error
    """
    if not os.path.exists(SOLANA_KEY_FILE):
        return None
    
    try:
        with open(SOLANA_KEY_FILE, "r") as f:
            return f.read().strip()
    except Exception as e:
        logger.error(f"Error loading private key: {e}")
        return None

def setup_private_key() -> None:
    """Set up the private key interactively"""
    print("\n=== Solana Private Key Setup ===\n")
    
    # Check if already set up
    if check_private_key_env():
        print("SOLANA_PRIVATE_KEY environment variable is already set.")
        print("You can use this key for trading.")
        return
    
    # Check if we have a saved key
    saved_key = load_private_key()
    if saved_key:
        public_key = get_public_key(saved_key)
        if public_key:
            print(f"Found saved private key for wallet: {public_key}")
            use_saved = input("Use this saved key? (y/n): ")
            
            if use_saved.lower() == "y":
                # Set as environment variable
                os.environ["SOLANA_PRIVATE_KEY"] = saved_key
                print("Private key loaded successfully!")
                print("You can now use the trading scripts.")
                return
    
    # Ask for new private key
    print("\nPlease enter your Solana private key:")
    print("(This is NOT your wallet address or seed phrase)")
    
    # Get private key securely
    private_key = getpass.getpass("Private key: ")
    
    # Validate the private key
    if not validate_private_key(private_key):
        print("Error: Invalid private key format.")
        print("Please make sure you're using a valid Solana private key.")
        return
    
    # Get and display the public key
    public_key = get_public_key(private_key)
    if not public_key:
        print("Error: Could not derive public key from private key.")
        print("Please make sure you're using a valid Solana private key.")
        return
    
    print(f"\nWallet address: {public_key}")
    
    # Confirm with the user
    confirm = input("Is this the correct wallet? (y/n): ")
    if confirm.lower() != "y":
        print("Setup cancelled.")
        return
    
    # Save the private key
    save_result = save_private_key(private_key)
    if not save_result:
        print("Warning: Could not save private key to file.")
    
    # Set as environment variable
    os.environ["SOLANA_PRIVATE_KEY"] = private_key
    
    print("\nPrivate key set up successfully!")
    print("You can now use the trading scripts.")

def clear_private_key() -> None:
    """Clear the private key from the file and environment"""
    # Clear environment variable
    if "SOLANA_PRIVATE_KEY" in os.environ:
        os.environ.pop("SOLANA_PRIVATE_KEY")
    
    # Clear file if it exists
    if os.path.exists(SOLANA_KEY_FILE):
        try:
            os.remove(SOLANA_KEY_FILE)
            print("Private key file removed.")
        except Exception as e:
            logger.error(f"Error removing private key file: {e}")
            print(f"Error removing private key file: {e}")
    
    print("Private key cleared successfully.")

def main():
    """Main function"""
    if len(sys.argv) > 1:
        # Handle command-line arguments
        if sys.argv[1] == "clear":
            clear_private_key()
            return
        elif sys.argv[1] == "check":
            if check_private_key_env():
                private_key = os.environ.get("SOLANA_PRIVATE_KEY")
                public_key = get_public_key(private_key)
                print(f"SOLANA_PRIVATE_KEY is set for wallet: {public_key}")
            else:
                print("SOLANA_PRIVATE_KEY is not set.")
            return
    
    # Interactive setup
    setup_private_key()

if __name__ == "__main__":
    main()