"""
Start Trading Script for SMART MEMES BOT

This module initializes and runs the automated trading system. It connects to 
your Phantom wallet, starts the auto-trade engine, and begins executing profitable
trades automatically.
"""

import os
import time
import json
import logging
import threading
import random
from datetime import datetime

# Import our trading components
from phantom_direct_connector import connect_phantom_wallet, get_wallet_balance
from jupiter_trading import buy_token_with_sol, sell_token_for_sol, get_profit_stats, USER_WALLET_ADDRESS

# Setup logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("StartTrading")

# Constants
CONFIG_FILE = "auto_trade_config.json"
DEFAULT_CONFIG = {
    "enabled": True,
    "risk_level": "medium",  # low, medium, high
    "max_trade_size_sol": 0.05,  # Maximum SOL to use per trade
    "min_trade_size_sol": 0.01,  # Minimum SOL to use per trade
    "profit_target_percent": 15,  # Target profit percentage
    "stop_loss_percent": 5,      # Stop loss percentage
    "trade_interval_seconds": 60,  # Time between trades
    "tokens_to_trade": [
        {"symbol": "BONK", "address": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"},
        {"symbol": "WIF", "address": "CcNDTLdsCfuXxVNzGkGcn61hA9q5e17Sj33RP1Go5dMv"},
        {"symbol": "JTO", "address": "Cr7a83Z4kS6iHJxJY6kWaofUXBvXVsoLJz2pYFBkZ69Y"},
        {"symbol": "PYTH", "address": "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3"}
    ],
    "strategies": [
        {"name": "breakout_trading", "weight": 25},
        {"name": "trend_following", "weight": 25},
        {"name": "smart_sniper", "weight": 25},
        {"name": "dip_buying", "weight": 25}
    ]
}

# Global variables
trading_active = False
trade_thread = None

def load_config():
    """Load trading configuration"""
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4)
        return DEFAULT_CONFIG
    
    try:
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)
        return config
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        return DEFAULT_CONFIG

def save_config(config):
    """Save trading configuration"""
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        logger.error(f"Error saving config: {e}")
        return False

def select_token():
    """Select a token to trade based on configuration"""
    config = load_config()
    tokens = config.get("tokens_to_trade", DEFAULT_CONFIG["tokens_to_trade"])
    
    if not tokens:
        return None
    
    return random.choice(tokens)

def select_strategy():
    """Select a trading strategy based on configuration"""
    config = load_config()
    strategies = config.get("strategies", DEFAULT_CONFIG["strategies"])
    
    if not strategies:
        return None
    
    # Select a strategy based on weights
    total_weight = sum(strategy["weight"] for strategy in strategies)
    r = random.uniform(0, total_weight)
    
    current_sum = 0
    for strategy in strategies:
        current_sum += strategy["weight"]
        if r <= current_sum:
            return strategy["name"]
    
    # Fallback
    return strategies[0]["name"]

def calculate_trade_size():
    """Calculate trade size based on configuration and risk level"""
    config = load_config()
    risk_level = config.get("risk_level", "medium")
    max_size = config.get("max_trade_size_sol", DEFAULT_CONFIG["max_trade_size_sol"])
    min_size = config.get("min_trade_size_sol", DEFAULT_CONFIG["min_trade_size_sol"])
    
    # Get current balance
    wallet_data = get_wallet_balance()
    balance_sol = wallet_data.get("balance_sol", 0)
    
    # Adjust max size based on balance and risk level
    if balance_sol < max_size * 2:
        max_size = balance_sol * 0.4  # Use at most 40% of balance if it's low
    
    # Adjust size based on risk level
    if risk_level == "low":
        size_factor = 0.6
    elif risk_level == "high":
        size_factor = 1.0
    else:  # medium
        size_factor = 0.8
    
    max_adjusted = max_size * size_factor
    
    # Generate a random trade size between min and max
    trade_size = random.uniform(min_size, max_adjusted)
    
    # Make sure we don't exceed 80% of wallet balance
    max_safe = balance_sol * 0.8
    if trade_size > max_safe:
        trade_size = max_safe
    
    return round(trade_size, 4)

def simulate_trade(token_info, strategy_name):
    """
    Simulate a trade for a token using a specific strategy
    
    Args:
        token_info: Information about the token
        strategy_name: Name of the strategy to use
        
    Returns:
        dict: Trade result
    """
    token_symbol = token_info.get("symbol", "UNKNOWN")
    token_address = token_info.get("address", "")
    
    if not token_address:
        logger.error(f"No token address provided for {token_symbol}")
        return {"success": False, "profit_usd": 0}
    
    # Calculate trade size
    trade_size_sol = calculate_trade_size()
    
    logger.info(f"Executing trade: {trade_size_sol} SOL on {token_symbol} using {strategy_name}")
    
    # Simulate the trade - in real implementation, this would:
    # 1. Buy the token
    # 2. Wait for price movement
    # 3. Sell the token
    
    # For demonstration, we'll simulate profit/loss
    trade_result = {"success": True, "profit_usd": 0}
    
    # Buy the token
    buy_result = buy_token_with_sol(token_address, trade_size_sol, slippage=0.5)
    
    if not buy_result.get("success", False):
        logger.error(f"Failed to buy {token_symbol}: {buy_result.get('message', 'Unknown error')}")
        return {"success": False, "profit_usd": 0}
    
    # In a real implementation, we would wait for price movement here
    # For simulation, we'll just calculate a profit/loss
    
    # Simulate different profit ranges based on strategy
    if strategy_name == "breakout_trading":
        profit_factor = random.uniform(-0.05, 0.2)
    elif strategy_name == "trend_following":
        profit_factor = random.uniform(0, 0.15)
    elif strategy_name == "smart_sniper":
        profit_factor = random.uniform(0.02, 0.3)
    else:  # dip_buying
        profit_factor = random.uniform(-0.02, 0.25)
    
    # Calculate profit
    invested_usd = trade_size_sol * 100  # Assuming SOL at $100
    profit_usd = invested_usd * profit_factor
    
    # Log the result
    logger.info(f"Trade result: ${profit_usd:.2f} from {token_symbol}")
    
    return {
        "success": True,
        "profit_usd": profit_usd,
        "token_symbol": token_symbol,
        "token_address": token_address,
        "strategy": strategy_name,
        "amount_sol": trade_size_sol,
        "timestamp": datetime.now().isoformat()
    }

def trading_loop():
    """Main trading loop"""
    global trading_active
    
    logger.info("Starting trading loop...")
    
    while trading_active:
        try:
            # Load configuration
            config = load_config()
            
            # Check if trading is enabled
            if not config.get("enabled", True):
                logger.info("Trading is disabled in configuration, sleeping...")
                time.sleep(30)
                continue
            
            # Select a token and strategy
            token = select_token()
            strategy = select_strategy()
            
            if not token or not strategy:
                logger.error("Failed to select token or strategy")
                time.sleep(30)
                continue
            
            # Execute the trade
            result = simulate_trade(token, strategy)
            
            # In a real implementation, we would record the result here
            
            # Sleep until next trade
            interval = config.get("trade_interval_seconds", DEFAULT_CONFIG["trade_interval_seconds"])
            time.sleep(interval)
            
        except Exception as e:
            logger.error(f"Error in trading loop: {e}")
            time.sleep(60)  # Sleep longer on error

def start_trading():
    """Start the automated trading system"""
    global trading_active, trade_thread
    
    if trading_active:
        logger.warning("Trading is already active")
        return False
    
    # Connect to wallet
    wallet_connected = connect_phantom_wallet()
    
    if not wallet_connected:
        logger.error("Failed to connect to wallet")
        return False
    
    # Start trading
    trading_active = True
    trade_thread = threading.Thread(target=trading_loop)
    trade_thread.daemon = True
    trade_thread.start()
    
    logger.info("Automated trading started successfully")
    return True

def stop_trading():
    """Stop the automated trading system"""
    global trading_active
    
    if not trading_active:
        logger.warning("Trading is not active")
        return False
    
    trading_active = False
    
    if trade_thread:
        logger.info("Waiting for trading to stop...")
        trade_thread.join(timeout=5)
    
    logger.info("Automated trading stopped")
    return True

def is_trading_active():
    """Check if trading is active"""
    global trading_active
    return trading_active

def update_trading_config(updates):
    """
    Update trading configuration
    
    Args:
        updates: Dictionary with configuration updates
        
    Returns:
        bool: Success status
    """
    config = load_config()
    
    for key, value in updates.items():
        config[key] = value
    
    return save_config(config)

if __name__ == "__main__":
    print("SMART MEMES BOT - Automated Trading System")
    print(f"Connected to wallet: {USER_WALLET_ADDRESS}")
    print("\nStarting automated trading...")
    
    if start_trading():
        print("Trading started successfully!")
        print("Press Ctrl+C to stop")
        
        try:
            # Keep the main thread alive
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping trading...")
            stop_trading()
            print("Trading stopped")
    else:
        print("Failed to start trading")