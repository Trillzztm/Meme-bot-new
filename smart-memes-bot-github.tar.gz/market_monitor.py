#!/usr/bin/env python3
"""
Real-time Market Monitor for Crypto Tokens

This script continuously monitors the market for potential trading opportunities by
analyzing price movements, volatility, and trends. It integrates with the trading
engine to execute trades when profitable opportunities are identified.
"""

import os
import sys
import json
import time
import logging
import requests
import threading
import datetime
import numpy as np
from typing import Dict, Any, List, Optional, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("market_monitor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("MarketMonitor")

# Constants
BIRDEYE_API_URL = "https://public-api.birdeye.so/public/solana"
JUPITER_API_URL = "https://quote-api.jup.ag/v6"
CONFIG_FILE = "market_monitor_config.json"
MARKET_DATA_FILE = "token_market_data.json"
TRADING_SIGNALS_FILE = "trading_signals.json"

# Default configuration
DEFAULT_CONFIG = {
    "active": True,
    "update_interval_sec": 30,
    "trading_pairs": [
        {"base": "SOL", "quote": "USDC"},
        {"base": "BONK", "quote": "USDC"},
        {"base": "WIF", "quote": "USDC"},
        {"base": "JTO", "quote": "USDC"}
    ],
    "tokens_to_monitor": ["SOL", "BONK", "WIF", "JTO"],
    "volatility_threshold": 1.5,  # % volatility to consider high
    "momentum_threshold": 2.0,    # % price change to consider strong momentum
    "volume_threshold": 5.0,      # % volume change to consider significant
    "breakout_threshold": 3.0,    # % price increase to consider a breakout
    "dip_threshold": -1.5,        # % price drop to consider a buying dip
    "timeframes": ["5m", "15m", "1h", "4h", "1d"],
    "strategy_weights": {
        "volatility": 0.2,
        "momentum": 0.25,
        "volume": 0.15,
        "breakout": 0.25,
        "dip_buying": 0.15
    },
    "alert_threshold": 70,        # Signal strength (0-100) to trigger alert
    "trade_threshold": 80,        # Signal strength to trigger automatic trade
    "notification_enabled": True,
    "auto_trade_enabled": True
}

# Token addresses
TOKEN_MAP = {
    "SOL": "So11111111111111111111111111111111111111112",
    "USDC": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "BONK": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "WIF": "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
    "JTO": "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"
}

# Global variables
config = {}
market_data = {}
trading_signals = []
stop_threads = False
last_update_time = 0

def load_config() -> Dict[str, Any]:
    """
    Load configuration from file
    
    Returns:
        Dict with configuration
    """
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
    
    # Use default config
    return DEFAULT_CONFIG

def save_config(config_data: Dict[str, Any]) -> None:
    """
    Save configuration to file
    
    Args:
        config_data: Configuration to save
    """
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config_data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving configuration: {e}")

def load_market_data() -> Dict[str, Any]:
    """
    Load market data from file
    
    Returns:
        Dict with market data
    """
    if os.path.exists(MARKET_DATA_FILE):
        try:
            with open(MARKET_DATA_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading market data: {e}")
    
    return {}

def save_market_data(data: Dict[str, Any]) -> None:
    """
    Save market data to file
    
    Args:
        data: Market data to save
    """
    try:
        with open(MARKET_DATA_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving market data: {e}")

def save_trading_signals(signals: List[Dict[str, Any]]) -> None:
    """
    Save trading signals to file
    
    Args:
        signals: Trading signals to save
    """
    try:
        with open(TRADING_SIGNALS_FILE, "w") as f:
            json.dump(signals, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving trading signals: {e}")

def get_token_price(token: str, quote_token: str = "USDC") -> float:
    """
    Get token price from Jupiter API
    
    Args:
        token: Token symbol or address
        quote_token: Quote token symbol or address
        
    Returns:
        float: Token price in quote token
    """
    # Resolve token addresses
    token_address = TOKEN_MAP.get(token.upper(), token)
    quote_address = TOKEN_MAP.get(quote_token.upper(), quote_token)
    
    try:
        url = f"{JUPITER_API_URL}/quote"
        
        # For simplicity, we'll assume tokens have 9 decimals, USDC has 6
        amount = "1000000000"  # 1 token with 9 decimals
        
        params = {
            "inputMint": token_address,
            "outputMint": quote_address,
            "amount": amount,
            "slippageBps": 50
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if "outAmount" in data:
                # USDC has 6 decimals
                quote_amount = int(data["outAmount"]) / 10**6
                return quote_amount
        
        # If we couldn't get a quote, try the reverse direction
        amount = "1000000"  # 1 USDC with 6 decimals
        
        params = {
            "inputMint": quote_address,
            "outputMint": token_address,
            "amount": amount,
            "slippageBps": 50
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if "outAmount" in data:
                # Token likely has 9 decimals
                token_amount = int(data["outAmount"]) / 10**9
                if token_amount > 0:
                    return 1 / token_amount
        
        # If all fails, return 0
        logger.warning(f"Failed to get price for {token}/{quote_token}")
        return 0
    
    except Exception as e:
        logger.error(f"Error getting token price: {e}")
        return 0

def get_birdeye_token_data(token: str) -> Dict[str, Any]:
    """
    Get token data from Birdeye API
    
    Args:
        token: Token symbol or address
        
    Returns:
        Dict with token data
    """
    # Resolve token address
    token_address = TOKEN_MAP.get(token.upper(), token)
    
    try:
        birdeye_api_key = os.environ.get("BIRDEYE_API_KEY")
        if not birdeye_api_key:
            return {"error": "BIRDEYE_API_KEY not set"}
        
        url = f"{BIRDEYE_API_URL}/token/meta"
        
        headers = {
            "X-API-KEY": birdeye_api_key
        }
        
        params = {
            "address": token_address
        }
        
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success", False) and "data" in data:
                return data["data"]
        
        return {"error": f"Failed to get data for {token}: {response.status_code} - {response.text}"}
    
    except Exception as e:
        logger.error(f"Error getting token data: {e}")
        return {"error": str(e)}

def get_birdeye_price_history(token: str, timeframe: str = "1h", limit: int = 100) -> List[Dict[str, Any]]:
    """
    Get price history from Birdeye API
    
    Args:
        token: Token symbol or address
        timeframe: Timeframe (e.g., "5m", "15m", "1h", "4h", "1d")
        limit: Number of data points to fetch
        
    Returns:
        List of price data points
    """
    # Resolve token address
    token_address = TOKEN_MAP.get(token.upper(), token)
    
    try:
        birdeye_api_key = os.environ.get("BIRDEYE_API_KEY")
        if not birdeye_api_key:
            return []
        
        url = f"{BIRDEYE_API_URL}/defi/ohlcv"
        
        headers = {
            "X-API-KEY": birdeye_api_key
        }
        
        params = {
            "address": token_address,
            "type": timeframe,
            "limit": limit
        }
        
        response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success", False) and "data" in data:
                return data["data"]["items"]
        
        logger.warning(f"Failed to get price history for {token}: {response.status_code}")
        return []
    
    except Exception as e:
        logger.error(f"Error getting price history: {e}")
        return []

def update_token_data() -> None:
    """Update market data for all monitored tokens"""
    global market_data, last_update_time, config
    
    # Check if it's time to update
    current_time = time.time()
    if current_time - last_update_time < config.get("update_interval_sec", 30):
        return
    
    tokens = config.get("tokens_to_monitor", ["SOL", "BONK", "WIF", "JTO"])
    
    for token in tokens:
        # Initialize token data if not exists
        if token not in market_data:
            market_data[token] = {
                "symbol": token,
                "price_usdc": 0,
                "price_history": {},
                "last_update": 0,
                "metrics": {}
            }
        
        # Update price
        price = get_token_price(token, "USDC")
        
        # Skip if price is 0 (error)
        if price == 0:
            continue
        
        # Calculate price change
        old_price = market_data[token].get("price_usdc", 0)
        if old_price > 0:
            price_change_pct = (price / old_price - 1) * 100
        else:
            price_change_pct = 0
        
        # Update price data
        market_data[token]["price_usdc"] = price
        market_data[token]["price_change_pct"] = price_change_pct
        market_data[token]["last_update"] = current_time
        
        # Try to get Birdeye data if API key is available
        birdeye_data = get_birdeye_token_data(token)
        if "error" not in birdeye_data:
            market_data[token]["market_cap"] = birdeye_data.get("marketCap", 0)
            market_data[token]["volume_24h"] = birdeye_data.get("volume24h", 0)
            market_data[token]["price_change_24h"] = birdeye_data.get("priceChange24h", 0) * 100  # Convert to %
        
        # Update price history for different timeframes
        timeframes = config.get("timeframes", ["5m", "15m", "1h", "4h", "1d"])
        
        for timeframe in timeframes:
            # Get price history
            history = get_birdeye_price_history(token, timeframe)
            
            if history:
                if timeframe not in market_data[token]["price_history"]:
                    market_data[token]["price_history"][timeframe] = []
                
                # Update price history
                market_data[token]["price_history"][timeframe] = history
        
        # Calculate metrics
        calculate_token_metrics(token)
    
    # Save market data
    save_market_data(market_data)
    
    # Update last update time
    last_update_time = current_time
    
    logger.info(f"Updated market data for {len(tokens)} tokens")

def calculate_token_metrics(token: str) -> None:
    """
    Calculate metrics for a token
    
    Args:
        token: Token symbol
    """
    global market_data
    
    if token not in market_data:
        return
    
    token_data = market_data[token]
    metrics = {}
    
    # Initialize metrics if not exists
    if "metrics" not in token_data:
        token_data["metrics"] = {}
    
    metrics = token_data["metrics"]
    
    # Calculate metrics for each timeframe
    timeframes = config.get("timeframes", ["5m", "15m", "1h", "4h", "1d"])
    
    for timeframe in timeframes:
        if timeframe not in token_data["price_history"]:
            continue
        
        history = token_data["price_history"][timeframe]
        
        if not history:
            continue
        
        # Extract price and volume data
        prices = [item["c"] for item in history]  # Closing prices
        volumes = [item["v"] for item in history]  # Volumes
        
        # Calculate volatility (standard deviation of returns)
        returns = []
        for i in range(1, len(prices)):
            if prices[i-1] > 0:
                ret = (prices[i] / prices[i-1] - 1) * 100
                returns.append(ret)
        
        if returns:
            volatility = np.std(returns)
        else:
            volatility = 0
        
        # Calculate momentum (recent price change)
        if len(prices) >= 2:
            momentum = (prices[-1] / prices[0] - 1) * 100
        else:
            momentum = 0
        
        # Calculate volume change
        if len(volumes) >= 2:
            volume_change = (volumes[-1] / volumes[0] - 1) * 100 if volumes[0] > 0 else 0
        else:
            volume_change = 0
        
        # Calculate breakout (current price vs recent high)
        if len(prices) >= 10:
            recent_high = max(prices[:-1])
            breakout = (prices[-1] / recent_high - 1) * 100 if recent_high > 0 else 0
        else:
            breakout = 0
        
        # Calculate dip (current price vs recent high)
        if len(prices) >= 10:
            recent_high = max(prices[:-1])
            dip = (prices[-1] / recent_high - 1) * 100 if recent_high > 0 else 0
        else:
            dip = 0
        
        # Store metrics for this timeframe
        metrics[timeframe] = {
            "volatility": volatility,
            "momentum": momentum,
            "volume_change": volume_change,
            "breakout": breakout,
            "dip": dip,
            "current_price": prices[-1] if prices else 0,
            "price_change": momentum,  # Same as momentum
            "last_update": time.time()
        }

def generate_trading_signals() -> List[Dict[str, Any]]:
    """
    Generate trading signals based on market data
    
    Returns:
        List of trading signals
    """
    global market_data, config, trading_signals
    
    signals = []
    strategy_weights = config.get("strategy_weights", {})
    
    tokens = config.get("tokens_to_monitor", ["SOL", "BONK", "WIF", "JTO"])
    timeframes = config.get("timeframes", ["5m", "15m", "1h", "4h", "1d"])
    
    # Timeframe weights (longer timeframes have more weight)
    timeframe_weights = {
        "5m": 0.1,
        "15m": 0.15,
        "1h": 0.2,
        "4h": 0.25,
        "1d": 0.3
    }
    
    for token in tokens:
        if token not in market_data:
            continue
        
        token_data = market_data[token]
        
        if "metrics" not in token_data:
            continue
        
        metrics = token_data["metrics"]
        
        # Calculate signal for each timeframe
        timeframe_signals = {}
        
        for timeframe in timeframes:
            if timeframe not in metrics:
                continue
            
            tm = metrics[timeframe]
            
            # Calculate signal strength for each strategy
            volatility_signal = min(1.0, tm["volatility"] / config.get("volatility_threshold", 1.5))
            momentum_signal = min(1.0, tm["momentum"] / config.get("momentum_threshold", 2.0))
            volume_signal = min(1.0, tm["volume_change"] / config.get("volume_threshold", 5.0))
            breakout_signal = min(1.0, tm["breakout"] / config.get("breakout_threshold", 3.0))
            dip_signal = min(1.0, abs(tm["dip"]) / abs(config.get("dip_threshold", -1.5))) if tm["dip"] < 0 else 0
            
            # Determine signal direction (buy or sell)
            if momentum_signal > 0:
                momentum_direction = "buy"
            else:
                momentum_direction = "sell"
                momentum_signal = abs(momentum_signal)
            
            if breakout_signal > 0:
                breakout_direction = "buy"
            else:
                breakout_direction = "sell"
                breakout_signal = abs(breakout_signal)
            
            # Dip is always a buy signal
            dip_direction = "buy"
            
            # Volatility can be buy or sell
            if tm["momentum"] > 0:
                volatility_direction = "buy"
            else:
                volatility_direction = "sell"
            
            # Volume can be buy or sell
            if tm["momentum"] > 0:
                volume_direction = "buy"
            else:
                volume_direction = "sell"
            
            # Calculate overall signal
            overall_strength = (
                volatility_signal * strategy_weights.get("volatility", 0.2) +
                momentum_signal * strategy_weights.get("momentum", 0.25) +
                volume_signal * strategy_weights.get("volume", 0.15) +
                breakout_signal * strategy_weights.get("breakout", 0.25) +
                dip_signal * strategy_weights.get("dip_buying", 0.15)
            )
            
            # Determine overall direction
            buy_signals = [
                (volatility_signal * strategy_weights.get("volatility", 0.2), volatility_direction == "buy"),
                (momentum_signal * strategy_weights.get("momentum", 0.25), momentum_direction == "buy"),
                (volume_signal * strategy_weights.get("volume", 0.15), volume_direction == "buy"),
                (breakout_signal * strategy_weights.get("breakout", 0.25), breakout_direction == "buy"),
                (dip_signal * strategy_weights.get("dip_buying", 0.15), dip_direction == "buy")
            ]
            
            buy_strength = sum(s[0] for s in buy_signals if s[1])
            sell_strength = sum(s[0] for s in buy_signals if not s[1])
            
            if buy_strength > sell_strength:
                overall_direction = "buy"
            else:
                overall_direction = "sell"
            
            # Store signal for this timeframe
            timeframe_signals[timeframe] = {
                "strength": overall_strength,
                "direction": overall_direction,
                "strategies": {
                    "volatility": {"strength": volatility_signal, "direction": volatility_direction},
                    "momentum": {"strength": momentum_signal, "direction": momentum_direction},
                    "volume": {"strength": volume_signal, "direction": volume_direction},
                    "breakout": {"strength": breakout_signal, "direction": breakout_direction},
                    "dip": {"strength": dip_signal, "direction": dip_direction}
                }
            }
        
        # Calculate final signal across all timeframes
        final_strength = 0
        final_direction = "buy"
        
        buy_strength = 0
        sell_strength = 0
        
        for timeframe, signal in timeframe_signals.items():
            weight = timeframe_weights.get(timeframe, 0.2)
            final_strength += signal["strength"] * weight
            
            if signal["direction"] == "buy":
                buy_strength += signal["strength"] * weight
            else:
                sell_strength += signal["strength"] * weight
        
        if buy_strength > sell_strength:
            final_direction = "buy"
        else:
            final_direction = "sell"
        
        # Convert to percentage
        final_strength = final_strength * 100
        
        # Create signal
        signal = {
            "token": token,
            "strength": final_strength,
            "direction": final_direction,
            "price": token_data.get("price_usdc", 0),
            "timestamp": time.time(),
            "timeframe_signals": timeframe_signals
        }
        
        # Check if signal is strong enough
        alert_threshold = config.get("alert_threshold", 70)
        trade_threshold = config.get("trade_threshold", 80)
        
        if final_strength >= alert_threshold:
            signal["alert"] = True
            
            if final_strength >= trade_threshold:
                signal["trade"] = True
        
        signals.append(signal)
    
    # Sort signals by strength
    signals.sort(key=lambda x: x.get("strength", 0), reverse=True)
    
    # Update global signals
    trading_signals = signals
    
    # Save signals
    save_trading_signals(signals)
    
    return signals

def process_trading_signals() -> None:
    """Process trading signals for alerts and auto-trading"""
    global trading_signals, config
    
    # Check if auto-trading is enabled
    auto_trade_enabled = config.get("auto_trade_enabled", False)
    
    for signal in trading_signals:
        # Check if this signal requires action
        if signal.get("alert", False):
            token = signal["token"]
            strength = signal["strength"]
            direction = signal["direction"]
            
            logger.info(f"SIGNAL ALERT: {token} - {direction.upper()} - Strength: {strength:.1f}%")
            
            # Check if auto-trading is enabled and this signal is tradeable
            if auto_trade_enabled and signal.get("trade", False):
                # Check if we have the jupiter_real_trader script
                if os.path.exists("jupiter_real_trader.py"):
                    logger.info(f"Auto-trading signal: {token} - {direction}")
                    
                    # Execute trade via the real trader
                    if direction == "buy":
                        sol_amount = 0.05  # Trade with 0.05 SOL
                        cmd = f"python jupiter_real_trader.py buy {token} {sol_amount} --slippage 100 --dry-run"
                    else:
                        # For sell, we'd need the token amount
                        # Just log it for now
                        logger.info(f"Would sell {token} but amount not determined")
                        continue
                    
                    try:
                        # Execute the command
                        logger.info(f"Executing: {cmd}")
                        os.system(cmd)
                    except Exception as e:
                        logger.error(f"Error executing trade: {e}")

def monitor_thread() -> None:
    """Thread for monitoring market data and generating signals"""
    global stop_threads
    
    logger.info("Market monitor thread started")
    
    while not stop_threads:
        try:
            # Update market data
            update_token_data()
            
            # Generate trading signals
            generate_trading_signals()
            
            # Process trading signals
            process_trading_signals()
            
            # Sleep until next update
            time.sleep(5)
        
        except Exception as e:
            logger.error(f"Error in monitor thread: {e}")
            time.sleep(5)

def start_monitor() -> None:
    """Start the market monitor"""
    global config, stop_threads
    
    # Load configuration
    config = load_config()
    
    # Reset stop flag
    stop_threads = False
    
    # Start monitor thread
    thread = threading.Thread(target=monitor_thread)
    thread.daemon = True
    thread.start()
    
    logger.info("Market monitor started")
    
    return thread

def stop_monitor() -> None:
    """Stop the market monitor"""
    global stop_threads
    
    stop_threads = True
    logger.info("Market monitor stopping...")

def main() -> None:
    """Main function"""
    try:
        logger.info("Starting market monitor...")
        
        # Check if Birdeye API key is set
        if not os.environ.get("BIRDEYE_API_KEY"):
            logger.warning("BIRDEYE_API_KEY not set, some features may be limited")
        
        # Start monitor
        monitor_thread = start_monitor()
        
        # Keep main thread alive
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt detected, stopping...")
        finally:
            stop_monitor()
            
            # Wait for thread to finish
            monitor_thread.join(timeout=5)
            
            logger.info("Market monitor stopped")
    
    except Exception as e:
        logger.error(f"Error in main function: {e}")

if __name__ == "__main__":
    main()