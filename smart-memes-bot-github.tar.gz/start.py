#!/usr/bin/env python
"""
SMART MEMES BOT - One-Click Starter

All you need to do is run this script and everything will start.
The script automatically initializes the dashboard, trading engine, and Telegram bot.
"""

import os
import sys
import time
import logging
import subprocess
import threading
import signal
import webbrowser

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - Starter - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("starter.log"),
    ],
)
logger = logging.getLogger("Starter")

# Global variables
processes = []
running = True

# ASCII art logo
LOGO = """
╔═══════════════════════════════════════════════════════╗
║  ██████╗ ███╗   ███╗ █████╗ ██████╗ ████████╗        ║
║ ██╔════╝ ████╗ ████║██╔══██╗██╔══██╗╚══██╔══╝        ║
║ ╚█████╗  ██╔████╔██║███████║██████╔╝   ██║           ║
║  ╚═══██╗ ██║╚██╔╝██║██╔══██║██╔══██╗   ██║           ║
║  ██████╔╝██║ ╚═╝ ██║██║  ██║██║  ██║   ██║           ║
║  ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝           ║
║ ███╗   ███╗███████╗███╗   ███╗███████╗███████╗       ║
║ ████╗ ████║██╔════╝████╗ ████║██╔════╝██╔════╝       ║
║ ██╔████╔██║█████╗  ██╔████╔██║█████╗  ███████╗       ║
║ ██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██╔══╝  ╚════██║       ║
║ ██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║███████╗███████║       ║
║ ╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚══════╝╚══════╝       ║
║ ██████╗  ██████╗ ████████╗                           ║
║ ██╔══██╗██╔═══██╗╚══██╔══╝                           ║
║ ██████╔╝██║   ██║   ██║                              ║
║ ██╔══██╗██║   ██║   ██║                              ║
║ ██████╔╝╚██████╔╝   ██║                              ║
║ ╚═════╝  ╚═════╝    ╚═╝                              ║
╚═══════════════════════════════════════════════════════╝
"""

def print_welcome():
    """Print welcome message"""
    print("\033[94m" + LOGO + "\033[0m")
    print("\033[92m" + "=" * 70 + "\033[0m")
    print("\033[92m🚀 SMART MEMES BOT - Automated Money Making System\033[0m")
    print("\033[92m" + "=" * 70 + "\033[0m")
    print("\033[96m✅ This script will start all components of your trading system:\033[0m")
    print("  📊 Web Dashboard - Monitor profits and trades")
    print("  💰 Trading Engine - Execute real trades for profit")
    print("  🤖 Telegram Bot - Control the system from your phone")
    print("\033[93m⚠️  Make sure your .env file has the required API keys\033[0m")
    print("\033[92m" + "=" * 70 + "\033[0m")
    print("\033[95m👉 Dashboard Login: http://localhost:5000\033[0m")
    print("\033[95m👉 Password: smartmemes2025\033[0m")
    print("\033[92m" + "=" * 70 + "\033[0m")

def signal_handler(sig, frame):
    """Handle Ctrl+C and other termination signals"""
    global running
    print("\n\033[93m⚠️  Stopping all services...\033[0m")
    running = False
    stop_all()
    sys.exit(0)

def stop_all():
    """Stop all running processes"""
    for process in processes:
        if process and process.poll() is None:
            try:
                process.terminate()
                logger.info(f"Terminated process: {process.pid}")
            except Exception as e:
                logger.error(f"Error terminating process: {e}")

def start_web_dashboard():
    """Start the web dashboard"""
    try:
        logger.info("Starting Web Dashboard...")
        print("\033[96m▶️  Starting Web Dashboard...\033[0m")
        
        # Create template files if needed
        subprocess.run(["python", "-c", "from main import create_templates; create_templates()"], 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Start the dashboard with gunicorn
        proc = subprocess.Popen(
            ["gunicorn", "--bind", "0.0.0.0:5000", "main:app"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        processes.append(proc)
        logger.info(f"Web Dashboard started with PID: {proc.pid}")
        print(f"\033[92m✅ Web Dashboard is running at http://localhost:5000 (PID: {proc.pid})\033[0m")
        
        # Try to open the dashboard in the default browser
        try:
            webbrowser.open("http://localhost:5000")
        except:
            pass
        
        return proc
    except Exception as e:
        logger.error(f"Error starting Web Dashboard: {e}")
        print(f"\033[91m❌ Failed to start Web Dashboard: {e}\033[0m")
        return None

def start_trading_engine():
    """Start the trading engine"""
    try:
        logger.info("Starting Trading Engine...")
        print("\033[96m▶️  Starting Trading Engine...\033[0m")
        
        # Check if the run_smart_trader.py file exists
        if os.path.exists("run_smart_trader.py"):
            proc = subprocess.Popen(
                ["python", "run_smart_trader.py"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            processes.append(proc)
            logger.info(f"Trading Engine started with PID: {proc.pid}")
            print(f"\033[92m✅ Trading Engine is running (PID: {proc.pid})\033[0m")
            return proc
        else:
            # Fallback to launching a simplified money maker
            print("\033[93m⚠️  run_smart_trader.py not found, using fallback...\033[0m")
            proc = subprocess.Popen(
                ["python", "-c", "from main import generate_profits; import time, random; \
                while True: generate_profits(); time.sleep(random.randint(5, 30))"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            processes.append(proc)
            logger.info(f"Fallback trading simulation started with PID: {proc.pid}")
            print(f"\033[92m✅ Trading simulation is running (PID: {proc.pid})\033[0m")
            return proc
    except Exception as e:
        logger.error(f"Error starting Trading Engine: {e}")
        print(f"\033[91m❌ Failed to start Trading Engine: {e}\033[0m")
        return None

def start_telegram_bot():
    """Start the Telegram bot"""
    try:
        logger.info("Starting Telegram Bot...")
        print("\033[96m▶️  Starting Telegram Bot...\033[0m")
        
        # Check which bot file to use
        if os.path.exists("enhanced_bot.py"):
            bot_file = "enhanced_bot.py"
        elif os.path.exists("bot.py"):
            bot_file = "bot.py"
        else:
            logger.error("No bot file found")
            print("\033[91m❌ No Telegram bot file found\033[0m")
            return None
        
        # Start the bot
        proc = subprocess.Popen(
            ["python", bot_file],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        processes.append(proc)
        logger.info(f"Telegram Bot started with PID: {proc.pid}")
        print(f"\033[92m✅ Telegram Bot is running (PID: {proc.pid})\033[0m")
        return proc
    except Exception as e:
        logger.error(f"Error starting Telegram Bot: {e}")
        print(f"\033[91m❌ Failed to start Telegram Bot: {e}\033[0m")
        return None

def check_process_status():
    """Check if processes are still running and restart if needed"""
    while running:
        for i, process in enumerate(processes):
            if process and process.poll() is not None:
                logger.warning(f"Process {process.pid} has exited. Restarting...")
                print(f"\033[93m⚠️  Process {process.pid} has stopped. Restarting...\033[0m")
                if i == 0:
                    processes[i] = start_web_dashboard()
                elif i == 1:
                    processes[i] = start_trading_engine()
                elif i == 2:
                    processes[i] = start_telegram_bot()
        
        # Check every 10 seconds
        time.sleep(10)

def check_env_variables():
    """Check if required environment variables are set"""
    required_vars = {
        "TELEGRAM_BOT_TOKEN": "The Telegram bot API token",
        "SOLANA_PRIVATE_KEY": "Your Solana wallet private key",
    }
    
    missing_vars = []
    
    for var, description in required_vars.items():
        if not os.environ.get(var):
            missing_vars.append((var, description))
    
    if missing_vars:
        print("\033[91m❌ Missing required environment variables:\033[0m")
        for var, desc in missing_vars:
            print(f"\033[93m  - {var}: {desc}\033[0m")
        
        # Create .env file if it doesn't exist
        if not os.path.exists(".env"):
            print("\033[96m📝 Creating .env file...\033[0m")
            with open(".env", "w") as f:
                f.write("# SMART MEMES BOT Environment Variables\n\n")
                for var, desc in required_vars.items():
                    f.write(f"# {desc}\n{var}=\n\n")
            
            print("\033[92m✅ Created .env file. Please fill in the required values and restart.\033[0m")
        else:
            print("\033[93m⚠️  Please update your .env file with the missing variables and restart.\033[0m")
        
        return False
    
    return True

def main():
    """Start everything"""
    # Print welcome message
    print_welcome()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Check environment variables
    if not check_env_variables():
        return
    
    # Start all components
    web_proc = start_web_dashboard()
    time.sleep(2)  # Give the dashboard time to start
    
    trading_proc = start_trading_engine()
    time.sleep(2)  # Give the trading engine time to start
    
    bot_proc = start_telegram_bot()
    
    # Print summary
    print("\033[92m" + "=" * 70 + "\033[0m")
    print("\033[92m✅ All systems are running! Your money-making machine is active.\033[0m")
    print("\033[96m📊 Access your dashboard at: http://localhost:5000\033[0m")
    print("\033[96m🔑 Login with password: smartmemes2025\033[0m")
    print("\033[92m" + "=" * 70 + "\033[0m")
    print("\033[93m⚠️  Press Ctrl+C to stop all services\033[0m")
    
    # Monitor processes and restart if needed
    check_process_status()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\033[93m⚠️  Stopping all services...\033[0m")
        stop_all()
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        print(f"\033[91m❌ An error occurred: {e}\033[0m")
        stop_all()
        sys.exit(1)