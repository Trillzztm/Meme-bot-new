"""
SMART MEMES BOT - Ultimate Money Maker

This script runs all components of the SMART MEMES BOT moneymaking system:
1. Insider wallet tracker
2. Market analyzer
3. Auto-trading engine

This is designed to be the ultimate money-making machine, running 24/7 and 
generating maximum profits with minimal oversight.
"""

import os
import sys
import time
import logging
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ultimate_moneymaker.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("UltimateMoneyMaker")

# Import components (with fallbacks)
try:
    # Import insider wallet tracker
    from insider_wallet_tracker import wallet_tracker
    INSIDER_TRACKER_AVAILABLE = True
    logger.info("Insider wallet tracker successfully imported")
except ImportError:
    INSIDER_TRACKER_AVAILABLE = False
    logger.warning("Insider wallet tracker not available - high-profit opportunities may be missed!")

try:
    # Import market analyzer 
    from market_analyzer import market_analyzer
    MARKET_ANALYZER_AVAILABLE = True
    logger.info("Market analyzer successfully imported")
except ImportError:
    MARKET_ANALYZER_AVAILABLE = False
    logger.warning("Market analyzer not available - trade profit optimization will be limited!")

try:
    # Import auto-trading engine
    from auto_trade_engine import auto_trader
    AUTO_TRADER_AVAILABLE = True
    logger.info("Auto-trading engine successfully imported")
except ImportError:
    AUTO_TRADER_AVAILABLE = False
    logger.error("Auto-trading engine not available - cannot execute trades!")

def initialize_system():
    """Initialize all money-making systems"""
    logger.info("Initializing ultimate money-making system...")
    
    # Start insider wallet tracker
    if INSIDER_TRACKER_AVAILABLE:
        try:
            logger.info("Starting insider wallet tracker...")
            wallet_tracker_thread = wallet_tracker.run_in_background()
            logger.info("Insider wallet tracker started successfully")
        except Exception as e:
            logger.error(f"Failed to start insider wallet tracker: {e}")
    else:
        logger.warning("Skipping insider wallet tracker initialization")
    
    # Start market analyzer
    if MARKET_ANALYZER_AVAILABLE:
        try:
            logger.info("Starting market analyzer...")
            market_analyzer_thread = market_analyzer.run_in_background()
            logger.info("Market analyzer started successfully")
        except Exception as e:
            logger.error(f"Failed to start market analyzer: {e}")
    else:
        logger.warning("Skipping market analyzer initialization")
    
    # Start auto-trading engine
    if AUTO_TRADER_AVAILABLE:
        try:
            logger.info("Starting auto-trading engine...")
            auto_trader_thread = auto_trader.run_in_background()
            logger.info("Auto-trading engine started successfully")
        except Exception as e:
            logger.error(f"Failed to start auto-trading engine: {e}")
    else:
        logger.error("Cannot start auto-trading engine - critical component missing!")
        
    logger.info("Money-making system initialization complete")
    
def status_report():
    """Generate a status report of all running systems"""
    logger.info("======= SYSTEM STATUS REPORT =======")
    
    # Insider wallet tracker status
    if INSIDER_TRACKER_AVAILABLE:
        opportunities = wallet_tracker.get_best_opportunities(3)
        logger.info(f"Insider wallet tracker: ACTIVE with {len(opportunities)} opportunities")
        if opportunities:
            for i, opp in enumerate(opportunities, 1):
                token = opp.get("token_name", "Unknown")
                confidence = opp.get("confidence", 0)
                logger.info(f"  {i}. {token}: {confidence:.2f} confidence")
    else:
        logger.info("Insider wallet tracker: NOT AVAILABLE")
    
    # Market analyzer status
    if MARKET_ANALYZER_AVAILABLE:
        opportunities = market_analyzer.get_best_opportunities(3)
        logger.info(f"Market analyzer: ACTIVE with {len(opportunities)} opportunities")
        if opportunities:
            for i, opp in enumerate(opportunities, 1):
                token = opp.get("token", "Unknown")
                potential = opp.get("profit_potential", 0)
                logger.info(f"  {i}. {token}: {potential:.1f}% potential")
    else:
        logger.info("Market analyzer: NOT AVAILABLE")
    
    # Auto-trading engine status
    if AUTO_TRADER_AVAILABLE:
        logger.info(f"Auto-trading engine: ACTIVE")
        logger.info(f"  Total profits: ${auto_trader.total_profit:.2f}")
        logger.info(f"  Daily profits: ${auto_trader.daily_profit:.2f}")
        logger.info(f"  Wallet balance: {auto_trader.wallet_balance_sol} SOL (${auto_trader.wallet_balance_usd:.2f})")
    else:
        logger.info("Auto-trading engine: NOT AVAILABLE")
    
    logger.info("====================================")

def run_forever():
    """Run all money-making systems indefinitely"""
    logger.info("Starting Ultimate Money Maker - expect massive profits!")
    
    try:
        # Initialize all systems
        initialize_system()
        
        # Keep main thread alive
        while True:
            # Periodic status report
            status_report()
            
            # Wait 5 minutes between status reports
            time.sleep(300)
    
    except KeyboardInterrupt:
        logger.info("Ultimate Money Maker shutting down by user request")
    except Exception as e:
        logger.error(f"Fatal error in Ultimate Money Maker: {e}")
        
        # Auto-restart after fatal error
        logger.info("Auto-restarting system in 10 seconds...")
        time.sleep(10)
        run_forever()

if __name__ == "__main__":
    run_forever()