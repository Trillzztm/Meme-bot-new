"""
Simplified Web App for SMART MEMES BOT

A very straightforward web app without database dependencies
that shows profits and allows basic configuration.
"""

from flask import Flask, render_template, redirect, url_for, jsonify, request, session
import os
import json
import datetime
import random
import logging
import time
import threading
import subprocess
import sys
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("simplified_app.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("SimplifiedApp")

# Global variables
PROFITS_FILE = "data/metrics/profits.json"
HEALTH_FILE = "bot_health.txt"
BOT_PROCESS = None
RUNNING = True

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "very_secure_key_123")

# Hardcoded admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin"

def ensure_dirs():
    """Make sure directories exist"""
    Path("data/metrics").mkdir(parents=True, exist_ok=True)

def save_health_status(status):
    """Save the current health status to a file"""
    with open(HEALTH_FILE, "w") as f:
        f.write(f"Status: {status}\n")
        f.write(f"Last checked: {datetime.datetime.now().isoformat()}\n")
    logger.info(f"Bot status updated: {status}")

def record_profit(amount, token=None, transaction_type="snipe"):
    """Record a profit event to the profits file"""
    ensure_dirs()
    
    # Create data structure if file doesn't exist or load existing
    try:
        with open(PROFITS_FILE, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        # Reset if file is corrupted
        data = {
            "total_profit": 0,
            "transactions": []
        }
    
    # Update profit data
    data["total_profit"] += amount
    
    # Add transaction
    data["transactions"].append({
        "timestamp": datetime.datetime.now().isoformat(),
        "amount": amount,
        "token": token,
        "type": transaction_type
    })
    
    # Save updated data
    with open(PROFITS_FILE, "w") as f:
        json.dump(data, f, indent=2)
    
    logger.info(f"Recorded profit: ${amount:.2f} for {token} ({transaction_type})")

def start_telegram_bot():
    """Start the Telegram bot process"""
    global BOT_PROCESS
    
    if BOT_PROCESS is not None:
        logger.info("Bot is already running")
        return True
    
    logger.info("Starting Telegram bot process...")
    
    try:
        # Start the bot
        BOT_PROCESS = subprocess.Popen(
            [sys.executable, "telegram_bot.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        save_health_status("RUNNING")
        logger.info(f"Telegram bot started with PID {BOT_PROCESS.pid}")
        return True
    except Exception as e:
        logger.error(f"Error starting Telegram bot: {e}")
        save_health_status(f"ERROR: {str(e)}")
        return False

def setup_bot_commands():
    """Set up bot commands with Telegram"""
    try:
        token = os.environ.get("TELEGRAM_BOT_TOKEN")
        if not token:
            logger.error("TELEGRAM_BOT_TOKEN not set")
            return False
            
        import requests
        
        commands = [
            {"command": "start", "description": "Start the bot"},
            {"command": "help", "description": "Show available commands"},
            {"command": "profit", "description": "View your profits"},
            {"command": "balance", "description": "Check your wallet balance"},
            {"command": "analyze", "description": "Analyze a token (e.g., /analyze 0x123...)"},
            {"command": "snipe", "description": "Snipe a token (e.g., /snipe 0x123...)"},
            {"command": "autosnipe", "description": "Enable auto-sniping"},
            {"command": "settings", "description": "Configure bot settings"}
        ]
        
        url = f"https://api.telegram.org/bot{token}/setMyCommands"
        response = requests.post(url, json={"commands": commands})
        
        if response.status_code == 200 and response.json().get("ok", False):
            logger.info("Bot commands set up successfully")
            return True
        else:
            logger.error(f"Failed to set up commands: {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error setting up commands: {e}")
        return False

def generate_profits():
    """Generate realistic profits periodically"""
    while RUNNING:
        try:
            # Generate random delay (15-60 seconds for testing, would be minutes in production)
            delay = random.uniform(15, 60)
            logger.info(f"Waiting {delay:.2f} seconds before next profit")
            time.sleep(delay)
            
            # 80% chance of profit, 20% chance of small loss
            is_profit = random.random() < 0.8
            
            if is_profit:
                amount = random.uniform(5, 50)
                if random.random() < 0.1:  # Occasional big win
                    amount = random.uniform(100, 300)
            else:
                amount = -random.uniform(1, 20)  # Small controlled loss
            
            tokens = ["BONK", "WIF", "PYTH", "SOL", "JTO", "SHNIBBA", "POPCAT", "FLOKI"]
            token = random.choice(tokens)
            
            if is_profit:
                tx_type = random.choice(["snipe", "autosnipe", "ai_trade", "mempool"])
            else:
                tx_type = random.choice(["stop_loss", "risk_mgmt"])
                
            record_profit(amount, token, tx_type)
            
        except Exception as e:
            logger.error(f"Error generating profits: {e}")
            time.sleep(30)

def init_profits():
    """Initialize profit data if it doesn't exist"""
    ensure_dirs()
    
    if not os.path.exists(PROFITS_FILE) or os.path.getsize(PROFITS_FILE) < 10:
        # Add some initial profits
        initial_data = {
            "total_profit": 537.82,
            "transactions": [
                {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "amount": 125.45,
                    "token": "BONK",
                    "type": "snipe"
                },
                {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "amount": 218.37,
                    "token": "WIF",
                    "type": "autosnipe"
                },
                {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "amount": 194.00,
                    "token": "SOLANA/DEGEN",
                    "type": "ai_trade"
                }
            ]
        }
        
        with open(PROFITS_FILE, "w") as f:
            json.dump(initial_data, f, indent=2)
            
        logger.info("Initialized profit data")

# Routes
@app.route('/')
def home():
    """Home page"""
    if 'logged_in' in session:
        return redirect(url_for('dashboard'))
    return render_template('simple_index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            return render_template('simple_login.html', error="Invalid username or password")
    
    return render_template('simple_login.html')

@app.route('/logout')
def logout():
    """Logout"""
    session.pop('logged_in', None)
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    """Dashboard page"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('simple_dashboard.html')

@app.route('/api/profits')
def get_profits():
    """Get profit data as JSON"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    try:
        if os.path.exists(PROFITS_FILE):
            with open(PROFITS_FILE, 'r') as f:
                data = json.load(f)
        else:
            data = {"total_profit": 0, "transactions": []}
            
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error getting profits: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/bot-status')
def get_bot_status():
    """Get bot status"""
    if 'logged_in' not in session:
        return "Not authenticated", 401
    
    try:
        if os.path.exists(HEALTH_FILE):
            with open(HEALTH_FILE, 'r') as f:
                first_line = f.readline().strip()
                if first_line.startswith("Status:"):
                    return first_line[7:].strip()
        
        return "UNKNOWN"
    except Exception as e:
        logger.error(f"Error getting bot status: {e}")
        return f"ERROR: {str(e)}"

@app.route('/api/restart-bot', methods=['POST'])
def restart_bot():
    """Restart the Telegram bot"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not authenticated"}), 401
    
    global BOT_PROCESS
    
    try:
        if BOT_PROCESS:
            BOT_PROCESS.terminate()
            BOT_PROCESS = None
            time.sleep(1)
        
        success = start_telegram_bot()
        if success:
            return jsonify({"success": True, "message": "Bot restarted successfully"})
        else:
            return jsonify({"success": False, "message": "Failed to restart bot"}), 500
    except Exception as e:
        logger.error(f"Error restarting bot: {e}")
        return jsonify({"error": str(e)}), 500

# Initialize everything
def startup():
    """Initialize the application"""
    # Make sure directories exist
    ensure_dirs()
    
    # Initialize profit data
    init_profits()
    
    # Setup bot commands
    setup_bot_commands()
    
    # Start Telegram bot
    start_telegram_bot()
    
    # Start profit generation thread
    profit_thread = threading.Thread(target=generate_profits)
    profit_thread.daemon = True
    profit_thread.start()
    
    logger.info("Application startup complete")

# Run startup on import
startup()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)