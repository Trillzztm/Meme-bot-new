"""
Transaction Signing Module for SMART MEMES BOT

This module provides functions for signing and sending transactions on Solana.
It handles the secure management of private keys and transaction creation.
"""

import os
import json
import base64
import logging
from typing import Dict, Any, Optional, List, Union, Tuple
import base58

# Import Solana libraries
from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solders.signature import Signature
from solana.rpc.api import Client
from solana.rpc.types import TxOpts
from solana.transaction import Transaction

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("TransactionSigner")

# Constants
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
SOLANA_PRIVATE_KEY = os.environ.get("SOLANA_PRIVATE_KEY")
PRIVATE_KEY_FILE = "solana_key.txt"  # Only stores the key if explicitly saved by user


def get_rpc_client() -> Client:
    """
    Get Solana RPC client
    
    Returns:
        Client: Solana RPC client
    """
    return Client(SOLANA_RPC_URL)


def load_private_key() -> Optional[str]:
    """
    Load private key from environment or local file
    
    Returns:
        str: Private key or None if not available
    """
    # First check environment variable
    if SOLANA_PRIVATE_KEY:
        return SOLANA_PRIVATE_KEY
    
    # Then check local file
    if os.path.exists(PRIVATE_KEY_FILE):
        try:
            with open(PRIVATE_KEY_FILE, "r") as f:
                return f.read().strip()
        except Exception as e:
            logger.error(f"Error reading private key file: {e}")
    
    return None


def save_private_key(private_key: str) -> bool:
    """
    Save private key to local file
    WARNING: This should be used with extreme caution
    
    Args:
        private_key: Private key to save
        
    Returns:
        bool: Success status
    """
    try:
        with open(PRIVATE_KEY_FILE, "w") as f:
            f.write(private_key)
        
        os.chmod(PRIVATE_KEY_FILE, 0o600)  # Restrict file permissions
        return True
    except Exception as e:
        logger.error(f"Error saving private key: {e}")
        return False


def create_keypair() -> Optional[Keypair]:
    """
    Create keypair from private key
    
    Returns:
        Keypair: Solana keypair or None if not available
    """
    private_key = load_private_key()
    if not private_key:
        logger.error("No private key available")
        return None
    
    try:
        if private_key.startswith("[") and private_key.endswith("]"):
            # Array format
            byte_array = json.loads(private_key)
            return Keypair.from_bytes(bytes(byte_array))
        elif len(private_key) == 64:
            # Hex format
            binary_data = bytes.fromhex(private_key)
            return Keypair.from_bytes(binary_data)
        else:
            # Base58 format
            return Keypair.from_base58_string(private_key)
    except Exception as e:
        logger.error(f"Error creating keypair: {e}")
        return None


def get_public_key() -> Optional[str]:
    """
    Get public key from keypair
    
    Returns:
        str: Public key as string or None if keypair unavailable
    """
    keypair = create_keypair()
    if not keypair:
        return None
    
    return str(keypair.pubkey())


def sign_transaction(transaction_data: bytes) -> Optional[bytes]:
    """
    Sign a transaction
    
    Args:
        transaction_data: Serialized transaction data
        
    Returns:
        bytes: Signed transaction data or None if signing fails
    """
    keypair = create_keypair()
    if not keypair:
        logger.error("No keypair available for signing")
        return None
    
    try:
        # Deserialize the transaction
        transaction = Transaction.from_bytes(transaction_data)
        
        # Sign the transaction
        transaction.sign(keypair)
        
        # Return the signed transaction
        return transaction.serialize()
    except Exception as e:
        logger.error(f"Error signing transaction: {e}")
        return None


def sign_and_send_transaction(transaction_data: bytes) -> Dict[str, Any]:
    """
    Sign and send a transaction
    
    Args:
        transaction_data: Serialized transaction data
        
    Returns:
        dict: Transaction result or error
    """
    keypair = create_keypair()
    if not keypair:
        return {"error": "No keypair available for signing"}
    
    try:
        # Deserialize the transaction
        transaction = Transaction.from_bytes(transaction_data)
        
        # Get RPC client
        client = get_rpc_client()
        
        # Sign and send the transaction
        logger.info("Signing and sending transaction...")
        opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
        result = client.send_transaction(transaction, keypair, opts=opts)
        
        if "result" in result:
            tx_hash = result["result"]
            logger.info(f"Transaction sent: {tx_hash}")
            
            return {
                "success": True,
                "tx_hash": tx_hash,
                "message": "Transaction submitted successfully"
            }
        else:
            error_msg = f"Error sending transaction: {result}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error signing and sending transaction: {e}")
        return {"error": str(e)}


def send_sol(recipient_address: str, amount_sol: float) -> Dict[str, Any]:
    """
    Send SOL to an address
    
    Args:
        recipient_address: Recipient's Solana address
        amount_sol: Amount of SOL to send
        
    Returns:
        dict: Transaction result or error
    """
    keypair = create_keypair()
    if not keypair:
        return {"error": "No keypair available for signing"}
    
    try:
        # Convert SOL to lamports
        lamports = int(amount_sol * 10**9)
        
        # Get RPC client
        client = get_rpc_client()
        
        # Create a transfer instruction
        from solana.system_program import TransferParams, transfer
        
        sender_pubkey = keypair.pubkey()
        recipient_pubkey = Pubkey.from_string(recipient_address)
        
        transfer_instruction = transfer(
            TransferParams(
                from_pubkey=sender_pubkey,
                to_pubkey=recipient_pubkey,
                lamports=lamports
            )
        )
        
        # Create a transaction
        transaction = Transaction().add(transfer_instruction)
        
        # Sign and send the transaction
        logger.info(f"Sending {amount_sol} SOL to {recipient_address}...")
        opts = TxOpts(skip_preflight=False, preflight_commitment="confirmed")
        result = client.send_transaction(transaction, keypair, opts=opts)
        
        if "result" in result:
            tx_hash = result["result"]
            logger.info(f"SOL transfer sent: {tx_hash}")
            
            return {
                "success": True,
                "tx_hash": tx_hash,
                "amount_sol": amount_sol,
                "recipient": recipient_address,
                "message": f"Successfully sent {amount_sol} SOL to {recipient_address}"
            }
        else:
            error_msg = f"Error sending SOL: {result}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error sending SOL: {e}")
        return {"error": str(e)}


def check_transaction_status(tx_hash: str) -> Dict[str, Any]:
    """
    Check the status of a transaction
    
    Args:
        tx_hash: Transaction hash/signature
        
    Returns:
        dict: Transaction status or error
    """
    try:
        client = get_rpc_client()
        signature = Signature.from_string(tx_hash)
        
        result = client.get_transaction(signature)
        
        if "result" in result and result["result"]:
            status = result["result"]["meta"]["status"]
            
            if "Err" in status:
                return {
                    "success": False,
                    "confirmed": True,
                    "error": status["Err"],
                    "tx_hash": tx_hash
                }
            else:
                return {
                    "success": True,
                    "confirmed": True,
                    "tx_hash": tx_hash
                }
        else:
            # Transaction not found or not confirmed yet
            return {
                "success": False,
                "confirmed": False,
                "tx_hash": tx_hash,
                "message": "Transaction not found or not confirmed yet"
            }
    except Exception as e:
        logger.error(f"Error checking transaction status: {e}")
        return {"error": str(e)}


def verify_private_key(private_key: str) -> bool:
    """
    Verify if a private key is valid
    
    Args:
        private_key: Private key to verify
        
    Returns:
        bool: Whether the private key is valid
    """
    try:
        if private_key.startswith("[") and private_key.endswith("]"):
            # Array format
            byte_array = json.loads(private_key)
            keypair = Keypair.from_bytes(bytes(byte_array))
        elif len(private_key) == 64:
            # Hex format
            binary_data = bytes.fromhex(private_key)
            keypair = Keypair.from_bytes(binary_data)
        else:
            # Base58 format
            keypair = Keypair.from_base58_string(private_key)
        
        # If we get here, the key is valid
        return True
    except Exception as e:
        logger.error(f"Invalid private key: {e}")
        return False


def generate_new_keypair() -> Dict[str, Any]:
    """
    Generate a new Solana keypair
    WARNING: This should only be used for testing or with explicit user consent
    
    Returns:
        dict: Keypair information
    """
    try:
        # Generate a new keypair
        keypair = Keypair()
        
        # Get the public and private keys
        public_key = str(keypair.pubkey())
        private_key = base58.b58encode(bytes(keypair.secret())).decode("ascii")
        
        return {
            "public_key": public_key,
            "private_key": private_key,
            "message": "Successfully generated new keypair"
        }
    except Exception as e:
        logger.error(f"Error generating new keypair: {e}")
        return {"error": str(e)}


def test_connectivity() -> Dict[str, Any]:
    """
    Test connectivity to Solana
    
    Returns:
        dict: Test results
    """
    try:
        client = get_rpc_client()
        response = client.get_health()
        
        if "result" in response and response["result"] == "ok":
            return {
                "connected": True,
                "message": "Successfully connected to Solana RPC"
            }
        else:
            return {
                "connected": False,
                "message": f"Failed to connect to Solana RPC: {response}"
            }
    except Exception as e:
        logger.error(f"Error testing connectivity: {e}")
        return {
            "connected": False,
            "message": f"Error: {str(e)}"
        }


def get_transaction_history(limit: int = 10) -> Dict[str, Any]:
    """
    Get transaction history for the wallet
    
    Args:
        limit: Maximum number of transactions to return
        
    Returns:
        dict: Transaction history or error
    """
    pubkey = get_public_key()
    if not pubkey:
        return {"error": "No wallet available"}
    
    try:
        client = get_rpc_client()
        pubkey_obj = Pubkey.from_string(pubkey)
        
        # Get signatures for the address
        signatures = client.get_signatures_for_address(pubkey_obj, limit=limit)
        
        if "result" in signatures:
            return {
                "success": True,
                "address": pubkey,
                "transactions": signatures["result"]
            }
        else:
            return {
                "success": False,
                "address": pubkey,
                "error": f"Failed to get transaction history: {signatures}"
            }
    except Exception as e:
        logger.error(f"Error getting transaction history: {e}")
        return {"error": str(e)}


if __name__ == "__main__":
    # Test the module
    print("\n=== Testing Transaction Signer ===")
    
    # Test connectivity
    print("\nTesting Solana connectivity...")
    connectivity = test_connectivity()
    print(f"Connectivity: {connectivity['connected']}")
    print(f"Message: {connectivity['message']}")
    
    # Check if we have a private key
    private_key = load_private_key()
    has_key = private_key is not None
    print(f"\nPrivate key available: {has_key}")
    
    if has_key:
        # Get public key
        public_key = get_public_key()
        print(f"Public key: {public_key}")
        
        # Get transaction history
        print("\nGetting transaction history...")
        history = get_transaction_history(5)
        if "error" not in history:
            print(f"Found {len(history['transactions'])} transactions")
        else:
            print(f"Error: {history['error']}")
    else:
        print("\nNo private key available. Some tests skipped.")