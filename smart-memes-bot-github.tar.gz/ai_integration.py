"""
Integration script to connect AI Signal Engine with the SMART MEMES BOT.

This module provides utility functions to connect the AI signal engine
with the rest of the bot's components, including traditional analysis fallbacks,
learning-based adaptations, and risk management.
"""

import logging
import asyncio
from typing import Dict, Any, Optional, List, Tuple

# Configure logger
logger = logging.getLogger(__name__)

# Try to import AI signal engine - use fallbacks if not available
try:
    # Import our AI engine
    from ai.ai_signal_engine import analyze_token as ai_analyze_token
    from ai.ai_signal_engine import get_token_safety_report as ai_safety_report
    HAS_AI_ENGINE = True
    logger.info("AI signal engine loaded successfully")
except ImportError:
    HAS_AI_ENGINE = False
    logger.warning("AI signal engine not available, using fallback analysis")

# Try to import learning engine - use static analysis if not available
try:
    from ai.learning_engine import (
        get_group_success_rate, should_auto_snipe, 
        get_investment_multiplier, save_trade_result,
        get_top_performing_groups, get_database_summary
    )
    HAS_LEARNING_ENGINE = True
    logger.info("AI learning engine loaded successfully")
except ImportError:
    HAS_LEARNING_ENGINE = False
    logger.warning("AI learning engine not available, using static analysis")

# Import traditional analysis tools as fallbacks
from utils.token_analyzer import analyze_token_traditional
from utils.token_safety import check_token_safety

async def get_ai_token_analysis(token_address: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Get AI-powered token analysis with fallback to traditional analysis if AI is not available.
    
    Args:
        token_address: The token address to analyze
        context: Optional additional context about the token
        
    Returns:
        Dictionary with analysis results
    """
    # Default response structure
    result = {
        "token_address": token_address,
        "score": 0,
        "verdict": "Analysis unavailable",
        "recommendation": "avoid",
        "used_ai": False
    }
    
    # Try AI analysis first if available
    if HAS_AI_ENGINE:
        try:
            logger.info(f"Requesting AI analysis for {token_address}")
            ai_result = await ai_analyze_token(token_address, context)
            
            if ai_result:
                result.update(ai_result)
                result["used_ai"] = True
                logger.info(f"AI analysis completed for {token_address}: Score {ai_result.get('score', 0)}")
                return result
            else:
                logger.warning(f"AI analysis failed for {token_address}, falling back to traditional")
        except Exception as e:
            logger.error(f"Error in AI analysis: {e}")
            
    # Fallback to traditional analysis
    try:
        logger.info(f"Using traditional analysis for {token_address}")
        trad_result = analyze_token_traditional(token_address)
        
        if trad_result:
            # Map traditional analysis to AI format
            result["score"] = trad_result.get("potential_score", 0)
            result["verdict"] = trad_result.get("summary", "Analysis completed")
            result["recommendation"] = "buy" if trad_result.get("potential_score", 0) >= 70 else "avoid"
            logger.info(f"Traditional analysis completed for {token_address}")
        else:
            logger.error(f"Traditional analysis failed for {token_address}")
            
    except Exception as e:
        logger.error(f"Error in traditional analysis: {e}")
        
    return result

async def get_ai_safety_report(token_address: str) -> Dict[str, Any]:
    """
    Get AI-powered token safety report with fallback to traditional safety check.
    
    Args:
        token_address: The token address to analyze
        
    Returns:
        Dictionary with safety analysis
    """
    # Default response structure
    result = {
        "token_address": token_address,
        "safety_score": 0,
        "risk_level": "high",
        "risks": ["Unknown risk - analysis unavailable"],
        "recommendation": "avoid",
        "used_ai": False
    }
    
    # Try AI safety analysis first if available
    if HAS_AI_ENGINE:
        try:
            logger.info(f"Requesting AI safety report for {token_address}")
            ai_result = await ai_safety_report(token_address)
            
            if ai_result:
                result.update(ai_result)
                result["used_ai"] = True
                logger.info(f"AI safety report completed for {token_address}: Risk {ai_result.get('risk_level', 'unknown')}")
                return result
            else:
                logger.warning(f"AI safety report failed for {token_address}, falling back to traditional")
        except Exception as e:
            logger.error(f"Error in AI safety report: {e}")
            
    # Fallback to traditional safety check
    try:
        logger.info(f"Using traditional safety check for {token_address}")
        trad_result = check_token_safety(token_address)
        
        if trad_result:
            # Map traditional safety to AI format
            result["safety_score"] = trad_result.get("safety_score", 0)
            result["risk_level"] = trad_result.get("risk_level", "high")
            result["risks"] = trad_result.get("risks", ["Unknown"])
            result["recommendation"] = trad_result.get("recommendation", "avoid")
            logger.info(f"Traditional safety check completed for {token_address}")
        else:
            logger.error(f"Traditional safety check failed for {token_address}")
            
    except Exception as e:
        logger.error(f"Error in traditional safety check: {e}")
        
    return result

async def record_trade_performance(token_address: str, group_id: int, profit_percent: float) -> bool:
    """
    Record token trade performance for AI learning.
    
    Args:
        token_address: The token address
        group_id: The Telegram group ID where the token was mentioned
        profit_percent: The profit percentage achieved
        
    Returns:
        Boolean indicating if recording was successful
    """
    try:
        if HAS_LEARNING_ENGINE:
            logger.info(f"Recording trade performance for {token_address} from group {group_id}: {profit_percent:.2f}%")
            save_trade_result(token_address, group_id, profit_percent)
            return True
        else:
            logger.warning("Learning engine not available, trade performance not recorded")
            return False
    except Exception as e:
        logger.error(f"Error recording trade performance: {e}")
        return False

def check_group_auto_snipe(group_id: int) -> bool:
    """
    Check if a group qualifies for auto-sniping based on historical performance.
    
    Args:
        group_id: The Telegram group ID
        
    Returns:
        Boolean indicating if auto-sniping is recommended
    """
    try:
        if HAS_LEARNING_ENGINE:
            auto_snipe = should_auto_snipe(group_id)
            logger.info(f"Group {group_id} auto-snipe status: {auto_snipe}")
            return auto_snipe
        else:
            # Conservative default
            logger.warning("Learning engine not available, using conservative default for auto-snipe")
            return False
    except Exception as e:
        logger.error(f"Error checking group auto-snipe: {e}")
        return False

def get_position_multiplier(group_id: int) -> float:
    """
    Get the position size multiplier for a group based on historical performance.
    
    Args:
        group_id: The Telegram group ID
        
    Returns:
        Position size multiplier (0.5 to 3.0)
    """
    try:
        if HAS_LEARNING_ENGINE:
            multiplier = get_investment_multiplier(group_id)
            logger.info(f"Group {group_id} investment multiplier: {multiplier:.2f}x")
            return multiplier
        else:
            # Conservative default
            logger.warning("Learning engine not available, using default multiplier")
            return 1.0
    except Exception as e:
        logger.error(f"Error getting position multiplier: {e}")
        return 1.0

async def get_smart_analysis(token_address: str, group_id: Optional[int] = None, 
                            context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Get comprehensive smart analysis combining AI, safety, and learning.
    
    Args:
        token_address: The token address to analyze
        group_id: Optional group ID for learning-based adjustments
        context: Optional additional context
        
    Returns:
        Dictionary with comprehensive analysis
    """
    # Get basic analysis and safety reports
    analysis = await get_ai_token_analysis(token_address, context)
    safety = await get_ai_safety_report(token_address)
    
    # Combine results
    result = {
        "token_address": token_address,
        "score": analysis.get("score", 0),
        "safety_score": safety.get("safety_score", 0),
        "risk_level": safety.get("risk_level", "high"),
        "risks": safety.get("risks", []),
        "verdict": analysis.get("verdict", "Unknown"),
        "recommendation": analysis.get("recommendation", "avoid"),
        "used_ai": analysis.get("used_ai", False) or safety.get("used_ai", False)
    }
    
    # Apply learning-based adjustments if group_id is provided
    if group_id is not None and HAS_LEARNING_ENGINE:
        # Get group success rate
        success_rate = get_group_success_rate(group_id)
        
        # Adjust score based on group's historical performance
        if success_rate > 0.7:  # Excellent performance
            result["score"] = min(100, result["score"] * 1.2)  # Boost score by up to 20%
            logger.info(f"Boosted score for token from high-performing group: {group_id}")
        elif success_rate < 0.3:  # Poor performance
            result["score"] = max(0, result["score"] * 0.8)  # Reduce score by up to 20%
            logger.info(f"Reduced score for token from low-performing group: {group_id}")
            
        # Add learning-based info to the result
        result["group_success_rate"] = success_rate
        result["investment_multiplier"] = get_investment_multiplier(group_id)
        result["auto_snipe_eligible"] = should_auto_snipe(group_id)
    
    # Final recommendation based on combined score and safety
    combined_score = (result["score"] * 0.6) + (result["safety_score"] * 0.4)
    
    if combined_score >= 75 and result["safety_score"] >= 60:
        result["final_recommendation"] = "buy"
    elif combined_score >= 60 and result["safety_score"] >= 50:
        result["final_recommendation"] = "watch"
    else:
        result["final_recommendation"] = "avoid"
        
    result["combined_score"] = combined_score
    
    return result

async def test_ai_integration():
    """Test the AI integration with a sample token address."""
    test_token = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # SOL on Solana
    test_group_id = 12345  # Sample group ID
    
    logger.info("Testing AI integration...")
    
    # Test basic analysis
    analysis = await get_ai_token_analysis(test_token)
    logger.info(f"Analysis result for {test_token}: {analysis}")
    
    # Test safety report
    safety = await get_ai_safety_report(test_token)
    logger.info(f"Safety report for {test_token}: {safety}")
    
    # Test comprehensive smart analysis
    smart = await get_smart_analysis(test_token, test_group_id)
    logger.info(f"Smart analysis for {test_token}: {smart}")
    
    # Test learning functions if available
    if HAS_LEARNING_ENGINE:
        logger.info(f"Group auto-snipe status: {check_group_auto_snipe(test_group_id)}")
        logger.info(f"Position multiplier: {get_position_multiplier(test_group_id)}")
        
        # Mock recording a trade result
        success = await record_trade_performance(test_token, test_group_id, 25.5)
        logger.info(f"Recorded trade performance: {success}")
        
        # Get database summary
        summary = get_database_summary()
        logger.info(f"Learning database summary: {summary}")
    
    return {
        "analysis": analysis,
        "safety": safety,
        "smart": smart
    }

# Run test if executed directly
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(test_ai_integration())