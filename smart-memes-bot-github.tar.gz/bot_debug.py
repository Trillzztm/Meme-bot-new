#!/usr/bin/env python3
"""
Telegram Bot Debugging Script
"""

import os
import sys
import logging
import requests
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot_debug.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("BotDebug")

def main():
    # Get token
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN environment variable not set!")
        sys.exit(1)
    
    logger.info(f"Found token: {token[:5]}...{token[-5:]}")
    
    # Test the token by making a getMe request
    url = f"https://api.telegram.org/bot{token}/getMe"
    logger.info(f"Testing token with URL: {url}")
    
    try:
        response = requests.get(url, timeout=30)
        logger.info(f"Response status code: {response.status_code}")
        logger.info(f"Response content: {response.text}")
        
        if response.status_code == 200:
            data = response.json()
            if data.get("ok", False):
                bot_info = data.get("result", {})
                logger.info(f"Bot name: {bot_info.get('first_name', 'Unknown')}")
                logger.info(f"Bot username: {bot_info.get('username', 'Unknown')}")
                logger.info("Token is VALID")
            else:
                logger.error(f"Token test failed: {data.get('description', 'Unknown error')}")
        else:
            logger.error(f"Request failed with status code {response.status_code}")
    
    except Exception as e:
        logger.error(f"Error testing token: {e}")

if __name__ == "__main__":
    main()