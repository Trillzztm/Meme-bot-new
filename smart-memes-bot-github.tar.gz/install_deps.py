"""
SMART MEMES BOT - Dependency Installer

This script helps install all required dependencies for the SMART MEMES BOT.
"""

import os
import sys
import subprocess
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - Installer - %(levelname)s - %(message)s"
)
logger = logging.getLogger("Installer")

# Required packages for each component
PACKAGES = {
    "web": [
        "Flask",
        "Flask-Login",
        "gunicorn",
    ],
    "telegram": [
        "python-telegram-bot>=20.0,<21.0",
    ],
    "ai": [
        "openai",
    ],
    "solana": [
        "solana>=0.27.0,<0.28.0",
        "pyserum>=0.2.0,<0.3.0",
    ],
    "utilities": [
        "aiohttp",
        "python-dotenv",
        "requests",
        "base58",
    ]
}

def install_package(package):
    """Install a Python package."""
    try:
        logger.info(f"Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to install {package}: {e}")
        return False

def install_component(component_name):
    """Install all packages for a component."""
    if component_name not in PACKAGES:
        logger.error(f"Unknown component: {component_name}")
        return False
    
    logger.info(f"Installing {component_name} component...")
    
    success = True
    for package in PACKAGES[component_name]:
        if not install_package(package):
            success = False
    
    if success:
        logger.info(f"✅ {component_name} component installed successfully!")
    else:
        logger.error(f"❌ Failed to install some packages for {component_name} component")
    
    return success

def install_all():
    """Install all required packages."""
    logger.info("Installing all components...")
    
    success = True
    for component in PACKAGES:
        if not install_component(component):
            success = False
    
    if success:
        logger.info("✅ All components installed successfully!")
    else:
        logger.error("❌ Failed to install some components")
    
    return success

def show_usage():
    """Show usage information."""
    print(f"Usage: {sys.argv[0]} [component]")
    print("Components:")
    for component in PACKAGES:
        print(f"  - {component}")
    print("If no component is specified, all components will be installed.")

def main():
    """Main entry point."""
    logger.info("SMART MEMES BOT Dependency Installer")
    
    # No arguments, install all
    if len(sys.argv) == 1:
        install_all()
        return
    
    # Help
    if sys.argv[1] in ["-h", "--help", "help"]:
        show_usage()
        return
    
    # Install specific component
    if sys.argv[1] in PACKAGES:
        install_component(sys.argv[1])
        return
    
    # Unknown argument
    logger.error(f"Unknown component: {sys.argv[1]}")
    show_usage()

if __name__ == "__main__":
    main()