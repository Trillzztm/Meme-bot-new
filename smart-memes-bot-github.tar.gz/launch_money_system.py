"""
SMART MEMES BOT - Launch Money System

This script starts all components of the SMART MEMES BOT system:
1. Telegram bot
2. Auto-trading service
3. Web dashboard

Simply run this script to start making money automatically 24/7.
"""

import os
import sys
import time
import signal
import logging
import datetime
import threading
import traceback
import subprocess
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - LaunchSystem - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("launch_system.log"),
    ],
)
logger = logging.getLogger("LaunchSystem")

# Constants
CHECK_INTERVAL = 60  # seconds


class LaunchSystem:
    """System that ensures all components are running 24/7"""
    
    def __init__(self):
        """Initialize the system"""
        self.running = False
        self.threads = {}
        self.processes = {}
    
    def start_component(self, name: str, command: List[str]) -> bool:
        """Start a component"""
        try:
            # Kill any existing process
            self.stop_component(name)
            
            # Start the process
            logger.info(f"Starting {name}...")
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True
            )
            
            self.processes[name] = process
            logger.info(f"{name} started with PID: {process.pid}")
            return True
        except Exception as e:
            logger.error(f"Error starting {name}: {e}")
            traceback.print_exc()
            return False
    
    def stop_component(self, name: str) -> bool:
        """Stop a component"""
        try:
            if name in self.processes:
                process = self.processes[name]
                if process.poll() is None:  # Process is still running
                    logger.info(f"Stopping {name} (PID: {process.pid})...")
                    process.terminate()
                    process.wait(timeout=5.0)
                
                del self.processes[name]
                return True
            return False
        except Exception as e:
            logger.error(f"Error stopping {name}: {e}")
            return False
    
    def check_component(self, name: str) -> bool:
        """Check if a component is running"""
        try:
            if name in self.processes:
                process = self.processes[name]
                return process.poll() is None  # True if process is still running
            return False
        except Exception as e:
            logger.error(f"Error checking {name}: {e}")
            return False
    
    def monitor_thread(self):
        """Thread that monitors all components"""
        while self.running:
            try:
                for name, process in list(self.processes.items()):
                    # Check if the process is still running
                    if process.poll() is not None:
                        # Process has ended
                        logger.warning(f"{name} has stopped (exit code: {process.poll()}), restarting...")
                        
                        # Get the command for this component
                        command = None
                        if name == "telegram_bot":
                            command = ["python", "direct_bot.py"]
                        elif name == "auto_trader":
                            command = ["python", "auto_trader_service.py"]
                        
                        if command:
                            # Restart the component
                            self.start_component(name, command)
                
                # Sleep for a bit
                time.sleep(CHECK_INTERVAL)
            except Exception as e:
                logger.error(f"Error in monitor thread: {e}")
                time.sleep(CHECK_INTERVAL)
    
    def start(self):
        """Start the entire system"""
        if self.running:
            logger.warning("System already running")
            return
        
        logger.info("Starting SMART MEMES BOT system...")
        self.running = True
        
        # Start the monitor thread
        self.threads["monitor"] = threading.Thread(target=self.monitor_thread)
        self.threads["monitor"].daemon = True
        self.threads["monitor"].start()
        
        # Start all components
        self.start_component("telegram_bot", ["python", "direct_bot.py"])
        self.start_component("auto_trader", ["python", "auto_trader_service.py"])
        
        logger.info("SMART MEMES BOT system started")
        logger.info("Money-making operations are now fully automated and running 24/7!")
        logger.info("You can now use the Telegram bot and web dashboard to monitor your profits.")
    
    def stop(self):
        """Stop the entire system"""
        if not self.running:
            logger.warning("System not running")
            return
        
        logger.info("Stopping SMART MEMES BOT system...")
        self.running = False
        
        # Stop all components
        for name in list(self.processes.keys()):
            self.stop_component(name)
        
        # Wait for threads to stop
        for name, thread in self.threads.items():
            if thread.is_alive():
                thread.join(timeout=5.0)
        
        self.threads = {}
        logger.info("SMART MEMES BOT system stopped")
    
    def print_status(self):
        """Print the status of all components"""
        logger.info("=== SMART MEMES BOT SYSTEM STATUS ===")
        
        for name in ["telegram_bot", "auto_trader"]:
            status = "RUNNING" if self.check_component(name) else "STOPPED"
            logger.info(f"{name}: {status}")
        
        logger.info("=====================================")


if __name__ == "__main__":
    try:
        # Create system
        system = LaunchSystem()
        
        # Handle signals
        def signal_handler(sig, frame):
            logger.info("Received signal to stop")
            system.stop()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Start system
        system.start()
        
        # Print initial status
        system.print_status()
        
        # Keep running until Ctrl+C
        try:
            while True:
                time.sleep(60)
                system.print_status()
        except KeyboardInterrupt:
            system.stop()
            logger.info("System stopped by user")
    except Exception as e:
        logger.error(f"Error running system: {e}")
        traceback.print_exc()