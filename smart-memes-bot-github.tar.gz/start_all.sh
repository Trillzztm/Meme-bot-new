#!/bin/bash

# This script starts the entire SMART MEMES BOT system

echo "Starting SMART MEMES BOT System..."
echo "=================================="
echo "This system will run 24/7 and make money automatically."
echo "You can access the dashboard at the Replit URL"
echo ""

# Kill any existing bot processes
pkill -f "python direct_bot.py" || true
pkill -f "python auto_trader_service.py" || true
pkill -f "python launch_money_system.py" || true

# Wait for processes to terminate
sleep 2

# Start the web dashboard (already running via workflow)
echo "✅ Web dashboard running at port 5000"

# Start the Telegram bot in the background
echo "Starting Telegram bot..."
nohup python direct_bot.py > direct_bot.log 2>&1 &
BOT_PID=$!
echo "✅ Telegram bot started with PID: $BOT_PID"

# Start the auto-trader service in the background
echo "Starting auto-trader service..."
nohup python auto_trader_service.py > auto_trader.log 2>&1 &
TRADER_PID=$!
echo "✅ Auto-trader service started with PID: $TRADER_PID"

# Start the money system in the background
echo "Starting money system monitor..."
nohup python launch_money_system.py > money_system.log 2>&1 &
MONEY_PID=$!
echo "✅ Money system started with PID: $MONEY_PID"

echo ""
echo "System started successfully! All components running 24/7."
echo "Making profits automatically..."
echo ""
echo "You can monitor logs in:"
echo "- direct_bot.log (Telegram bot)"
echo "- auto_trader.log (Auto-trader service)"
echo "- money_system.log (Money system)"
echo ""
echo "Check dashboard for real-time profit updates!"