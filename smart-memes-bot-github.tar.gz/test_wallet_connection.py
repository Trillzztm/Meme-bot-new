#!/usr/bin/env python3
"""
WALLET CONNECTION TEST - SMART MEMES BOT

This script tests if your wallet is properly connected and ready to make real money trades.
"""

import os
import sys
import json
import asyncio
import logging
from typing import Dict, Any

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - WalletTest - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("WalletTest")

# Import Jupiter client
sys.path.append(".")
try:
    from utils.jupiter_client import JupiterClient, SOL_MINT, BONK_MINT
except ImportError:
    logger.error("Failed to import Jupiter client. Make sure utils/jupiter_client.py exists.")
    sys.exit(1)


async def test_wallet_connection():
    """Test if the wallet is properly connected"""
    
    # Check if we have the private key
    private_key = os.environ.get("SOLANA_PRIVATE_KEY")
    if not private_key:
        logger.error("❌ SOLANA_PRIVATE_KEY not found in environment variables!")
        logger.error("Please set this variable to connect your wallet.")
        return False
    
    logger.info("✅ Found SOLANA_PRIVATE_KEY in environment variables")
    
    # Create Jupiter client
    try:
        client = JupiterClient()
        logger.info("✅ Created Jupiter client successfully")
    except Exception as e:
        logger.error(f"❌ Failed to create Jupiter client: {e}")
        return False
    
    # Check if we have wallet address
    if not client.wallet_address:
        logger.error("❌ No wallet address found. Check your private key format.")
        return False
    
    logger.info(f"✅ Wallet address detected: {client.wallet_address}")
    
    # Get wallet balance
    try:
        # Using direct RPC query for simplicity
        import aiohttp
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.mainnet-beta.solana.com",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "getBalance",
                    "params": [client.wallet_address]
                },
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    logger.error(f"❌ Failed to get wallet balance: {await response.text()}")
                    return False
                
                result = await response.json()
                
                if "result" in result:
                    balance_lamports = result["result"]["value"]
                    balance_sol = balance_lamports / 10**9
                    logger.info(f"✅ Wallet balance: {balance_sol:.6f} SOL")
                    
                    # Check if we have enough SOL for trading
                    if balance_sol < 0.01:
                        logger.warning(f"⚠️ Low wallet balance: {balance_sol:.6f} SOL")
                        logger.warning("Consider adding more SOL for better trading")
                    
                    return True
                else:
                    logger.error(f"❌ Failed to read wallet balance: {result}")
                    return False
    except Exception as e:
        logger.error(f"❌ Error getting wallet balance: {e}")
        return False


async def test_quote():
    """Test getting a price quote from Jupiter"""
    try:
        client = JupiterClient()
        
        # Try to get a simple SOL → BONK quote
        logger.info("Testing Jupiter quote API...")
        quote = await client.get_quote(SOL_MINT, BONK_MINT, 10000000)  # 0.01 SOL
        
        if "error" in quote:
            logger.error(f"❌ Failed to get Jupiter quote: {quote['error']}")
            return False
        
        # Extract important info from quote
        in_amount = int(quote.get("inAmount", 0))
        out_amount = int(quote.get("outAmount", 0))
        price_impact = quote.get("priceImpactPct", 0)
        
        logger.info(f"✅ Jupiter quote received!")
        logger.info(f"   Input: {in_amount / 10**9:.6f} SOL")
        logger.info(f"   Output: {out_amount} BONK")
        logger.info(f"   Price Impact: {price_impact}%")
        
        return True
    except Exception as e:
        logger.error(f"❌ Error testing Jupiter quote: {e}")
        return False


async def main():
    """Main test function"""
    print("\n" + "="*50)
    print("SMART MEMES BOT - WALLET CONNECTION TEST")
    print("="*50 + "\n")
    
    # Test wallet connection
    print("\n📝 TESTING WALLET CONNECTION...")
    wallet_ok = await test_wallet_connection()
    
    # Test Jupiter quote API
    print("\n📝 TESTING JUPITER API CONNECTION...")
    quote_ok = await test_quote()
    
    # Print summary
    print("\n" + "="*50)
    print("TEST SUMMARY")
    print("="*50)
    
    if wallet_ok:
        print("✅ Wallet Connection: CONNECTED")
    else:
        print("❌ Wallet Connection: FAILED")
    
    if quote_ok:
        print("✅ Jupiter API: WORKING")
    else:
        print("❌ Jupiter API: FAILED")
    
    if wallet_ok and quote_ok:
        print("\n🎉 ALL TESTS PASSED! Your system is ready to make real money trades!")
        print("Run './start_money_maker.sh' to start making profits!")
    else:
        print("\n⚠️ SOME TESTS FAILED. Please fix the issues above before trading.")
    
    print("\n" + "="*50 + "\n")


if __name__ == "__main__":
    asyncio.run(main())