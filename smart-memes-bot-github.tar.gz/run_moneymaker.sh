#!/bin/bash

# Run Money Maker Script for SMART MEMES BOT
# This bash script launches the SMART MEMES BOT money making system
# with all required components.

echo "========================================"
echo "  SMART MEMES BOT - MONEY MAKER SYSTEM  "
echo "========================================"
echo ""
echo "Starting the money-making system..."
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is required but not installed."
    exit 1
fi

# Check if required packages are installed
echo "Checking required packages..."
python3 -c "import flask, requests, datetime, json, threading, logging" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Error: Required Python packages are missing."
    echo "Please install them using: pip install flask requests"
    exit 1
fi

# Check for necessary files
if [ ! -f "phantom_direct_connector.py" ] || [ ! -f "jupiter_trading.py" ]; then
    echo "Error: Required component files are missing."
    echo "Please make sure phantom_direct_connector.py and jupiter_trading.py exist."
    exit 1
fi

# Create necessary directories
mkdir -p templates
mkdir -p static

# Start the money-making system
echo "Launching the system..."
echo ""
python3 launch_moneymaker.py

# This script will only continue if the program exits
echo ""
echo "SMART MEMES BOT has been stopped."