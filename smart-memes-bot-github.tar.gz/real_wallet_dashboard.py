"""
Real Wallet Dashboard Integration for SMART MEMES BOT

This module connects the web dashboard to real cryptocurrency wallets,
displaying actual balances, portfolio values, and enabling real money trades.
"""

import os
import json
import logging
import requests
from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify
from datetime import datetime

# Import wallet integration
from wallet_integration import (
    get_solana_balance,
    get_wallet_tokens,
    get_wallet_portfolio,
    execute_trade,
    wallet_initialized,
    test_connection
)

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("RealWalletDashboard")

# Constants
TRANSACTIONS_FILE = "real_transactions.json"

# Blueprint for real wallet routes
real_wallet_bp = Blueprint('real_wallet', __name__)


def save_transaction(token, amount, tx_type, status="completed", tx_hash=None):
    """
    Save a transaction to the transactions file
    
    Args:
        token: Token symbol or address
        amount: Amount (positive for buys, negative for sells)
        tx_type: Transaction type
        status: Transaction status
        tx_hash: Optional transaction hash
    """
    if not os.path.exists(TRANSACTIONS_FILE):
        transactions = []
    else:
        try:
            with open(TRANSACTIONS_FILE, "r") as f:
                transactions = json.load(f)
        except:
            transactions = []
    
    # Add new transaction
    transactions.append({
        "timestamp": datetime.now().isoformat(),
        "token": token,
        "amount": amount,
        "type": tx_type,
        "status": status,
        "tx_hash": tx_hash
    })
    
    # Save transactions
    with open(TRANSACTIONS_FILE, "w") as f:
        json.dump(transactions, f, indent=2)


def get_transactions():
    """
    Get all transactions
    
    Returns:
        list: List of transactions
    """
    if not os.path.exists(TRANSACTIONS_FILE):
        return []
    
    try:
        with open(TRANSACTIONS_FILE, "r") as f:
            return json.load(f)
    except:
        return []


@real_wallet_bp.route('/real-dashboard')
def real_dashboard():
    """Real money dashboard"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('real_dashboard.html')


@real_wallet_bp.route('/api/wallet/portfolio')
def wallet_portfolio():
    """Get wallet portfolio"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    portfolio = get_wallet_portfolio()
    transactions = get_transactions()
    
    # Calculate lifetime profit/loss from transactions
    total_profit = 0
    for tx in transactions:
        if tx['type'] in ['sell', 'profit']:
            total_profit += tx['amount']
    
    return jsonify({
        "portfolio": portfolio,
        "transactions": transactions,
        "total_profit": total_profit,
        "wallet_initialized": wallet_initialized(),
        "connection_status": test_connection()
    })


@real_wallet_bp.route('/api/wallet/trade', methods=['POST'])
def execute_wallet_trade():
    """Execute a trade with real wallet"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    data = request.json
    
    token_address = data.get('token_address')
    amount = data.get('amount')
    side = data.get('side', 'buy')
    
    if not token_address or not amount:
        return jsonify({"error": "Missing parameters"}), 400
    
    try:
        amount = float(amount)
    except:
        return jsonify({"error": "Invalid amount"}), 400
    
    # Execute trade
    result = execute_trade(token_address, amount, side)
    
    # Save transaction if successful
    if result.get('success'):
        tx_amount = amount if side == 'buy' else -amount
        save_transaction(token_address, tx_amount, side, result.get('status', 'completed'), result.get('tx_hash'))
    
    return jsonify(result)


@real_wallet_bp.route('/api/wallet/status')
def wallet_status():
    """Get wallet status"""
    if 'logged_in' not in session:
        return jsonify({"error": "Not logged in"}), 401
    
    return jsonify({
        "wallet_initialized": wallet_initialized(),
        "connection_status": test_connection()
    })