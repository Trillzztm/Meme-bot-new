"""
Advanced token sniper module with safety checks.

This module handles token sniping operations including:
- Token validation and safety checks
- Automatic token purchase on DEXes
- Profit tracking and automatic selling
- Auto-sniping based on token mentions in watched groups
"""

import os
import logging
import json
import time
import asyncio
import re
from datetime import datetime, timedelta
import random
from typing import Dict, List, Any, Optional, Union

# Import database module with SQLite compatibility
import database as db

# Configure logging
logger = logging.getLogger(__name__)

# Constants
MIN_LIQUIDITY_USD = 5000  # Minimum liquidity in USD
MAX_SLIPPAGE = 25  # Maximum slippage percentage to allow
MIN_SAFETY_SCORE = 60  # Minimum safety score for auto-buying
MIN_TIME_BETWEEN_SNIPES = 300  # Minimum seconds between snipes (prevent spam)
DEFAULT_GAS_BOOST = 5  # Percentage to boost gas price for faster transactions
# Token tracking list for manual sniping
TOKEN_LIST = []

# Supported DEXes
SUPPORTED_DEXES = {
    "ethereum": ["uniswap_v2", "uniswap_v3", "sushiswap"],
    "bsc": ["pancakeswap_v2", "biswap", "apeswap"],
    "polygon": ["quickswap", "sushiswap", "uniswap_v3"],
    "arbitrum": ["sushiswap", "uniswap_v3", "camelot"],
    "optimism": ["uniswap_v3", "velodrome"],
    "avalanche": ["traderjoe", "pangolin"],
    "fantom": ["spookyswap", "spiritswap"],
    "solana": ["raydium", "orca"]
}

# User settings storage (in-memory for demo)
user_settings = {}

def initialize_user_settings(user_id):
    """
    Initialize settings for a new user if they don't exist.
    
    Args:
        user_id (str): Telegram user ID
        
    Returns:
        dict: User settings
    """
    if user_id not in user_settings:
        # Default settings
        user_settings[user_id] = {
            "max_spend": 0.1,              # Default max spend in ETH
            "slippage": 12,                # Default slippage percentage
            "gas_price": "medium",         # Default gas price setting
            "auto_snipe": False,           # Auto-snipe enabled?
            "safety_minimum_score": 70,    # Minimum safety score to allow sniping
            "max_tax": 15,                 # Maximum tax percentage to allow
            "ignore_safety": False,        # Ignore safety checks?
            "auto_sell_profit_target": 0,  # 0 means disabled
            "auto_sell_loss_limit": 0,     # 0 means disabled
            "tracked_tokens": [],          # List of tokens being tracked
            "blacklisted_tokens": [],      # Blacklisted tokens
            "blocked_groups": [],          # Blocked groups
            "favorite_dexes": {}           # Preferred DEXes per network
        }
        
        # Also create in database if available
        try:
            db.get_or_create_user(user_id)
            db_settings = db.get_user_settings(user_id)
            if not db_settings:
                db.update_user_settings(user_id, user_settings[user_id])
        except Exception as e:
            logger.error(f"Error initializing user settings in database: {str(e)}")
    
    return user_settings[user_id]

def update_user_settings(user_id, settings_update):
    """
    Update settings for a user.
    
    Args:
        user_id (str): Telegram user ID
        settings_update (dict): Settings to update
        
    Returns:
        dict: Updated user settings
    """
    # Initialize if not exists
    if user_id not in user_settings:
        initialize_user_settings(user_id)
    
    # Update in-memory settings
    user_settings[user_id].update(settings_update)
    
    # Also update in database if available
    try:
        db.update_user_settings(user_id, settings_update)
    except Exception as e:
        logger.error(f"Error updating user settings in database: {str(e)}")
    
    return user_settings[user_id]

def add_token_to_track(user_id, token_address, token_symbol=None, token_name=None, network="ethereum"):
    """
    Add a token to user's tracking list.
    
    Args:
        user_id (str): Telegram user ID
        token_address (str): Token contract address
        token_symbol (str, optional): Token symbol
        token_name (str, optional): Token name
        network (str): Blockchain network
        
    Returns:
        bool: Success or failure
    """
    # Initialize if not exists
    if user_id not in user_settings:
        initialize_user_settings(user_id)
    
    # Add to tracked tokens if not already there
    if "tracked_tokens" not in user_settings[user_id]:
        user_settings[user_id]["tracked_tokens"] = []
    
    # Create token entry
    token_entry = {
        "address": token_address,
        "symbol": token_symbol,
        "name": token_name,
        "network": network,
        "added_at": datetime.now().timestamp()
    }
    
    # Check if already tracked
    for token in user_settings[user_id]["tracked_tokens"]:
        if token.get("address", "").lower() == token_address.lower():
            # Update existing entry
            token.update(token_entry)
            
            # Also update in database if available
            try:
                if asyncio.iscoroutinefunction(db.add_token_to_watchlist):
                    asyncio.create_task(db.add_token_to_watchlist(token_address, user_id, token_name, network))
                else:
                    db.add_token_to_watchlist(token_address, user_id, token_name, network)
            except Exception as e:
                logger.error(f"Error updating tracked token in database: {str(e)}")
            
            return True
    
    # Add new entry
    user_settings[user_id]["tracked_tokens"].append(token_entry)
    
    # Also add in database if available
    try:
        if asyncio.iscoroutinefunction(db.add_token_to_watchlist):
            asyncio.create_task(db.add_token_to_watchlist(token_address, user_id, token_name, network))
        else:
            db.add_token_to_watchlist(token_address, user_id, token_name, network)
    except Exception as e:
        logger.error(f"Error adding tracked token to database: {str(e)}")
    
    return True

# Track last sniped tokens to prevent duplicates
last_snipes = {}

async def validate_token_for_sniping(token_address, network="ethereum", user_settings=None):
    """
    Comprehensive token validation before sniping.
    
    Args:
        token_address (str): The token contract address
        network (str): Blockchain network
        user_settings (dict, optional): User settings to override defaults
        
    Returns:
        tuple: (is_valid, validation_results)
    """
    logger.info(f"Validating token {token_address} on {network} for sniping")
    
    # Initialize validation results
    validation = {
        "is_valid": False,
        "token_address": token_address,
        "network": network,
        "checks": [],
        "errors": [],
        "warnings": []
    }
    
    try:
        # Import analyze_token and check_token_safety from token_analyzer
        # This is done here to avoid circular imports
        from token_analyzer import analyze_token, check_token_safety
        
        # Check if the address is valid
        if not re.match(r"^0x[a-fA-F0-9]{40}$", token_address) and not re.match(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$", token_address):
            validation["errors"].append("Invalid token address format")
            return False, validation
        
        # Get safety check results
        safety_check = await check_token_safety(token_address, network)
        if not safety_check.get("success", False):
            validation["errors"].append(f"Failed to perform safety check: {safety_check.get('error', 'Unknown error')}")
            return False, validation
        
        # Extract safety data
        safety_score = safety_check.get("safety_score", 0)
        is_honeypot = safety_check.get("is_potential_honeypot", False)
        buy_tax = safety_check.get("buy_tax", 0)
        sell_tax = safety_check.get("sell_tax", 0)
        issues = safety_check.get("issues", [])
        token_info = safety_check.get("token_info", {})
        
        # Use user settings if provided, otherwise use defaults
        min_safety_score = user_settings.get("safety_minimum_score", MIN_SAFETY_SCORE) if user_settings else MIN_SAFETY_SCORE
        max_tax = user_settings.get("max_tax", 15) if user_settings else 15
        ignore_safety = user_settings.get("ignore_safety", False) if user_settings else False
        
        # Check if token is in user's blacklist
        blacklisted_tokens = []
        if user_settings and "blacklisted_tokens" in user_settings:
            try:
                if isinstance(user_settings["blacklisted_tokens"], str):
                    blacklisted_tokens = json.loads(user_settings["blacklisted_tokens"])
                else:
                    blacklisted_tokens = user_settings["blacklisted_tokens"]
            except:
                pass
        
        if token_address.lower() in [t.lower() for t in blacklisted_tokens]:
            validation["errors"].append("Token is in your blacklist")
            return False, validation
        
        # Add token info to the validation
        validation["token_info"] = {
            "name": token_info.get("name", "Unknown"),
            "symbol": token_info.get("symbol", "???"),
            "safety_score": safety_score,
            "buy_tax": buy_tax,
            "sell_tax": sell_tax
        }
        
        # Perform validation checks
        checks = validation["checks"]
        
        # Check for honeypot
        if is_honeypot:
            validation["errors"].append("Token appears to be a honeypot")
            checks.append({"name": "honeypot_check", "passed": False, "value": "Potential honeypot detected"})
        else:
            checks.append({"name": "honeypot_check", "passed": True, "value": "Not a honeypot"})
        
        # Check safety score
        if safety_score < min_safety_score and not ignore_safety:
            validation["errors"].append(f"Safety score too low: {safety_score} (minimum: {min_safety_score})")
            checks.append({"name": "safety_score", "passed": False, "value": safety_score})
        else:
            checks.append({"name": "safety_score", "passed": True, "value": safety_score})
        
        # Check taxes
        total_tax = buy_tax + sell_tax
        if total_tax > max_tax and not ignore_safety:
            validation["errors"].append(f"Total tax too high: {total_tax}% (maximum: {max_tax}%)")
            checks.append({"name": "tax_check", "passed": False, "value": f"{buy_tax}% buy, {sell_tax}% sell"})
        else:
            checks.append({"name": "tax_check", "passed": True, "value": f"{buy_tax}% buy, {sell_tax}% sell"})
        
        # Get token analysis for more data
        analysis = await analyze_token(token_address, network)
        if analysis.get("success", False):
            # Check liquidity
            liquidity = analysis.get("token_info", {}).get("liquidity_usd", 0)
            if liquidity < MIN_LIQUIDITY_USD and not ignore_safety:
                validation["warnings"].append(f"Low liquidity: ${liquidity} (minimum: ${MIN_LIQUIDITY_USD})")
                checks.append({"name": "liquidity_check", "passed": False, "value": f"${liquidity}"})
            else:
                checks.append({"name": "liquidity_check", "passed": True, "value": f"${liquidity}"})
            
            # Add price prediction
            price_prediction = analysis.get("price_prediction", {})
            if price_prediction.get("success", False):
                validation["price_prediction"] = {
                    "current_price": price_prediction.get("current_price", 0),
                    "prediction_24h": price_prediction.get("predictions", [])[0].get("price_change", 0) if price_prediction.get("predictions") else 0,
                    "prediction_7d": price_prediction.get("predictions", [])[1].get("price_change", 0) if len(price_prediction.get("predictions", [])) > 1 else 0
                }
            
            # Add investment recommendation
            validation["recommendation"] = analysis.get("recommendation", {})
        
        # Final validation result
        is_valid = len(validation["errors"]) == 0
        validation["is_valid"] = is_valid
        
        return is_valid, validation
        
    except Exception as e:
        logger.error(f"Error validating token: {str(e)}")
        validation["errors"].append(f"Validation error: {str(e)}")
        return False, validation

async def execute_token_snipe(token_address, amount, network="ethereum", 
                             slippage=0.5, gas_price="auto", dex="auto", 
                             user_id=None, is_auto=False):
    """
    Execute a token snipe transaction.
    
    Args:
        token_address (str): The token contract address
        amount (float): Amount to spend in native currency
        network (str): Blockchain network
        slippage (float): Maximum slippage percentage
        gas_price (str): Gas price setting (low, medium, high, rapid, auto)
        dex (str): DEX to use (or "auto" for automatic selection)
        user_id (str): Telegram user ID
        is_auto (bool): Whether this is an auto-snipe
        
    Returns:
        dict: Transaction results
    """
    logger.info(f"Executing snipe for {token_address} on {network}, amount: {amount}")
    
    # For this demo, we'll simulate transaction execution
    # In a real implementation, we would call blockchain APIs
    
    # Initialize result
    result = {
        "success": False,
        "token_address": token_address,
        "network": network,
        "amount": amount,
        "amount_spent": amount,  # For display in success message
        "estimated_tokens": 0,  # For display in success message
        "wallet_address": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",  # Example wallet address
        "timestamp": datetime.now().timestamp(),
        "transaction_hash": None,
        "tokens_received": 0,
        "entry_price": 0,
        "status": "pending",
        "error": None
    }
    
    try:
        # Validate the token first
        if user_id:
            # Get user settings
            user_settings_dict = await get_user_settings(user_id)
            is_valid, validation = await validate_token_for_sniping(token_address, network, user_settings_dict)
        else:
            is_valid, validation = await validate_token_for_sniping(token_address, network)
        
        if not is_valid:
            result["status"] = "failed"
            result["error"] = "Token validation failed: " + "; ".join(validation.get("errors", []))
            
            # Record the failed snipe in database if user_id is provided
            if user_id:
                try:
                    if asyncio.iscoroutinefunction(db.create_snipe_transaction):
                        await db.create_snipe_transaction(
                            token_address=token_address,
                            transaction_hash="",
                            user_id=user_id,
                            amount=amount,
                            entry_price=0
                        )
                    else:
                        db.create_snipe_transaction(
                            token_address=token_address,
                            transaction_hash="",
                            user_id=user_id,
                            amount=amount,
                            entry_price=0
                        )
                except Exception as e:
                    logger.error(f"Error recording snipe transaction: {str(e)}")
            
            return result
        
        # Check if we've sniped this token recently to prevent duplicates
        if token_address in last_snipes:
            last_snipe_time = last_snipes[token_address]
            if (datetime.now() - last_snipe_time).total_seconds() < MIN_TIME_BETWEEN_SNIPES:
                result["status"] = "failed"
                result["error"] = f"This token was sniped recently, please wait {MIN_TIME_BETWEEN_SNIPES} seconds between snipes"
                return result
        
        # Select DEX if auto
        if dex == "auto":
            available_dexes = SUPPORTED_DEXES.get(network, [])
            if available_dexes:
                dex = available_dexes[0]
            else:
                result["status"] = "failed"
                result["error"] = f"No supported DEXes for network {network}"
                return result
        
        # Calculate gas price
        gas_prices = {
            "low": 0.8,
            "medium": 1.0,
            "high": 1.5,
            "rapid": 2.0,
            "auto": 1.0
        }
        gas_multiplier = gas_prices.get(gas_price, 1.0)
        if gas_price == "auto":
            # We'd fetch the current gas price from the network here
            # For the demo, we'll use a random value
            gas_multiplier = 0.8 + (random.random() * 0.4)
        
        # For this demo, generate a simulated transaction
        tx_hash = f"0x{''.join(random.choices('0123456789abcdef', k=64))}"
        tokens_received = amount * 1000000  # Simulated tokens received
        entry_price = amount / tokens_received  # Simulated entry price
        
        # Record the transaction
        result["success"] = True
        result["status"] = "completed"
        result["transaction_hash"] = tx_hash
        result["tokens_received"] = tokens_received
        result["entry_price"] = entry_price
        result["estimated_tokens"] = tokens_received
        
        # Record the snipe time to prevent duplicates
        last_snipes[token_address] = datetime.now()
        
        # Record the transaction in database if user_id is provided
        if user_id:
            try:
                if asyncio.iscoroutinefunction(db.create_snipe_transaction):
                    transaction_id = await db.create_snipe_transaction(
                        token_address=token_address,
                        transaction_hash=tx_hash,
                        user_id=user_id,
                        amount=amount,
                        entry_price=entry_price
                    )
                else:
                    transaction_id = db.create_snipe_transaction(
                        token_address=token_address,
                        transaction_hash=tx_hash,
                        user_id=user_id,
                        amount=amount,
                        entry_price=entry_price
                    )
                
                logger.info(f"Recorded transaction ID: {transaction_id}")
                result["transaction_id"] = transaction_id
            except Exception as e:
                logger.error(f"Error recording snipe transaction: {str(e)}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error executing token snipe: {str(e)}")
        result["status"] = "failed"
        result["error"] = f"Snipe execution error: {str(e)}"
        return result

async def get_user_settings(user_id):
    """Get user settings from database."""
    try:
        if asyncio.iscoroutinefunction(db.get_user_settings):
            db_settings = await db.get_user_settings(user_id)
        else:
            db_settings = db.get_user_settings(user_id)
        
        if db_settings:
            return db_settings
        
        # Return default settings if not found
        return initialize_user_settings(user_id)
    except Exception as e:
        logger.error(f"Error getting user settings: {str(e)}")
        return initialize_user_settings(user_id)

async def get_user_transactions(user_id, limit=10):
    """Get recent transactions for a user."""
    try:
        if asyncio.iscoroutinefunction(db.get_transactions):
            return await db.get_transactions(user_id, limit=limit)
        else:
            return db.get_transactions(user_id, limit=limit)
    except Exception as e:
        logger.error(f"Error getting user transactions: {str(e)}")
        return []

async def run_token_sniping_tasks():
    """Run token sniping background tasks."""
    logger.info("Starting token sniping tasks")
    
    while True:
        try:
            # Task 1: Update token prices and values
            await update_token_prices_and_values()
            
            # Task 2: Check auto-sell conditions
            await check_auto_sell_conditions()
            
            # Task 3: Check group mentions for auto-sniping
            await check_group_mentions_for_auto_sniping()
            
            # Sleep for 60 seconds
            await asyncio.sleep(60)
        
        except Exception as e:
            logger.error(f"Error in token sniping tasks: {str(e)}")
            await asyncio.sleep(10)  # Sleep briefly before retrying

async def update_token_prices_and_values():
    """Update token prices and values for all tracked tokens."""
    try:
        # Get all users with their tracked tokens
        try:
            # Get users with SQLite
            conn = db.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT id FROM users")
            users = [dict(row) for row in cursor.fetchall()]
            
            for user in users:
                user_id = user['id']
                
                # Get tracked tokens for user
                cursor.execute("SELECT * FROM token_watchlist WHERE user_id = ?", (user_id,))
                tokens = [dict(row) for row in cursor.fetchall()]
                
                await process_tokens_for_user(user_id, tokens)
                
        except Exception as e:
            logger.error(f"Error updating token prices and values: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error updating token prices and values: {str(e)}")

async def process_tokens_for_user(user_id, tokens):
    """Process tokens for a specific user."""
    try:
        # Process each token
        for token in tokens:
            token_address = token['token_address']
            network = token['network']
            
            # Get current price
            current_price = await get_token_price(token_address, network)
            
            if current_price:
                # In a real implementation, we would update the token price in database
                # and calculate current value of holdings
                logger.debug(f"Updated price for {token_address}: {current_price}")
    
    except Exception as e:
        logger.error(f"Error processing tokens for user {user_id}: {str(e)}")

async def check_auto_sell_conditions():
    """Check auto-sell conditions for all active snipes."""
    try:
        # Get all active snipes with their tokens
        try:
            # Get active snipes with SQLite
            conn = db.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM snipe_transactions WHERE status = 'pending' OR status = 'completed'")
            snipes = [dict(row) for row in cursor.fetchall()]
            
            for snipe in snipes:
                try:
                    await check_snipe_for_auto_sell(snipe)
                except Exception as e:
                    logger.error(f"Error checking snipe {snipe.get('id')}: {str(e)}")
                
        except Exception as e:
            logger.error(f"Error checking auto-sell conditions: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error checking auto-sell conditions: {str(e)}")

async def check_snipe_for_auto_sell(snipe):
    """Check auto-sell conditions for a specific snipe."""
    try:
        token_address = snipe['token_address']
        user_id = snipe['user_id']
        entry_price = snipe['entry_price'] or 0
        
        if entry_price <= 0:
            return
        
        # Get current price
        current_price = await get_token_price(token_address)
        
        if not current_price:
            return
        
        # Calculate profit/loss percentage
        if entry_price > 0:
            profit_percent = ((current_price / entry_price) - 1) * 100
        else:
            profit_percent = 0
        
        # Get user settings
        user_settings_dict = await get_user_settings(user_id)
        
        # Check profit target
        profit_target = user_settings_dict.get("auto_sell_profit_target", 0)
        if profit_target > 0 and profit_percent >= profit_target:
            # Execute auto-sell
            logger.info(f"Auto-selling {token_address} at profit target: {profit_percent:.2f}%")
            await execute_token_sell(token_address, user_id, "profit_target")
        
        # Check loss limit
        loss_limit = user_settings_dict.get("auto_sell_loss_limit", 0)
        if loss_limit > 0 and profit_percent <= -loss_limit:
            # Execute auto-sell
            logger.info(f"Auto-selling {token_address} at loss limit: {profit_percent:.2f}%")
            await execute_token_sell(token_address, user_id, "loss_limit")
    
    except Exception as e:
        logger.error(f"Error checking snipe for auto-sell: {str(e)}")

async def execute_token_sell(token_address, user_id, reason):
    """Execute a token sell transaction."""
    # In a real implementation, this would execute a sell transaction
    # For the demo, we'll just log it
    logger.info(f"Would execute sell for {token_address} by user {user_id} due to {reason}")

async def check_group_mentions_for_auto_sniping():
    """Check group mentions for auto-sniping."""
    try:
        # Get all groups with auto-sniping enabled
        try:
            # Get groups with SQLite
            conn = db.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM tracked_groups WHERE auto_snipe = 1")
            groups = [dict(row) for row in cursor.fetchall()]
            
            for group in groups:
                group_id = group['group_id']
                min_mentions = group['min_mentions']
                
                # Get token mentions for this group
                cursor.execute("""
                SELECT * FROM token_mentions 
                WHERE group_id = ? AND mention_count >= ?
                """, (group_id, min_mentions))
                
                mentions = [dict(row) for row in cursor.fetchall()]
                
                for mention in mentions:
                    token_address = mention['token_address']
                    
                    # Check if this token has already been sniped
                    cursor.execute("""
                    SELECT * FROM snipe_transactions 
                    WHERE token_address = ? AND group_id = ?
                    """, (token_address, group_id))
                    
                    existing_snipes = cursor.fetchall()
                    
                    if not existing_snipes:
                        # This is a new token mention with sufficient mentions for auto-sniping
                        await consider_auto_sniping(token_address, group_id, mention)
                
        except Exception as e:
            logger.error(f"Error checking group mentions for auto-sniping: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error checking group mentions for auto-sniping: {str(e)}")

async def consider_auto_sniping(token_address, group_id, mention):
    """Consider auto-sniping a token based on group mentions."""
    try:
        # In a real implementation, we would validate the token and execute the snipe
        # For the demo, we'll just log it
        logger.info(f"Considering auto-snipe for {token_address} from group {group_id}")
        
        # Validate the token
        is_valid, validation = await validate_token_for_sniping(token_address)
        
        if is_valid:
            logger.info(f"Would auto-snipe valid token {token_address} from group {group_id}")
            # In a real implementation, we would execute the snipe
        else:
            logger.info(f"Token {token_address} from group {group_id} failed validation: {validation.get('errors')}")
    
    except Exception as e:
        logger.error(f"Error considering auto-sniping: {str(e)}")

async def get_token_price(token_address, network="ethereum"):
    """Get the current price of a token."""
    # In a real implementation, this would call a price API
    # For the demo, we'll just generate a random price
    try:
        # Example:
        # 0.000001 to 0.1 with some randomness
        price = 0.00001 * (1 + (random.random() * 0.2) - 0.1)  # +/- 10% random variation
        return price
    except Exception as e:
        logger.error(f"Error getting token price: {str(e)}")
        return None