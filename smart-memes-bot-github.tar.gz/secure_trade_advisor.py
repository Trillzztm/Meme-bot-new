"""
Secure Trade Advisor for SMART MEMES BOT

This module provides trading suggestions that require manual approval.
It analyzes market conditions to recommend profitable trades,
but YOU retain complete control over your funds.
"""

import os
import time
import json
import logging
import random
import requests
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SecureTradeAdvisor")

# Constants
SUGGESTIONS_FILE = "trade_suggestions.json"
BIRDEYE_API_KEY = os.environ.get("BIRDEYE_API_KEY")
SOL_PRICE_USD = 100.0  # Fallback price if API call fails

# Base tokens to track
TRACKED_TOKENS = [
    {"symbol": "BONK", "address": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"}, 
    {"symbol": "WIF", "address": "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"},
    {"symbol": "JTO", "address": "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"},
    {"symbol": "PYTH", "address": "CsKLfUw8rT4QZ2jjQY58RWcyF3fuRuD2rQYJxQRcJ5Sw"},
    {"symbol": "RNDR", "address": "rndrizKT3MK1iimdxRdWabcF7Zg7AR5T4nud4EkHBof"},
]

def get_suggestions_file():
    """Get or create the suggestions file"""
    if not os.path.exists(SUGGESTIONS_FILE):
        with open(SUGGESTIONS_FILE, "w") as f:
            json.dump({"suggestions": [], "completed": []}, f, indent=2)
    
    try:
        with open(SUGGESTIONS_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading suggestions file: {e}")
        return {"suggestions": [], "completed": []}

def save_suggestions_file(data):
    """Save suggestions to file"""
    try:
        with open(SUGGESTIONS_FILE, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving suggestions file: {e}")
        return False

def get_sol_price():
    """Get current SOL price in USD from BirdEye API"""
    if not BIRDEYE_API_KEY:
        logger.warning("No BIRDEYE_API_KEY found. Using fallback price.")
        return SOL_PRICE_USD
    
    try:
        url = "https://public-api.birdeye.so/public/price?address=So11111111111111111111111111111111111111112"
        headers = {"X-API-KEY": BIRDEYE_API_KEY}
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success") and "data" in data:
                return data["data"]["value"]
        
        return SOL_PRICE_USD
    except Exception as e:
        logger.error(f"Error getting SOL price: {e}")
        return SOL_PRICE_USD

def get_token_price(token_address):
    """Get token price in USD from BirdEye API"""
    if not BIRDEYE_API_KEY:
        # Without API key, use simulated price
        return random.uniform(0.001, 0.1)
    
    try:
        url = f"https://public-api.birdeye.so/public/price?address={token_address}"
        headers = {"X-API-KEY": BIRDEYE_API_KEY}
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success") and "data" in data:
                return data["data"]["value"]
        
        # If API call fails, return simulated price
        return random.uniform(0.001, 0.1)
    except Exception as e:
        logger.error(f"Error getting token price: {e}")
        return random.uniform(0.001, 0.1)

def get_market_sentiment():
    """Get overall market sentiment and conditions"""
    # This would typically use real data from APIs
    # For now, we'll use a simple simulation for demonstration
    sentiments = ["bullish", "bearish", "neutral", "trending upward", "trending downward"]
    return random.choice(sentiments)

def analyze_token(token):
    """Analyze a token and determine if it's a good trading opportunity"""
    token_address = token["address"]
    token_symbol = token["symbol"]
    
    # Get token price
    price_usd = get_token_price(token_address)
    
    # Calculate historical price change (simulated)
    hour_change = random.uniform(-15, 15)
    day_change = random.uniform(-30, 30)
    
    # Technical analysis indicators (simulated)
    rsi = random.uniform(20, 80)
    volume_change = random.uniform(-50, 200)
    
    # Decision factors
    buy_signals = 0
    sell_signals = 0
    
    # Analyze RSI
    if rsi < 30:
        buy_signals += 1
    elif rsi > 70:
        sell_signals += 1
    
    # Analyze price movement
    if hour_change > 5 and day_change > 10:
        buy_signals += 1  # Momentum play
    if hour_change < -10 and day_change < -20:
        buy_signals += 1  # Potential bounce play
    if hour_change > 20 and rsi > 75:
        sell_signals += 1  # Overbought
    
    # Analyze volume
    if volume_change > 100:
        buy_signals += 1  # High interest
    
    # Generate trading signal
    signal = None
    confidence = 0
    target_price = price_usd
    stop_loss = price_usd
    
    if buy_signals > sell_signals and buy_signals >= 2:
        signal = "buy"
        confidence = min(0.5 + (buy_signals * 0.1), 0.9)
        target_price = price_usd * (1 + random.uniform(0.1, 0.3))
        stop_loss = price_usd * (1 - random.uniform(0.05, 0.15))
    elif sell_signals > buy_signals and sell_signals >= 2:
        signal = "sell"
        confidence = min(0.5 + (sell_signals * 0.1), 0.9)
        target_price = price_usd * (1 - random.uniform(0.1, 0.2))
        stop_loss = price_usd * (1 + random.uniform(0.05, 0.15))
    
    return {
        "symbol": token_symbol,
        "address": token_address,
        "price_usd": price_usd,
        "hour_change_percent": hour_change,
        "day_change_percent": day_change,
        "rsi": rsi,
        "volume_change_percent": volume_change,
        "signal": signal,
        "confidence": confidence,
        "target_price": target_price,
        "stop_loss": price_usd if signal == "buy" else stop_loss,
        "timestamp": datetime.now().isoformat()
    }

def generate_trade_suggestions():
    """Generate trading suggestions for tracked tokens"""
    suggestions = []
    
    # Get overall market sentiment
    market_sentiment = get_market_sentiment()
    logger.info(f"Current market sentiment: {market_sentiment}")
    
    # Analyze each token
    for token in TRACKED_TOKENS:
        analysis = analyze_token(token)
        
        if analysis["signal"]:
            # Calculate suggestion details
            sol_price = get_sol_price()
            suggested_amount_usd = random.uniform(10, 25)
            suggested_amount_sol = suggested_amount_usd / sol_price
            
            suggestion = {
                "id": f"sugg_{int(time.time())}_{token['symbol']}",
                "symbol": token["symbol"],
                "address": token["address"],
                "signal": analysis["signal"],
                "confidence": analysis["confidence"],
                "price_usd": analysis["price_usd"],
                "target_price": analysis["target_price"],
                "stop_loss": analysis["stop_loss"],
                "suggested_amount_usd": suggested_amount_usd,
                "suggested_amount_sol": suggested_amount_sol,
                "potential_profit_percent": abs((analysis["target_price"] - analysis["price_usd"]) / analysis["price_usd"] * 100),
                "potential_loss_percent": abs((analysis["stop_loss"] - analysis["price_usd"]) / analysis["price_usd"] * 100),
                "reason": get_suggestion_reason(analysis),
                "timestamp": datetime.now().isoformat(),
                "expires_at": (datetime.now() + timedelta(hours=4)).isoformat(),
                "status": "pending"
            }
            
            suggestions.append(suggestion)
    
    # Save new suggestions
    data = get_suggestions_file()
    
    # Add new suggestions
    data["suggestions"].extend(suggestions)
    
    # Remove expired suggestions
    now = datetime.now()
    data["suggestions"] = [
        s for s in data["suggestions"] 
        if s["status"] == "pending" and datetime.fromisoformat(s["expires_at"]) > now
    ]
    
    save_suggestions_file(data)
    
    if suggestions:
        logger.info(f"Generated {len(suggestions)} new trade suggestions")
    else:
        logger.info("No new trade suggestions generated")
    
    return suggestions

def get_suggestion_reason(analysis):
    """Generate a human-readable reason for the suggestion"""
    if analysis["signal"] == "buy":
        if analysis["rsi"] < 30:
            return f"RSI is low ({analysis['rsi']:.1f}), suggesting token is oversold"
        elif analysis["hour_change_percent"] > 5:
            return f"Token showing positive momentum (+{analysis['hour_change_percent']:.1f}% in last hour)"
        elif analysis["volume_change_percent"] > 100:
            return f"Significant volume increase (+{analysis['volume_change_percent']:.1f}%), indicating high interest"
        else:
            return "Technical indicators suggest good buying opportunity"
    else:  # sell
        if analysis["rsi"] > 70:
            return f"RSI is high ({analysis['rsi']:.1f}), suggesting token is overbought"
        elif analysis["hour_change_percent"] < -5:
            return f"Token showing negative momentum ({analysis['hour_change_percent']:.1f}% in last hour)"
        else:
            return "Technical indicators suggest selling opportunity"

def mark_suggestion_completed(suggestion_id, action, tx_hash=None):
    """Mark a suggestion as completed"""
    data = get_suggestions_file()
    
    # Find the suggestion
    for idx, suggestion in enumerate(data["suggestions"]):
        if suggestion["id"] == suggestion_id:
            # Update the suggestion
            suggestion["status"] = "completed"
            suggestion["action_taken"] = action
            suggestion["completed_at"] = datetime.now().isoformat()
            if tx_hash:
                suggestion["tx_hash"] = tx_hash
            
            # Move to completed list
            data["completed"].append(suggestion)
            data["suggestions"].pop(idx)
            
            save_suggestions_file(data)
            return True
    
    return False

def get_pending_suggestions(min_confidence=0.6):
    """Get list of pending suggestions above the confidence threshold"""
    data = get_suggestions_file()
    
    # Filter for pending suggestions above confidence threshold
    return [
        s for s in data["suggestions"] 
        if s["status"] == "pending" and s["confidence"] >= min_confidence
    ]

def get_completed_suggestions(limit=10):
    """Get recently completed suggestions"""
    data = get_suggestions_file()
    
    # Return most recent completed suggestions
    return data["completed"][-limit:]

def get_suggestion_by_id(suggestion_id):
    """Get a specific suggestion by ID"""
    data = get_suggestions_file()
    
    # Find in pending suggestions
    for suggestion in data["suggestions"]:
        if suggestion["id"] == suggestion_id:
            return suggestion
    
    # Find in completed suggestions
    for suggestion in data["completed"]:
        if suggestion["id"] == suggestion_id:
            return suggestion
    
    return None

def get_jupiter_swap_link(input_mint, output_mint, amount_sol):
    """Generate a Jupiter swap link for easy trading"""
    base_url = "https://jup.ag/swap"
    input_param = f"inputMint={input_mint}"
    output_param = f"outputMint={output_mint}"
    amount_param = f"amount={amount_sol}"
    
    return f"{base_url}?{input_param}&{output_param}&{amount_param}"

def generate_simple_report():
    """Generate a simple report of current trading suggestions"""
    pending = get_pending_suggestions()
    completed = get_completed_suggestions(5)
    
    report = "== SMART MEMES BOT - Trade Suggestions ==\n\n"
    
    if pending:
        report += f"You have {len(pending)} trade suggestions pending:\n\n"
        for idx, sugg in enumerate(pending):
            profit = sugg["potential_profit_percent"]
            loss = sugg["potential_loss_percent"]
            risk_reward = profit / loss if loss > 0 else float('inf')
            
            report += f"{idx+1}. {sugg['signal'].upper()} {sugg['symbol']} (${sugg['price_usd']:.4f})\n"
            report += f"   Confidence: {sugg['confidence']*100:.1f}%\n"
            report += f"   Suggested amount: {sugg['suggested_amount_sol']:.4f} SOL (${sugg['suggested_amount_usd']:.2f})\n"
            report += f"   Target price: ${sugg['target_price']:.4f} (Profit: {profit:.1f}%)\n"
            report += f"   Stop loss: ${sugg['stop_loss']:.4f} (Loss: {loss:.1f}%)\n"
            report += f"   Risk/Reward: {risk_reward:.2f}\n"
            report += f"   Reason: {sugg['reason']}\n"
            
            # Generate Jupiter link for easy trading
            if sugg['signal'] == 'buy':
                sol_mint = "So11111111111111111111111111111111111111112"
                link = get_jupiter_swap_link(sol_mint, sugg['address'], sugg['suggested_amount_sol'])
                report += f"   Trade link: {link}\n"
            else:  # sell
                sol_mint = "So11111111111111111111111111111111111111112"
                link = get_jupiter_swap_link(sugg['address'], sol_mint, 0)  # Amount will be selected in UI
                report += f"   Trade link: {link}\n"
            
            report += "\n"
    else:
        report += "No pending trade suggestions at this time.\n\n"
    
    if completed:
        report += "Recently completed suggestions:\n\n"
        for idx, sugg in enumerate(completed):
            report += f"{idx+1}. {sugg['action_taken']} {sugg['symbol']} on {sugg['completed_at'][:10]}\n"
            report += f"   Price: ${sugg['price_usd']:.4f}, Amount: {sugg['suggested_amount_sol']:.4f} SOL\n"
            report += "\n"
    
    return report

def run_advisor():
    """Run the secure trade advisor once"""
    logger.info("Running Secure Trade Advisor analysis...")
    
    try:
        # Generate new suggestions
        suggestions = generate_trade_suggestions()
        
        # Print a report
        report = generate_simple_report()
        print(report)
        
        return suggestions
    except Exception as e:
        logger.error(f"Error running trade advisor: {e}")
        return []

if __name__ == "__main__":
    run_advisor()