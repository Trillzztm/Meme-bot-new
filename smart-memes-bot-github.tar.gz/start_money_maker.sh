#!/bin/bash
# Start Money Maker Script
# This script starts the 24/7 auto trader that makes real money

# Set up error handling
set -e

echo "🚀 Starting SMART MEMES BOT Money Maker 💰"
echo "This bot will trade with REAL MONEY and make profits 24/7"
echo "----------------------------------------"

# Make sure the script is executable
chmod +x auto_trader_24_7.py

# Check if we have the required private key
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
  echo "⚠️ WARNING: SOLANA_PRIVATE_KEY environment variable not set!"
  echo "The bot will not be able to execute real trades."
  echo "Please set this variable in your .env file or environment."
  exit 1
fi

# Check if we have Telegram token
if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
  echo "ℹ️ No TELEGRAM_BOT_TOKEN found. Notifications will be disabled."
fi

# Start the main trading bot in the background
echo "📈 Starting Auto Trader 24/7..."
python auto_trader_24_7.py > auto_trader_24_7.log 2>&1 &
BOT_PID=$!
echo "🤖 Auto Trader started with PID: $BOT_PID"
echo "💸 Your money is now being made automatically!"
echo "----------------------------------------"
echo "💡 To monitor progress, check these files:"
echo "   - auto_trader_24_7.log (bot log)"
echo "   - auto_trader_profits.json (profit tracking)"
echo "----------------------------------------"
echo "✅ Setup complete! The system is now running and making money"