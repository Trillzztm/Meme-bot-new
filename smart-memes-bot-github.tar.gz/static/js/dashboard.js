// Dashboard.js - JavaScript for the CryptoWatcherBot Dashboard

// Initialize the dashboard when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();
    
    // Initialize timeago function for timestamps
    initTimeago();
    
    // Initialize charts
    initCharts();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize tooltips and toasts
    initBootstrapComponents();
});

// Initialize timeago function for human-readable timestamps
function initTimeago() {
    // Simple timeago function
    // This would normally use a library, but we'll implement a basic version
    const timeElements = document.querySelectorAll('[data-timeago]');
    timeElements.forEach(element => {
        const timestamp = parseInt(element.getAttribute('data-timeago'));
        element.textContent = getRelativeTimeString(timestamp);
    });
}

// Get a relative time string
function getRelativeTimeString(timestamp) {
    const now = Math.floor(Date.now() / 1000);
    const secondsAgo = now - timestamp;
    
    if (secondsAgo < 60) {
        return 'just now';
    } else if (secondsAgo < 3600) {
        const minutes = Math.floor(secondsAgo / 60);
        return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    } else if (secondsAgo < 86400) {
        const hours = Math.floor(secondsAgo / 3600);
        return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    } else if (secondsAgo < 2592000) {
        const days = Math.floor(secondsAgo / 86400);
        return `${days} day${days !== 1 ? 's' : ''} ago`;
    } else if (secondsAgo < 31536000) {
        const months = Math.floor(secondsAgo / 2592000);
        return `${months} month${months !== 1 ? 's' : ''} ago`;
    } else {
        const years = Math.floor(secondsAgo / 31536000);
        return `${years} year${years !== 1 ? 's' : ''} ago`;
    }
}

// Initialize charts
function initCharts() {
    // Token mentions chart
    const mentionsCtx = document.getElementById('mentionsChart');
    
    if (mentionsCtx) {
        // Sample data - in a real app, this would come from an API
        const mentionsData = {
            labels: ['BTC', 'ETH', 'SOL', 'MATIC', 'BNB', 'DOGE', 'SHIB'],
            datasets: [{
                label: 'Mentions',
                data: [65, 59, 42, 31, 26, 18, 13],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(201, 203, 207, 0.2)'
                ],
                borderColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 206, 86)',
                    'rgb(75, 192, 192)',
                    'rgb(153, 102, 255)',
                    'rgb(255, 159, 64)',
                    'rgb(201, 203, 207)'
                ],
                borderWidth: 1
            }]
        };
        
        const mentionsChart = new Chart(mentionsCtx, {
            type: 'bar',
            data: mentionsData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.raw} mentions`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
}

// Set up event listeners
function setupEventListeners() {
    // Add wallet form submission
    const addWalletBtn = document.getElementById('addWalletBtn');
    if (addWalletBtn) {
        addWalletBtn.addEventListener('click', handleAddWallet);
    }
    
    // Add token form submission
    const addTokenBtn = document.getElementById('addTokenBtn');
    if (addTokenBtn) {
        addTokenBtn.addEventListener('click', handleAddToken);
    }
    
    // Add group form submission
    const addGroupBtn = document.getElementById('addGroupBtn');
    if (addGroupBtn) {
        addGroupBtn.addEventListener('click', handleAddGroup);
    }
    
    // Save settings button
    const saveSettingsBtn = document.getElementById('saveSettings');
    if (saveSettingsBtn) {
        saveSettingsBtn.addEventListener('click', handleSaveSettings);
    }
    
    // View wallet button
    const viewWalletBtns = document.querySelectorAll('.view-wallet-btn');
    viewWalletBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            loadWalletDetails(address);
        });
    });
    
    // View token button
    const viewTokenBtns = document.querySelectorAll('.view-token-btn');
    viewTokenBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            loadTokenDetails(address);
        });
    });
    
    // Check token safety
    const checkTokenBtns = document.querySelectorAll('.check-token-btn');
    checkTokenBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            checkTokenSafety(address);
        });
    });
    
    // Remove wallet button
    const removeWalletBtns = document.querySelectorAll('.remove-wallet-btn');
    removeWalletBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            confirmRemoveWallet(address);
        });
    });
    
    // Remove token button
    const removeTokenBtns = document.querySelectorAll('.remove-token-btn');
    removeTokenBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            confirmRemoveToken(address);
        });
    });
    
    // Copy address button
    const copyBtns = document.querySelectorAll('.copy-address');
    copyBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            copyToClipboard(address);
            showSuccessToast('Address copied to clipboard');
        });
    });
    
    // Refresh wallets button
    const refreshWalletsBtn = document.querySelector('.refresh-wallets');
    if (refreshWalletsBtn) {
        refreshWalletsBtn.addEventListener('click', refreshWallets);
    }
    
    // Refresh tokens button
    const refreshTokensBtn = document.querySelector('.refresh-tokens');
    if (refreshTokensBtn) {
        refreshTokensBtn.addEventListener('click', refreshTokens);
    }
    
    // Meme generation form
    const memeForm = document.getElementById('memeForm');
    if (memeForm) {
        memeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            generateMeme();
        });
    }
}

// Initialize Bootstrap components
function initBootstrapComponents() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Handler for adding a wallet
function handleAddWallet() {
    const walletAddress = document.getElementById('walletAddress').value;
    const walletLabel = document.getElementById('walletLabel').value;
    const notifyOnChanges = document.getElementById('notifyOnChanges').checked;
    
    if (!walletAddress) {
        showErrorToast('Please enter a wallet address');
        return;
    }
    
    // Validate Ethereum address format
    if (!isValidEthAddress(walletAddress)) {
        showErrorToast('Invalid Ethereum address format');
        return;
    }
    
    // In a real app, this would send data to the server
    console.log('Adding wallet:', { walletAddress, walletLabel, notifyOnChanges });
    
    // Close the modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addWalletModal'));
    modal.hide();
    
    // Show success message
    showSuccessToast('Wallet added successfully');
    
    // In a real app, we would refresh the wallet list here
    // For demo purposes, add a small delay and reload the page
    setTimeout(() => {
        window.location.reload();
    }, 1500);
}

// Handler for adding a token
function handleAddToken() {
    const tokenAddress = document.getElementById('tokenAddress').value;
    const tokenNetwork = document.getElementById('tokenNetwork').value;
    const performSafetyCheck = document.getElementById('performSafetyCheck').checked;
    
    if (!tokenAddress) {
        showErrorToast('Please enter a token address');
        return;
    }
    
    // Validate address format
    if (!isValidEthAddress(tokenAddress)) {
        showErrorToast('Invalid token address format');
        return;
    }
    
    // In a real app, this would send data to the server
    console.log('Adding token:', { tokenAddress, tokenNetwork, performSafetyCheck });
    
    // Close the modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addTokenModal'));
    modal.hide();
    
    // Show success message
    showSuccessToast('Token added successfully');
    
    // In a real app, we would refresh the token list here
    // For demo purposes, add a small delay and reload the page
    setTimeout(() => {
        window.location.reload();
    }, 1500);
}

// Handler for adding a group
function handleAddGroup() {
    const groupIdentifier = document.getElementById('groupIdentifier').value;
    const trackTokenMentions = document.getElementById('trackTokenMentions').checked;
    
    if (!groupIdentifier) {
        showErrorToast('Please enter a group ID or username');
        return;
    }
    
    // Validate group identifier format
    if (!isValidGroupIdentifier(groupIdentifier)) {
        showErrorToast('Invalid group identifier format');
        return;
    }
    
    // In a real app, this would send data to the server
    console.log('Adding group:', { groupIdentifier, trackTokenMentions });
    
    // Close the modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addGroupModal'));
    modal.hide();
    
    // Show success message
    showSuccessToast('Group added successfully');
    
    // In a real app, we would refresh the group list here
    // For demo purposes, add a small delay and reload the page
    setTimeout(() => {
        window.location.reload();
    }, 1500);
}

// Handler for saving settings
function handleSaveSettings() {
    const notifyAll = document.getElementById('notifyAllSwitch').checked;
    const notifyImportant = document.getElementById('notifyImportantSwitch').checked;
    const darkMode = document.getElementById('darkModeSwitch').checked;
    
    // In a real app, this would send data to the server
    console.log('Saving settings:', { notifyAll, notifyImportant, darkMode });
    
    // Show success message
    showSuccessToast('Settings saved successfully');
}

// Load wallet details
function loadWalletDetails(address) {
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('walletDetailModal'));
    modal.show();
    
    // Set the title
    document.getElementById('walletDetailTitle').textContent = `Wallet ${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    
    // Hide the content and show the spinner
    document.getElementById('walletDetailContent').classList.add('d-none');
    
    // In a real app, this would fetch data from the server
    // Simulate API call
    setTimeout(() => {
        // Show the content and hide the spinner
        const contentDiv = document.getElementById('walletDetailContent');
        contentDiv.classList.remove('d-none');
        
        // Sample wallet details
        contentDiv.innerHTML = `
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card border-0 bg-dark bg-opacity-25">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">Wallet Address</h6>
                            <p class="card-text font-monospace">${address}</p>
                            <h6 class="card-subtitle mb-2 text-muted mt-3">Balance</h6>
                            <p class="card-text fs-4 fw-bold">1.245 ETH</p>
                            <h6 class="card-subtitle mb-2 text-muted mt-3">Value (USD)</h6>
                            <p class="card-text fs-4 fw-bold">$2,312.56</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-0 bg-dark bg-opacity-25 h-100">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">Token Holdings</h6>
                            <canvas id="walletTokensChart" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <h6 class="mb-3">Token Holdings</h6>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Token</th>
                            <th>Balance</th>
                            <th>Value (USD)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="token-icon me-2 bg-primary bg-opacity-10 text-primary">
                                        <i data-feather="dollar-sign" class="feather-sm"></i>
                                    </div>
                                    <div>
                                        <span class="fw-medium">USDT</span>
                                        <div class="small text-muted">Tether USD</div>
                                    </div>
                                </div>
                            </td>
                            <td>1,250.00</td>
                            <td>$1,250.00</td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="token-icon me-2 bg-warning bg-opacity-10 text-warning">
                                        <i data-feather="dollar-sign" class="feather-sm"></i>
                                    </div>
                                    <div>
                                        <span class="fw-medium">LINK</span>
                                        <div class="small text-muted">Chainlink</div>
                                    </div>
                                </div>
                            </td>
                            <td>25.75</td>
                            <td>$320.50</td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary">View</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `;
        
        // Initialize Feather icons for the new content
        feather.replace();
        
        // Initialize the wallet tokens chart
        const walletTokensCtx = document.getElementById('walletTokensChart');
        if (walletTokensCtx) {
            const walletTokensChart = new Chart(walletTokensCtx, {
                type: 'doughnut',
                data: {
                    labels: ['USDT', 'LINK', 'UNI', 'AAVE', 'Other'],
                    datasets: [{
                        data: [1250, 320, 180, 150, 95],
                        backgroundColor: [
                            'rgba(83, 166, 250, 0.8)',
                            'rgba(255, 168, 0, 0.8)',
                            'rgba(250, 82, 82, 0.8)',
                            'rgba(129, 82, 250, 0.8)',
                            'rgba(170, 170, 170, 0.8)'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                boxWidth: 12,
                                padding: 15
                            }
                        }
                    },
                    cutout: '70%'
                }
            });
        }
    }, 1000);
}

// Load token details
function loadTokenDetails(address) {
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('tokenDetailModal'));
    modal.show();
    
    // Set the title
    document.getElementById('tokenDetailTitle').textContent = 'Token Details';
    
    // Hide the content and show the spinner
    document.getElementById('tokenDetailContent').classList.add('d-none');
    
    // In a real app, this would fetch data from the server
    // Simulate API call
    setTimeout(() => {
        // Show the content and hide the spinner
        const contentDiv = document.getElementById('tokenDetailContent');
        contentDiv.classList.remove('d-none');
        
        // Sample token details
        contentDiv.innerHTML = `
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="d-flex align-items-center mb-4">
                        <div class="token-icon me-3 bg-success bg-opacity-10 text-success p-3" style="width: 50px; height: 50px;">
                            <i data-feather="dollar-sign"></i>
                        </div>
                        <div>
                            <h5 class="mb-0">Chainlink (LINK)</h5>
                            <small class="text-muted">ERC-20 Token</small>
                        </div>
                    </div>
                    
                    <div class="card border-0 bg-dark bg-opacity-25 mb-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <h6 class="card-subtitle mb-2 text-muted">Current Price</h6>
                                    <p class="card-text fs-4 fw-bold">$12.45</p>
                                </div>
                                <div class="col-6">
                                    <h6 class="card-subtitle mb-2 text-muted">24h Change</h6>
                                    <p class="card-text fs-4 fw-bold text-success">+3.2%</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h6 class="text-muted mb-2">Contract Address</h6>
                        <div class="font-monospace bg-dark p-2 rounded">${address}</div>
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="card border-0 bg-dark bg-opacity-25">
                                <div class="card-body p-3">
                                    <h6 class="card-subtitle mb-2 text-muted">Market Cap</h6>
                                    <p class="card-text fw-bold">$6.2B</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card border-0 bg-dark bg-opacity-25">
                                <div class="card-body p-3">
                                    <h6 class="card-subtitle mb-2 text-muted">Liquidity</h6>
                                    <p class="card-text fw-bold">$124.5M</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card border-0 bg-dark bg-opacity-25">
                                <div class="card-body p-3">
                                    <h6 class="card-subtitle mb-2 text-muted">Holders</h6>
                                    <p class="card-text fw-bold">245,325</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card border-0 bg-dark bg-opacity-25">
                                <div class="card-body p-3">
                                    <h6 class="card-subtitle mb-2 text-muted">Age</h6>
                                    <p class="card-text fw-bold">1,245 days</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-0 bg-dark bg-opacity-25 mb-3">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted">Price History (30 days)</h6>
                            <div style="height: 200px;">
                                <canvas id="tokenPriceChart"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card border-0 bg-dark bg-opacity-25">
                        <div class="card-body">
                            <h6 class="card-subtitle mb-2 text-muted mb-3">Safety Check</h6>
                            
                            <div class="d-flex align-items-center mb-3">
                                <div class="me-3">
                                    <div class="rounded-circle bg-success d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                        <i data-feather="check" class="text-white" style="width: 16px; height: 16px;"></i>
                                    </div>
                                </div>
                                <div>
                                    <p class="mb-0">Contract Verified</p>
                                </div>
                            </div>
                            
                            <div class="d-flex align-items-center mb-3">
                                <div class="me-3">
                                    <div class="rounded-circle bg-success d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                        <i data-feather="check" class="text-white" style="width: 16px; height: 16px;"></i>
                                    </div>
                                </div>
                                <div>
                                    <p class="mb-0">Liquidity Locked</p>
                                </div>
                            </div>
                            
                            <div class="d-flex align-items-center mb-3">
                                <div class="me-3">
                                    <div class="rounded-circle bg-success d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                        <i data-feather="check" class="text-white" style="width: 16px; height: 16px;"></i>
                                    </div>
                                </div>
                                <div>
                                    <p class="mb-0">No Honeypot Detected</p>
                                </div>
                            </div>
                            
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <div class="rounded-circle bg-success d-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                        <i data-feather="check" class="text-white" style="width: 16px; height: 16px;"></i>
                                    </div>
                                </div>
                                <div>
                                    <p class="mb-0">Ownership Renounced</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Initialize Feather icons for the new content
        feather.replace();
        
        // Initialize token price chart
        const tokenPriceCtx = document.getElementById('tokenPriceChart');
        if (tokenPriceCtx) {
            const tokenPriceChart = new Chart(tokenPriceCtx, {
                type: 'line',
                data: {
                    labels: Array.from({length: 30}, (_, i) => i + 1),
                    datasets: [{
                        label: 'Price (USD)',
                        data: [12.2, 12.1, 12.3, 12.5, 12.4, 12.3, 12.2, 12.3, 12.1, 12.0, 11.8, 11.9, 12.0, 12.1, 12.3, 12.2, 12.1, 11.9, 11.8, 11.7, 11.8, 11.9, 12.1, 12.3, 12.4, 12.3, 12.5, 12.6, 12.5, 12.4],
                        borderColor: 'rgba(83, 166, 250, 1)',
                        backgroundColor: 'rgba(83, 166, 250, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.05)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                maxTicksLimit: 10
                            }
                        }
                    }
                }
            });
        }
    }, 1000);
}

// Check token safety
function checkTokenSafety(address) {
    // Show loading toast
    showSuccessToast('Checking token safety...');
    
    // In a real app, this would send a request to the server
    // Simulate API call
    setTimeout(() => {
        // Show results modal
        const modal = new bootstrap.Modal(document.getElementById('tokenDetailModal'));
        modal.show();
        
        // Set the title
        document.getElementById('tokenDetailTitle').textContent = 'Token Safety Check';
        
        // Show the content and hide the spinner
        const contentDiv = document.getElementById('tokenDetailContent');
        contentDiv.classList.remove('d-none');
        
        // Sample safety check results
        contentDiv.innerHTML = `
            <div class="card border-0 bg-dark bg-opacity-25 mb-4">
                <div class="card-body text-center">
                    <div class="display-1 mb-3">🛡️</div>
                    <h4 class="card-title">Safety Score</h4>
                    <div class="d-flex justify-content-center mb-3">
                        <div class="progress" style="width: 70%; height: 10px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 85%"></div>
                        </div>
                    </div>
                    <h2 class="display-4 fw-bold text-success mb-3">85/100</h2>
                    <p class="lead">This token appears to have a high safety score.</p>
                </div>
            </div>
            
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="card border-0 bg-dark bg-opacity-25 h-100">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">No Issues Found</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush bg-transparent">
                                <li class="list-group-item bg-transparent d-flex align-items-center">
                                    <i data-feather="check-circle" class="text-success me-2"></i>
                                    Contract is verified
                                </li>
                                <li class="list-group-item bg-transparent d-flex align-items-center">
                                    <i data-feather="check-circle" class="text-success me-2"></i>
                                    Ownership is renounced
                                </li>
                                <li class="list-group-item bg-transparent d-flex align-items-center">
                                    <i data-feather="check-circle" class="text-success me-2"></i>
                                    Liquidity is locked for 180+ days
                                </li>
                                <li class="list-group-item bg-transparent d-flex align-items-center">
                                    <i data-feather="check-circle" class="text-success me-2"></i>
                                    No honeypot functions detected
                                </li>
                                <li class="list-group-item bg-transparent d-flex align-items-center">
                                    <i data-feather="check-circle" class="text-success me-2"></i>
                                    Token age: 1,245 days
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-0 bg-dark bg-opacity-25 h-100">
                        <div class="card-header bg-transparent">
                            <h5 class="mb-0">Recommendations</h5>
                        </div>
                        <div class="card-body">
                            <p>This token appears to be safe based on our automatic checks. However, always DYOR (Do Your Own Research) before investing.</p>
                            
                            <div class="alert alert-info">
                                <div class="d-flex">
                                    <div class="me-3">
                                        <i data-feather="info" class="text-info"></i>
                                    </div>
                                    <div>
                                        <h6 class="alert-heading">Reminder</h6>
                                        <p class="mb-0">Automated checks can help identify potential risks, but they cannot guarantee safety. Always invest with caution.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <button class="btn btn-primary mt-3 w-100">
                                <i data-feather="cpu" class="feather-sm me-2"></i> AI Analysis
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Initialize Feather icons for the new content
        feather.replace();
    }, 2000);
}

// Confirm remove wallet
function confirmRemoveWallet(address) {
    if (confirm(`Are you sure you want to remove wallet ${address.substring(0, 6)}...${address.substring(address.length - 4)}?`)) {
        // In a real app, this would send a request to the server
        console.log('Removing wallet:', address);
        
        showSuccessToast('Wallet removed successfully');
        
        // In a real app, we would update the UI here
        // For demo purposes, add a small delay and reload the page
        setTimeout(() => {
            window.location.reload();
        }, 1500);
    }
}

// Confirm remove token
function confirmRemoveToken(address) {
    if (confirm(`Are you sure you want to remove this token?`)) {
        // In a real app, this would send a request to the server
        console.log('Removing token:', address);
        
        showSuccessToast('Token removed successfully');
        
        // In a real app, we would update the UI here
        // For demo purposes, add a small delay and reload the page
        setTimeout(() => {
            window.location.reload();
        }, 1500);
    }
}

// Refresh wallets
function refreshWallets() {
    // In a real app, this would trigger a refresh of wallet data
    showSuccessToast('Refreshing wallet data...');
    
    // Simulate refreshing after a delay
    setTimeout(() => {
        showSuccessToast('Wallet data updated');
    }, 1500);
}

// Refresh tokens
function refreshTokens() {
    // In a real app, this would trigger a refresh of token data
    showSuccessToast('Refreshing token data...');
    
    // Simulate refreshing after a delay
    setTimeout(() => {
        showSuccessToast('Token data updated');
    }, 1500);
}

// Generate meme
function generateMeme() {
    const memeTheme = document.getElementById('memeTheme').value;
    const topText = document.getElementById('topText').value;
    const bottomText = document.getElementById('bottomText').value;
    
    // Show generation in progress
    const memeResult = document.getElementById('memeResult');
    memeResult.classList.remove('d-none');
    
    // In a real app, this would send a request to the server
    console.log('Generating meme:', { memeTheme, topText, bottomText });
    
    // Simulate meme generation
    setTimeout(() => {
        // Hide the spinner
        memeResult.classList.add('d-none');
        
        // Show success message
        showSuccessToast('Meme generated and sent to your Telegram');
    }, 2000);
}

// Utility functions

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).catch(err => {
        console.error('Could not copy text: ', err);
    });
}

// Show success toast
function showSuccessToast(message) {
    document.getElementById('successToastMessage').textContent = message;
    const toast = new bootstrap.Toast(document.getElementById('successToast'));
    toast.show();
}

// Show error toast
function showErrorToast(message) {
    document.getElementById('errorToastMessage').textContent = message;
    const toast = new bootstrap.Toast(document.getElementById('errorToast'));
    toast.show();
}

// Validate Ethereum address
function isValidEthAddress(address) {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
}

// Validate group identifier
function isValidGroupIdentifier(identifier) {
    return /^(-100\d+|@[\w_]+)$/.test(identifier);
}

// Custom filter for Flask Jinja templates
// In a real app, this would be implemented in Flask
// This is just for the demo
function timeago(timestamp) {
    return getRelativeTimeString(timestamp);
}
