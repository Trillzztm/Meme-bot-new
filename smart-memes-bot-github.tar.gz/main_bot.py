"""
Main entry point for the Telegram bot using a clean, straightforward approach.

This is a streamlined implementation that directly uses the python-telegram-bot
library with the exact handlers provided.
"""

import os
import logging
from telegram.ext import ApplicationBuilder, CommandHandler
from handlers.start_help import start, help_command
from handlers.manualsnipe import manualsnipe
from handlers.tokeninfo import tokeninfo

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Get bot token from environment
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

def main():
    """Main function to run the bot."""
    # Verify the token is available
    if not BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN environment variable not set")
        return
    
    # Create the Application instance
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Register command handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("manualsnipe", manualsnipe))
    app.add_handler(CommandHandler("tokeninfo", tokeninfo))

    # Start the bot
    logger.info("SmartMemesBot running...")
    app.run_polling()

if __name__ == "__main__":
    main()