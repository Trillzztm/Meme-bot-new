"""
Money Dashboard for SMART MEMES BOT

This module provides a web-based dashboard to display real-time profit statistics
from the auto trading system. It includes visualizations of profits, trade history,
and wallet status.
"""

import os
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Tuple

from flask import Flask, render_template, jsonify, redirect, url_for, request, flash, session

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("MoneyDashboard")

# Import local modules
try:
    from auto_trade_engine import get_auto_trade_stats, is_auto_trading_active
    AUTO_TRADE_INSTALLED = True
except ImportError:
    logger.warning("Auto trade engine not available, some features will be disabled")
    AUTO_TRADE_INSTALLED = False

# Constants
AUTO_TRADE_PROFITS_FILE = "auto_trade_profits.json"
REAL_TRADES_FILE = "real_trades.json"
DASHBOARD_SECRET = os.environ.get("DASHBOARD_SECRET", "smartmemes2025")

# Flask setup
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "smartmemes2025secrect")

# Data cache to reduce file I/O
data_cache = {
    "auto_trade_profits": None,
    "recent_trades": None,
    "cache_time": 0,
    "cache_duration": 5  # Cache data for 5 seconds
}

def get_cached_data(data_type: str, loader_func) -> Any:
    """Get data from cache or load it if cache is stale"""
    global data_cache
    
    current_time = time.time()
    if (data_cache[data_type] is None or 
        current_time - data_cache["cache_time"] > data_cache["cache_duration"]):
        # Cache is stale, reload data
        data_cache[data_type] = loader_func()
        data_cache["cache_time"] = current_time
        
    return data_cache[data_type]

def load_auto_trade_profits() -> Dict[str, Any]:
    """Load auto-trade profits data"""
    if not os.path.exists(AUTO_TRADE_PROFITS_FILE):
        return {
            "total_profit_usd": 0,
            "trades_completed": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "largest_profit_usd": 0,
            "largest_loss_usd": 0,
            "transactions": []
        }
    
    try:
        with open(AUTO_TRADE_PROFITS_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading auto-trade profits: {e}")
        return {
            "total_profit_usd": 0,
            "trades_completed": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "largest_profit_usd": 0,
            "largest_loss_usd": 0,
            "transactions": []
        }

def load_recent_trades(limit: int = 100) -> List[Dict[str, Any]]:
    """Load recent trades from real_trades.json"""
    if not os.path.exists(REAL_TRADES_FILE):
        return []
    
    try:
        trades = []
        with open(REAL_TRADES_FILE, "r") as f:
            for line in f:
                try:
                    trade = json.loads(line.strip())
                    trades.append(trade)
                except:
                    pass
        
        # Return most recent trades first
        return sorted(trades, key=lambda x: x.get("timestamp", ""), reverse=True)[:limit]
    except Exception as e:
        logger.error(f"Error loading recent trades: {e}")
        return []

def format_timestamp(timestamp: str) -> str:
    """Format ISO timestamp to more readable format"""
    try:
        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestamp

def get_profit_by_token() -> Dict[str, float]:
    """Get profits grouped by token"""
    trades = load_recent_trades(1000)  # Get up to 1000 recent trades
    
    token_profits = {}
    for trade in trades:
        token = trade.get("output_token", "Unknown")
        profit = trade.get("profit_usd", 0)
        
        if token not in token_profits:
            token_profits[token] = 0
            
        token_profits[token] += profit
    
    # Sort by profit (descending)
    return dict(sorted(token_profits.items(), key=lambda x: x[1], reverse=True))

def get_profit_by_strategy() -> Dict[str, float]:
    """Get profits grouped by strategy"""
    trades = load_recent_trades(1000)  # Get up to 1000 recent trades
    
    strategy_profits = {}
    for trade in trades:
        strategy = trade.get("strategy", "Unknown")
        profit = trade.get("profit_usd", 0)
        
        if strategy not in strategy_profits:
            strategy_profits[strategy] = 0
            
        strategy_profits[strategy] += profit
    
    # Sort by profit (descending)
    return dict(sorted(strategy_profits.items(), key=lambda x: x[1], reverse=True))

def get_profit_timeframe() -> Tuple[List[str], List[float]]:
    """Get profits over time by day"""
    trades = load_recent_trades(1000)  # Get up to 1000 recent trades
    
    # Group profits by day
    day_profits = {}
    for trade in trades:
        try:
            timestamp = trade.get("timestamp", "")
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            day = dt.strftime("%Y-%m-%d")
            
            profit = trade.get("profit_usd", 0)
            
            if day not in day_profits:
                day_profits[day] = 0
                
            day_profits[day] += profit
        except:
            continue
    
    # Ensure we have data for the last 7 days
    days = []
    profits = []
    
    today = datetime.now()
    for i in range(6, -1, -1):
        day = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        days.append(day)
        profits.append(day_profits.get(day, 0))
    
    return days, profits

def get_wallet_balance() -> Dict[str, Any]:
    """Get wallet balance (use mocked data for demo)"""
    try:
        # Try to import wallet connector
        from phantom_direct_connector import get_wallet_balance
        
        # Get real wallet balance
        balance = get_wallet_balance()
        if isinstance(balance, dict):
            return {
                "balance_sol": balance.get("balance_sol", 0),
                "balance_usd": balance.get("balance_sol", 0) * 100,  # Approximate SOL price
                "is_real": True
            }
    except:
        pass
    
    # Return cached data if available
    if hasattr(get_wallet_balance, "last_balance"):
        return get_wallet_balance.last_balance
    
    # Generate demo data
    balance = {
        "balance_sol": 0.198,
        "balance_usd": 19.80,
        "is_real": False
    }
    
    # Cache data
    get_wallet_balance.last_balance = balance
    return balance

# Flask routes
@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('money_dashboard.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        password = request.form.get('password')
        if password == DASHBOARD_SECRET:
            session['logged_in'] = True
            flash('Login successful', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout"""
    session.pop('logged_in', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

@app.route('/api/dashboard_data')
def dashboard_data():
    """API route to get dashboard data"""
    if not session.get('logged_in'):
        return jsonify({"error": "Unauthorized"}), 401
    
    # Get data from cache or load it
    auto_trade_stats = get_cached_data("auto_trade_profits", load_auto_trade_profits)
    recent_trades = get_cached_data("recent_trades", lambda: load_recent_trades(20))
    
    # Format timestamps in recent trades
    for trade in recent_trades:
        if "timestamp" in trade:
            trade["formatted_timestamp"] = format_timestamp(trade["timestamp"])
    
    # Get profits by token and strategy
    profit_by_token = get_profit_by_token()
    profit_by_strategy = get_profit_by_strategy()
    
    # Get profits over time
    time_labels, time_data = get_profit_timeframe()
    
    # Get wallet balance
    wallet_balance = get_wallet_balance()
    
    # Get auto-trading status
    auto_trading_active = False
    if AUTO_TRADE_INSTALLED:
        try:
            auto_trading_active = is_auto_trading_active()
        except:
            pass
    
    return jsonify({
        "auto_trade_stats": auto_trade_stats,
        "recent_trades": recent_trades,
        "profit_by_token": profit_by_token,
        "profit_by_strategy": profit_by_strategy,
        "profit_timeline": {
            "labels": time_labels,
            "data": time_data
        },
        "wallet_balance": wallet_balance,
        "auto_trading_active": auto_trading_active
    })

@app.route('/api/toggle_trading', methods=['POST'])
def toggle_trading():
    """API route to toggle auto-trading"""
    if not session.get('logged_in'):
        return jsonify({"error": "Unauthorized"}), 401
    
    if not AUTO_TRADE_INSTALLED:
        return jsonify({"error": "Auto-trading engine not available"}), 500
    
    action = request.json.get('action')
    
    try:
        if action == 'start':
            from auto_trade_engine import start_auto_trading
            start_auto_trading()
            return jsonify({"status": "success", "message": "Auto-trading started"})
        elif action == 'stop':
            from auto_trade_engine import stop_auto_trading
            stop_auto_trading()
            return jsonify({"status": "success", "message": "Auto-trading stopped"})
        else:
            return jsonify({"error": "Invalid action"}), 400
    except Exception as e:
        return jsonify({"error": f"Error toggling auto-trading: {str(e)}"}), 500

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    """404 error handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """500 error handler"""
    return render_template('500.html', error=str(e)), 500

if __name__ == '__main__':
    # Create static, templates directory if they don't exist
    os.makedirs('static', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    
    # Create HTML templates
    with open('templates/base.html', 'w') as f:
        f.write('''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART MEMES BOT - {% block title %}Dashboard{% endblock %}</title>
    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    {% block head %}{% endblock %}
    <style>
        body {
            padding-top: 20px;
        }
        .card-header {
            font-weight: bold;
        }
        .profit-positive {
            color: #28a745;
        }
        .profit-negative {
            color: #dc3545;
        }
        .dashboard-card {
            height: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">SMART MEMES BOT</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Dashboard</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        {% if session.logged_in %}
                        <li class="nav-item">
                            <a class="nav-link" href="/logout">Logout</a>
                        </li>
                        {% else %}
                        <li class="nav-item">
                            <a class="nav-link" href="/login">Login</a>
                        </li>
                        {% endif %}
                    </ul>
                </div>
            </div>
        </nav>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }}">{{ message }}</div>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>''')
    
    with open('templates/money_dashboard.html', 'w') as f:
        f.write('''{% extends "base.html" %}

{% block title %}Money Dashboard{% endblock %}

{% block content %}
{% if not session.logged_in %}
    <div class="alert alert-warning">
        You need to <a href="/login">login</a> to access the dashboard.
    </div>
{% else %}
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card dashboard-card">
                <div class="card-header bg-primary text-white">
                    Wallet Balance
                </div>
                <div class="card-body">
                    <h5 id="wallet-balance">Loading...</h5>
                    <p id="wallet-balance-usd">Loading...</p>
                    <div class="text-muted" id="wallet-balance-source"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card">
                <div class="card-header bg-success text-white">
                    Total Profit
                </div>
                <div class="card-body">
                    <h5 id="total-profit">Loading...</h5>
                    <p><span id="total-trades">0</span> trades (<span id="success-rate">0%</span> success)</p>
                    <div id="auto-trading-status" class="mt-2">
                        <button id="toggle-trading" class="btn btn-sm btn-outline-primary">
                            Loading...
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card">
                <div class="card-header bg-info text-white">
                    Profit Highlights
                </div>
                <div class="card-body">
                    <p>Largest Profit: <span id="largest-profit">Loading...</span></p>
                    <p>Largest Loss: <span id="largest-loss">Loading...</span></p>
                    <p>Recent Profit: <span id="recent-profit">Loading...</span></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    Profit Timeline
                </div>
                <div class="card-body">
                    <canvas id="profit-chart" height="250"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    Most Profitable Tokens
                </div>
                <div class="card-body">
                    <ul id="profitable-tokens" class="list-group">
                        <li class="list-group-item">Loading...</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    Recent Trades
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Token</th>
                                    <th>Strategy</th>
                                    <th>Amount</th>
                                    <th>Profit</th>
                                    <th>TX Hash</th>
                                </tr>
                            </thead>
                            <tbody id="recent-trades">
                                <tr>
                                    <td colspan="6" class="text-center">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
{% endif %}
{% endblock %}

{% block scripts %}
{% if session.logged_in %}
<script>
    // Format number as currency
    function formatCurrency(value) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(value);
    }
    
    // Format number with 6 decimal places
    function formatDecimal(value) {
        return parseFloat(value).toFixed(6);
    }
    
    // Truncate TX hash
    function truncateHash(hash) {
        if (!hash) return 'N/A';
        return hash.substring(0, 8) + '...' + hash.substring(hash.length - 4);
    }
    
    // Update dashboard data
    function updateDashboard() {
        $.getJSON('/api/dashboard_data', function(data) {
            // Update wallet balance
            const wallet = data.wallet_balance;
            $('#wallet-balance').text(formatDecimal(wallet.balance_sol) + ' SOL');
            $('#wallet-balance-usd').text(formatCurrency(wallet.balance_usd));
            $('#wallet-balance-source').text(wallet.is_real ? 'Real wallet data' : 'Demo data');
            
            // Update profit stats
            const stats = data.auto_trade_stats;
            $('#total-profit').text(formatCurrency(stats.total_profit_usd));
            $('#total-trades').text(stats.trades_completed);
            
            if (stats.trades_completed > 0) {
                const successRate = (stats.successful_trades / stats.trades_completed) * 100;
                $('#success-rate').text(successRate.toFixed(1) + '%');
            } else {
                $('#success-rate').text('0%');
            }
            
            $('#largest-profit').text(formatCurrency(stats.largest_profit_usd));
            $('#largest-loss').text(formatCurrency(stats.largest_loss_usd));
            
            // Update auto-trading status
            const trading_active = data.auto_trading_active;
            if (trading_active) {
                $('#toggle-trading').text('Stop Auto-Trading').removeClass('btn-outline-success').addClass('btn-outline-danger');
            } else {
                $('#toggle-trading').text('Start Auto-Trading').removeClass('btn-outline-danger').addClass('btn-outline-success');
            }
            
            // Update recent trades
            const trades = data.recent_trades;
            let tradeRows = '';
            
            if (trades.length === 0) {
                tradeRows = '<tr><td colspan="6" class="text-center">No recent trades</td></tr>';
            } else {
                // Calculate recent profit
                let recentProfit = 0;
                for (let i = 0; i < Math.min(5, trades.length); i++) {
                    recentProfit += trades[i].profit_usd;
                }
                $('#recent-profit').text(formatCurrency(recentProfit));
                
                trades.forEach(trade => {
                    const profitClass = trade.profit_usd >= 0 ? 'profit-positive' : 'profit-negative';
                    
                    tradeRows += `
                    <tr>
                        <td>${trade.formatted_timestamp || trade.timestamp}</td>
                        <td>${trade.output_token}</td>
                        <td>${trade.strategy}</td>
                        <td>${formatCurrency(trade.input_amount_usd)}</td>
                        <td class="${profitClass}">${formatCurrency(trade.profit_usd)}</td>
                        <td><a href="https://solscan.io/tx/${trade.tx_hash}" target="_blank">${truncateHash(trade.tx_hash)}</a></td>
                    </tr>
                    `;
                });
            }
            
            $('#recent-trades').html(tradeRows);
            
            // Update token profits
            const tokenProfits = data.profit_by_token;
            let tokenListItems = '';
            
            if (Object.keys(tokenProfits).length === 0) {
                tokenListItems = '<li class="list-group-item">No token data</li>';
            } else {
                Object.entries(tokenProfits).slice(0, 5).forEach(([token, profit]) => {
                    const profitClass = profit >= 0 ? 'profit-positive' : 'profit-negative';
                    tokenListItems += `
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        ${token}
                        <span class="${profitClass}">${formatCurrency(profit)}</span>
                    </li>
                    `;
                });
            }
            
            $('#profitable-tokens').html(tokenListItems);
            
            // Update profit chart
            updateProfitChart(data.profit_timeline.labels, data.profit_timeline.data);
        });
    }
    
    // Profit chart
    let profitChart = null;
    
    function updateProfitChart(labels, data) {
        const ctx = document.getElementById('profit-chart').getContext('2d');
        
        if (profitChart) {
            profitChart.data.labels = labels;
            profitChart.data.datasets[0].data = data;
            profitChart.update();
        } else {
            profitChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Daily Profit (USD)',
                        data: data,
                        backgroundColor: 'rgba(40, 167, 69, 0.2)',
                        borderColor: 'rgba(40, 167, 69, 1)',
                        borderWidth: 2,
                        tension: 0.1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }
    
    // Toggle auto-trading
    $('#toggle-trading').click(function() {
        const action = $(this).text().startsWith('Start') ? 'start' : 'stop';
        
        $.ajax({
            url: '/api/toggle_trading',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ action: action }),
            success: function(response) {
                if (action === 'start') {
                    $('#toggle-trading').text('Stop Auto-Trading').removeClass('btn-outline-success').addClass('btn-outline-danger');
                } else {
                    $('#toggle-trading').text('Start Auto-Trading').removeClass('btn-outline-danger').addClass('btn-outline-success');
                }
            },
            error: function(error) {
                alert('Error: ' + (error.responseJSON?.error || 'Failed to toggle auto-trading'));
            }
        });
    });
    
    // Initial update
    updateDashboard();
    
    // Auto-refresh every 5 seconds
    setInterval(updateDashboard, 5000);
</script>
{% endif %}
{% endblock %}''')
    
    with open('templates/login.html', 'w') as f:
        f.write('''{% extends "base.html" %}

{% block title %}Login{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-primary text-white">
                Login to Dashboard
            </div>
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}''')
    
    with open('templates/404.html', 'w') as f:
        f.write('''{% extends "base.html" %}

{% block title %}Page Not Found{% endblock %}

{% block content %}
<div class="alert alert-danger">
    <h4 class="alert-heading">Page Not Found</h4>
    <p>The page you requested does not exist.</p>
    <hr>
    <p class="mb-0"><a href="/" class="alert-link">Return to Dashboard</a></p>
</div>
{% endblock %}''')
    
    with open('templates/500.html', 'w') as f:
        f.write('''{% extends "base.html" %}

{% block title %}Server Error{% endblock %}

{% block content %}
<div class="alert alert-danger">
    <h4 class="alert-heading">Server Error</h4>
    <p>An error occurred while processing your request.</p>
    <p>{{ error }}</p>
    <hr>
    <p class="mb-0"><a href="/" class="alert-link">Return to Dashboard</a></p>
</div>
{% endblock %}''')
    
    # Run the app in development mode
    app.run(debug=True, host='0.0.0.0', port=5000)