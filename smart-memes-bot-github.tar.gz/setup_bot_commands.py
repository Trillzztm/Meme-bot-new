#!/usr/bin/env python3
"""
SMART MEMES BOT - Command Setup

This script registers the bot commands with Telegram to make them clickable and usable.
"""

import os
import sys
import requests
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot_setup.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("BotSetup")

def main():
    # Get token
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN environment variable not set!")
        sys.exit(1)
    
    logger.info(f"Using bot token: {token[:5]}...{token[-5:]}")
    
    # Define commands
    commands = [
        {"command": "start", "description": "Start the bot and see welcome message"},
        {"command": "help", "description": "Show available commands and usage info"},
        {"command": "profit", "description": "View your current trading profits"},
        {"command": "balance", "description": "Check your wallet balance"},
        {"command": "analyze", "description": "Analyze a token's safety (e.g., /analyze 0x123...)"},
        {"command": "snipe", "description": "Snipe a token automatically (e.g., /snipe 0x123...)"},
        {"command": "autosnipe", "description": "Turn on automatic token sniping"},
        {"command": "tracktoken", "description": "Track a token's price (e.g., /tracktoken 0x123...)"},
        {"command": "trackwallet", "description": "Monitor a wallet (e.g., /trackwallet 0x123...)"},
        {"command": "generateprememe", "description": "Create viral marketing memes"},
        {"command": "settings", "description": "Configure your trading preferences"},
        {"command": "aiadvice", "description": "Get AI trading recommendations"},
        {"command": "watchgroup", "description": "Monitor a Telegram group (e.g., /watchgroup -123456)"},
        {"command": "tokensafety", "description": "Check token safety score (e.g., /tokensafety 0x123...)"}
    ]
    
    # Set commands
    url = f"https://api.telegram.org/bot{token}/setMyCommands"
    payload = {"commands": commands}
    
    try:
        logger.info("Registering commands with Telegram API...")
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("ok", False):
                logger.info("✅ Commands registered successfully!")
                
                # Also send a message to the developer
                send_message = f"https://api.telegram.org/bot{token}/sendMessage"
                dev_message = {
                    "chat_id": "6915721378",  # Your chat ID from the logs
                    "text": "🚀 *SMART MEMES BOT - Commands Registered!*\n\nAll commands are now clickable in the menu. Try clicking on /help to see all available commands.\n\nYour bot is now fully operational and ready to make money 24/7!",
                    "parse_mode": "Markdown"
                }
                message_response = requests.post(send_message, json=dev_message)
                
                if message_response.status_code == 200:
                    logger.info("✅ Notification sent to developer")
                else:
                    logger.error(f"Failed to send notification: {message_response.text}")
                
            else:
                logger.error(f"Failed to register commands: {data.get('description', 'Unknown error')}")
        else:
            logger.error(f"Request failed with status code {response.status_code}: {response.text}")
    
    except Exception as e:
        logger.error(f"Error setting up commands: {e}")

if __name__ == "__main__":
    main()