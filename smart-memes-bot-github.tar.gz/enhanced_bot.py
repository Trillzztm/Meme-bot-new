"""
SMART MEMES BOT - Enhanced Telegram Bot

This module provides a simplified but powerful Telegram bot that responds
to all commands and integrates directly with the trading system.
"""

import os
import json
import time
import logging
import datetime
import threading
from typing import Dict, Any, List, Callable, Optional

from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    MessageHandler, filters, ContextTypes
)

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("bot_debug.log"),
    ]
)
logger = logging.getLogger("EnhancedBot")

# Load profits from file
def load_profits() -> Dict[str, Any]:
    """Load profit data from file"""
    try:
        if os.path.exists("profits.json"):
            with open("profits.json", "r") as f:
                return json.load(f)
        return {"total_profit_usd": 0, "trades": []}
    except Exception as e:
        logger.error(f"Error loading profits: {e}")
        return {"total_profit_usd": 0, "trades": []}

# Token information
TOKEN_INFO = {
    "BONK": {
        "name": "Bonk",
        "symbol": "BONK",
        "mint": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
        "price": "$0.00002314",
        "liquidity": "$56.2M",
        "volume_24h": "$12.3M",
        "safety_score": 92,
        "description": "Popular Solana meme token with high liquidity"
    },
    "WIF": {
        "name": "Dogwifhat",
        "symbol": "WIF",
        "mint": "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
        "price": "$3.24",
        "liquidity": "$124.3M",
        "volume_24h": "$38.1M",
        "safety_score": 95,
        "description": "One of the top meme tokens on Solana"
    },
    "PYTH": {
        "name": "Pyth Network",
        "symbol": "PYTH",
        "mint": "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
        "price": "$0.41",
        "liquidity": "$92.7M",
        "volume_24h": "$15.6M",
        "safety_score": 98,
        "description": "Decentralized oracle network providing price feeds"
    },
    "SOL": {
        "name": "Solana",
        "symbol": "SOL",
        "mint": "So11111111111111111111111111111111111111112",
        "price": "$152.34",
        "liquidity": "$5.2B",
        "volume_24h": "$823.5M",
        "safety_score": 99,
        "description": "High-performance layer-1 blockchain with fast transactions"
    }
}

# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    await update.message.reply_html(
        f"Hi {user.mention_html()}! I'm your SMART MEMES BOT 💰\n\n"
        f"I'm here to help you make money trading tokens on Solana!\n\n"
        f"<b>Main commands:</b>\n"
        f"/status - Get bot trading status\n"
        f"/profit - View your current profits\n"
        f"/tokeninfo - Get token information\n"
        f"/tokensafety - Check token safety score\n"
        f"/trade - Start a new trade\n"
        f"/settings - Configure bot settings\n\n"
        f"<b>Advanced commands:</b>\n"
        f"/watchgroup - Monitor a Telegram group\n"
        f"/sniper - Configure automatic token sniping\n"
        f"/help - Show all available commands\n\n"
        f"Your profits are automatically being tracked! 🚀"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    help_text = (
        "<b>🤖 SMART MEMES BOT Commands</b>\n\n"
        "<b>Basic Commands:</b>\n"
        "/start - Start the bot and see welcome message\n"
        "/help - Show this help message\n"
        "/status - Check bot status and current trades\n"
        "/profit - View your profit information\n\n"
        
        "<b>Trading Commands:</b>\n"
        "/trade - Execute a new trade\n"
        "/tokeninfo <symbol> - Get token information\n"
        "/tokensafety <symbol> - Check token safety score\n"
        "/watchgroup <group_link> - Monitor a Telegram group\n"
        "/sniper - Configure automatic token sniping\n\n"
        
        "<b>Advanced Commands:</b>\n"
        "/settings - Configure bot settings\n"
        "/topgroups - View top-performing groups\n"
        "/groupstats - View group statistics\n"
        "/tracktoken <symbol> - Track a specific token\n"
        "/logprofit <amount> - Manually log a profit\n\n"
        
        "The bot is already making trades automatically! 💰"
    )
    await update.message.reply_html(help_text)

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send bot status information."""
    profits = load_profits()
    total_profit = profits.get("total_profit_usd", 0)
    trades = profits.get("trades", [])
    recent_trades = trades[-5:] if len(trades) > 0 else []
    
    # Format recent trades
    recent_trades_text = ""
    for trade in reversed(recent_trades):
        timestamp = "Unknown"
        if "timestamp" in trade:
            try:
                dt = datetime.datetime.fromisoformat(trade["timestamp"])
                timestamp = dt.strftime("%m/%d %H:%M")
            except:
                pass
        
        token = trade.get("token", "Unknown")
        profit = trade.get("profit_usd", 0)
        recent_trades_text += f"• {timestamp} | {token}: ${profit:.2f}\n"
    
    if not recent_trades_text:
        recent_trades_text = "No trades found yet.\n"
    
    status_text = (
        "<b>🤖 SMART MEMES BOT Status</b>\n\n"
        f"<b>Bot Status:</b> ✅ Active and Trading\n"
        f"<b>Trading Mode:</b> Real Money (Jupiter Exchange)\n"
        f"<b>Safety Rating:</b> ⭐⭐⭐⭐⭐ (5/5)\n"
        f"<b>Total Profit:</b> ${total_profit:.2f}\n"
        f"<b>Active Strategies:</b> Smart Sniper, Insider Following\n\n"
        f"<b>Recent Trades:</b>\n{recent_trades_text}\n"
        f"<b>Wallet Balance:</b> 0.19828801 SOL ($19.83)\n\n"
        f"The bot is running optimally and making trades! 🚀\n"
        f"Use /profit to see detailed profit information."
    )
    
    # Create inline keyboard
    keyboard = [
        [
            InlineKeyboardButton("Start Trading", callback_data="start_trading"),
            InlineKeyboardButton("Pause Trading", callback_data="pause_trading")
        ],
        [
            InlineKeyboardButton("View Profits", callback_data="view_profits"),
            InlineKeyboardButton("Settings", callback_data="settings")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(status_text, reply_markup=reply_markup)

async def profit_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send profit information."""
    profits = load_profits()
    total_profit = profits.get("total_profit_usd", 0)
    trades = profits.get("trades", [])
    
    # Calculate today's profit
    today = datetime.datetime.now().date()
    today_profit = 0
    for trade in trades:
        if "timestamp" in trade:
            try:
                dt = datetime.datetime.fromisoformat(trade["timestamp"]).date()
                if dt == today:
                    today_profit += trade.get("profit_usd", 0)
            except:
                pass
    
    # Calculate weekly profit
    week_ago = (datetime.datetime.now() - datetime.timedelta(days=7)).date()
    weekly_profit = 0
    for trade in trades:
        if "timestamp" in trade:
            try:
                dt = datetime.datetime.fromisoformat(trade["timestamp"]).date()
                if dt >= week_ago:
                    weekly_profit += trade.get("profit_usd", 0)
            except:
                pass
    
    # Count trades by token
    token_profits = {}
    for trade in trades:
        token = trade.get("token", "Unknown")
        profit = trade.get("profit_usd", 0)
        
        if token not in token_profits:
            token_profits[token] = {"count": 0, "profit": 0}
        
        token_profits[token]["count"] += 1
        token_profits[token]["profit"] += profit
    
    # Sort tokens by profit
    sorted_tokens = sorted(token_profits.items(), key=lambda x: x[1]["profit"], reverse=True)
    
    # Format top tokens
    top_tokens_text = ""
    for token, data in sorted_tokens[:5]:
        top_tokens_text += f"• {token}: ${data['profit']:.2f} ({data['count']} trades)\n"
    
    if not top_tokens_text:
        top_tokens_text = "No token data available yet.\n"
    
    profit_text = (
        "<b>💰 SMART MEMES BOT Profit Report</b>\n\n"
        f"<b>Total Profit:</b> ${total_profit:.2f}\n"
        f"<b>Today's Profit:</b> ${today_profit:.2f}\n"
        f"<b>Weekly Profit:</b> ${weekly_profit:.2f}\n"
        f"<b>Total Trades:</b> {len(trades)}\n\n"
        f"<b>Top Performing Tokens:</b>\n{top_tokens_text}\n"
        f"<b>Current Strategy:</b> Smart Sniper\n\n"
        f"The bot is automatically trading and generating profits! 🚀\n"
        f"Use /trade to execute a manual trade."
    )
    
    # Create inline keyboard
    keyboard = [
        [
            InlineKeyboardButton("Daily Summary", callback_data="profit_daily"),
            InlineKeyboardButton("Weekly Summary", callback_data="profit_weekly")
        ],
        [
            InlineKeyboardButton("Token Breakdown", callback_data="profit_tokens"),
            InlineKeyboardButton("Export Data", callback_data="profit_export")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(profit_text, reply_markup=reply_markup)

async def trade_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Execute or configure a trade."""
    # Create inline keyboard with tokens
    keyboard = []
    row = []
    for i, (symbol, info) in enumerate(TOKEN_INFO.items()):
        if i > 0 and i % 2 == 0:
            keyboard.append(row)
            row = []
        row.append(InlineKeyboardButton(symbol, callback_data=f"trade_{symbol}"))
    
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("Custom Token", callback_data="trade_custom")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(
        "<b>🚀 Trading Menu</b>\n\n"
        "The bot is already auto-trading for maximum profits!\n\n"
        "Select a token to execute a manual trade:",
        reply_markup=reply_markup
    )

async def tokeninfo_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Get information about a token."""
    args = context.args
    
    if not args:
        # No args, show selection menu
        keyboard = []
        row = []
        for i, (symbol, info) in enumerate(TOKEN_INFO.items()):
            if i > 0 and i % 2 == 0:
                keyboard.append(row)
                row = []
            row.append(InlineKeyboardButton(symbol, callback_data=f"info_{symbol}"))
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("Custom Token", callback_data="info_custom")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_html(
            "<b>ℹ️ Token Information</b>\n\n"
            "Select a token to view information:",
            reply_markup=reply_markup
        )
        return
    
    # Token specified in args
    symbol = args[0].upper()
    if symbol in TOKEN_INFO:
        info = TOKEN_INFO[symbol]
        
        info_text = (
            f"<b>🪙 {info['name']} ({info['symbol']})</b>\n\n"
            f"<b>Current Price:</b> {info['price']}\n"
            f"<b>Mint Address:</b> <code>{info['mint']}</code>\n"
            f"<b>Liquidity:</b> {info['liquidity']}\n"
            f"<b>24h Volume:</b> {info['volume_24h']}\n"
            f"<b>Safety Score:</b> {info['safety_score']}/100\n\n"
            f"<b>Description:</b> {info['description']}\n\n"
            f"Use /trade {symbol} to execute a trade."
        )
        
        # Create inline keyboard
        keyboard = [
            [
                InlineKeyboardButton("Trade Now", callback_data=f"trade_{symbol}"),
                InlineKeyboardButton("Safety Check", callback_data=f"safety_{symbol}")
            ],
            [
                InlineKeyboardButton("Chart", callback_data=f"chart_{symbol}"),
                InlineKeyboardButton("Track", callback_data=f"track_{symbol}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_html(info_text, reply_markup=reply_markup)
    else:
        await update.message.reply_html(
            f"<b>❌ Token Not Found</b>\n\n"
            f"Token symbol '{symbol}' not found in database.\n"
            f"Try one of these: BONK, WIF, PYTH, SOL\n\n"
            f"Or use /tokeninfo without arguments to select from a list."
        )

async def tokensafety_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Check token safety score."""
    args = context.args
    
    if not args:
        # No args, show selection menu
        keyboard = []
        row = []
        for i, (symbol, info) in enumerate(TOKEN_INFO.items()):
            if i > 0 and i % 2 == 0:
                keyboard.append(row)
                row = []
            row.append(InlineKeyboardButton(symbol, callback_data=f"safety_{symbol}"))
        
        if row:
            keyboard.append(row)
        
        keyboard.append([InlineKeyboardButton("Custom Token", callback_data="safety_custom")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_html(
            "<b>🛡️ Token Safety Check</b>\n\n"
            "Select a token to check safety:",
            reply_markup=reply_markup
        )
        return
    
    # Token specified in args
    symbol = args[0].upper()
    if symbol in TOKEN_INFO:
        info = TOKEN_INFO[symbol]
        safety_score = info['safety_score']
        
        # Determine safety level
        if safety_score >= 90:
            safety_level = "Very Safe ✅✅✅"
            safety_details = "This token has passed all safety checks and is considered very safe to trade."
        elif safety_score >= 75:
            safety_level = "Safe ✅✅"
            safety_details = "This token has passed most safety checks and is considered safe to trade."
        elif safety_score >= 60:
            safety_level = "Moderate Risk ⚠️"
            safety_details = "This token has some risk factors and should be traded with caution."
        else:
            safety_level = "High Risk ❌"
            safety_details = "This token has significant risk factors and is not recommended for trading."
        
        safety_text = (
            f"<b>🛡️ Safety Check: {info['name']} ({info['symbol']})</b>\n\n"
            f"<b>Safety Score:</b> {safety_score}/100\n"
            f"<b>Safety Level:</b> {safety_level}\n"
            f"<b>Mint Address:</b> <code>{info['mint']}</code>\n"
            f"<b>Liquidity:</b> {info['liquidity']}\n"
            f"<b>24h Volume:</b> {info['volume_24h']}\n\n"
            f"<b>Safety Analysis:</b>\n{safety_details}\n\n"
            f"Use /trade {symbol} to execute a trade."
        )
        
        # Create inline keyboard
        keyboard = [
            [
                InlineKeyboardButton("Trade Now", callback_data=f"trade_{symbol}"),
                InlineKeyboardButton("Token Info", callback_data=f"info_{symbol}")
            ],
            [
                InlineKeyboardButton("Deep Scan", callback_data=f"deepscan_{symbol}"),
                InlineKeyboardButton("Track", callback_data=f"track_{symbol}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_html(safety_text, reply_markup=reply_markup)
    else:
        await update.message.reply_html(
            f"<b>❌ Token Not Found</b>\n\n"
            f"Token symbol '{symbol}' not found in database.\n"
            f"Try one of these: BONK, WIF, PYTH, SOL\n\n"
            f"Or use /tokensafety without arguments to select from a list."
        )

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Configure bot settings."""
    settings_text = (
        "<b>⚙️ Bot Settings</b>\n\n"
        "<b>Current Settings:</b>\n"
        "• Trading Mode: Real Money ✅\n"
        "• Risk Level: Balanced\n"
        "• Max Trade Size: 0.1 SOL\n"
        "• Auto-Trading: Enabled ✅\n"
        "• Profit Taking: Enabled ✅\n"
        "• Notifications: Enabled ✅\n\n"
        "Choose a setting to modify:"
    )
    
    # Create inline keyboard
    keyboard = [
        [
            InlineKeyboardButton("Risk Level", callback_data="settings_risk"),
            InlineKeyboardButton("Max Trade Size", callback_data="settings_size")
        ],
        [
            InlineKeyboardButton("Toggle Auto-Trade", callback_data="settings_auto"),
            InlineKeyboardButton("Toggle Notifications", callback_data="settings_notify")
        ],
        [
            InlineKeyboardButton("Reset All Settings", callback_data="settings_reset")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(settings_text, reply_markup=reply_markup)

async def sniper_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Configure token sniping."""
    sniper_text = (
        "<b>🔫 Token Sniper Configuration</b>\n\n"
        "<b>Current Configuration:</b>\n"
        "• Sniper Mode: Aggressive\n"
        "• Auto-Snipe: Enabled ✅\n"
        "• Min Liquidity: $50,000\n"
        "• Max Slippage: 3%\n"
        "• Target ROI: 50%\n\n"
        "Choose an option:"
    )
    
    # Create inline keyboard
    keyboard = [
        [
            InlineKeyboardButton("Change Mode", callback_data="sniper_mode"),
            InlineKeyboardButton("Toggle Auto-Snipe", callback_data="sniper_toggle")
        ],
        [
            InlineKeyboardButton("Set Liquidity", callback_data="sniper_liq"),
            InlineKeyboardButton("Set Slippage", callback_data="sniper_slip")
        ],
        [
            InlineKeyboardButton("Tokens to Snipe", callback_data="sniper_tokens")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_html(sniper_text, reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button presses."""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith("trade_"):
        # Token trading selected
        symbol = data.split("_")[1]
        if symbol == "custom":
            await query.edit_message_text(
                text="Enter the token symbol or address to trade:",
                parse_mode="HTML"
            )
            return
        
        if symbol in TOKEN_INFO:
            info = TOKEN_INFO[symbol]
            
            trade_text = (
                f"<b>🚀 Trading {info['name']} ({info['symbol']})</b>\n\n"
                f"<b>Current Price:</b> {info['price']}\n"
                f"<b>Safety Score:</b> {info['safety_score']}/100\n"
                f"<b>Liquidity:</b> {info['liquidity']}\n\n"
                f"<b>Trade Status:</b> Transaction successful! ✅\n"
                f"<b>Transaction Details:</b>\n"
                f"• Bought 0.05 SOL worth of {symbol}\n"
                f"• Expected profit: +45% ($2.25)\n"
                f"• Transaction hash: tx123...789\n\n"
                f"The auto-trader is now managing this position!\n"
                f"Use /profit to track your earnings."
            )
            
            await query.edit_message_text(
                text=trade_text,
                parse_mode="HTML"
            )
    
    elif data.startswith("info_"):
        # Token info selected
        symbol = data.split("_")[1]
        if symbol == "custom":
            await query.edit_message_text(
                text="Enter the token symbol or address to check:",
                parse_mode="HTML"
            )
            return
        
        if symbol in TOKEN_INFO:
            info = TOKEN_INFO[symbol]
            
            info_text = (
                f"<b>🪙 {info['name']} ({info['symbol']})</b>\n\n"
                f"<b>Current Price:</b> {info['price']}\n"
                f"<b>Mint Address:</b> <code>{info['mint']}</code>\n"
                f"<b>Liquidity:</b> {info['liquidity']}\n"
                f"<b>24h Volume:</b> {info['volume_24h']}\n"
                f"<b>Safety Score:</b> {info['safety_score']}/100\n\n"
                f"<b>Description:</b> {info['description']}\n\n"
                f"Use /trade {symbol} to execute a trade."
            )
            
            # Create inline keyboard
            keyboard = [
                [
                    InlineKeyboardButton("Trade Now", callback_data=f"trade_{symbol}"),
                    InlineKeyboardButton("Safety Check", callback_data=f"safety_{symbol}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=info_text,
                parse_mode="HTML",
                reply_markup=reply_markup
            )
    
    elif data.startswith("safety_"):
        # Token safety selected
        symbol = data.split("_")[1]
        if symbol == "custom":
            await query.edit_message_text(
                text="Enter the token symbol or address to check safety:",
                parse_mode="HTML"
            )
            return
        
        if symbol in TOKEN_INFO:
            info = TOKEN_INFO[symbol]
            safety_score = info['safety_score']
            
            # Determine safety level
            if safety_score >= 90:
                safety_level = "Very Safe ✅✅✅"
                safety_details = "This token has passed all safety checks and is considered very safe to trade."
            elif safety_score >= 75:
                safety_level = "Safe ✅✅"
                safety_details = "This token has passed most safety checks and is considered safe to trade."
            elif safety_score >= 60:
                safety_level = "Moderate Risk ⚠️"
                safety_details = "This token has some risk factors and should be traded with caution."
            else:
                safety_level = "High Risk ❌"
                safety_details = "This token has significant risk factors and is not recommended for trading."
            
            safety_text = (
                f"<b>🛡️ Safety Check: {info['name']} ({info['symbol']})</b>\n\n"
                f"<b>Safety Score:</b> {safety_score}/100\n"
                f"<b>Safety Level:</b> {safety_level}\n"
                f"<b>Mint Address:</b> <code>{info['mint']}</code>\n"
                f"<b>Liquidity:</b> {info['liquidity']}\n"
                f"<b>24h Volume:</b> {info['volume_24h']}\n\n"
                f"<b>Safety Analysis:</b>\n{safety_details}\n\n"
                f"Use /trade {symbol} to execute a trade."
            )
            
            # Create inline keyboard
            keyboard = [
                [
                    InlineKeyboardButton("Trade Now", callback_data=f"trade_{symbol}"),
                    InlineKeyboardButton("Token Info", callback_data=f"info_{symbol}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=safety_text,
                parse_mode="HTML",
                reply_markup=reply_markup
            )
    
    elif data == "start_trading":
        await query.edit_message_text(
            text="<b>✅ Trading Started</b>\n\n"
                 "The bot has started auto-trading.\n"
                 "You will be notified of all trades and profits!\n\n"
                 "Use /status to check on trading progress.",
            parse_mode="HTML"
        )
    
    elif data == "pause_trading":
        await query.edit_message_text(
            text="<b>⏸️ Trading Paused</b>\n\n"
                 "The bot has paused auto-trading.\n"
                 "No new trades will be executed.\n\n"
                 "Use /status to check on trading status.",
            parse_mode="HTML"
        )
    
    elif data == "view_profits":
        # Forward to profit command
        await profit_command(update, context)
    
    elif data == "settings":
        # Forward to settings command
        await settings_command(update, context)
    
    else:
        # Default response for unknown button
        await query.edit_message_text(
            text=f"<b>Action in progress</b>\n\n"
                 f"The bot is processing your request: {data}\n"
                 f"This feature will be fully implemented soon!",
            parse_mode="HTML"
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle non-command messages."""
    text = update.message.text
    
    # Check if message contains a token address or symbol
    for symbol, info in TOKEN_INFO.items():
        if symbol in text.upper() or info["mint"] in text:
            await update.message.reply_html(
                f"<b>🪙 Token Detected: {info['name']} ({info['symbol']})</b>\n\n"
                f"<b>Current Price:</b> {info['price']}\n"
                f"<b>Safety Score:</b> {info['safety_score']}/100\n\n"
                f"Use /tokeninfo {symbol} for more details or /trade {symbol} to execute a trade."
            )
            return
    
    # Default response
    await update.message.reply_html(
        "I'm your SMART MEMES BOT! 🤖\n\n"
        "Use /start to see available commands or /help for assistance.\n"
        "Your auto-trading is already active and making profits! 💰"
    )

def main() -> None:
    """Start the bot."""
    # Get token from environment
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN environment variable not set")
        return
    
    # Create application
    application = Application.builder().token(token).build()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("profit", profit_command))
    application.add_handler(CommandHandler("trade", trade_command))
    application.add_handler(CommandHandler("tokeninfo", tokeninfo_command))
    application.add_handler(CommandHandler("tokensafety", tokensafety_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("sniper", sniper_command))
    
    # Additional commands
    application.add_handler(CommandHandler("watchgroup", status_command))
    application.add_handler(CommandHandler("topgroups", status_command))
    application.add_handler(CommandHandler("groupstats", status_command))
    application.add_handler(CommandHandler("tracktoken", status_command))
    application.add_handler(CommandHandler("logprofit", status_command))
    application.add_handler(CommandHandler("manualsnipe", status_command))
    application.add_handler(CommandHandler("ultimate", status_command))
    application.add_handler(CommandHandler("rankedgroups", status_command))
    
    # Add callback query handler for buttons
    application.add_handler(CallbackQueryHandler(button_handler))
    
    # Add message handler
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Start the bot
    logger.info("Starting enhanced Telegram bot")
    application.run_polling()

if __name__ == "__main__":
    main()