"""
Test for AI Integration with Fallback Mechanisms

This script tests the AI integration layer with its fallback mechanisms to
ensure the system works properly even without OpenAI API access.
"""

import asyncio
import logging
import sys
from typing import Dict, Any, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Import the AI integration layer
from ai_integration import (
    get_ai_token_analysis, 
    get_ai_safety_report,
    get_smart_analysis,
    check_group_auto_snipe,
    get_position_multiplier
)


async def test_token_analysis_with_fallback():
    """Test token analysis with fallback to simplified algorithm."""
    print("\n===== TESTING TOKEN ANALYSIS WITH FALLBACK =====")
    
    test_tokens = [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC on Solana
        "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Random Solana token 1
        "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"   # Random Solana token 2
    ]
    
    for token in test_tokens:
        print(f"\nAnalyzing token: {token}")
        
        # Get token analysis
        analysis = await get_ai_token_analysis(token)
        
        # Print results
        print(f"Score: {analysis.get('score', 0)}/100")
        print(f"Verdict: {analysis.get('verdict', 'Unknown')}")
        print(f"Recommendation: {analysis.get('recommendation', 'Unknown')}")
        
        # Print if AI was used or fallback
        if analysis.get('used_ai', False):
            print("Source: AI analysis")
        else:
            print("Source: Fallback analysis (simplified algorithm)")


async def test_safety_analysis_with_fallback():
    """Test safety analysis with fallback to simplified algorithm."""
    print("\n===== TESTING SAFETY ANALYSIS WITH FALLBACK =====")
    
    test_tokens = [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC on Solana
        "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Random Solana token 1
        "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"   # Random Solana token 2
    ]
    
    for token in test_tokens:
        print(f"\nChecking safety for token: {token}")
        
        # Get safety analysis
        safety = await get_ai_safety_report(token)
        
        # Print results
        print(f"Safety Score: {safety.get('safety_score', 0)}/100")
        print(f"Risk Level: {safety.get('risk_level', 'Unknown')}")
        print(f"Risks: {', '.join(safety.get('risks', ['Unknown']))}")
        print(f"Recommendation: {safety.get('recommendation', 'Unknown')}")
        
        # Print if AI was used or fallback
        if safety.get('used_ai', False):
            print("Source: AI analysis")
        else:
            print("Source: Fallback safety check")


async def test_learning_integration():
    """Test learning integration with group performance data."""
    print("\n===== TESTING LEARNING INTEGRATION =====")
    
    test_groups = [
        {"id": 10001, "name": "High Performance Group"},
        {"id": 10002, "name": "Medium Performance Group"},
        {"id": 10003, "name": "Low Performance Group"}
    ]
    
    for group in test_groups:
        group_id = group["id"]
        print(f"\nChecking group: {group['name']} (ID: {group_id})")
        
        # Get auto-snipe status
        auto_snipe = check_group_auto_snipe(group_id)
        print(f"Auto-Snipe Eligible: {auto_snipe}")
        
        # Get position multiplier
        multiplier = get_position_multiplier(group_id)
        print(f"Investment Multiplier: {multiplier:.2f}x")


async def test_smart_analysis():
    """Test smart analysis with combined AI, safety, and learning."""
    print("\n===== TESTING SMART ANALYSIS =====")
    
    test_cases = [
        {"token": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "group": 10001, "name": "USDC with High Performance Group"},
        {"token": "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU", "group": 10002, "name": "Random Token with Medium Performance Group"},
        {"token": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263", "group": 10003, "name": "Random Token with Low Performance Group"}
    ]
    
    for case in test_cases:
        print(f"\nSmart Analysis for: {case['name']}")
        print(f"Token: {case['token']}")
        print(f"Group: {case['group']}")
        
        # Get smart analysis
        analysis = await get_smart_analysis(case['token'], case['group'])
        
        # Print primary results
        print(f"Base Score: {analysis.get('score', 0)}/100")
        print(f"Safety Score: {analysis.get('safety_score', 0)}/100")
        print(f"Combined Score: {analysis.get('combined_score', 0):.1f}/100")
        print(f"Final Recommendation: {analysis.get('final_recommendation', 'Unknown').upper()}")
        
        # Print learning-augmented data if available
        if 'group_success_rate' in analysis:
            print(f"Group Success Rate: {analysis['group_success_rate']:.2f}")
            print(f"Auto-Snipe Eligible: {analysis.get('auto_snipe_eligible', False)}")
            print(f"Investment Multiplier: {analysis.get('investment_multiplier', 1.0):.2f}x")


async def run_all_tests():
    """Run all tests for the AI integration layer."""
    await test_token_analysis_with_fallback()
    await test_safety_analysis_with_fallback()
    await test_learning_integration()
    await test_smart_analysis()


if __name__ == "__main__":
    print("\n***** TESTING AI INTEGRATION WITH FALLBACK MECHANISMS *****\n")
    asyncio.run(run_all_tests())
    print("\n***** TESTING COMPLETE *****\n")