#!/bin/bash

# SMART MEMES BOT Startup Script
echo "Starting SMART MEMES BOT System..."

# Check for required dependencies
echo "Checking dependencies..."
DEPS_MISSING=0

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed!"
    DEPS_MISSING=1
fi

# Check for pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed!"
    DEPS_MISSING=1
fi

# Check for gunicorn
if ! command -v gunicorn &> /dev/null; then
    echo "⚠️ gunicorn is not installed! Installing..."
    pip3 install gunicorn
fi

# Exit if any dependencies are missing
if [ $DEPS_MISSING -eq 1 ]; then
    echo "Please install missing dependencies and try again."
    exit 1
fi

# Install required Python packages
echo "Installing required Python packages..."
python3 install_deps.py

# Check for required environment variables
echo "Checking environment variables..."

# Function to check if an environment variable is set
check_env_var() {
    if [ -z "${!1}" ]; then
        echo "⚠️ $1 is not set!"
        return 1
    else
        echo "✅ $1 is set"
        return 0
    fi
}

# Check critical environment variables
check_env_var "OPENAI_API_KEY" || MISSING_VARS=1
check_env_var "TELEGRAM_BOT_TOKEN" || MISSING_VARS=1
check_env_var "SOLANA_PRIVATE_KEY" || MISSING_VARS=1

# Warn if any environment variables are missing
if [ ! -z "$MISSING_VARS" ]; then
    echo "⚠️ Some environment variables are missing. The system may not function correctly."
    echo "You can set them in .env file or export them before running this script."
    echo
fi

# Run the system
echo "Starting SMART MEMES BOT system..."
python3 run.py

# If we get here, the application has exited
echo "SMART MEMES BOT system has exited."