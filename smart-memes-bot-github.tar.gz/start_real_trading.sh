#!/bin/bash
# Start Real Money Trading Script - SMART MEMES BOT
# This script starts the real money trader that uses insider wallet tracking

echo "==============================================="
echo "SMART MEMES BOT - REAL MONEY TRADER STARTER"
echo "==============================================="
echo

# Make scripts executable
chmod +x real_money_trader.py
chmod +x auto_trader_simple.py

# Check if we have the required private key
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
  echo "⚠️ WARNING: SOLANA_PRIVATE_KEY environment variable not set!"
  echo "The bot will not be able to execute real trades."
  exit 1
fi

# Kill any existing trader processes
pkill -f "python real_money_trader.py" > /dev/null 2>&1
echo "✅ Cleaned up any previous trader processes"

# Kill any existing auto trader processes
pkill -f "python auto_trader_simple.py" > /dev/null 2>&1
echo "✅ Cleaned up any previous auto trader processes"

# Start the real money trader in the background with improved reliability
echo "🚀 Starting Real Money Trader in background mode..."

# Start with nohup and redirect stdout and stderr to log files
# Using disown to prevent the process from being killed when the terminal closes
nohup python real_money_trader.py > real_trader.out 2> real_trader.err < /dev/null &
TRADER_PID=$!

# Detach process from terminal
disown -h $TRADER_PID

echo "✅ Real Money Trader started with PID: $TRADER_PID"

# Create a PID file to track it
echo $TRADER_PID > real_trader.pid
echo "✅ PID saved to real_trader.pid"

# Ensure the process is actually running
sleep 2
if ps -p $TRADER_PID > /dev/null; then
    echo "✅ Verified that Real Money Trader is running properly"
else
    echo "⚠️ Warning: Real Money Trader may have stopped immediately after starting"
    echo "Check real_trader.err for error messages"
fi

echo
echo "💰 Your REAL MONEY is now being made automatically with insider tracking!"
echo
echo "💡 Monitor progress with:"
echo "   tail -f real_money_trader.log    (see detailed logs)"
echo "   tail -f real_trader.out          (see standard output)"
echo "   cat real_profits.json            (see real profits)"
echo
echo "📱 You will receive Telegram notifications for:"
echo "   - REAL money trades based on insider wallet signals"
echo "   - Social media signal-based trades"
echo "   - Market analysis-based trades"
echo
echo "⚠️ To stop everything run: ./stop_real_trading.sh"
echo
echo "==============================================="