"""
Command handlers for the Telegram bot.
"""
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import wallet_tracker
import token_analyzer
import token_safety
import meme_generator
from config import USER_DATA, MAX_WALLETS_PER_USER, MAX_TOKENS_PER_USER
import utils

logger = logging.getLogger(__name__)

# Command Handlers
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /start command - introduce the bot and show available commands.
    """
    user_id = update.effective_user.id
    if user_id not in USER_DATA:
        USER_DATA[user_id] = {
            "watched_wallets": {},
            "watched_tokens": {},
            "tracked_mention_groups": [],
            "settings": {
                "notification_preference": "all"
            }
        }
    
    welcome_message = (
        "🚀 *Welcome to CryptoWatcherBot!* 🚀\n\n"
        "I can help you monitor crypto wallets, analyze tokens, and generate crypto memes.\n\n"
        "*Available Commands:*\n"
        "/monitor <wallet_address> - Monitor a wallet\n"
        "/snipe <token_address> - Snipe a token\n"
        "/check <token_address> - Check token safety\n"
        "/track <group_id> - Track token mentions in a group\n"
        "/analyze <token_address> - AI analysis of a token\n"
        "/meme <theme> - Generate a crypto meme\n"
        "/help - Show detailed help\n\n"
        "Let's get started! 🔥"
    )
    
    keyboard = [
        [
            InlineKeyboardButton("Monitor Wallet", callback_data="help_monitor"),
            InlineKeyboardButton("Snipe Token", callback_data="help_snipe")
        ],
        [
            InlineKeyboardButton("Check Safety", callback_data="help_check"),
            InlineKeyboardButton("Generate Meme", callback_data="help_meme")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_message,
        parse_mode="Markdown",
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /help command - show detailed information about each command.
    """
    help_text = (
        "📖 *CryptoWatcherBot Help* 📖\n\n"
        "*Wallet Monitoring*\n"
        "/monitor <wallet_address> - Start monitoring a wallet\n"
        "/unmonitor <wallet_address> - Stop monitoring a wallet\n"
        "/wallets - List all monitored wallets\n\n"
        
        "*Token Tools*\n"
        "/snipe <token_address> - Snipe a token (get in early)\n"
        "/check <token_address> - Check token safety and potential risks\n"
        "/analyze <token_address> - Get AI-powered analysis of a token\n\n"
        
        "*Tracking & Analytics*\n"
        "/track <group_id> - Track token mentions in a Telegram group\n"
        "/stats <token_address> - Get mention statistics for a token\n\n"
        
        "*Meme Generation*\n"
        "/meme <theme> - Generate a crypto meme with the given theme\n"
        "/custommeme <text1>|<text2> - Create a custom meme with your text\n\n"
        
        "*Settings & Info*\n"
        "/settings - Configure your notification preferences\n"
        "/about - Information about this bot\n"
    )
    
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def monitor_wallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /monitor command - start monitoring a wallet address.
    """
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "⚠️ Please provide a wallet address to monitor.\n"
            "Example: `/monitor 0x742d35Cc6634C0532925a3b844Bc454e4438f44e`",
            parse_mode="Markdown"
        )
        return
    
    wallet_address = context.args[0].strip()
    user_id = update.effective_user.id
    
    # Validate wallet address
    if not utils.is_valid_eth_address(wallet_address):
        await update.message.reply_text("❌ Invalid wallet address format. Please check and try again.")
        return
    
    # Check if user has reached the maximum number of watched wallets
    if len(USER_DATA[user_id]["watched_wallets"]) >= MAX_WALLETS_PER_USER:
        await update.message.reply_text(
            f"⚠️ You can only monitor up to {MAX_WALLETS_PER_USER} wallets. "
            "Please remove a wallet before adding a new one."
        )
        return
    
    # Add the wallet to watched wallets
    try:
        wallet_info = await wallet_tracker.get_wallet_info(wallet_address)
        USER_DATA[user_id]["watched_wallets"][wallet_address] = {
            "balance": wallet_info["balance"],
            "tokens": wallet_info["tokens"],
            "last_updated": utils.get_current_timestamp()
        }
        
        await update.message.reply_text(
            f"✅ Now monitoring wallet: `{wallet_address}`\n\n"
            f"💰 Current Balance: {wallet_info['balance_formatted']} ETH\n"
            f"🔣 Token Count: {len(wallet_info['tokens'])}\n\n"
            "You'll receive notifications for significant transactions.",
            parse_mode="Markdown"
        )
        
    except Exception as e:
        logger.error(f"Error monitoring wallet: {str(e)}")
        await update.message.reply_text(
            "❌ There was an error monitoring this wallet. Please try again later."
        )

async def snipe_token_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /snipe command - snipe a token (get details for potential investment).
    """
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "⚠️ Please provide a token address to snipe.\n"
            "Example: `/snipe 0x742d35Cc6634C0532925a3b844Bc454e4438f44e`",
            parse_mode="Markdown"
        )
        return
    
    token_address = context.args[0].strip()
    user_id = update.effective_user.id
    
    # Validate token address
    if not utils.is_valid_eth_address(token_address):
        await update.message.reply_text("❌ Invalid token address format. Please check and try again.")
        return
    
    # Check if user has reached the maximum number of watched tokens
    if len(USER_DATA[user_id]["watched_tokens"]) >= MAX_TOKENS_PER_USER:
        await update.message.reply_text(
            f"⚠️ You can only snipe up to {MAX_TOKENS_PER_USER} tokens. "
            "Please remove a token before adding a new one."
        )
        return
    
    # Process the token snipe
    try:
        # First message to show we're working on it
        progress_message = await update.message.reply_text(
            "🔍 Sniping token... Checking liquidity and safety...",
        )
        
        # Get token info and safety check
        token_info = await token_analyzer.get_token_info(token_address)
        safety_score, safety_issues = await token_safety.check_token_safety(token_address)
        
        # Update user data
        USER_DATA[user_id]["watched_tokens"][token_address] = {
            "name": token_info.get("name", "Unknown"),
            "symbol": token_info.get("symbol", "Unknown"),
            "price": token_info.get("price", 0),
            "last_updated": utils.get_current_timestamp()
        }
        
        # Prepare response message
        response = (
            f"🎯 *Token Sniped:* {token_info.get('name', 'Unknown')} ({token_info.get('symbol', 'Unknown')})\n\n"
            f"💰 *Price:* ${token_info.get('price', 'Unknown')}\n"
            f"💧 *Liquidity:* ${token_info.get('liquidity', 'Unknown')}\n"
            f"📊 *Market Cap:* ${token_info.get('market_cap', 'Unknown')}\n"
            f"👥 *Holders:* {token_info.get('holders', 'Unknown')}\n\n"
            f"🛡️ *Safety Score:* {safety_score}/100\n"
        )
        
        if safety_issues:
            response += "\n⚠️ *Potential Issues:*\n"
            for issue in safety_issues[:3]:  # Show top 3 issues
                response += f"• {issue}\n"
        
        # Add call to action buttons
        keyboard = [
            [
                InlineKeyboardButton("Full Analysis", callback_data=f"analyze_{token_address}"),
                InlineKeyboardButton("Check Safety", callback_data=f"safety_{token_address}")
            ],
            [
                InlineKeyboardButton("Buy/Sell Links", callback_data=f"trade_{token_address}"),
                InlineKeyboardButton("Set Alert", callback_data=f"alert_{token_address}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Edit the progress message with the full response
        await progress_message.edit_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error sniping token: {str(e)}")
        await update.message.reply_text(
            "❌ There was an error sniping this token. Please try again later."
        )

async def check_token_safety_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /check command - perform a comprehensive token safety check.
    """
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "⚠️ Please provide a token address to check.\n"
            "Example: `/check 0x742d35Cc6634C0532925a3b844Bc454e4438f44e`",
            parse_mode="Markdown"
        )
        return
    
    token_address = context.args[0].strip()
    
    # Validate token address
    if not utils.is_valid_eth_address(token_address):
        await update.message.reply_text("❌ Invalid token address format. Please check and try again.")
        return
    
    # Process the token safety check
    try:
        # First message to show we're working on it
        progress_message = await update.message.reply_text(
            "🔍 Checking token safety... This may take a moment...",
        )
        
        # Get safety information
        safety_score, safety_issues = await token_safety.check_token_safety(token_address)
        token_info = await token_analyzer.get_token_info(token_address)
        
        # Prepare response message
        if safety_score >= 80:
            safety_emoji = "✅"
            safety_text = "Seems Safe"
        elif safety_score >= 50:
            safety_emoji = "⚠️"
            safety_text = "Use Caution"
        else:
            safety_emoji = "🚫"
            safety_text = "High Risk"
        
        response = (
            f"🛡️ *Safety Check for:* {token_info.get('name', 'Unknown')} ({token_info.get('symbol', 'Unknown')})\n\n"
            f"*Address:* `{token_address}`\n\n"
            f"*Safety Score:* {safety_score}/100 {safety_emoji} - {safety_text}\n\n"
        )
        
        if safety_issues:
            response += "*Issues Found:*\n"
            for issue in safety_issues:
                response += f"• {issue}\n"
        else:
            response += "✅ No major issues found\n"
        
        # Add safety metrics
        response += "\n*Contract Details:*\n"
        response += f"• Age: {token_info.get('age_days', 'Unknown')} days\n"
        response += f"• Verified: {'Yes' if token_info.get('verified', False) else 'No'}\n"
        response += f"• Renounced Ownership: {'Yes' if token_info.get('renounced_ownership', False) else 'No'}\n"
        response += f"• Locked Liquidity: {'Yes' if token_info.get('locked_liquidity', False) else 'No'}\n"
        
        # Add recommendations
        response += "\n*Recommendations:*\n"
        if safety_score >= 80:
            response += "• DYOR, but seems safe for investment\n"
        elif safety_score >= 50:
            response += "• Proceed with caution and limit exposure\n"
        else:
            response += "• Not recommended for investment - high risk\n"
        
        # Edit the progress message with the full response
        keyboard = [
            [InlineKeyboardButton("Detailed Analysis", callback_data=f"analyze_{token_address}")],
            [InlineKeyboardButton("Check Holders", callback_data=f"holders_{token_address}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await progress_message.edit_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error checking token safety: {str(e)}")
        await update.message.reply_text(
            "❌ There was an error checking this token's safety. Please try again later."
        )

async def track_mentions_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /track command - track token mentions in a Telegram group.
    """
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "⚠️ Please provide a group ID or link to track.\n"
            "Example: `/track -1001234567890` or `/track @group_name`",
            parse_mode="Markdown"
        )
        return
    
    group_identifier = context.args[0].strip()
    user_id = update.effective_user.id
    
    # Simple validation
    if not group_identifier.startswith('-100') and not group_identifier.startswith('@'):
        await update.message.reply_text(
            "❌ Invalid group identifier format. Please use a group ID (starting with -100) "
            "or a group username (starting with @)."
        )
        return
    
    # Add the group to tracked groups
    if group_identifier not in USER_DATA[user_id]["tracked_mention_groups"]:
        USER_DATA[user_id]["tracked_mention_groups"].append(group_identifier)
    
    await update.message.reply_text(
        f"✅ Now tracking token mentions in: {group_identifier}\n\n"
        "I'll monitor for token symbols, contract addresses, and token names. "
        "You'll receive reports on the most mentioned tokens."
    )

async def analyze_token_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /analyze command - provide AI-powered token analysis.
    """
    if not context.args or len(context.args) < 1:
        await update.message.reply_text(
            "⚠️ Please provide a token address to analyze.\n"
            "Example: `/analyze 0x742d35Cc6634C0532925a3b844Bc454e4438f44e`",
            parse_mode="Markdown"
        )
        return
    
    token_address = context.args[0].strip()
    
    # Validate token address
    if not utils.is_valid_eth_address(token_address):
        await update.message.reply_text("❌ Invalid token address format. Please check and try again.")
        return
    
    # Process the token analysis
    try:
        # First message to show we're working on it
        progress_message = await update.message.reply_text(
            "🧠 Analyzing token... This may take a moment...",
        )
        
        # Get token analysis
        token_info = await token_analyzer.get_token_info(token_address)
        analysis = await token_analyzer.analyze_token(token_address)
        
        # Prepare response message
        response = (
            f"🔍 *AI Analysis for:* {token_info.get('name', 'Unknown')} ({token_info.get('symbol', 'Unknown')})\n\n"
            f"*Price:* ${token_info.get('price', 'Unknown')}\n"
            f"*Market Cap:* ${token_info.get('market_cap', 'Unknown')}\n\n"
            f"*Analysis Summary:*\n{analysis['summary']}\n\n"
            f"*Strengths:*\n"
        )
        
        for strength in analysis['strengths']:
            response += f"• {strength}\n"
        
        response += "\n*Concerns:*\n"
        for concern in analysis['concerns']:
            response += f"• {concern}\n"
        
        response += f"\n*Recommendation:* {analysis['recommendation']}"
        
        # Edit the progress message with the full response
        keyboard = [
            [InlineKeyboardButton("Price Chart", callback_data=f"chart_{token_address}")],
            [InlineKeyboardButton("Trading Volume", callback_data=f"volume_{token_address}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await progress_message.edit_text(
            response,
            parse_mode="Markdown",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error analyzing token: {str(e)}")
        await update.message.reply_text(
            "❌ There was an error analyzing this token. Please try again later."
        )

async def generate_meme_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle the /meme command - generate a crypto-themed meme.
    """
    # Check if user provided a theme
    if not context.args or len(context.args) < 1:
        # Show available meme themes
        from config import MEME_TEMPLATES
        
        themes_list = "\n".join([f"• {theme.replace('_', ' ').title()}" for theme in MEME_TEMPLATES])
        
        await update.message.reply_text(
            "🎭 *Available Meme Themes:*\n\n"
            f"{themes_list}\n\n"
            "Use `/meme <theme>` to generate a meme.\n"
            "Example: `/meme moon_lambo`\n\n"
            "Or use `/custommeme <text1>|<text2>` for custom text.",
            parse_mode="Markdown"
        )
        return
    
    theme = context.args[0].strip().lower()
    
    # Generate the meme
    try:
        # First message to show we're working on it
        progress_message = await update.message.reply_text(
            "🎨 Generating your crypto meme...",
        )
        
        # Custom text if provided as additional arguments
        custom_text = None
        if len(context.args) > 1:
            custom_text = " ".join(context.args[1:])
        
        # Generate the meme
        meme_data = await meme_generator.generate_meme(theme, custom_text)
        
        # Create the image
        image_path = await meme_generator.create_meme_image(meme_data)
        
        # Send the meme
        with open(image_path, 'rb') as meme:
            await update.message.reply_photo(
                photo=meme,
                caption=f"🎭 Your {theme.replace('_', ' ')} meme is ready! Share it on social media! #crypto #meme"
            )
        
        # Delete the progress message
        await progress_message.delete()
        
        # Delete the temporary file
        import os
        os.remove(image_path)
        
    except Exception as e:
        logger.error(f"Error generating meme: {str(e)}")
        await update.message.reply_text(
            "❌ There was an error generating your meme. Please try again later."
        )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle button callbacks from inline keyboards.
    """
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data.startswith("help_"):
        # Help button callbacks
        help_type = data.split("_")[1]
        
        if help_type == "monitor":
            await query.message.reply_text(
                "📋 *Wallet Monitoring Help*\n\n"
                "The `/monitor` command allows you to track a crypto wallet's activity.\n\n"
                "*Usage:* `/monitor <wallet_address>`\n\n"
                "You'll receive notifications when:\n"
                "• Significant tokens are bought or sold\n"
                "• Large transfers occur\n"
                "• New tokens are received\n\n"
                "You can monitor up to 5 wallets at once.",
                parse_mode="Markdown"
            )
        
        elif help_type == "snipe":
            await query.message.reply_text(
                "🎯 *Token Sniping Help*\n\n"
                "The `/snipe` command helps you get early information about tokens.\n\n"
                "*Usage:* `/snipe <token_address>`\n\n"
                "You'll get details about:\n"
                "• Current price and liquidity\n"
                "• Market cap and holders\n"
                "• Initial safety assessment\n\n"
                "This is useful for finding new opportunities early.",
                parse_mode="Markdown"
            )
        
        elif help_type == "check":
            await query.message.reply_text(
                "🛡️ *Token Safety Check Help*\n\n"
                "The `/check` command performs a thorough safety analysis of a token.\n\n"
                "*Usage:* `/check <token_address>`\n\n"
                "The safety check includes:\n"
                "• Contract audit for common vulnerabilities\n"
                "• Ownership and liquidity analysis\n"
                "• Holder distribution examination\n"
                "• Rug pull potential assessment\n\n"
                "Always use this before investing in a new token!",
                parse_mode="Markdown"
            )
        
        elif help_type == "meme":
            await query.message.reply_text(
                "🎭 *Meme Generation Help*\n\n"
                "The `/meme` command creates crypto-themed memes for sharing.\n\n"
                "*Usage:* `/meme <theme>` or `/meme <theme> <custom_text>`\n\n"
                "Available themes include:\n"
                "• moon_lambo, buy_the_dip, diamond_hands\n"
                "• paper_hands, to_the_moon, hodl\n\n"
                "For custom memes with your text:\n"
                "• `/custommeme <text1>|<text2>`",
                parse_mode="Markdown"
            )
    
    elif data.startswith("analyze_"):
        # Token analysis button callback
        token_address = data.split("_")[1]
        await query.message.reply_text(f"Analyzing token {token_address}...")
        # Call the analyze command handler
        context.args = [token_address]
        await analyze_token_command(update, context)
    
    elif data.startswith("safety_"):
        # Token safety check button callback
        token_address = data.split("_")[1]
        await query.message.reply_text(f"Checking safety for {token_address}...")
        # Call the safety check command handler
        context.args = [token_address]
        await check_token_safety_command(update, context)
    
    # Add other button handlers as needed
    # ...

async def inline_query_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Handle inline queries for quick meme generation.
    """
    from telegram import InlineQueryResultPhoto
    
    query = update.inline_query.query
    
    if not query:
        return
    
    # Parse the query for meme generation
    parts = query.split()
    
    if len(parts) < 1:
        return
    
    theme = parts[0]
    custom_text = " ".join(parts[1:]) if len(parts) > 1 else None
    
    try:
        # Generate the meme
        meme_data = await meme_generator.generate_meme(theme, custom_text)
        
        # Create the image
        image_path = await meme_generator.create_meme_image(meme_data)
        
        # Create the inline result
        results = [
            InlineQueryResultPhoto(
                id="1",
                photo_url=f"https://example.com/memes/{image_path}",  # This would need a proper URL in production
                thumb_url=f"https://example.com/memes/thumbs/{image_path}",  # Same issue
                caption=f"🎭 {theme.replace('_', ' ')} crypto meme #crypto #meme",
                title=f"{theme.replace('_', ' ').title()} Meme"
            )
        ]
        
        await update.inline_query.answer(results)
        
    except Exception as e:
        logger.error(f"Error handling inline query: {str(e)}")
