"""
Test script for Smart Trading system with AI and learning capabilities.

This script demonstrates the full capabilities of the AI-powered trading system
including the learning engine, AI analysis, and automated decision making.
"""

import logging
import asyncio
import sys
import os
import random
from typing import Dict, Any, List, Optional
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Try to import the AI integration layer
try:
    from ai_integration import (
        get_smart_analysis, record_trade_performance, 
        check_group_auto_snipe, get_position_multiplier
    )
    HAS_AI = True
except ImportError:
    HAS_AI = False
    logger.error("AI integration layer not available - cannot run tests")

# Try to import needed components
try:
    from utils.token_scanner import extract_token_address, is_valid_token_address
    from utils.trading import calculate_position_size, calculate_exit_strategy, execute_trade
    from utils.solana_trade import get_wallet_info
    HAS_TRADING = True
except ImportError:
    HAS_TRADING = False
    logger.warning("Trading utilities not available - limited functionality")


async def test_smart_trading_flow(token_address: str, group_id: int = 12345):
    """
    Test the complete smart trading flow.
    
    Args:
        token_address: Token address to analyze and potentially trade
        group_id: The group ID where the token was discovered
    """
    if not HAS_AI:
        logger.error("AI integration not available - cannot proceed with testing")
        return
        
    logger.info("=" * 60)
    logger.info(f"TESTING SMART TRADING FLOW FOR {token_address}")
    logger.info("=" * 60)
    
    # Step 1: Get smart analysis with learning-augmented score
    logger.info("\n📊 STEP 1: Get smart analysis with learning-augmented score")
    analysis = await get_smart_analysis(token_address, group_id)
    
    # Print analysis summary
    logger.info(f"Token Address: {token_address}")
    logger.info(f"Analysis Score: {analysis.get('score', 0)}/100")
    logger.info(f"Safety Score: {analysis.get('safety_score', 0)}/100")
    logger.info(f"Combined Score: {analysis.get('combined_score', 0):.1f}/100")
    logger.info(f"Risk Level: {analysis.get('risk_level', 'unknown')}")
    logger.info(f"Final Recommendation: {analysis.get('final_recommendation', 'unknown').upper()}")
    
    # Show learning-based adjustments if available
    if "group_success_rate" in analysis:
        logger.info(f"Group Success Rate: {analysis['group_success_rate']:.2f}")
        logger.info(f"Investment Multiplier: {analysis['investment_multiplier']:.2f}x")
        logger.info(f"Auto-Snipe Eligible: {analysis['auto_snipe_eligible']}")
    
    # Step 2: Check if we should auto-snipe based on learning
    logger.info("\n🔍 STEP 2: Check if we should auto-snipe based on learning")
    should_snipe = check_group_auto_snipe(group_id)
    logger.info(f"Group {group_id} auto-snipe status: {should_snipe}")
    
    # Step 3: Calculate position size using multiplier
    logger.info("\n💰 STEP 3: Calculate position size using multiplier")
    base_amount = 0.1  # SOL
    multiplier = get_position_multiplier(group_id)
    position_size = base_amount * multiplier
    
    logger.info(f"Base amount: {base_amount} SOL")
    logger.info(f"Group multiplier: {multiplier:.2f}x")
    logger.info(f"Calculated position size: {position_size:.4f} SOL")
    
    if HAS_TRADING:
        # Get wallet info
        wallet_info = await get_wallet_info()
        logger.info(f"Wallet balance: {wallet_info.get('sol_balance', 0):.4f} SOL")
    
    # Step 4: Make trading decision
    logger.info("\n🧠 STEP 4: Make trading decision")
    
    # Decision logic
    execute_trade_flag = False
    
    if analysis.get('final_recommendation') == "buy":
        if should_snipe:
            logger.info("✅ AUTO-SNIPE CRITERIA MET - this token would be auto-sniped")
            execute_trade_flag = True
        else:
            logger.info("⚠️ RECOMMENDATION IS BUY, but group doesn't qualify for auto-snipe")
            execute_trade_flag = True if random.random() > 0.5 else False  # Simulate user decision
    else:
        logger.info("❌ NOT RECOMMENDED TO BUY - would skip this token")
        
    # Step 5: Execute trade if decision is yes
    if execute_trade_flag and HAS_TRADING:
        logger.info("\n🚀 STEP 5: Execute trade")
        
        # Calculate exit strategy
        entry_price = random.uniform(0.000001, 0.0001)  # Simulate entry price
        exit_strategy = calculate_exit_strategy(entry_price, analysis)
        
        logger.info(f"Entry price: {entry_price:.10f}")
        logger.info(f"Stop loss: {exit_strategy.get('stop_loss', 0):.10f} ({exit_strategy.get('stop_loss_percent', 0)*100:.1f}%)")
        logger.info(f"Take profit targets:")
        logger.info(f"  TP1: {exit_strategy.get('take_profit_1', 0):.10f} ({exit_strategy.get('tp1_percent', 0)*100:.1f}%)")
        logger.info(f"  TP2: {exit_strategy.get('take_profit_2', 0):.10f} ({exit_strategy.get('tp2_percent', 0)*100:.1f}%)")
        logger.info(f"  TP3: {exit_strategy.get('take_profit_3', 0):.10f} ({exit_strategy.get('tp3_percent', 0)*100:.1f}%)")
        
        # Execute trade (simulated)
        logger.info(f"Executing trade for {position_size:.4f} SOL")
        result = await execute_trade(
            token_address=token_address,
            amount=position_size,
            is_buy=True,
            slippage=0.02
        )
        
        if result.get('success'):
            logger.info(f"Trade executed successfully!")
            logger.info(f"Transaction hash: {result.get('transaction_hash', 'Unknown')}")
            logger.info(f"Tokens received: {result.get('tokens_received', 0):.2f}")
            
            # Step 6: Record trade for learning
            logger.info("\n📈 STEP 6: Record trade for learning")
            
            # Simulate profit outcome for demonstration
            simulated_profit = random.uniform(-20, 100)
            logger.info(f"Simulated profit: {simulated_profit:.2f}%")
            
            # Record the performance
            await record_trade_performance(token_address, group_id, simulated_profit)
            logger.info("Trade performance recorded for learning")
        else:
            logger.error(f"Trade execution failed: {result.get('error', 'Unknown error')}")
    elif execute_trade_flag:
        logger.warning("Would execute trade but trading utilities not available")
    else:
        logger.info("Trade execution skipped - decision was not to buy")
        
    logger.info("\n" + "=" * 60)
    logger.info("SMART TRADING TEST COMPLETE")
    logger.info("=" * 60 + "\n")


async def run_tests():
    """Run multiple tests across different scenarios."""
    try:
        # Test on Solana token
        test_tokens = [
            "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # SOL
            "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",  # Sample token 1
            "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"   # Sample token 2
        ]
        
        # Sample group IDs with different performance profiles
        groups = [
            {"id": 10001, "name": "High-Performing Group"},
            {"id": 10002, "name": "Medium-Performing Group"},
            {"id": 10003, "name": "Low-Performing Group"}
        ]
        
        # Run test for SOL token as baseline
        await test_smart_trading_flow(test_tokens[0], groups[0]["id"])
        
        # Run tests for other tokens with different groups
        await test_smart_trading_flow(test_tokens[1], groups[1]["id"])
        await test_smart_trading_flow(test_tokens[2], groups[2]["id"])
        
    except Exception as e:
        logger.error(f"Error running tests: {e}")


if __name__ == "__main__":
    if not HAS_AI:
        print("ERROR: AI integration not available - cannot run tests")
        sys.exit(1)
        
    print("\n===== RUNNING SMART TRADING SYSTEM TESTS =====\n")
    asyncio.run(run_tests())