"""
SMART MEMES BOT - Jupiter Real Money Trader

This module implements REAL money trading via Jupiter Exchange.
It connects to your Phantom wallet and executes actual trades with your funds.
"""

import os
import json
import asyncio
import logging
import datetime
import traceback
from utils.jupiter_client import swap_sol_to_token, swap_token_to_sol

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("jupiter_real_trades.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("JupiterRealTrader")

# Constants
SOL_MINT = "So11111111111111111111111111111111111111112"
DEFAULT_SLIPPAGE = 50  # 0.5%

# List of successful trades
TRADE_HISTORY = []

# Keep track of currently held tokens
CURRENT_HOLDINGS = {}

async def execute_real_trade(token_name, token_address, amount_sol):
    """
    Execute a real trade using Jupiter Exchange.
    
    Args:
        token_name: The token symbol (e.g., "BONK")
        token_address: The token mint address
        amount_sol: Amount of SOL to swap
        
    Returns:
        Dictionary with trade result details
    """
    try:
        logger.info(f"🚨 EXECUTING REAL MONEY TRADE: {amount_sol} SOL → {token_name} 🚨")
        
        # Execute the swap
        result = await swap_sol_to_token(token_address, amount_sol)
        
        if "error" in result:
            logger.error(f"Trade failed: {result['error']}")
            return None
            
        # Record successful trade
        trade_info = {
            "type": "buy",
            "token": token_name,
            "token_address": token_address,
            "amount_sol": amount_sol,
            "signature": result["signature"],
            "url": result["url"],
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        # Add to trade history and current holdings
        TRADE_HISTORY.append(trade_info)
        CURRENT_HOLDINGS[token_name] = {
            "token_address": token_address,
            "bought_amount_sol": amount_sol,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        # Save trade history to file
        with open('jupiter_real_trades_history.json', 'w') as f:
            json.dump(TRADE_HISTORY, f, indent=2)
            
        logger.info(f"✅ REAL TRADE COMPLETED: {amount_sol} SOL → {token_name}")
        logger.info(f"Transaction URL: {result['url']}")
        
        return {
            "success": True,
            "token": token_name,
            "amount_sol": amount_sol,
            "signature": result["signature"],
            "url": result["url"]
        }
        
    except Exception as e:
        logger.error(f"Error executing real trade: {str(e)}")
        logger.error(traceback.format_exc())
        return None

async def sell_token_for_profit(token_name, token_address, expected_profit_percent=20):
    """
    Sell a token back to SOL for profit.
    
    Args:
        token_name: The token symbol (e.g., "BONK")
        token_address: The token mint address
        expected_profit_percent: Expected profit percentage (used for logging)
        
    Returns:
        Dictionary with trade result details
    """
    try:
        if token_name not in CURRENT_HOLDINGS:
            logger.warning(f"No holdings found for {token_name}")
            return None
            
        # This is simplified - in a real implementation we would:
        # 1. Get the token balance 
        # 2. Estimate the current value in SOL
        # 3. Calculate actual profit
        
        logger.info(f"🚨 SELLING {token_name} FOR PROFIT ({expected_profit_percent}% expected) 🚨")
        
        # For now, we'll just log this - implementation would need token balance
        logger.info(f"Selling {token_name} tokens back to SOL")
        logger.info(f"Original buy: {CURRENT_HOLDINGS[token_name]['bought_amount_sol']} SOL")
        
        # This would be replaced with actual token amount once we integrate token balance checking
        # token_amount = actual_token_balance
        
        # For now just log that we would sell
        logger.info(f"Would execute: swap_token_to_sol({token_address}, token_amount)")
        
        # Remove from current holdings
        holding_info = CURRENT_HOLDINGS.pop(token_name, None)
        
        # Record the trade
        sell_info = {
            "type": "sell",
            "token": token_name,
            "token_address": token_address,
            "expected_profit_percent": expected_profit_percent,
            "original_buy_amount_sol": holding_info["bought_amount_sol"] if holding_info else 0,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        TRADE_HISTORY.append(sell_info)
        
        # Save trade history
        with open('jupiter_real_trades_history.json', 'w') as f:
            json.dump(TRADE_HISTORY, f, indent=2)
            
        logger.info(f"✅ SELL TRADE RECORDED FOR {token_name}")
        
        return {
            "success": True,
            "token": token_name,
            "expected_profit_percent": expected_profit_percent
        }
        
    except Exception as e:
        logger.error(f"Error selling token: {str(e)}")
        logger.error(traceback.format_exc())
        return None

async def test_real_trade():
    """
    Test a small real trade to verify functionality.
    Uses a minimal amount of SOL to test the system.
    """
    try:
        # Very small test amount (0.005 SOL ≈ $0.50)
        test_amount = 0.005
        
        # Use BONK as test token (popular, liquid)
        token_name = "BONK"
        token_address = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
        
        logger.info(f"Running test trade with {test_amount} SOL → {token_name}")
        
        # Execute the test trade
        result = await execute_real_trade(token_name, token_address, test_amount)
        
        if result and result["success"]:
            logger.info(f"✅ TEST TRADE SUCCESSFUL! Transaction: {result['url']}")
            return True
        else:
            logger.error("❌ TEST TRADE FAILED!")
            return False
            
    except Exception as e:
        logger.error(f"Error in test trade: {str(e)}")
        logger.error(traceback.format_exc())
        return False

# Run a test if executed directly
if __name__ == "__main__":
    asyncio.run(test_real_trade())