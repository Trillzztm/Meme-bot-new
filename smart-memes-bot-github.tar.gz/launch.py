"""
SMART MEMES BOT - Launch Script

This script launches the entire SMART MEMES BOT system, including:
1. The Telegram bot for user interaction
2. The Flask web dashboard for monitoring and control
"""

import os
import sys
import time
import logging
import threading
import subprocess
import signal

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - Launch - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("launch.log"),
    ],
)
logger = logging.getLogger("Launch")

def start_telegram_bot():
    """Start the Telegram bot in a separate process"""
    try:
        logger.info("Starting Telegram bot...")
        bot_process = subprocess.Popen(
            [sys.executable, "direct_bot.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        logger.info(f"Telegram bot started with PID {bot_process.pid}")
        return bot_process
    except Exception as e:
        logger.error(f"Error starting Telegram bot: {e}")
        return None

def start_web_dashboard():
    """Start the web dashboard in a separate process"""
    try:
        logger.info("Starting web dashboard...")
        dashboard_process = subprocess.Popen(
            ["gunicorn", "--bind", "0.0.0.0:5000", "--reuse-port", "--reload", "main:app"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        logger.info(f"Web dashboard started with PID {dashboard_process.pid}")
        return dashboard_process
    except Exception as e:
        logger.error(f"Error starting web dashboard: {e}")
        return None

def monitor_process(process, name, restart_func):
    """Monitor a process and restart it if it fails"""
    while True:
        if process.poll() is not None:
            logger.warning(f"{name} process died with return code {process.returncode}, restarting...")
            process = restart_func()
        time.sleep(5)

def handle_exit(bot_process, dashboard_process):
    """Handle clean exit by stopping all processes"""
    logger.info("Stopping all processes...")
    
    # Stop the bot process
    if bot_process and bot_process.poll() is None:
        logger.info(f"Stopping Telegram bot (PID {bot_process.pid})...")
        bot_process.terminate()
        try:
            bot_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Telegram bot did not terminate gracefully, killing...")
            bot_process.kill()
    
    # Stop the dashboard process
    if dashboard_process and dashboard_process.poll() is None:
        logger.info(f"Stopping web dashboard (PID {dashboard_process.pid})...")
        dashboard_process.terminate()
        try:
            dashboard_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Web dashboard did not terminate gracefully, killing...")
            dashboard_process.kill()
    
    logger.info("All processes stopped.")

def main():
    """Main function to start everything"""
    logger.info("=== STARTING SMART MEMES BOT SYSTEM ===")
    
    # Start the Telegram bot
    bot_process = start_telegram_bot()
    
    # Start the web dashboard
    dashboard_process = start_web_dashboard()
    
    # Set up signal handlers for clean exit
    def signal_handler(sig, frame):
        logger.info(f"Received signal {sig}, shutting down...")
        handle_exit(bot_process, dashboard_process)
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Set up monitors for each process in separate threads
    if bot_process:
        bot_monitor = threading.Thread(
            target=monitor_process,
            args=(bot_process, "Telegram bot", start_telegram_bot),
            daemon=True,
        )
        bot_monitor.start()
    
    if dashboard_process:
        dashboard_monitor = threading.Thread(
            target=monitor_process,
            args=(dashboard_process, "Web dashboard", start_web_dashboard),
            daemon=True,
        )
        dashboard_monitor.start()
    
    # Print success message
    logger.info("""
    ====================================================
    🚀 SMART MEMES BOT SYSTEM LAUNCHED SUCCESSFULLY 🚀
    
    Telegram Bot: Running ✅
    Web Dashboard: http://0.0.0.0:5000 ✅
    
    Use the web dashboard to monitor profits and trades.
    Send /start to the Telegram bot to start interacting.
    ====================================================
    """)
    
    # Keep the main thread running to allow signal handlers to work
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down...")
        handle_exit(bot_process, dashboard_process)

if __name__ == "__main__":
    main()