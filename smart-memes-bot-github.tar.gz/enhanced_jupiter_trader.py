"""
Enhanced Jupiter Trader for SMART MEMES BOT - REAL MONEY EDITION

This script executes real trades through Jupiter Exchange, 
directly connecting to the blockchain and using the wallet's private key.

⚠️ WARNING: THIS IS A REAL MONEY TRADING SYSTEM ⚠️
All trades will use actual funds from your connected wallet.
"""

import os
import time
import logging
import requests
import json
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("EnhancedJupiterTrader")

# Import our modules
import phantom_direct_connector
from api_rate_limiter import wait_for_rate_limit, record_api_call

def execute_real_trade(token_symbol, amount_sol=0.01, slippage_bps=50):
    """
    Execute a real SOL to token trade using Jupiter Exchange
    
    Args:
        token_symbol: Symbol of token to buy (e.g., "BONK", "WIF")
        amount_sol: Amount of SOL to swap
        slippage_bps: Slippage tolerance in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Trade result
    """
    # Convert SOL to lamports
    amount_lamports = int(amount_sol * 10**9)
    
    # Get wallet address
    wallet_address = phantom_direct_connector.get_wallet_address()
    if not wallet_address:
        return {"success": False, "error": "Could not get wallet address"}
    
    # SOL mint address is fixed
    input_mint = "So11111111111111111111111111111111111111112"
    
    # Get the token mint address
    try:
        # Try to import token addresses
        from token_mint_addresses import get_token_mint_address
        output_mint = get_token_mint_address(token_symbol)
    except:
        # Fallback to common tokens
        if token_symbol == "BONK":
            output_mint = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
        elif token_symbol == "WIF":
            output_mint = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
        elif token_symbol == "JTO":
            output_mint = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"
        elif token_symbol == "PYTH":
            output_mint = "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3"
        else:
            output_mint = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"  # Default to BONK
    
    logger.info(f"🚀 REAL TRADE: {amount_sol} SOL to {token_symbol} (mint: {output_mint})")
    
    # Step 1: Get a quote from Jupiter API with advanced rate limiting
    from api_rate_limiter import retry_with_backoff
    
    # Define function to get Jupiter quote with retries
    def get_jupiter_quote(params):
        quote_url = "https://quote-api.jup.ag/v6/quote"
        logger.info(f"Getting Jupiter quote with params: {params}")
        response = requests.get(quote_url, params=params)
        return response
    
    # Parameters for the quote request
    quote_params = {
        "inputMint": input_mint,
        "outputMint": output_mint,
        "amount": amount_lamports,
        "slippageBps": slippage_bps
    }
    
    try:
        # Use retry_with_backoff to get quote with exponential backoff
        quote_response = retry_with_backoff("jupiter", get_jupiter_quote, quote_params)
        
        if quote_response.status_code != 200:
            logger.error(f"Quote API error: {quote_response.text}")
            return {"success": False, "error": f"Quote API error: {quote_response.text}"}
        
        quote_data = quote_response.json()
        logger.info(f"Received Jupiter quote. Output amount: {quote_data.get('outAmount')}")
        
        # Step 2: Get swap transaction with advanced rate limiting
        # Define function to get Jupiter swap with retries
        def get_jupiter_swap(payload):
            swap_url = "https://quote-api.jup.ag/v6/swap"
            logger.info("Getting swap transaction data")
            response = requests.post(swap_url, json=payload)
            return response
        
        # Prepare swap payload
        swap_payload = {
            "quoteResponse": quote_data,
            "userPublicKey": wallet_address,
            "wrapAndUnwrapSol": True,
            "prioritizationFeeLamports": 10000,  # 10,000 lamports priority fee
        }
        
        # Use retry_with_backoff for the swap request
        swap_url = "https://quote-api.jup.ag/v6/swap"  # Define swap_url here
        swap_response = retry_with_backoff("jupiter", get_jupiter_swap, swap_payload)
        
        if swap_response.status_code != 200:
            logger.error(f"Swap API error: {swap_response.text}")
            return {"success": False, "error": f"Swap API error: {swap_response.text}"}
        
        swap_data = swap_response.json()
        
        # Step 3: Submit the transaction
        tx_data = swap_data.get("swapTransaction")
        if not tx_data:
            logger.error("No transaction data in response")
            return {"success": False, "error": "No transaction data in response"}
        
        logger.info("Submitting transaction to blockchain...")
        result = phantom_direct_connector.submit_transaction(tx_data)
        
        if result.get("success"):
            tx_hash = result.get("signature")
            logger.info(f"✅ REAL TRANSACTION EXECUTED with signature: {tx_hash}")
            
            # Record the transaction
            with open("real_transactions.json", "a") as f:
                transaction_record = {
                    "timestamp": datetime.now().isoformat(),
                    "input_token": "SOL",
                    "output_token": token_symbol,
                    "input_amount_sol": amount_sol,
                    "input_amount_lamports": amount_lamports,
                    "expected_output_amount": quote_data.get("outAmount"),
                    "tx_hash": tx_hash,
                    "success": True
                }
                f.write(json.dumps(transaction_record) + "\n")
            
            return {
                "success": True,
                "tx_hash": tx_hash,
                "input_token": "SOL",
                "output_token": token_symbol,
                "input_amount_sol": amount_sol,
                "expected_output_amount": quote_data.get("outAmount")
            }
        else:
            logger.error(f"Transaction submission failed: {result.get('error')}")
            return {"success": False, "error": f"Transaction submission failed: {result.get('error')}"}
    
    except Exception as e:
        logger.error(f"Error executing trade: {str(e)}")
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    # Example usage - uncomment to test
    # result = execute_real_trade("BONK", amount_sol=0.01)
    # print(f"Trade result: {result}")
    
    # To run directly:
    # python enhanced_jupiter_trader.py
    
    # Execute a trade from command-line arguments
    import sys
    if len(sys.argv) >= 3:
        token = sys.argv[1]
        amount = float(sys.argv[2])
        result = execute_real_trade(token, amount_sol=amount)
        print(f"Trade result: {result}")
    else:
        print("Usage: python enhanced_jupiter_trader.py <TOKEN_SYMBOL> <AMOUNT_SOL>")
        print("Example: python enhanced_jupiter_trader.py BONK 0.01")
