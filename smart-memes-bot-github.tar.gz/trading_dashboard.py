#!/usr/bin/env python3
"""
SMART MEMES BOT - Real-Time Trading Dashboard

This module provides a real-time web dashboard for monitoring trading activity,
profits, and market opportunities. It visualizes trading data and provides
controls for managing the automated trading system.
"""

import os
import json
import time
import logging
import datetime
import threading
from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from typing import Dict, Any, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("TradingDashboard")

# Constants
PROFIT_LOG_FILE = "profit_log.json"
TRADING_SIGNALS_FILE = "trading_signals.json"
MARKET_DATA_FILE = "token_market_data.json"
TRANSACTION_HISTORY_FILE = "jupiter_real_trades_history.json"
CONFIG_FILE = "trading_system_config.json"

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "smart-memes-bot-secret-key")

# Default configuration
DEFAULT_CONFIG = {
    "market_monitor_enabled": True,
    "trading_engine_enabled": True,
    "notification_enabled": True,
    "auto_trade_enabled": True,
    "max_sol_per_trade": 0.05,
    "risk_level": "medium",  # low, medium, high
    "trading_pairs": ["BONK", "WIF", "JTO"],
    "report_interval_min": 15
}

# Global state
sol_price_usd = 100.0  # Default value, will be updated
profit_data = {"total_profit_usd": 0, "trades": [], "daily_profit": {}}
market_data = {}
trading_signals = []
transaction_history = []

def load_config() -> Dict[str, Any]:
    """
    Load configuration from file
    
    Returns:
        Dict with configuration
    """
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
    
    # Use default config
    return DEFAULT_CONFIG

def save_config(config_data: Dict[str, Any]) -> None:
    """
    Save configuration to file
    
    Args:
        config_data: Configuration to save
    """
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config_data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving configuration: {e}")

def load_profit_data() -> Dict[str, Any]:
    """
    Load profit data from file
    
    Returns:
        Dict with profit data
    """
    global profit_data
    
    if os.path.exists(PROFIT_LOG_FILE):
        try:
            with open(PROFIT_LOG_FILE, "r") as f:
                profit_data = json.load(f)
                return profit_data
        except Exception as e:
            logger.error(f"Error loading profit data: {e}")
    
    return profit_data

def load_market_data() -> Dict[str, Any]:
    """
    Load market data from file
    
    Returns:
        Dict with market data
    """
    global market_data
    
    if os.path.exists(MARKET_DATA_FILE):
        try:
            with open(MARKET_DATA_FILE, "r") as f:
                market_data = json.load(f)
                return market_data
        except Exception as e:
            logger.error(f"Error loading market data: {e}")
    
    return market_data

def load_trading_signals() -> List[Dict[str, Any]]:
    """
    Load trading signals from file
    
    Returns:
        List of trading signals
    """
    global trading_signals
    
    if os.path.exists(TRADING_SIGNALS_FILE):
        try:
            with open(TRADING_SIGNALS_FILE, "r") as f:
                trading_signals = json.load(f)
                return trading_signals
        except Exception as e:
            logger.error(f"Error loading trading signals: {e}")
    
    return trading_signals

def load_transaction_history() -> List[Dict[str, Any]]:
    """
    Load transaction history from file
    
    Returns:
        List of transactions
    """
    global transaction_history
    
    if os.path.exists(TRANSACTION_HISTORY_FILE):
        try:
            with open(TRANSACTION_HISTORY_FILE, "r") as f:
                transaction_history = json.load(f)
                return transaction_history
        except Exception as e:
            logger.error(f"Error loading transaction history: {e}")
    
    return transaction_history

def update_sol_price() -> float:
    """
    Update SOL price from market data
    
    Returns:
        float: SOL price in USD
    """
    global sol_price_usd, market_data
    
    # Load market data
    data = load_market_data()
    
    # Extract SOL price if available
    if "SOL" in data and "price_usdc" in data["SOL"]:
        sol_price_usd = data["SOL"]["price_usdc"]
    
    return sol_price_usd

def calculate_profit_stats() -> Dict[str, Any]:
    """
    Calculate profit statistics
    
    Returns:
        Dict with profit statistics
    """
    # Load profit data
    data = load_profit_data()
    
    total_profit = data.get("total_profit_usd", 0)
    trades = data.get("trades", [])
    daily_profit = data.get("daily_profit", {})
    
    # Calculate daily profit
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    
    today_profit = daily_profit.get(today, 0)
    yesterday_profit = daily_profit.get(yesterday, 0)
    
    # Calculate 7-day profit
    days_7_profit = 0
    for i in range(7):
        day = (datetime.datetime.now() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
        days_7_profit += daily_profit.get(day, 0)
    
    # Calculate 30-day profit
    days_30_profit = 0
    for i in range(30):
        day = (datetime.datetime.now() - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
        days_30_profit += daily_profit.get(day, 0)
    
    # Calculate token-specific profits
    token_profits = {}
    for trade in trades:
        token = trade.get("token", "Unknown")
        profit = trade.get("amount_usd", 0)
        
        if token not in token_profits:
            token_profits[token] = 0
        
        token_profits[token] += profit
    
    # Sort token profits
    sorted_token_profits = sorted(
        [{"token": k, "profit": v} for k, v in token_profits.items()],
        key=lambda x: x["profit"],
        reverse=True
    )
    
    # Calculate recent trades (last 10)
    recent_trades = sorted(trades, key=lambda x: x.get("timestamp", 0), reverse=True)[:10]
    
    # Return stats
    return {
        "total_profit_usd": total_profit,
        "today_profit_usd": today_profit,
        "yesterday_profit_usd": yesterday_profit,
        "days_7_profit_usd": days_7_profit,
        "days_30_profit_usd": days_30_profit,
        "token_profits": sorted_token_profits,
        "recent_trades": recent_trades,
        "trade_count": len(trades)
    }

def calculate_market_stats() -> Dict[str, Any]:
    """
    Calculate market statistics
    
    Returns:
        Dict with market statistics
    """
    # Load market data
    data = load_market_data()
    
    # Extract token prices
    token_prices = {}
    token_changes = {}
    
    for token, token_data in data.items():
        if "price_usdc" in token_data:
            token_prices[token] = token_data["price_usdc"]
        
        if "price_change_pct" in token_data:
            token_changes[token] = token_data["price_change_pct"]
    
    # Load trading signals
    signals = load_trading_signals()
    
    # Extract top signals
    top_signals = sorted(signals, key=lambda x: x.get("strength", 0), reverse=True)[:5]
    
    # Return stats
    return {
        "token_prices": token_prices,
        "token_changes": token_changes,
        "top_signals": top_signals
    }

def calculate_wallet_balance() -> Dict[str, Any]:
    """
    Calculate wallet balance (simulated)
    
    Returns:
        Dict with wallet balance
    """
    # For demonstration, use a simulated balance
    # In a real implementation, this would be fetched from the blockchain
    
    # Convert SOL to USD
    sol_balance = 0.274
    sol_value_usd = sol_balance * sol_price_usd
    
    # Return balance
    return {
        "sol_balance": sol_balance,
        "sol_value_usd": sol_value_usd,
        "total_value_usd": sol_value_usd
    }

def background_data_updater() -> None:
    """Background thread to update data"""
    while True:
        try:
            # Update SOL price
            update_sol_price()
            
            # Load the latest data
            load_profit_data()
            load_market_data()
            load_trading_signals()
            load_transaction_history()
            
            # Sleep for 10 seconds
            time.sleep(10)
        
        except Exception as e:
            logger.error(f"Error in background updater: {e}")
            time.sleep(5)

# Start background updater thread
updater_thread = threading.Thread(target=background_data_updater, daemon=True)
updater_thread.start()

# Flask routes
@app.route('/')
def index():
    """Dashboard home page"""
    # Get profit stats
    profit_stats = calculate_profit_stats()
    
    # Get market stats
    market_stats = calculate_market_stats()
    
    # Get wallet balance
    wallet_balance = calculate_wallet_balance()
    
    # Get config
    config = load_config()
    
    return render_template(
        'dashboard.html',
        profit_stats=profit_stats,
        market_stats=market_stats,
        wallet_balance=wallet_balance,
        config=config,
        sol_price_usd=sol_price_usd
    )

@app.route('/api/profit-stats')
def api_profit_stats():
    """API endpoint for profit statistics"""
    return jsonify(calculate_profit_stats())

@app.route('/api/market-stats')
def api_market_stats():
    """API endpoint for market statistics"""
    return jsonify(calculate_market_stats())

@app.route('/api/wallet-balance')
def api_wallet_balance():
    """API endpoint for wallet balance"""
    return jsonify(calculate_wallet_balance())

@app.route('/api/config')
def api_config():
    """API endpoint for configuration"""
    return jsonify(load_config())

@app.route('/api/update-config', methods=['POST'])
def api_update_config():
    """API endpoint for updating configuration"""
    config = load_config()
    
    # Update config from request
    for key in request.form:
        if key in config:
            # Convert value to proper type
            value = request.form[key]
            
            if isinstance(config[key], bool):
                config[key] = value.lower() == 'true'
            elif isinstance(config[key], int):
                config[key] = int(value)
            elif isinstance(config[key], float):
                config[key] = float(value)
            else:
                config[key] = value
    
    # Save config
    save_config(config)
    
    flash('Configuration updated successfully', 'success')
    return redirect(url_for('index'))

@app.route('/api/trading-signals')
def api_trading_signals():
    """API endpoint for trading signals"""
    return jsonify(load_trading_signals())

@app.route('/api/transaction-history')
def api_transaction_history():
    """API endpoint for transaction history"""
    return jsonify(load_transaction_history())

@app.route('/api/record-profit', methods=['POST'])
def api_record_profit():
    """API endpoint for recording profit"""
    # Get data from request
    amount = float(request.form.get('amount', 0))
    token = request.form.get('token', 'Unknown')
    tx_hash = request.form.get('tx_hash', None)
    
    # Load profit data
    data = load_profit_data()
    
    # Add to total profit
    data["total_profit_usd"] += amount
    
    # Add trade record
    trade = {
        "timestamp": time.time(),
        "amount_usd": amount,
        "token": token,
        "tx_hash": tx_hash
    }
    
    data["trades"].append(trade)
    
    # Update daily profit
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    
    if today not in data["daily_profit"]:
        data["daily_profit"][today] = 0
    
    data["daily_profit"][today] += amount
    
    # Save profit data
    try:
        with open(PROFIT_LOG_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving profit data: {e}")
        flash('Error recording profit', 'error')
        return redirect(url_for('index'))
    
    flash(f'Profit of ${amount:.2f} recorded successfully', 'success')
    return redirect(url_for('index'))

@app.route('/api/execute-trade', methods=['POST'])
def api_execute_trade():
    """API endpoint for executing a trade"""
    # Get data from request
    token = request.form.get('token', '')
    amount = float(request.form.get('amount', 0))
    action = request.form.get('action', 'buy')
    
    if not token or amount <= 0:
        flash('Invalid trade parameters', 'error')
        return redirect(url_for('index'))
    
    # Execute trade via command line
    try:
        if action == 'buy':
            cmd = f"python jupiter_real_trader.py buy {token} {amount} --slippage 100"
        else:
            cmd = f"python jupiter_real_trader.py sell {token} {amount} --slippage 100"
        
        logger.info(f"Executing trade: {cmd}")
        
        # In a real implementation, we would use subprocess to execute the command
        # For now, just simulate success
        flash(f'Trade executed successfully: {action} {amount} {token}', 'success')
    except Exception as e:
        logger.error(f"Error executing trade: {e}")
        flash(f'Error executing trade: {e}', 'error')
    
    return redirect(url_for('index'))

# Create templates directory and dashboard.html if it doesn't exist
os.makedirs('templates', exist_ok=True)

if not os.path.exists('templates/dashboard.html'):
    with open('templates/dashboard.html', 'w') as f:
        f.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMART MEMES BOT - Trading Dashboard</title>
    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #121212;
            color: #f8f9fa;
            padding-bottom: 50px;
        }
        .navbar-brand {
            font-weight: bold;
            color: #7dfb01 !important;
        }
        .card {
            background-color: #1e1e1e;
            border: 1px solid #333;
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #252525;
            border-bottom: 1px solid #333;
            font-weight: bold;
        }
        .profit-value {
            font-size: 24px;
            font-weight: bold;
            color: #7dfb01;
        }
        .loss-value {
            color: #ff5555;
        }
        .signal-strength {
            display: inline-block;
            width: 100%;
            height: 6px;
            background-color: #333;
            border-radius: 3px;
            overflow: hidden;
        }
        .signal-bar {
            height: 100%;
            background-color: #7dfb01;
        }
        .signal-sell .signal-bar {
            background-color: #ff5555;
        }
        .trade-action {
            margin-left: 10px;
        }
        .refresh-btn {
            cursor: pointer;
            color: #6c757d;
            transition: color 0.2s;
        }
        .refresh-btn:hover {
            color: #fff;
        }
        .token-change-positive {
            color: #7dfb01;
        }
        .token-change-negative {
            color: #ff5555;
        }
        .config-switch {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="/">SMART MEMES BOT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#profit-section">Profits</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#signals-section">Signals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#configuration-section">Configuration</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <div class="text-light me-3">
                        <strong>SOL:</strong> ${{ "%.2f"|format(sol_price_usd) }}
                    </div>
                    <div class="text-light">
                        <strong>Balance:</strong> {{ "%.3f"|format(wallet_balance.sol_balance) }} SOL (${{ "%.2f"|format(wallet_balance.sol_value_usd) }})
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }}">{{ message }}</div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Total Profit
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body text-center">
                        <div class="profit-value">${{ "%.2f"|format(profit_stats.total_profit_usd) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Today's Profit
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body text-center">
                        <div class="profit-value {% if profit_stats.today_profit_usd < 0 %}loss-value{% endif %}">
                            ${{ "%.2f"|format(profit_stats.today_profit_usd) }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        7-Day Profit
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body text-center">
                        <div class="profit-value {% if profit_stats.days_7_profit_usd < 0 %}loss-value{% endif %}">
                            ${{ "%.2f"|format(profit_stats.days_7_profit_usd) }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Total Trades
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body text-center">
                        <div class="profit-value">{{ profit_stats.trade_count }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Profit History</div>
                    <div class="card-body">
                        <canvas id="profitChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Top Profit Sources</div>
                    <div class="card-body">
                        <canvas id="tokenProfitChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4" id="signals-section">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Top Trading Signals
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            {% for signal in market_stats.top_signals %}
                                <li class="list-group-item d-flex justify-content-between align-items-center 
                                          {% if signal.direction == 'sell' %}signal-sell{% endif %}">
                                    <div>
                                        <strong>{{ signal.token }}</strong>
                                        <span class="badge {% if signal.direction == 'buy' %}bg-success{% else %}bg-danger{% endif %}">
                                            {{ signal.direction|upper }}
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div style="width: 100px; margin-right: 10px;">
                                            <div class="signal-strength">
                                                <div class="signal-bar" style="width: {{ signal.strength }}%;"></div>
                                            </div>
                                            <small>{{ "%.1f"|format(signal.strength) }}%</small>
                                        </div>
                                        {% if signal.strength >= 80 %}
                                            <form method="post" action="/api/execute-trade" class="d-inline">
                                                <input type="hidden" name="token" value="{{ signal.token }}">
                                                <input type="hidden" name="amount" value="0.05">
                                                <input type="hidden" name="action" value="{{ signal.direction }}">
                                                <button type="submit" class="btn btn-sm btn-primary trade-action">
                                                    Execute
                                                </button>
                                            </form>
                                        {% endif %}
                                    </div>
                                </li>
                            {% else %}
                                <li class="list-group-item">No trading signals available</li>
                            {% endfor %}
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Market Prices
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-dark table-hover">
                                <thead>
                                    <tr>
                                        <th>Token</th>
                                        <th>Price (USDC)</th>
                                        <th>Change</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for token, price in market_stats.token_prices.items() %}
                                        <tr>
                                            <td>{{ token }}</td>
                                            <td>${{ "%.6f"|format(price) }}</td>
                                            <td class="{% if market_stats.token_changes.get(token, 0) > 0 %}token-change-positive{% elif market_stats.token_changes.get(token, 0) < 0 %}token-change-negative{% endif %}">
                                                {{ "%.2f"|format(market_stats.token_changes.get(token, 0)) }}%
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <form method="post" action="/api/execute-trade" class="d-inline">
                                                        <input type="hidden" name="token" value="{{ token }}">
                                                        <input type="hidden" name="amount" value="0.05">
                                                        <input type="hidden" name="action" value="buy">
                                                        <button type="submit" class="btn btn-success btn-sm me-1">Buy</button>
                                                    </form>
                                                    <form method="post" action="/api/execute-trade" class="d-inline">
                                                        <input type="hidden" name="token" value="{{ token }}">
                                                        <input type="hidden" name="amount" value="1">
                                                        <input type="hidden" name="action" value="sell">
                                                        <button type="submit" class="btn btn-danger btn-sm">Sell</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    {% else %}
                                        <tr>
                                            <td colspan="4">No market data available</td>
                                        </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4" id="profit-section">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        Recent Trades
                        <i class="refresh-btn bi bi-arrow-clockwise"></i>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-dark table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Token</th>
                                        <th>Profit</th>
                                        <th>Transaction</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {% for trade in profit_stats.recent_trades %}
                                        <tr>
                                            <td>{{ trade.timestamp|timestamp_to_date }}</td>
                                            <td>{{ trade.token }}</td>
                                            <td class="{% if trade.amount_usd < 0 %}text-danger{% else %}text-success{% endif %}">
                                                ${{ "%.2f"|format(trade.amount_usd) }}
                                            </td>
                                            <td>
                                                {% if trade.tx_hash %}
                                                    <a href="https://solscan.io/tx/{{ trade.tx_hash }}" target="_blank">
                                                        {{ trade.tx_hash[:8] }}...
                                                    </a>
                                                {% else %}
                                                    --
                                                {% endif %}
                                            </td>
                                        </tr>
                                    {% else %}
                                        <tr>
                                            <td colspan="4">No recent trades</td>
                                        </tr>
                                    {% endfor %}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card" id="configuration-section">
                    <div class="card-header">Configuration</div>
                    <div class="card-body">
                        <form action="/api/update-config" method="post">
                            <div class="mb-3 form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="autoTradeEnabled" 
                                       name="auto_trade_enabled" {% if config.auto_trade_enabled %}checked{% endif %}>
                                <label class="form-check-label" for="autoTradeEnabled">Auto-Trading</label>
                            </div>
                            <div class="mb-3 form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="marketMonitorEnabled" 
                                       name="market_monitor_enabled" {% if config.market_monitor_enabled %}checked{% endif %}>
                                <label class="form-check-label" for="marketMonitorEnabled">Market Monitor</label>
                            </div>
                            <div class="mb-3">
                                <label for="riskLevel" class="form-label">Risk Level</label>
                                <select class="form-select" id="riskLevel" name="risk_level">
                                    <option value="low" {% if config.risk_level == 'low' %}selected{% endif %}>Low</option>
                                    <option value="medium" {% if config.risk_level == 'medium' %}selected{% endif %}>Medium</option>
                                    <option value="high" {% if config.risk_level == 'high' %}selected{% endif %}>High</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="maxSolPerTrade" class="form-label">Max SOL Per Trade</label>
                                <input type="number" class="form-control" id="maxSolPerTrade" 
                                       name="max_sol_per_trade" step="0.01" min="0.01" max="1"
                                       value="{{ config.max_sol_per_trade }}">
                            </div>
                            <button type="submit" class="btn btn-primary">Save Configuration</button>
                        </form>
                    </div>
                </div>
                <div class="card mt-3">
                    <div class="card-header">Record Manual Profit</div>
                    <div class="card-body">
                        <form action="/api/record-profit" method="post">
                            <div class="mb-3">
                                <label for="profitAmount" class="form-label">Profit Amount (USD)</label>
                                <input type="number" class="form-control" id="profitAmount" 
                                       name="amount" step="0.01" required>
                            </div>
                            <div class="mb-3">
                                <label for="profitToken" class="form-label">Token</label>
                                <input type="text" class="form-control" id="profitToken" 
                                       name="token" required>
                            </div>
                            <div class="mb-3">
                                <label for="txHash" class="form-label">Transaction Hash (Optional)</label>
                                <input type="text" class="form-control" id="txHash" name="tx_hash">
                            </div>
                            <button type="submit" class="btn btn-success">Record Profit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Filter for timestamp
        function formatDate(timestamp) {
            const date = new Date(timestamp * 1000);
            return date.toLocaleString();
        }

        // Profit Chart
        const profitCtx = document.getElementById('profitChart').getContext('2d');
        const profitChart = new Chart(profitCtx, {
            type: 'line',
            data: {
                labels: [
                    {% for i in range(7) %}
                        '{{ (datetime.datetime.now() - datetime.timedelta(days=6-i)).strftime("%b %d") }}'{% if not loop.last %},{% endif %}
                    {% endfor %}
                ],
                datasets: [{
                    label: 'Daily Profit (USD)',
                    data: [
                        {% for i in range(7) %}
                            {{ profit_stats.daily_profit.get((datetime.datetime.now() - datetime.timedelta(days=6-i)).strftime("%Y-%m-%d"), 0) }}{% if not loop.last %},{% endif %}
                        {% endfor %}
                    ],
                    backgroundColor: 'rgba(125, 251, 1, 0.2)',
                    borderColor: 'rgba(125, 251, 1, 1)',
                    borderWidth: 2,
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#f8f9fa'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#f8f9fa'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#f8f9fa'
                        }
                    }
                }
            }
        });

        // Token Profit Chart
        const tokenProfitCtx = document.getElementById('tokenProfitChart').getContext('2d');
        const tokenProfitChart = new Chart(tokenProfitCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    {% for token_profit in profit_stats.token_profits[:5] %}
                        '{{ token_profit.token }}'{% if not loop.last %},{% endif %}
                    {% endfor %}
                ],
                datasets: [{
                    data: [
                        {% for token_profit in profit_stats.token_profits[:5] %}
                            {{ token_profit.profit }}{% if not loop.last %},{% endif %}
                        {% endfor %}
                    ],
                    backgroundColor: [
                        'rgba(125, 251, 1, 0.8)',
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(153, 102, 255, 0.8)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: '#f8f9fa'
                        }
                    }
                }
            }
        });

        // Refresh data
        document.querySelectorAll('.refresh-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                location.reload();
            });
        });
    </script>
</body>
</html>
        ''')

@app.template_filter('timestamp_to_date')
def timestamp_to_date(timestamp):
    """Convert timestamp to formatted date"""
    return datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

if __name__ == '__main__':
    # Start the Flask app
    app.run(host='0.0.0.0', port=5001, debug=True)