"""
Real Trading System for SMART MEMES BOT

This script integrates all the real trading components:
1. Jupiter API Integration
2. Solana Transaction Signing
3. Secure Wallet Management

This is a REAL MONEY system that executes actual trades with your crypto.
"""

import os
import time
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, Any, List, Optional, Union

# Import our real trading modules
from jupiter_api_integration import (
    execute_swap, 
    buy_token_with_sol, 
    sell_token_for_sol, 
    get_quote,
    get_sol_balance,
    check_valid_private_key,
    get_wallet_address
)
from solana_transaction_signer import (
    TransactionSigner,
    transfer_sol,
    test_transaction_signer
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("real_trading_system.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("RealTradingSystem")

# Common token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
JTO_MINT = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"
PYTH_MINT = "CsKLfUw8rT4QZ2jjQY58RWcyF3fuRuD2rQYJxQRcJ5Sw"
RNDR_MINT = "rndrizKT3MK1iimdxRdWabcF7Zg7AR5T4nud4EkHBof"

# Mapping of symbols to addresses
TOKEN_ADDRESSES = {
    "SOL": SOL_MINT,
    "USDC": USDC_MINT,
    "BONK": BONK_MINT,
    "WIF": WIF_MINT,
    "JTO": JTO_MINT,
    "PYTH": PYTH_MINT,
    "RNDR": RNDR_MINT
}

def check_system_ready() -> Dict[str, Any]:
    """
    Check if the real trading system is ready
    
    Returns:
        Dict with system status
    """
    status = {
        "ready": False,
        "private_key_available": False,
        "wallet_connected": False,
        "has_sol_balance": False,
        "errors": []
    }
    
    # Check for private key
    status["private_key_available"] = check_valid_private_key()
    if not status["private_key_available"]:
        status["errors"].append("No valid private key found. Set SOLANA_PRIVATE_KEY environment variable.")
    
    # If private key available, test wallet connection
    if status["private_key_available"]:
        wallet_address = get_wallet_address()
        status["wallet_connected"] = wallet_address is not None
        status["wallet_address"] = wallet_address
        
        if not status["wallet_connected"]:
            status["errors"].append("Failed to connect to wallet with provided private key.")
        
        # If wallet connected, check SOL balance
        if status["wallet_connected"]:
            balance = get_sol_balance()
            if "error" not in balance:
                status["sol_balance"] = balance["balance_sol"]
                status["sol_balance_usd"] = balance["balance_usd"]
                status["has_sol_balance"] = balance["balance_sol"] > 0
                
                if not status["has_sol_balance"]:
                    status["errors"].append("Wallet has zero SOL balance. Please add funds.")
            else:
                status["errors"].append(f"Error getting SOL balance: {balance['error']}")
    
    # System is ready if we have private key, wallet connection, and SOL balance
    status["ready"] = (
        status["private_key_available"] and 
        status["wallet_connected"] and 
        status["has_sol_balance"]
    )
    
    return status

def get_token_info(symbol_or_address: str) -> Dict[str, Any]:
    """
    Get token information from symbol or address
    
    Args:
        symbol_or_address: Token symbol or address
        
    Returns:
        Dict with token information
    """
    # Check if it's a known symbol
    symbol_upper = symbol_or_address.upper()
    if symbol_upper in TOKEN_ADDRESSES:
        return {
            "symbol": symbol_upper,
            "address": TOKEN_ADDRESSES[symbol_upper]
        }
    
    # Otherwise, assume it's an address
    # Try to find the symbol for this address
    for symbol, address in TOKEN_ADDRESSES.items():
        if address.lower() == symbol_or_address.lower():
            return {
                "symbol": symbol,
                "address": address
            }
    
    # If we can't find a symbol, use the address as is
    return {
        "symbol": "UNKNOWN",
        "address": symbol_or_address
    }

def execute_real_trade(
    input_token: str,
    output_token: str,
    amount: float,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Execute a real trade between two tokens
    
    Args:
        input_token: Input token symbol or address
        output_token: Output token symbol or address
        amount: Amount in input token's native units (e.g., SOL, not lamports)
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        Dict with trade result
    """
    # Get token information
    input_token_info = get_token_info(input_token)
    output_token_info = get_token_info(output_token)
    
    logger.info(f"Executing real trade: {amount} {input_token_info['symbol']} -> {output_token_info['symbol']}")
    
    # Check if system is ready
    status = check_system_ready()
    if not status["ready"]:
        error_msg = f"System not ready for trading: {', '.join(status['errors'])}"
        logger.error(error_msg)
        return {"error": error_msg}
    
    # Check which trading function to use
    if input_token_info["symbol"] == "SOL":
        # Convert SOL to a token
        logger.info(f"Buying {output_token_info['symbol']} with {amount} SOL")
        
        return buy_token_with_sol(
            token_mint=output_token_info["address"],
            sol_amount=amount,
            slippage_bps=slippage_bps
        )
    elif output_token_info["symbol"] == "SOL":
        # Sell a token for SOL
        logger.info(f"Selling {amount} {input_token_info['symbol']} for SOL")
        
        # For tokens other than SOL, we need to handle decimals
        # This is a simplification, in real code we would look up the token's decimals
        decimals = 9  # Most SPL tokens use 9 decimals
        token_amount = int(amount * (10 ** decimals))
        
        return sell_token_for_sol(
            token_mint=input_token_info["address"],
            token_amount=token_amount,
            slippage_bps=slippage_bps
        )
    else:
        # General token-to-token swap
        logger.info(f"Swapping {amount} {input_token_info['symbol']} for {output_token_info['symbol']}")
        
        # For non-SOL tokens, we need to handle decimals
        # Again, this is a simplification
        decimals = 9  # Most SPL tokens use 9 decimals
        token_amount = int(amount * (10 ** decimals))
        
        return execute_swap(
            input_mint=input_token_info["address"],
            output_mint=output_token_info["address"],
            amount=token_amount,
            slippage_bps=slippage_bps
        )

def transfer_sol_to_address(
    to_address: str,
    amount_sol: float
) -> Dict[str, Any]:
    """
    Transfer SOL to another address
    
    Args:
        to_address: Recipient address
        amount_sol: Amount of SOL to transfer
        
    Returns:
        Dict with transfer result
    """
    # Check if system is ready
    status = check_system_ready()
    if not status["ready"]:
        error_msg = f"System not ready for transfers: {', '.join(status['errors'])}"
        logger.error(error_msg)
        return {"error": error_msg}
    
    # Check if we have enough SOL
    if status["sol_balance"] < amount_sol:
        error_msg = f"Insufficient SOL balance: have {status['sol_balance']} SOL, need {amount_sol} SOL"
        logger.error(error_msg)
        return {"error": error_msg}
    
    logger.info(f"Transferring {amount_sol} SOL to {to_address}")
    
    # Create a transaction signer
    signer = TransactionSigner()
    
    # Execute the transfer
    return transfer_sol(to_address, amount_sol, signer)

def get_trading_status() -> Dict[str, Any]:
    """
    Get current trading system status
    
    Returns:
        Dict with system status
    """
    status = check_system_ready()
    
    # Add more information about current token prices, etc.
    if status["ready"]:
        # Get quotes for common pairs to check prices
        prices = {}
        for token_symbol in ["BONK", "WIF", "JTO", "PYTH", "RNDR"]:
            try:
                # Try to get price in USDC
                if token_symbol in TOKEN_ADDRESSES:
                    quote = get_quote(
                        TOKEN_ADDRESSES[token_symbol],
                        USDC_MINT,
                        10**9  # 1 token in smallest units
                    )
                    
                    if "error" not in quote:
                        input_decimals = 9  # Most tokens
                        output_decimals = 6  # USDC is 6 decimals
                        
                        # Calculate price per token in USDC
                        price = int(quote["outputAmount"]) / (10**output_decimals) / (10**9 / 10**input_decimals)
                        prices[token_symbol] = price
            except Exception as e:
                logger.error(f"Error getting price for {token_symbol}: {e}")
        
        status["token_prices"] = prices
    
    return status

def main():
    """Main function for the real trading system"""
    parser = argparse.ArgumentParser(description="Real Trading System for SMART MEMES BOT")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Check system status")
    
    # Trade command
    trade_parser = subparsers.add_parser("trade", help="Execute a trade")
    trade_parser.add_argument("input_token", help="Input token symbol or address")
    trade_parser.add_argument("output_token", help="Output token symbol or address")
    trade_parser.add_argument("amount", type=float, help="Amount in input token's native units")
    trade_parser.add_argument("--slippage", type=int, default=50, help="Slippage in basis points (default: 50)")
    
    # Transfer command
    transfer_parser = subparsers.add_parser("transfer", help="Transfer SOL to an address")
    transfer_parser.add_argument("to_address", help="Recipient address")
    transfer_parser.add_argument("amount", type=float, help="Amount of SOL to transfer")
    
    args = parser.parse_args()
    
    # Execute the command
    if args.command == "status":
        status = get_trading_status()
        print("\n=== REAL TRADING SYSTEM STATUS ===")
        print(f"System ready: {status['ready']}")
        if not status['ready']:
            print(f"Errors: {', '.join(status['errors'])}")
        if "wallet_address" in status:
            print(f"Wallet: {status['wallet_address']}")
        if "sol_balance" in status:
            print(f"SOL Balance: {status['sol_balance']} SOL (${status['sol_balance_usd']:.2f})")
        if "token_prices" in status:
            print("\nToken Prices:")
            for token, price in status["token_prices"].items():
                print(f"  {token}: ${price:.6f}")
    
    elif args.command == "trade":
        result = execute_real_trade(
            input_token=args.input_token,
            output_token=args.output_token,
            amount=args.amount,
            slippage_bps=args.slippage
        )
        
        print("\n=== TRADE RESULT ===")
        if "error" in result:
            print(f"Error: {result['error']}")
        elif result.get("success"):
            print(f"Success! Transaction: {result['tx_hash']}")
            print(f"Input: {args.amount} {args.input_token}")
            if "output_amount" in result:
                print(f"Output: {result['output_amount']} {args.output_token}")
        else:
            print(f"Trade failed: {result}")
    
    elif args.command == "transfer":
        result = transfer_sol_to_address(
            to_address=args.to_address,
            amount_sol=args.amount
        )
        
        print("\n=== TRANSFER RESULT ===")
        if "error" in result:
            print(f"Error: {result['error']}")
        elif result.get("success"):
            print(f"Success! Transaction: {result['tx_hash']}")
            print(f"Transferred: {args.amount} SOL")
            print(f"To: {args.to_address}")
        else:
            print(f"Transfer failed: {result}")
    
    else:
        # Default action if no command provided
        status = check_system_ready()
        print("\n=== REAL TRADING SYSTEM ===")
        print(f"System ready: {status['ready']}")
        if not status['ready']:
            print(f"Errors: {', '.join(status['errors'])}")
        print("\nAvailable commands:")
        print("  status - Check system status")
        print("  trade <input_token> <output_token> <amount> [--slippage SLIPPAGE] - Execute a trade")
        print("  transfer <to_address> <amount> - Transfer SOL to an address")

if __name__ == "__main__":
    main()