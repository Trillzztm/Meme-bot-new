#!/bin/bash
# Start Watchdog Script - SMART MEMES BOT
# This script starts the watchdog process that monitors the auto trader

echo "==============================================="
echo "SMART MEMES BOT - WATCHDOG STARTER"
echo "==============================================="
echo

# Make scripts executable
chmod +x watchdog.py
chmod +x auto_trader_simple.py

# Check if we have the required private key
if [ -z "$SOLANA_PRIVATE_KEY" ]; then
  echo "⚠️ WARNING: SOLANA_PRIVATE_KEY environment variable not set!"
  echo "The bot will not be able to execute real trades."
  exit 1
fi

# Kill any existing watchdog processes
pkill -f "python watchdog.py" > /dev/null 2>&1
echo "✅ Cleaned up any previous watchdog processes"

# Kill any existing auto trader processes
pkill -f "python auto_trader_simple.py" > /dev/null 2>&1
echo "✅ Cleaned up any previous trading processes"

# Start the watchdog in the background with improved reliability
echo "🚀 Starting Watchdog in background mode..."

# Start with nohup and redirect stdout and stderr to log files
# Using disown to prevent the process from being killed when the terminal closes
nohup python watchdog.py > watchdog.out 2> watchdog.err < /dev/null &
WATCHDOG_PID=$!

# Detach process from terminal
disown -h $WATCHDOG_PID

echo "✅ Watchdog started with PID: $WATCHDOG_PID"

# Create a PID file to track it
echo $WATCHDOG_PID > watchdog.pid
echo "✅ PID saved to watchdog.pid"

# Ensure the process is actually running
sleep 2
if ps -p $WATCHDOG_PID > /dev/null; then
    echo "✅ Verified that Watchdog is running properly"
else
    echo "⚠️ Warning: Watchdog may have stopped immediately after starting"
    echo "Check watchdog.err for error messages"
fi

echo
echo "💰 Your money is now being made automatically with enhanced reliability!"
echo
echo "💡 Monitor progress with:"
echo "   tail -f watchdog.log           (see watchdog logs)"
echo "   tail -f auto_trader_simple.log (see trading logs)"
echo "   cat auto_trader_profits.json   (see profits)"
echo
echo "📱 You will receive Telegram notifications for:"
echo "   - Each trade"
echo "   - Bot restarts (if they occur)"
echo "   - Any critical issues"
echo
echo "⚠️ To stop everything run: ./stop_watchdog.sh"
echo
echo "==============================================="