#!/bin/bash
# Stop Real Money Trading Script - SMART MEMES BOT
# This script stops the real money trader

echo "==============================================="
echo "SMART MEMES BOT - STOP REAL MONEY TRADER"
echo "==============================================="
echo

# Kill any existing real money trader processes
pkill -f "python real_money_trader.py" > /dev/null 2>&1
echo "✅ Stopped Real Money Trader processes"

# Clean up PID files
if [ -f "real_trader.pid" ]; then
  rm real_trader.pid
  echo "✅ Removed Real Money Trader PID file"
fi

echo
echo "💰 Real Money Trading has been stopped. Your profits are safe!"
echo "Check real_profits.json to see your total real profits."
echo

# Display current profits
if [ -f "real_profits.json" ]; then
  TOTAL_PROFIT=$(grep "total_profit_usd" real_profits.json | cut -d':' -f2 | cut -d',' -f1)
  echo "💵 Current total profit: $TOTAL_PROFIT"
  echo
fi

echo "To start trading again with insider wallet tracking, run: ./start_real_trading.sh"
echo
echo "==============================================="