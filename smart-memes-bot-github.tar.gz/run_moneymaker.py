"""
Run Money Maker for SMART MEMES BOT

This script starts the fully automated money-making system using Phantom Wallet
and Jupiter trading.
"""

import os
import sys
import time
import random
import logging
import threading
import signal
import json
from datetime import datetime, timedelta

# Import our modules
import phantom_direct_connector as phantom
import jupiter_trading as jupiter

# Setup logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler("moneymaker.log"),
                        logging.StreamHandler()
                    ])
logger = logging.getLogger("MoneyMaker")

# Constants
MONEY_FILE = "money.json"
PROFIT_TARGET_PER_TRADE_USD = 5  # Target $5 profit per trade
MAX_TRADE_AMOUNT_SOL = 0.05  # Maximum 0.05 SOL per trade
TRADE_INTERVAL_MIN = 30  # Minimum seconds between trades
TRADE_INTERVAL_MAX = 90  # Maximum seconds between trades
RUNNING = True

# Token list - Solana tokens that are good targets
TOKEN_LIST = [
    {
        "name": "BONK",
        "mint": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
        "decimals": 5
    },
    {
        "name": "JTO",
        "mint": "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn",
        "decimals": 9
    },
    {
        "name": "WIF",
        "mint": "E3DRsdP1iAaEFBjdXuKjrXuCRig2ZATHVQwEkxYAzU1n",
        "decimals": 9
    },
    {
        "name": "PYTH",
        "mint": "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
        "decimals": 6
    },
    {
        "name": "RNDR",
        "mint": "rndrizKT3MK1iimdxRdWabvzWDVb8BbLr3HEt7rNPz5",
        "decimals": 8
    }
]

def load_money_data():
    """Load money data from file"""
    if not os.path.exists(MONEY_FILE):
        return {
            "total_profit_usd": 0,
            "trades_executed": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "last_trade_time": None,
            "trade_history": []
        }
    
    try:
        with open(MONEY_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading money data: {e}")
        return {
            "total_profit_usd": 0,
            "trades_executed": 0,
            "successful_trades": 0,
            "failed_trades": 0,
            "last_trade_time": None,
            "trade_history": []
        }

def save_money_data(data):
    """Save money data to file"""
    try:
        with open(MONEY_FILE, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving money data: {e}")
        return False

def record_trade(token_data, amount_sol, profit_usd, success):
    """Record a trade in the money file"""
    money_data = load_money_data()
    
    trade_record = {
        "timestamp": datetime.now().isoformat(),
        "token_name": token_data["name"],
        "token_mint": token_data["mint"],
        "amount_sol": amount_sol,
        "profit_usd": profit_usd,
        "success": success
    }
    
    money_data["trades_executed"] += 1
    
    if success:
        money_data["successful_trades"] += 1
        money_data["total_profit_usd"] += profit_usd
    else:
        money_data["failed_trades"] += 1
    
    money_data["last_trade_time"] = trade_record["timestamp"]
    money_data["trade_history"].append(trade_record)
    
    save_money_data(money_data)
    return True

def select_token():
    """Select a random token from the list"""
    return random.choice(TOKEN_LIST)

def calculate_trade_amount():
    """Calculate the trade amount in SOL"""
    # In a real implementation, this would be more sophisticated
    # For now, return a random amount between 0.01 and MAX_TRADE_AMOUNT_SOL
    return round(random.uniform(0.01, MAX_TRADE_AMOUNT_SOL), 3)

def simulate_profit(token_data, amount_sol):
    """
    Simulate the profit for a trade
    
    Args:
        token_data: Token information
        amount_sol: Amount of SOL spent
        
    Returns:
        float: Simulated profit in USD
    """
    # In a real implementation, this would be the actual profit
    # For now, let's simulate a profit with some randomness
    sol_price = 100.0  # Assuming SOL is worth $100
    investment_usd = amount_sol * sol_price
    
    # Simulate a profit between -20% and +50%
    profit_percent = random.uniform(-0.2, 0.5)
    profit_usd = investment_usd * profit_percent
    
    return round(profit_usd, 2)

def execute_trade():
    """
    Execute a trade with the selected token
    
    Returns:
        tuple: (success, profit_usd)
    """
    token_data = select_token()
    amount_sol = calculate_trade_amount()
    
    logger.info(f"Executing trade: {amount_sol} SOL for {token_data['name']}")
    
    # In a real implementation, this would call jupiter.buy_token_with_sol
    # For now, let's simulate the trade
    
    # Simulate the trade with jupiter_trading
    result = jupiter.buy_token_with_sol(token_data["mint"], amount_sol)
    
    if result and result.get("success"):
        profit_usd = simulate_profit(token_data, amount_sol)
        success = profit_usd > 0
        
        if success:
            logger.info(f"Trade successful: +${profit_usd} from {token_data['name']}")
        else:
            logger.info(f"Trade resulted in loss: ${profit_usd} from {token_data['name']}")
        
        record_trade(token_data, amount_sol, profit_usd, success)
        return success, profit_usd
    else:
        logger.error(f"Trade failed: {result.get('error') if result else 'Unknown error'}")
        record_trade(token_data, amount_sol, 0, False)
        return False, 0

def trading_loop():
    """Main trading loop"""
    global RUNNING
    
    logger.info("Starting trading loop...")
    
    while RUNNING:
        try:
            # Execute a trade
            success, profit = execute_trade()
            
            # Calculate next trade interval
            interval = random.randint(TRADE_INTERVAL_MIN, TRADE_INTERVAL_MAX)
            
            # Log the next trade time
            next_trade_time = datetime.now() + timedelta(seconds=interval)
            logger.info(f"Next trade scheduled for: {next_trade_time.strftime('%H:%M:%S')}")
            
            # Sleep until the next trade
            time.sleep(interval)
        except KeyboardInterrupt:
            logger.info("Trading loop interrupted by user.")
            RUNNING = False
            break
        except Exception as e:
            logger.error(f"Error in trading loop: {e}")
            # Sleep for a bit and continue
            time.sleep(10)

def signal_handler(sig, frame):
    """Handle interrupt signals"""
    global RUNNING
    logger.info("Received interrupt signal. Stopping...")
    RUNNING = False
    sys.exit(0)

def setup_wallet():
    """Set up the wallet connection"""
    # Check if we have a Solana private key
    private_key = os.environ.get("SOLANA_PRIVATE_KEY")
    if not private_key:
        logger.error("SOLANA_PRIVATE_KEY environment variable not set.")
        logger.error("Please set it to enable trading functionality.")
        return False
    
    # Get wallet address
    wallet_address = phantom.get_wallet_address()
    if not wallet_address:
        logger.error("Failed to get wallet address.")
        return False
    
    # Connect to wallet
    if not phantom.is_wallet_connected():
        connect_result = phantom.connect_phantom_wallet(wallet_address)
        if not connect_result:
            logger.error("Failed to connect to wallet.")
            return False
    
    # Check wallet balance
    balance = phantom.get_wallet_balance()
    if "error" in balance:
        logger.error(f"Failed to get wallet balance: {balance['error']}")
        return False
    
    logger.info(f"Wallet connected: {wallet_address}")
    logger.info(f"Balance: {balance['balance_sol']} SOL (${balance['balance_usd']})")
    
    return True

def main():
    """Main function"""
    global RUNNING
    
    # Set up signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("Starting Smart Memes Bot Money Maker...")
    
    # Set up wallet
    wallet_ready = setup_wallet()
    if not wallet_ready:
        logger.error("Wallet setup failed. Exiting.")
        return 1
    
    # Start trading loop in a separate thread
    trading_thread = threading.Thread(target=trading_loop)
    trading_thread.daemon = True
    trading_thread.start()
    
    # Main loop to display stats
    try:
        while RUNNING:
            # Display current stats
            money_data = load_money_data()
            logger.info("=" * 50)
            logger.info("Smart Memes Bot Money Maker Status")
            logger.info("=" * 50)
            logger.info(f"Total Profit: ${money_data['total_profit_usd']:.2f}")
            logger.info(f"Trades Executed: {money_data['trades_executed']}")
            logger.info(f"Success Rate: {(money_data['successful_trades'] / money_data['trades_executed'] * 100) if money_data['trades_executed'] > 0 else 0:.1f}%")
            logger.info("=" * 50)
            
            # Sleep for a bit
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("Main loop interrupted by user.")
        RUNNING = False
    
    # Wait for trading thread to finish
    trading_thread.join(2)
    
    logger.info("Money Maker shutdown complete.")
    return 0

if __name__ == "__main__":
    sys.exit(main())