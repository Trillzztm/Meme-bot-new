#!/usr/bin/env python3
"""
Run script for SMART MEMES BOT Money Dashboard

This script launches the Money Dashboard, which displays real-time profit statistics,
trade history, and wallet balances.
"""

import os
import sys
import logging
from money_dashboard import app

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("DashboardRunner")

def run_dashboard():
    """Run the Money Dashboard Flask app"""
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # Make sure templates are available
    if not os.path.exists('templates/money_dashboard.html'):
        logger.info("Initial setup: Creating template files")
        from money_dashboard import app as template_creator
    
    # Run the Flask app with Gunicorn in the Replit environment
    port = 5000
    logger.info(f"Starting Money Dashboard on port {port}")
    logger.info(f"Access at: https://{os.environ.get('REPLIT_DEPLOYMENT', '').split(',')[0]}")
    logger.info(f"Login with password: smartmemes2025")
    
    app.run(host='0.0.0.0', port=port, debug=False)

if __name__ == "__main__":
    run_dashboard()