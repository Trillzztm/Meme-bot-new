"""
Database Initialization Module for SMART MEMES BOT.

This module handles database connection and initialization for the bot.
It provides the SQLAlchemy database object and functions for initialization.
"""

import os
import time
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from flask_sqlalchemy import SQLAlchemy

# Configure logging
logger = logging.getLogger(__name__)

# Create SQLAlchemy database object
db = SQLAlchemy()

def get_database_url():
    """
    Get the database URL from environment variables.
    
    Returns:
        Database URL string
    """
    # Get PostgreSQL connection details from environment variables
    database_url = os.environ.get("DATABASE_URL")
    
    if not database_url:
        # Construct URL from individual components if available
        pg_user = os.environ.get("PGUSER")
        pg_password = os.environ.get("PGPASSWORD")
        pg_host = os.environ.get("PGHOST")
        pg_port = os.environ.get("PGPORT")
        pg_database = os.environ.get("PGDATABASE")
        
        if all([pg_user, pg_password, pg_host, pg_port, pg_database]):
            database_url = f"postgresql://{pg_user}:{pg_password}@{pg_host}:{pg_port}/{pg_database}"
        else:
            # Default to SQLite for development if PostgreSQL not available
            logger.warning("PostgreSQL environment variables not found, using SQLite")
            database_url = "sqlite:///crypto_bot.db"
    
    return database_url

def init_app(app):
    """
    Initialize the database with the Flask app.
    
    Args:
        app: Flask application instance
    """
    database_url = get_database_url()
    
    # Configure database
    app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Initialize
    db.init_app(app)
    
    # Create tables
    with app.app_context():
        init_db()

def init_db():
    """Initialize the database with tables and default data."""
    try:
        # Import models here to avoid circular imports
        import models
        
        # Create tables
        db.create_all()
        
        # Create default admin and settings
        try:
            models.create_default_admin()
        except Exception as e:
            logger.error(f"Error creating default admin: {e}")
        
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise

def update_bot_stats():
    """Update bot statistics in the database."""
    try:
        # Import models here to avoid circular imports
        from models import SystemStats
        
        # Get or create stats record
        stats = SystemStats.query.first()
        if not stats:
            stats = SystemStats()
            db.session.add(stats)
        
        # Update last updated timestamp
        stats.last_updated = time.time()
        
        # In a real implementation, we would gather actual statistics here
        # For now, just update the timestamp
        
        db.session.commit()
        logger.info("Bot stats updated")
        return True
    except Exception as e:
        logger.error(f"Error updating bot stats: {e}")
        db.session.rollback()
        return False

def get_bot_settings(category=None):
    """
    Get bot settings from database.
    
    Args:
        category: Optional category filter
        
    Returns:
        Dictionary of settings
    """
    try:
        # Import models here to avoid circular imports
        from models import BotSettings
        
        settings = {}
        query = BotSettings.query
        
        if category:
            query = query.filter_by(category=category)
        
        for setting in query.all():
            settings[setting.name] = setting.value
        
        return settings
    except Exception as e:
        logger.error(f"Error getting bot settings: {e}")
        return {}

def update_bot_setting(name, value, category=None, description=None, user_id=1):
    """
    Update a bot setting in the database.
    
    Args:
        name: Setting name
        value: Setting value
        category: Optional setting category
        description: Optional setting description
        user_id: User ID
        
    Returns:
        Success status
    """
    try:
        # Import models here to avoid circular imports
        from models import BotSettings
        
        # Get or create setting
        setting = BotSettings.query.filter_by(name=name).first()
        if not setting:
            setting = BotSettings(
                name=name,
                user_id=user_id
            )
            db.session.add(setting)
        
        # Update setting
        setting.value = str(value)
        if category:
            setting.category = category
        if description:
            setting.description = description
        
        db.session.commit()
        logger.info(f"Updated bot setting: {name} = {value}")
        return True
    except Exception as e:
        logger.error(f"Error updating bot setting: {e}")
        db.session.rollback()
        return False

# Test database connection
def test_database_connection():
    """
    Test the database connection.
    
    Returns:
        True if connection successful, False otherwise
    """
    try:
        # Create a small engine just for testing
        database_url = get_database_url()
        engine = create_engine(database_url)
        connection = engine.connect()
        connection.close()
        logger.info("Database connection test successful")
        return True
    except Exception as e:
        logger.error(f"Database connection test failed: {e}")
        return False

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Test database connection
    result = test_database_connection()
    print(f"Database connection test: {'Passed' if result else 'Failed'}")