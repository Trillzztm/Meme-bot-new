"""
Jupiter Direct Trading Module for SMART MEMES BOT

This module provides direct trading functionality with Jupiter on Solana.
It handles transaction signing, execution, and verification for real trades.
"""

import os
import json
import time
import base64
import logging
import requests
from typing import Dict, Any, Optional, List, Union
from datetime import datetime

# Import local modules for transaction signing
import transaction_signer as tx_signer

# Import Solana transaction libraries
from solana.rpc.api import Client
from solana.transaction import Transaction

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("JupiterDirectTrades")

# Constants
JUPITER_API_BASE = "https://quote-api.jup.ag/v6"
JUPITER_QUOTE_API = f"{JUPITER_API_BASE}/quote"
JUPITER_SWAP_API = f"{JUPITER_API_BASE}/swap"

# Common token addresses
SOL_MINT = "So11111111111111111111111111111111111111112"
USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
BONK_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
WIF_MINT = "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
JTO_MINT = "7Q2afV64in6N6SeZsAAB81TJzwDoD6zpqmHkzi9Dcavn"

# Transaction history file
TRANSACTION_HISTORY_FILE = "jupiter_real_trades.json"

def get_quote(
    input_mint: str,
    output_mint: str,
    amount: int,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Get a quote from Jupiter API
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Quote response or error
    """
    try:
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": str(amount),
            "slippageBps": slippage_bps,
            "onlyDirectRoutes": False,
            "asLegacyTransaction": False  # Use versioned transactions for better efficiency
        }
        
        logger.info(f"Getting Jupiter quote for {amount} of {input_mint} to {output_mint}")
        response = requests.get(JUPITER_QUOTE_API, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            # Log quote details
            input_amount = int(data.get("inputAmount", "0"))
            output_amount = int(data.get("outputAmount", "0"))
            impact = data.get("priceImpactPct", 0)
            
            logger.info(f"Quote: {input_amount} → {output_amount} (Impact: {impact:.2f}%)")
            
            return data
        else:
            error_msg = f"Error getting quote: {response.status_code} - {response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error in get_quote: {e}")
        return {"error": str(e)}

def get_swap_transaction(
    quote_response: Dict[str, Any],
    user_public_key: str
) -> Dict[str, Any]:
    """
    Get swap transaction from Jupiter API
    
    Args:
        quote_response: Quote response from get_quote
        user_public_key: User's public key
        
    Returns:
        dict: Swap transaction or error
    """
    try:
        # Check if we have an error from the quote
        if "error" in quote_response:
            return quote_response
        
        # Prepare swap request
        swap_request = {
            "quoteResponse": quote_response,
            "userPublicKey": user_public_key,
            "wrapAndUnwrapSol": True,  # Auto wrap/unwrap SOL
            "dynamicComputeUnitLimit": True  # Optimize compute units
        }
        
        logger.info(f"Getting swap transaction for {user_public_key}")
        response = requests.post(JUPITER_SWAP_API, json=swap_request)
        
        if response.status_code == 200:
            data = response.json()
            
            # Extract transaction data
            tx_data = data.get("swapTransaction")
            if not tx_data:
                return {"error": "No transaction in response"}
            
            # Add input/output information to result
            data["inputMint"] = quote_response.get("inputMint")
            data["outputMint"] = quote_response.get("outputMint")
            data["inputAmount"] = quote_response.get("inputAmount")
            data["outputAmount"] = quote_response.get("outputAmount")
            
            logger.info("Got swap transaction successfully")
            return data
        else:
            error_msg = f"Error getting swap transaction: {response.status_code} - {response.text}"
            logger.error(error_msg)
            return {"error": error_msg}
    except Exception as e:
        logger.error(f"Error in get_swap_transaction: {e}")
        return {"error": str(e)}

def execute_swap_transaction(swap_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute a swap transaction
    
    Args:
        swap_data: Swap data from get_swap_transaction
        
    Returns:
        dict: Transaction result or error
    """
    try:
        # Check if we have an error from previous steps
        if "error" in swap_data:
            return swap_data
        
        # Extract transaction data
        encoded_tx = swap_data.get("swapTransaction")
        if not encoded_tx:
            return {"error": "No transaction data found"}
        
        # Decode the transaction
        tx_bytes = base64.b64decode(encoded_tx)
        
        # Sign and send the transaction
        logger.info("Signing and sending transaction...")
        result = tx_signer.sign_and_send_transaction(tx_bytes)
        
        # Record the trade
        if "success" in result and result["success"]:
            tx_hash = result["tx_hash"]
            
            # Add trade details to result
            result["inputMint"] = swap_data.get("inputMint")
            result["outputMint"] = swap_data.get("outputMint")
            result["inputAmount"] = swap_data.get("inputAmount")
            result["outputAmount"] = swap_data.get("outputAmount")
            
            # Save the trade to history
            save_trade_to_history(
                tx_hash=tx_hash,
                input_mint=swap_data.get("inputMint"),
                output_mint=swap_data.get("outputMint"),
                input_amount=swap_data.get("inputAmount"),
                output_amount=swap_data.get("outputAmount"),
                status="sent"
            )
            
            # Log success
            logger.info(f"Transaction sent: {tx_hash}")
        else:
            logger.error(f"Failed to send transaction: {result.get('error', 'Unknown error')}")
        
        return result
    except Exception as e:
        logger.error(f"Error in execute_swap_transaction: {e}")
        return {"error": str(e)}

def swap_token(
    input_mint: str,
    output_mint: str,
    amount: int,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    High-level function to swap tokens using Jupiter
    
    Args:
        input_mint: Input token mint address
        output_mint: Output token mint address
        amount: Amount in input token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Swap result or error
    """
    # Validate that we have a wallet
    wallet_address = tx_signer.get_public_key()
    if not wallet_address:
        return {"error": "No wallet available. Check your private key."}
    
    # Step 1: Get a quote
    quote = get_quote(input_mint, output_mint, amount, slippage_bps)
    if "error" in quote:
        return quote
    
    # Step 2: Get a swap transaction
    swap_tx = get_swap_transaction(quote, wallet_address)
    if "error" in swap_tx:
        return swap_tx
    
    # Step 3: Execute the swap
    result = execute_swap_transaction(swap_tx)
    
    return result

def buy_token_with_sol(
    token_mint: str,
    sol_amount: float,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Buy a token using SOL
    
    Args:
        token_mint: Token mint address to buy
        sol_amount: Amount of SOL to spend (in SOL, not lamports)
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Transaction result or error
    """
    # Convert SOL to lamports
    lamports = int(sol_amount * 10**9)
    
    return swap_token(
        input_mint=SOL_MINT,
        output_mint=token_mint,
        amount=lamports,
        slippage_bps=slippage_bps
    )

def sell_token_for_sol(
    token_mint: str,
    token_amount: int,
    slippage_bps: int = 50
) -> Dict[str, Any]:
    """
    Sell a token for SOL
    
    Args:
        token_mint: Token mint address to sell
        token_amount: Amount to sell in token's smallest units
        slippage_bps: Slippage in basis points (1 bps = 0.01%)
        
    Returns:
        dict: Transaction result or error
    """
    return swap_token(
        input_mint=token_mint,
        output_mint=SOL_MINT,
        amount=token_amount,
        slippage_bps=slippage_bps
    )

def save_trade_to_history(
    tx_hash: str,
    input_mint: str,
    output_mint: str,
    input_amount: Union[int, str],
    output_amount: Union[int, str],
    status: str = "sent"
) -> None:
    """
    Save trade to history file
    
    Args:
        tx_hash: Transaction hash
        input_mint: Input token mint address
        output_mint: Output token mint address
        input_amount: Input amount (in smallest units)
        output_amount: Output amount (in smallest units)
        status: Transaction status (sent, confirmed, failed)
    """
    try:
        # Convert amounts to integers
        if isinstance(input_amount, str):
            input_amount = int(input_amount)
        if isinstance(output_amount, str):
            output_amount = int(output_amount)
        
        # Load existing trade history
        history = load_trade_history()
        
        # Create trade record
        trade = {
            "timestamp": datetime.now().isoformat(),
            "tx_hash": tx_hash,
            "input_mint": input_mint,
            "output_mint": output_mint,
            "input_amount": input_amount,
            "output_amount": output_amount,
            "status": status,
            "real_trade": True
        }
        
        # Add to history
        history.append(trade)
        
        # Save updated history
        with open(TRANSACTION_HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
            
        logger.info(f"Saved trade to history: {tx_hash}")
    except Exception as e:
        logger.error(f"Error saving trade to history: {e}")

def load_trade_history() -> List[Dict[str, Any]]:
    """
    Load trade history from file
    
    Returns:
        list: Trade history
    """
    if not os.path.exists(TRANSACTION_HISTORY_FILE):
        return []
    
    try:
        with open(TRANSACTION_HISTORY_FILE, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading trade history: {e}")
        return []

def update_trade_status(tx_hash: str, status: str) -> bool:
    """
    Update trade status in history
    
    Args:
        tx_hash: Transaction hash
        status: New status (confirmed, failed)
        
    Returns:
        bool: Success flag
    """
    try:
        history = load_trade_history()
        
        # Find and update the trade
        for trade in history:
            if trade.get("tx_hash") == tx_hash:
                trade["status"] = status
                
                # Save updated history
                with open(TRANSACTION_HISTORY_FILE, "w") as f:
                    json.dump(history, f, indent=2)
                
                logger.info(f"Updated trade status: {tx_hash} -> {status}")
                return True
        
        logger.warning(f"Trade not found in history: {tx_hash}")
        return False
    except Exception as e:
        logger.error(f"Error updating trade status: {e}")
        return False

def check_pending_trades() -> None:
    """
    Check status of pending trades and update
    """
    try:
        history = load_trade_history()
        client = Client(tx_signer.SOLANA_RPC_URL)
        
        # Find pending trades
        pending_trades = [t for t in history if t.get("status") == "sent"]
        
        if pending_trades:
            logger.info(f"Checking {len(pending_trades)} pending trades...")
            
            for trade in pending_trades:
                tx_hash = trade.get("tx_hash")
                if not tx_hash:
                    continue
                
                # Check transaction status
                try:
                    response = client.get_transaction(tx_hash)
                    
                    if response and "result" in response and response["result"]:
                        # Transaction found, check if it succeeded
                        if response["result"]["meta"]["status"] == {"Ok": None}:
                            update_trade_status(tx_hash, "confirmed")
                        else:
                            update_trade_status(tx_hash, "failed")
                    else:
                        # Transaction not found yet, might still be pending
                        pass
                except Exception as e:
                    logger.warning(f"Error checking transaction {tx_hash}: {e}")
    except Exception as e:
        logger.error(f"Error checking pending trades: {e}")

def get_trade_stats() -> Dict[str, Any]:
    """
    Get trading statistics
    
    Returns:
        dict: Trading statistics
    """
    try:
        history = load_trade_history()
        
        # Initialize stats
        stats = {
            "total_trades": len(history),
            "confirmed_trades": 0,
            "pending_trades": 0,
            "failed_trades": 0,
            "total_sol_spent": 0,
            "total_sol_received": 0,
            "tokens_bought": {},
            "tokens_sold": {}
        }
        
        # Calculate stats
        for trade in history:
            status = trade.get("status", "unknown")
            
            if status == "confirmed":
                stats["confirmed_trades"] += 1
            elif status == "sent":
                stats["pending_trades"] += 1
            elif status == "failed":
                stats["failed_trades"] += 1
            
            # Calculate SOL spent/received
            input_mint = trade.get("input_mint")
            output_mint = trade.get("output_mint")
            
            if status == "confirmed":
                if input_mint == SOL_MINT:
                    # Buying token with SOL
                    input_amount = trade.get("input_amount", 0)
                    sol_spent = input_amount / 10**9
                    stats["total_sol_spent"] += sol_spent
                    
                    # Track tokens bought
                    token = output_mint
                    if token not in stats["tokens_bought"]:
                        stats["tokens_bought"][token] = 0
                    stats["tokens_bought"][token] += 1
                
                elif output_mint == SOL_MINT:
                    # Selling token for SOL
                    output_amount = trade.get("output_amount", 0)
                    sol_received = output_amount / 10**9
                    stats["total_sol_received"] += sol_received
                    
                    # Track tokens sold
                    token = input_mint
                    if token not in stats["tokens_sold"]:
                        stats["tokens_sold"][token] = 0
                    stats["tokens_sold"][token] += 1
        
        # Calculate net SOL profit/loss
        stats["net_sol"] = stats["total_sol_received"] - stats["total_sol_spent"]
        
        return stats
    except Exception as e:
        logger.error(f"Error getting trade stats: {e}")
        return {"error": str(e)}

def test_jupiter_api() -> Dict[str, Any]:
    """
    Test Jupiter API connectivity
    
    Returns:
        dict: Test results
    """
    try:
        logger.info("Testing Jupiter API...")
        
        # Get a simple quote as a test
        test_amount = 100000000  # 0.1 SOL
        quote = get_quote(SOL_MINT, USDC_MINT, test_amount)
        
        if "error" in quote:
            return {
                "success": False,
                "message": quote["error"]
            }
        else:
            return {
                "success": True,
                "message": "Successfully connected to Jupiter API",
                "details": {
                    "inputMint": quote.get("inputMint"),
                    "outputMint": quote.get("outputMint"),
                    "inputAmount": quote.get("inputAmount"),
                    "outputAmount": quote.get("outputAmount"),
                    "priceImpactPct": quote.get("priceImpactPct")
                }
            }
    except Exception as e:
        logger.error(f"Error testing Jupiter API: {e}")
        return {
            "success": False,
            "message": f"Error: {str(e)}"
        }

def test_full_integration() -> Dict[str, Any]:
    """
    Test full integration with Jupiter and transaction signing
    
    Returns:
        dict: Test results
    """
    results = {}
    
    # Step 1: Check private key
    wallet_address = tx_signer.get_public_key()
    results["wallet_available"] = wallet_address is not None
    
    if not results["wallet_available"]:
        results["message"] = "No wallet available. Check your private key."
        return results
    
    results["wallet_address"] = wallet_address
    
    # Step 2: Test Jupiter API
    api_test = test_jupiter_api()
    results["jupiter_api"] = api_test
    
    if not api_test["success"]:
        results["message"] = f"Jupiter API test failed: {api_test['message']}"
        return results
    
    # Step 3: Test getting a swap transaction (without sending)
    try:
        logger.info("Testing swap transaction generation...")
        
        # Get a quote
        test_amount = 10000000  # 0.01 SOL (small amount for testing)
        quote = get_quote(SOL_MINT, USDC_MINT, test_amount)
        
        if "error" in quote:
            results["swap_transaction"] = {
                "success": False,
                "message": quote["error"]
            }
            results["message"] = f"Failed to get quote: {quote['error']}"
            return results
        
        # Get a swap transaction
        swap_tx = get_swap_transaction(quote, wallet_address)
        
        if "error" in swap_tx:
            results["swap_transaction"] = {
                "success": False,
                "message": swap_tx["error"]
            }
            results["message"] = f"Failed to get swap transaction: {swap_tx['error']}"
            return results
        
        results["swap_transaction"] = {
            "success": True,
            "message": "Successfully generated swap transaction"
        }
        
        # DO NOT execute the transaction in a test
        
        results["message"] = "All integration tests passed successfully"
        results["success"] = True
        return results
    except Exception as e:
        logger.error(f"Error in test_full_integration: {e}")
        results["message"] = f"Error: {str(e)}"
        results["success"] = False
        return results

if __name__ == "__main__":
    # Test the integration when run directly
    print("\n=== Testing Jupiter Direct Trading ===\n")
    
    results = test_full_integration()
    
    print(f"Test results: {'Success' if results.get('success') else 'Failed'}")
    print(f"Message: {results.get('message')}")
    
    if results.get("wallet_available"):
        print(f"\nWallet: {results.get('wallet_address')}")
    
    # Show trade statistics if available
    try:
        stats = get_trade_stats()
        if "error" not in stats:
            print(f"\nTrade stats:")
            print(f"Total trades: {stats['total_trades']}")
            print(f"Confirmed: {stats['confirmed_trades']}, Pending: {stats['pending_trades']}, Failed: {stats['failed_trades']}")
            print(f"Total SOL spent: {stats['total_sol_spent']:.4f}")
            print(f"Total SOL received: {stats['total_sol_received']:.4f}")
            print(f"Net SOL profit/loss: {stats['net_sol']:.4f}")
    except Exception as e:
        print(f"Error getting trade stats: {e}")