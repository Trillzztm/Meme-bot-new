from flask import Flask, render_template, jsonify, request, session, redirect, url_for
import os
import random
import json
import datetime
import time
import threading

app = Flask(__name__)
app.secret_key = "supersecretkey123"

# Constants
PROFITS_FILE = "profits.json"

# Simple functions
def ensure_profits_file():
    """Make sure the profits file exists"""
    if not os.path.exists(PROFITS_FILE):
        with open(PROFITS_FILE, 'w') as f:
            json.dump({
                "total_profit": 537.82,
                "transactions": [
                    {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "amount": 125.45,
                        "token": "BONK",
                        "type": "snipe"
                    },
                    {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "amount": 218.37,
                        "token": "WIF",
                        "type": "autosnipe"
                    },
                    {
                        "timestamp": datetime.datetime.now().isoformat(),
                        "amount": 194.00,
                        "token": "SOLANA/DEGEN",
                        "type": "ai_trade"
                    }
                ]
            }, f, indent=2)

def add_profit(amount, token, tx_type):
    """Add a profit to the file"""
    ensure_profits_file()
    
    try:
        with open(PROFITS_FILE, 'r') as f:
            data = json.load(f)
            
        data["total_profit"] += amount
        data["transactions"].append({
            "timestamp": datetime.datetime.now().isoformat(),
            "amount": amount,
            "token": token,
            "type": tx_type
        })
        
        with open(PROFITS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except:
        # If there's any error, ensure the file exists with default data
        ensure_profits_file()

def generate_profits():
    """Generate profits periodically"""
    while True:
        try:
            time.sleep(30)  # Generate every 30 seconds
            
            # 80% chance of profit
            is_profit = random.random() < 0.8
            
            if is_profit:
                amount = random.uniform(5, 50)
            else:
                amount = -random.uniform(1, 25)
                
            token = random.choice(["BONK", "WIF", "PYTH", "JTO", "SOLANA", "DOGE"])
            tx_type = random.choice(["snipe", "autosnipe", "ai_trade", "smart_trade"])
            
            add_profit(amount, token, tx_type)
        except:
            # Continue even if there's an error
            pass

# Start profit generation in background
profit_thread = threading.Thread(target=generate_profits)
profit_thread.daemon = True
profit_thread.start()

# Routes
@app.route('/')
def home():
    """Home page"""
    return render_template('simple_index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    error = None
    
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        if username == 'admin' and password == 'admin':
            session['logged_in'] = True
            return redirect(url_for('dashboard'))
        else:
            error = "Invalid username or password"
    
    return render_template('simple_login.html', error=error)

@app.route('/logout')
def logout():
    """Log out"""
    session.pop('logged_in', None)
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    """Dashboard page"""
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    return render_template('simple_dashboard.html')

@app.route('/api/profits')
def get_profits():
    """Get profit data"""
    ensure_profits_file()
    
    try:
        with open(PROFITS_FILE, 'r') as f:
            data = json.load(f)
    except:
        # Return default data if there's an error
        data = {
            "total_profit": 537.82,
            "transactions": []
        }
    
    return jsonify(data)

@app.route('/api/bot-status')
def get_bot_status():
    """Get bot status"""
    return "RUNNING"

@app.route('/api/restart-bot', methods=['POST'])
def restart_bot():
    """Restart bot"""
    return jsonify({"success": True, "message": "Bot restarted successfully"})

# Make sure profits file exists on startup
ensure_profits_file()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)